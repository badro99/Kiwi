/* Kiwi · restaurant menu workspace. Preview layout, production data only. */
(function () {
  'use strict';
  let tab=(()=>{try{return sessionStorage.getItem('kiwiMenuTab')||'menu';}catch(_){return 'menu';}})(), filter='all', subFilter=null, query='', hoursPeriod=null, openItemMenu=null, nutriFilter='all'; // subFilter : sous-catégorie active ('__none' = non classés)
  const $=(s,r=document)=>r.querySelector(s), $$=(s,r=document)=>[...r.querySelectorAll(s)];
  const esc=(s)=>String(s==null?'':s).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
  // 16 → "16 MAD", 14.5 → "14,50 MAD" (never "14,5"), as on the till.
  const cash=(n)=>{const v=+n||0,o={minimumFractionDigits:Number.isInteger(v)?0:2,maximumFractionDigits:2};return (window.KiwiNumber?.format(v,o) ?? new Intl.NumberFormat(document.documentElement?.lang==='en'?'en-GB':'fr-FR',o).format(v))+' MAD';};
  const venue=()=>window.KiwiVenue?.getCurrentVenueData?.()?.id||window.KiwiVenue?.getVenue?.()||null;
  const isRestaurant=()=>{const KV=window.KiwiVenue,v=KV?.getCurrentVenueData?.()||{},t=String(KV?.getVenueType?.()||v.type||v.subtype||'').toLowerCase();return ['restaurant','cafe','café','restauration'].includes(t);};
  const S=()=>window.KiwiMenuStore;
  // An older or example document can miss a list; the page must still open.
  const D=()=>{const d=S()?.data(venue())||{};for(const k of ['cats','items','stations','opts'])if(!Array.isArray(d[k]))d[k]=[];return d;};
  const find=(key,id)=>(D()[key]||[]).find(x=>x.id===id);
  const cat=(id)=>find('cats',id), item=(id)=>find('items',id), station=(id)=>find('stations',id), group=(id)=>find('opts',id);
  const UI_I18N = {
    en: {
      title: 'Menu & modifiers',
      loading: 'Loading menu…',
      home: 'Home',
      articles: 'items',
      article: 'item',
      sections: 'sections',
      section: 'section',
      tabMenu: 'Menu & modifiers',
      tabStations: 'Kitchen stations',
      tabRecipes: 'Recipes',
      tabPerformance: 'Performance',
      tabHours: 'Peak hours',
      tabAlerts: '86 Alerts',
      tabNfc: 'NFC Tags',
      tabCaisse: 'Till settings',
      tabPromos: 'Promotions',
      caisseTitle: 'Till settings',
      caisseSub: 'Delivery, quote terms or cake sizes: what the menu does not say, read by your till.',
      scanMenu: 'Scan a menu',
      importExcel: 'Import Excel',
      translateMenu: 'Translations',
      tabI18n: 'Translations',
      i18nTitle: 'The menu in everyone’s language',
      i18nReview: 'Review every language before sharing the menu, especially allergens and ingredients. Automatic translations are suggestions. Edit a cell to confirm your wording, and review it again after changing the original.',
      i18nHint: 'Kiwi AI translates only new or changed entries in the languages selected for this menu; the original text is never modified. Edit a cell to correct it: a correction is never overwritten.',
      i18nFill: 'Translate what’s missing',
      i18nRedo: 'Retranslate everything',
      i18nRedoConfirm: 'Retranslate the whole menu?',
      i18nRedoDesc: 'Your manual corrections are kept.',
      i18nAddLang: 'Add a language to the menu',
      i18nChooseLang: 'Choose the language your customers need',
      i18nChooseHint: 'The language is translated once, then stays editable.',
      i18nClosePicker: 'Close',
      i18nAvailable: '{n} languages available',
      i18nRemoveLang: 'Remove',
      i18nRemoveConfirm: 'Remove this language?',
      i18nRemoveManual: '{n} manual correction(s) will be permanently deleted.',
      i18nOriginal: 'Original',
      i18nSections: 'Sections',
      i18nItems: 'Items',
      i18nOptions: 'Options',
      i18nDesc: 'description',
      i18nStatusOk: 'approved',
      i18nStatusUnreviewed: 'to review',
      i18nApprove: 'Approve wording and allergens',
      i18nStatusStale: 'outdated',
      i18nStatusMissing: 'missing',
      i18nStatusManual: 'corrected by hand',
      i18nUpToDate: 'All translations are up to date.',
      i18nDone: '{n} translation(s) added.',
      i18nQuota: 'Translation quota reached for today. It will resume later.',
      i18nError: 'Translation unavailable right now. It will retry in a few minutes.',
      i18nDemo: 'Automatic translation is for signed-in merchant accounts.',
      i18nBusy: 'Translating · {n} entries',
      i18nEmpty: 'Add items to translate them.',
      all: 'All',
      allWithCount: 'All · {n}',
      uncategorizedWithCount: 'Uncategorized · {n}',
      addSubCat: '+ Subcategory',
      classifyCount: 'Classify {n} item{s}',
      rename: 'Rename',
      editGroup: 'Edit choices',
      delete: 'Delete',
      withoutSubcat: 'Uncategorized',
      noSection: 'Uncategorized',
      kitchen: 'Kitchen',
      counter: 'Counter',
      stepCount: '{n} course(s)',
      optGroupCount: '{n} option group(s)',
      reuse: 'Reuse',
      standalone: 'Sellable individually',
      formulaOnly: 'Off, the item is reserved for set menus and no longer appears on its own on the menu.',
      formulaChoicePhoto: 'Show photo in set menus',
      formulaChoicePhotoHelp: 'In OrderPro, this item’s uploaded photo appears when it is offered as a set-menu choice.',
      archive: 'Archive',
      restore: 'Restore',
      archived: 'Archived',
      formulaOnlyBadge: 'Set menus only',
      step: 'Step',
      extra: 'Extra',
      deleteStep: 'Delete this step',
      removeChoice: 'Remove this choice',
      selectionRule: 'Selection rule',
      archivedGroup: 'Archived items',
      formula: 'SET MENU',
      searchPlaceholder: 'Search an item…',
      moveLeft: '← Move left',
      moveRight: 'Move right →',
      renameSection: 'Rename section',
      reorderDishes: 'Reorder dishes',
      moveDish: 'Move dish',
      reorderPick: 'Section',
      reorderHint: 'Drag a dish or pick its position. The till, the QR menu and online orders follow this order.',
      deleteSection: 'Delete section',
      newSection: '+ New section',
      newItem: '+ New item',
      emptyMenuTitle: 'Your menu is empty',
      emptyMenuDesc: 'Create a section, then add your first item. No demo content will be added.',
      createSectionBtn: 'Create a section',
      emptyItemsDesc: 'Your sections are ready. Add your first item. No demo content will be added.',
      addFirstItemBtn: 'Add an item',
      noItemMatch: 'No items match your search.',
      modAndOpts: 'Modifiers & options',
      newGroupBtn: '+ New option group',
      noOptGroups: 'No option groups.',
      required: 'Required',
      optional: 'Optional',
      manyChoices: 'Multiple choices',
      oneChoice: 'Single choice',
      usedByCount: 'Used by {n} item(s)',
      noChoices: 'No choices',
      stationsTitle: 'Preparation stations',
      stationsSub: 'One section, one station. All tickets remain visible in the All tab of the KDS.',
      addStation: 'Add station',
      defaultStationFallback: 'Kitchen · receives remainder',
      routingBySection: 'Routing by section',
      defaultRoute: '{name} · default',
      addFirstStation: 'Add your first station.',
      createSectionsForRouting: 'Create sections to configure their routing.',
      recipesTitle: 'Recipes & dish costs',
      recipesSub: 'Define exact quantities to link each sale to stock and calculate margins.',
      recipesCompletedCount: '{done} / {total} recipes completed',
      ingredientCount: '{n} ingredient(s)',
      viewAndEdit: 'View and edit',
      complete: 'Complete',
      costSummaryPortion: '{cost} MAD / portion',
      missingCostOrQty: 'Quantities or costs to complete',
      addItemsFirst: 'Add items first.',
      statusToComplete: 'Incomplete',
      statusCostIncomplete: 'Incomplete cost',
      statusCosted: 'Costed recipe',
      statusCheckStock: 'Check stock',
      statusToMonitor: 'To monitor',
      statusCostCompliant: 'Compliant cost',
      nutritionComplete: 'Nutrition complete',
      nutritionIncomplete: 'Nutrition incomplete',
      nutritionShort: 'Nutrition',
      tabNutrition: 'Nutrition',
      nutritionTitle: 'Nutrition and allergens',
      nutritionSub: 'Computed from recipes and stock records; published on the menu once a dish is complete. Nothing is typed here.',
      nutritionProgress: '{done} / {total} complete',
      nutritionFilterAll: 'All',
      nutritionFilterTodo: 'To complete',
      nutritionFilterDone: 'Complete',
      nutritionFilterHidden: 'Hidden',
      nutritionFilterEmpty: 'No dish in this state.',
      nutritionNoRecipe: 'No recipe',
      nutritionNoRecipeHint: 'Add the recipe to compute.',
      nutritionMissingShort: 'Incomplete: {n} ingredient(s) to complete in Stock',
      nutritionVisibleToggle: 'Visible',
      nutritionHiddenToggle: 'Hidden',
      nutritionDisabledNotice: 'Nutrition is switched off for this venue (operator setting): nothing is published on the menu, the records stay computed here.',
      nutritionHidden: 'Nutrition hidden',
      nutritionAwaitsRecipe: 'Computed as soon as the recipe has ingredients with quantities.',
      nutritionDisabled: 'Nutrition disabled',
      nutritionMissing: 'Incomplete: {n} ingredient(s) without a complete nutrition record',
      nutritionFix: 'Complete in Stock',
      nutritionAllergens: 'Allergens',
      nutritionNone: 'none',
      nutritionIndicative: 'Indicative values per portion, excluding options',
      nutritionHide: 'Hide nutrition for this dish',
      nutritionHideHint: 'The recipe stays calculated, but customers will not see these values.',
      allergen_gluten: 'Gluten', allergen_crustaces: 'Crustaceans', allergen_oeufs: 'Eggs', allergen_poissons: 'Fish',
      allergen_arachides: 'Peanuts', allergen_soja: 'Soy', allergen_lait: 'Milk', allergen_fruits_a_coque: 'Nuts',
      allergen_celeri: 'Celery', allergen_moutarde: 'Mustard', allergen_sesame: 'Sesame', allergen_sulfites: 'Sulphites',
      allergen_lupin: 'Lupin', allergen_mollusques: 'Molluscs',
      perfTitle: 'Item performance',
      perfSub: 'Popularity, revenue and contribution · Last 30 days · Real POS data.',
      daysCount: '{n} days',
      rangeLabel: '{from} to {to} · business days',
      menuItemsOnly: 'current menu items only',
      freeAmountItem: 'Free-amount item',
      freeAmountSection: 'Free amount · not on the menu',
      offMenuSection: 'Not on the current menu',
      freeAmountReadout: 'No recipe possible',
      offMenuReadout: 'Removed, renamed or unmatched item',
      ledgerGross: 'Gross sales',
      ledgerTickets: '{n} tickets',
      ledgerTickets1: '{n} ticket',
      ledgerRefunds: 'Refunds',
      ledgerRefundCount: '{n} refunds',
      ledgerRefundCount1: '{n} refund',
      ledgerNet: 'Net revenue',
      ledgerNetSub: 'gross sales minus refunds',
      ledgerEligible: 'Recipe-eligible revenue',
      ledgerEligibleSub: '{share} of gross · menu items only',
      ledgerLoading: 'Sales history is still loading on this device. These figures are partial, not a complete 30 days.',
      ledgerUnknown: 'This device cannot confirm the sales history is complete. Treat these figures as partial.',
      ledgerDuplicates: '{n} duplicate settlement(s) excluded ({amount}): the same ticket arrived more than once with the same time, amount and items.',
      ledgerOffMenu: '{amount} of item lines are outside the current menu, including {free} in free-amount items. They count in sales but cannot have a recipe.',
      ledgerUnitemised: '{amount} of sales is not explained by item lines (service charges, or {n} tickets without detail).',
    ledgerDiscounts: '{amount} of ticket discounts, spread pro rata over the lines of their ticket, as the VAT base is.',
    ledgerVatBasis: 'Contribution excludes VAT ({rate} % included in prices).',
    ledgerTodayCost: 'These sales did not freeze their cost: each dish’s current cost is applied to the past. A change in purchase price will change these contributions.',
    costSrcRecipe: 'Recipe',
    costSrcFrozen: 'Cost frozen at sale',
    costSrcFlat: 'Entered cost',
    costSrcVariant: 'Purchase price',
    costObserved: 'observed {amount}',
    salesTitle: 'Sales by category and item',
    salesSub: 'What each line of a ticket collected, VAT included, after ticket discounts spread over its lines. A formula keeps its price; its components count in quantity only.',
    salesPeriodAria: 'Period',
    salesPresetToday: 'Today',
    salesPresetYesterday: 'Yesterday',
    salesPreset7: '7 days',
    salesPreset30: '30 days',
    salesPresetMonth: 'This month',
    salesPresetLastMonth: 'Last month',
    salesDayLabel: '{day} · business day',
    salesAvgTicket: 'Average ticket',
    salesAvgTicketSub: 'gross sales ÷ tickets',
    salesByCategory: 'By category',
    salesByItem: 'By item',
    salesColCategory: 'Category',
    salesColQty: 'Sold',
    salesColRevenue: 'Collected',
    salesColShare: 'Share',
    salesColAvgPrice: 'Average price',
    salesItemsCount: '{n} items',
    salesItemsCount1: '1 item',
    salesInFormula: '{n} in a formula',
    salesAtZero: '{n} at 0 MAD',
    salesUnsold: '{n} menu items had no sale in this period.',
    salesUnsold1: '1 menu item had no sale in this period.',
    salesNone: 'No sales in this period',
    salesNoneDesc: 'Pick another period, or come back after the next service.',
    salesLoading: 'Sales history is still loading on this device. These figures are partial for this period.',
    salesOffline: 'Offline: these are the sales this device holds. They will be completed when it reconnects.',
    salesError: 'Sales could not be read on this device. Reload the page; nothing has been changed.',
    salesShareNote: 'Shares are of item lines ({amount}). Refunds and amounts without item detail are in the strip above, not in these tables.',
      ledgerRefundLines: 'Refunds reduce net revenue. They are not removed item by item from the table below.',
      noItemsToAnalyze: 'No items to analyze',
      noItemsToAnalyzeDesc: 'Add your dishes in Menu & modifiers. Performance will appear after the first sales.',
      noSalesYet: 'No item sales yet',
      noSalesYetDesc: 'Once the till records detailed receipts, Kiwi will automatically classify dishes.',
      completeRecipesForProfit: 'Complete recipes to see each dish’s contribution',
      completeRecipesForProfitDesc: 'Sales are received. Dish costs are needed to compare what each one contributes.',
      analyzedRevenue: 'Menu item revenue',
      itemsSold: 'items sold',
      itemSold: 'item sold',
      grossProfitCalc: 'Calculated contribution',
      recipesSoldAndCosted: '{n} recipe(s) sold and costed',
      costCoverage: 'Cost coverage',
      costCoverageSub: 'share of revenue with complete recipe',
      grossProfitPerItem: 'Contribution per item',
      popularityXDays: 'Popularity · sales over {n} days',
      perfDotSizeHint: 'Dot size = revenue',
      perfAxesHint: 'Lines = 70 % of a fair share of sales, and your menu’s sales-weighted average contribution',
      perfClickHint: 'Click an item to open its recipe',
      quadStar: 'Stars',
      quadStarHint: 'Popular, high contribution',
      quadStarAction: 'Promote',
      quadPlow: 'Plowhorses',
      quadPlowHint: 'Popular, low contribution',
      quadPlowAction: 'Review cost or price',
      quadPuzzle: 'Puzzles',
      quadPuzzleHint: 'High contribution, few orders',
      quadPuzzleAction: 'Position better',
      quadDog: 'Dogs',
      quadDogHint: 'Few orders, low contribution',
      quadDogAction: 'Rework or remove',
      matrixLabelStar: 'STARS',
      matrixHintStar: 'High contribution · high volume',
      matrixLabelPlow: 'TO OPTIMIZE',
      matrixHintPlow: 'Popular · low contribution',
      matrixLabelPuzzle: 'TO DEVELOP',
      matrixHintPuzzle: 'High contribution · low volume',
      matrixLabelDog: 'TO REVIEW',
      matrixHintDog: 'Low contribution & volume',
      legendStar: 'Stars',
      legendPlow: 'To optimize',
      legendPuzzle: 'To develop',
      legendDog: 'To review',
      colItem: 'Item',
      colSold: 'Sold',
      colRevenue: 'Revenue',
      colRevenueDesc: 'revenue',
      colUnitCost: 'Cost / item',
      colProfit: 'Contribution',
      colProfitDesc: 'contribution',
      colMargin: 'Contribution rate',
      colMarginDesc: 'contribution rate',
      colReadout: 'Status',
      completeRecipeLink: 'Complete recipe',
      estimateLabel: 'Cost sheet · {amount}',
      estimateStale: 'prices older than 90 days',
      estimateIncomplete: 'sheet incomplete',
      insightsTitle: 'What to do',
      insightsSub: 'Drawn from the sales and costs above. Nothing changes without you.',
      insightUncosted: '{amount} of sales with no known cost ({n} dishes): complete their recipe to see what they contribute.',
      insightObservedGap: '{item}: observed cost {observed}, recipe {theory} ({gap}). Check the quantities used and the waste.',
      insightEstimateGap: '{item}: the cost sheet says {estimate}, the recipe {theory} ({gap}). One of the two is out of date.',
      insightPlow: '{items}: ordered a lot, low contribution. Review the price or the portion.',
      insightPuzzle: '{items}: high contribution, few orders. Feature them on the menu and with the servers.',
      insightStale: 'Cost sheets with purchase prices older than 90 days: {items}. Update the prices.',
      insightNone: 'Nothing to flag for this period.',
      insightOpenSheet: 'Open the cost sheets',
      rxTitle: 'Recipe · {name}',
      rxDesc: '{cat} · {price} selling price',
      rxCostPortion: 'Cost per portion',
      rxPrice: 'Selling price',
      rxContribution: 'Contribution per portion',
      rxFoodCost: 'Food cost',
      rxObserved: 'Observed cost',
      rxObservedWait: 'After the first sales tracked in stock',
      rxHT: 'excl. VAT',
      rxOfPrice: 'of the selling price',
      rxStatusOk: 'Recipe costed',
      rxStatusTodo: 'Recipe to complete',
      rxStatusWatch: 'Cost to watch',
      rxStatusGap: 'Gap to check',
      rxOkHint: 'The observed cost will be compared with this recipe after the first sales.',
      rxGapUp: '{gap} above the planned cost. Check portions and stock withdrawals.',
      rxGapDown: '{gap} below the planned cost. Check portions and stock withdrawals.',
      rxMissing: '{n} to complete: {names}',
      rxToStock: 'Complete in Stock',
      rxComposition: 'Composition',
      rxCompositionSub: 'Quantities for the whole recipe. They drive cost, stock and nutrition.',
      rxPortions: 'Portions',
      rxPrep: 'Prep time',
      rxMin: 'min',
      rxIngredient: 'Ingredient',
      rxQty: 'Quantity',
      rxLineCost: 'Cost',
      rxLinked: 'In stock · {price} / {unit}',
      rxUnlinked: 'Not in stock',
      rxNoPrice: 'No price in stock',
      rxUnitMismatch: 'Unit not convertible to stock ({unit})',
      rxNoQty: 'Quantity missing',
      rxAdd: 'Add an ingredient',
      rxRemove: 'Remove {name}',
      rxIngPh: 'Ingredient from stock',
      rxChoose: 'Unit',
      rxMethod: 'Method',
      rxSteps: 'Steps',
      rxStepsPh: 'One step per line',
      rxNotes: 'Team notes',
      rxNotesPh: 'Allergens, sizing, plating…',
      rxNoStock: 'Add your raw materials in Stock first: their price is what costs the recipe.',
      rxToastQtyT: 'Quantities missing',
      rxToastQty: 'Add at least one ingredient with a quantity.',
      rxToastUnitT: 'Units missing',
      rxToastUnit: 'Choose a unit for each ingredient.',
      rxSavedT: 'Recipe saved',
      rxSaved: 'Stock, costs and nutrition updated.',
      rxAtLeast: 'at least {amount}',
      rxAtLeastSub: 'Lines without a known cost are not counted.',
      itRule: 'Guest picks {min} to {max}',
      itAlone: 'À la carte · {price}',
      itChoiceOne: '1 choice',
      itChoiceCount: '{n} choices',
      itCollapse: 'Collapse course',
      itExpand: 'Expand course',
      itAddChoice: 'Add a choice',
      itSecItem: 'Item',
      itSecItemHelp: 'What the guest sees on the menu and what they pay.',
      itSecOptionsHelp: 'Groups offered when this item is ordered: doneness, sauce, side.',
      itSecFormula: 'Set menu',
      itPrice: 'Price',
      itDescPh: 'E.g. Chickpea and lentil soup, served with dates.',
      itNameRequired: 'Name the item to save it.',
      itApplyTpl: 'Copy',
      itSaveTpl: 'Save as template',
      itPhoto: 'Photo',
      itVideo: 'Video',
      itAvailHelp: 'Off, the item is 86’d and can no longer be ordered.',
      itRuleMinMax: 'The minimum ({min}) is above the maximum ({max}).',
      itStepNoChoice: 'Add at least one dish to this course.',
      itStepTooFew: '{n} dishes for a minimum of {min}: add dishes or lower the minimum.',
      itStepTooFew1: 'Only 1 dish for a minimum of {min}: add dishes or lower the minimum.',
      itNoStep: 'No course yet. Add one below.',
      itFormulaCopied: 'Set menu copied',
      itFormulaEmpty: 'Empty set menu',
      itFormulaEmptyHelp: 'Add at least one choice before saving it as a template.',
      itTemplateName: 'Template name',
      itFormulaSaved: 'Template saved',
      itSaved: 'Menu updated',
      itNoMedia: 'No photo or video',
      itMediaRemoved: 'Media removed. Save to confirm.',
      itDefaultStep: 'Choice',
      itUploadUnavailable: 'Media storage unavailable.',
      itUploading: 'Uploading…',
      itUploadReady: 'Media ready. Save to keep it.',
      itUploadFailed: 'Upload failed. Try again.',
      mxTitle: 'Menu matrix',
      mxSub: 'Each dot is a dish that sold and has a cost. Further right: sells more. Higher up: contributes more per item. Popular means at least 70 % of a fair share of sales; profitable means at or above your menu’s average contribution, weighted by what sells.',
      mxMedianQty: 'popular from {n} sold',
      mxMedianProfit: 'average · {amount}',
      mxPerUnit: '{amount} per item',
      mxSoldN: '{n} sold',
      mxMore: '+ {n} more',
      mxEmptyQuad: 'No dish here',
      mxTooFew: 'At least two dishes that sold and have a complete cost are needed to compare them. Complete the recipes of the dishes you sell.',
      mxCluster: '{n} dishes at the same spot',
      mxBasis: 'Based on {n} dishes',
      mxAxisY: 'Contribution per item',
      mxAxisX: 'Sold · last {n} days',
      mxSize: 'Dot size = sales',
      mxRateSub: 'of the costed dishes’ sales',
      perfDetail: 'Detail by item',
      pairsTitle: 'Often ordered together',
      pairsSub: 'Dishes that land on the same ticket more often than chance would. Material for a set menu, or for teaching the team to suggest the second one.',
      pairsFew: 'Not enough tickets to tell yet: {n} of the {min} needed.',
      pairsNone: 'No pair comes up more often than chance in this period.',
      pairsLine: '{pct} of tickets with {a} also have {b}',
      pairsMeta: 'together on {n} tickets · {lift}× chance',
      mxContribution: '{amount} contribution',
      recipeDraftTitle: 'Draft, not saved',
      recipeDraftFrom: 'Taken from the cost sheet “{name}”. Check each ingredient against your stock, then save: until then nothing changes.',
      recipeDraftExisting: 'The current recipe stays in place until you save.',
      insightOpenRecipe: 'Open the recipe',
      insightUncosted1: '{amount} of sales with no known cost (1 dish): complete its recipe to see what it contributes.',
      marginMissing: 'Contribution unknown',
      noSaleRecorded: 'No sales',
      hoursTitle: 'Performance by time of day',
      hoursSub: 'Which items sell when · Last {n} days · Real POS data',
      hoursObserved: 'Actual sale hours · Opening hours not configured',
      setHoursPrompt: 'Enter restaurant operating hours',
      setHoursPromptDesc: 'Kiwi generates service moments from saved opening hours. No shifts are invented.',
      noServiceToAnalyze: 'No service to analyze',
      noServiceToAnalyzeDesc: 'Current opening hours do not overlap with morning, lunch, or evening. Check opening hours in Settings.',
      generatedRevenue: 'Revenue generated',
      inPeriod: 'in this time window',
      topItem: 'Top item',
      top10Items: 'Top 10 items · {label}',
      noSalesInPeriod: 'No sales yet in this time window',
      noSalesInPeriodDesc: 'Detailed sales will appear here automatically.',
      itemsWithPeak: 'Items with a peak period',
      peakInsightTag: 'KIWI INSIGHT · {label}',
      peakInsightTitle: '{item} leads this service',
      peakInsightBody: '{qty} unit(s), representing {share}% of items sold during this window. {peakShare}% of its analyzed sales occur during {period}.',
      peakNotableBody: '{share}% of its {total} sales occur during {period} ({hours}).',
      alerts86Title: '86 Alerts',
      alerts86Sub: 'Unavailable items shared with POS and OrderPro.',
      reactivate: 'Reactivate',
      no86Alerts: 'No 86 alerts.',
      unavailableBadge: '86 · unavailable',
      nfcTitle: 'NFC Tags',
      nfcSub: 'Manage the tags that open your OrderPro menu.',
      nfcUnavailable: 'NFC Tags unavailable',
      nfcUnavailableDesc: 'Enable OrderPro for this venue to manage its tags.',
      editSectionTitle: 'Edit section',
      newSectionTitle: 'New section',
      sectionNameLabel: 'Section name',
      sectionNamePlaceholder: 'e.g. Drinks',
      stationLabel: 'Preparation station',
      cancelBtn: 'Cancel',
      saveBtn: 'Save',
      doneBtn: 'Done',
      editItemTitle: 'Edit · {name}',
      newItemTitle: 'New item',
      nameLabel: 'Name',
      priceLabel: 'Price (MAD)',
      sectionLabel: 'Section',
      availabilityLabel: 'Availability',
      availableOpt: 'Available',
      unavailableOpt: '86 · unavailable',
      descLabel: 'Description',
      mediaLabel: 'Photo or video',
      addPhotoBtn: 'Add photo',
      addVideoBtn: 'Add video',
      removeMediaBtn: 'Remove',
      mediaStatusKept: 'Current media preserved.',
      noMediaStatus: 'No media.',
      itemOptionsLabel: 'Options for this item',
      createOptGroupFirst: 'Create an option group first.',
      isFormulaLabel: 'Formula / Set Menu (choice of courses)',
      isFormulaHelp: 'Allows composing a menu with courses (starter, main, drink...) during order entry.',
      formulaTemplatePlaceholder: 'Choose a saved formula…',
      noFormulaTemplates: 'No saved formulas',
      copyTemplateBtn: 'Copy to this item',
      saveTemplateBtn: 'Save this formula as a reusable template',
      addStepBtn: 'Add a course',
      stepTitlePlaceholder: 'Course title (e.g. Drink)',
      minLabel: 'Min',
      maxLabel: 'Max',
      noChoicesInStep: 'No choices in this course.',
      chooseItemPlaceholder: 'Choose an item…',
      addChoiceBtn: 'Add',
      noItemsOnMenuFormulaNotice: 'No items on the menu yet. First create your items (e.g. Espresso, Croissant), then come back to build the formula: choices are selected from the list, never typed by hand.',
      saveAndCreateItemBtn: 'Save and create an item',
      allChosenNotice: 'All menu items are already offered in this course.',
      editGroupTitle: 'Edit option group',
      newGroupTitle: 'New option group',
      groupNameLabel: 'Group name',
      groupNamePlaceholder: 'e.g. Cooking, Side, Size',
      groupTypeLabel: 'Type of choice',
      groupRequiredLabel: 'Requirement',
      groupRequiredOpt: 'Required (at least 1 choice)',
      groupOptionalOpt: 'Optional (customer can skip)',
      choicesLabel: 'Choices',
      addChoicePlaceholder: 'e.g. Rare, Fries, Large',
      addChoiceBtnLabel: 'Add choice',
      ogOptional: 'Optional',
      ogRequired: 'Required',
      ogRuleOneReq: 'When ordering, the customer picks exactly one option.',
      ogRuleOneOpt: 'When ordering, the customer picks one option, or none.',
      ogRuleManyReq: 'When ordering, the customer picks at least one option.',
      ogRuleManyOpt: 'When ordering, the customer picks as many options as they like, or none.',
      ogChoicesHelp: 'The supplement is added to the item price. Leave it empty when the choice is included.',
      ogMark: 'Marker',
      ogMarkPick: 'Pick a marker',
      ogNoMark: 'No marker',
      ogMarkHelp: 'The marker is an emoji shown on the kitchen screen. Optional.',
      ogChoiceName: 'Choice',
      ogSupplement: 'Supplement',
      ogRemoveChoice: 'Remove this choice',
      ogNameRequired: 'Give the group a name.',
      ogChoicesRequired: 'Add at least one choice with a name.',
      ogChoiceUnnamed: 'Name each choice, or remove it.',
      confirmDeleteDefault: 'This permanently deletes this item.',
      extraPricePlaceholder: 'Extra (MAD)',
      newSubcategoryTitle: 'New subcategory',
      subNamePlaceholder: 'Name (e.g. Cookies, Cakes, Classics)',
      renameSubcategoryTitle: 'Rename subcategory',
      newNameLabel: 'New name',
      deleteSubcategoryConfirm: 'Delete « {name} » ?',
      deleteSubcategoryDesc: '{n} item(s) will remain in this section and move to "Uncategorized".',
      deleteCategoryConfirm: 'Delete section « {name} » ?',
      deleteCategoryDesc: 'This section and its {n} item(s) will be permanently deleted.',
      deleteItemConfirm: 'Delete « {name} » ?',
      deleteGroupConfirm: 'Delete « {name} » ?',
      addStationTitle: 'Add a station',
      renameStationTitle: 'Rename station',
      stationNameLabel: 'Station name',
      deleteStationConfirm: 'Delete « {name} » ?',
      stationDefault: 'this station',
      scanUnavailable: 'Scan unavailable',
      reloadPage: 'Reload the page.',
      createSubFirstToast: 'Create a subcategory first',
      useAddSubHelp: 'Use "+ Subcategory".',
      allClassifiedToast: 'All items classified',
      noUnclassifiedItems: 'No items without subcategory.',
      classifyTag: 'CLASSIFICATION',
      classifyTitle: 'Classify items',
      articlesWithoutSub: 'items without subcategory',
      articleWithoutSub: 'item without subcategory',
      classifyInstantSaveNotice: 'Each choice is saved immediately.',
      chooseSelectPlaceholder: 'Choose',
      sectionsTitle: 'Sections',
      availableToggle: 'On sale: {name}',
      newItemShort: 'Item',
      emptySectionText: 'No items in this section yet.',
    },
    ar: {
      title: 'القائمة والإضافات',
      loading: 'جارٍ تحميل القائمة…',
      home: 'الرئيسية',
      articles: 'منتجات',
      article: 'منتج',
      sections: 'أقسام',
      section: 'قسم',
      tabMenu: 'القائمة والإضافات',
      tabStations: 'محطات التحضير',
      tabRecipes: 'الوصفات',
      tabPerformance: 'الأداء',
      tabHours: 'ساعات الذروة',
      tabAlerts: 'تنبيهات 86',
      tabNfc: 'رموز NFC',
      tabCaisse: 'إعدادات الصندوق',
      tabPromos: 'العروض',
      caisseTitle: 'إعدادات الصندوق',
      caisseSub: 'التوصيل أو شروط العرض أو أحجام الكعك: ما لا تقوله القائمة، يقرؤه صندوقك.',
      scanMenu: 'مسح القائمة',
      importExcel: 'استيراد Excel',
      translateMenu: 'الترجمات',
      tabI18n: 'الترجمات',
      i18nTitle: 'القائمة بلغة كل واحد',
      i18nReview: 'راجع كل لغة قبل مشاركة القائمة، وخاصة مسببات الحساسية والمكونات. الترجمات الآلية اقتراحات. عدّل الخانة لاعتماد صياغتك وراجعها مجددا بعد تغيير النص الأصلي.',
      i18nHint: 'يترجم Kiwi AI فقط المدخلات الجديدة أو المعدلة باللغات المختارة لهذه القائمة؛ النص الأصلي لا يتغير أبدا. عدّل خانة لتصحيحها: التصحيح لا يُستبدل أبدا.',
      i18nFill: 'ترجمة ما ينقص',
      i18nRedo: 'إعادة ترجمة الكل',
      i18nRedoConfirm: 'إعادة ترجمة القائمة كاملة؟',
      i18nRedoDesc: 'تُحفظ تصحيحاتك اليدوية.',
      i18nAddLang: 'إضافة لغة إلى القائمة',
      i18nChooseLang: 'اختر اللغة التي يحتاجها زبناؤك',
      i18nChooseHint: 'تُترجم اللغة مرة واحدة، ويمكنك تعديلها بعد ذلك.',
      i18nClosePicker: 'إغلاق',
      i18nAvailable: '{n} لغة متاحة',
      i18nRemoveLang: 'حذف',
      i18nRemoveConfirm: 'حذف هذه اللغة؟',
      i18nRemoveManual: 'سيتم حذف {n} تصحيح يدوي نهائيا.',
      i18nOriginal: 'النص الأصلي',
      i18nSections: 'الأقسام',
      i18nItems: 'الأصناف',
      i18nOptions: 'الخيارات',
      i18nDesc: 'الوصف',
      i18nStatusOk: 'معتمد',
      i18nStatusUnreviewed: 'للمراجعة',
      i18nApprove: 'اعتماد النص ومسببات الحساسية',
      i18nStatusStale: 'للمراجعة',
      i18nStatusMissing: 'ناقص',
      i18nStatusManual: 'مصحح يدويا',
      i18nUpToDate: 'كل الترجمات محدثة.',
      i18nDone: 'تمت إضافة {n} ترجمة.',
      i18nQuota: 'تم بلوغ حصة الترجمة اليوم، ستستأنف لاحقا.',
      i18nError: 'تعذرت الترجمة حاليا، ستتم إعادة المحاولة بعد دقائق.',
      i18nDemo: 'الترجمة التلقائية متاحة لحسابات التجار المتصلة.',
      i18nBusy: 'جارٍ الترجمة · {n} مدخل',
      i18nEmpty: 'أضف أصنافا لترجمتها.',
      all: 'الكل',
      allWithCount: 'الكل · {n}',
      uncategorizedWithCount: 'غير مصنف · {n}',
      addSubCat: '+ تصنيف فرعي',
      classifyCount: 'تصنيف {n} منتج',
      rename: 'إعادة تسمية',
      editGroup: 'تعديل الخيارات',
      delete: 'حذف',
      withoutSubcat: 'بدون تصنيف فرعي',
      noSection: 'بدون قسم',
      kitchen: 'المطبخ',
      counter: 'المكتب',
      stepCount: '{n} مرحلة',
      optGroupCount: '{n} مجموعة خيارات',
      reuse: 'إعادة استخدام',
      standalone: 'يُباع منفرداً',
      formulaOnly: 'عند الإيقاف يُحصر الصنف في القوائم المجمعة ولا يظهر منفرداً في القائمة.',
      formulaChoicePhoto: 'عرض الصورة داخل الفورمولات',
      formulaChoicePhotoHelp: 'في OrderPro، تظهر صورة هذا الصنف عندما يكون اختياراً داخل فورمولة.',
      archive: 'أرشفة',
      restore: 'استعادة',
      archived: 'مؤرشف',
      formulaOnlyBadge: 'للقوائم المجمعة فقط',
      step: 'المرحلة',
      extra: 'إضافة',
      deleteStep: 'حذف هذه المرحلة',
      removeChoice: 'إزالة هذا الخيار',
      selectionRule: 'قاعدة الاختيار',
      archivedGroup: 'أصناف مؤرشفة',
      formula: 'قائمة مجمعة',
      searchPlaceholder: 'البحث عن منتج…',
      moveLeft: '← للأمام',
      moveRight: 'للخلف →',
      renameSection: 'إعادة تسمية القسم',
      reorderDishes: 'إعادة ترتيب الأطباق',
      moveDish: 'نقل الطبق',
      reorderPick: 'القسم',
      reorderHint: 'اسحب طبقاً أو اختر موضعه. الصندوق وقائمة QR والطلبات عبر الإنترنت تتبع هذا الترتيب.',
      deleteSection: 'حذف القسم',
      newSection: '+ قسم جديد',
      newItem: '+ منتج جديد',
      emptyMenuTitle: 'قائمتك فارغة',
      emptyMenuDesc: 'أنشئ قسماً ثم أضف أول منتج. لن يتم إضافة أي محتوى تجريبي.',
      createSectionBtn: 'إنشاء قسم',
      emptyItemsDesc: 'أقسامك جاهزة. أضف أول منتج. لن يتم إضافة أي محتوى تجريبي.',
      addFirstItemBtn: 'إضافة منتج',
      noItemMatch: 'لا توجد منتجات مطابقة.',
      modAndOpts: 'المعدلات والخيارات',
      newGroupBtn: '+ مجموعة خيارات جديدة',
      noOptGroups: 'لا توجد مجموعات خيارات.',
      required: 'إلزامي',
      optional: 'اختياري',
      manyChoices: 'خيارات متعددة',
      oneChoice: 'خيار واحد',
      usedByCount: 'مستخدم في {n} منتج',
      noChoices: 'لا توجد خيارات',
      stationsTitle: 'محطات التحضير',
      stationsSub: 'قسم لكل محطة. تظل جميع التذاكر مرئية في تبويب الكل في شاشة المطبخ.',
      addStation: 'إضافة محطة',
      defaultStationFallback: 'المطبخ · يستقبل الباقي',
      routingBySection: 'التوجيه حسب القسم',
      defaultRoute: '{name} · افتراضي',
      addFirstStation: 'أضف أول محطة تحضير.',
      createSectionsForRouting: 'أنشئ أقساماً لتحديد توجيهها.',
      recipesTitle: 'الوصفات والتكاليف لكل طبق',
      recipesSub: 'حدد الكميات بدقة لربط المبيعات بالمخزون وحساب هوامش الربح.',
      recipesCompletedCount: '{done} / {total} وصفة مكتملة',
      ingredientCount: '{n} مكونات',
      viewAndEdit: 'عرض وتعديل',
      complete: 'استكمال',
      costSummaryPortion: '{cost} MAD / حصة',
      missingCostOrQty: 'بحاجة لتحديد الكميات أو التكاليف',
      addItemsFirst: 'أضف منتجات أولاً.',
      statusToComplete: 'بحاجة للاستكمال',
      statusCostIncomplete: 'تكلفة غير مكتملة',
      statusCosted: 'وصفة مسعرة',
      statusCheckStock: 'فحص المخزون',
      statusToMonitor: 'للمتابعة',
      statusCostCompliant: 'تكلفة مطابقة',
      nutritionComplete: 'القيم الغذائية مكتملة',
      nutritionIncomplete: 'القيم الغذائية غير مكتملة',
      nutritionShort: 'القيم الغذائية',
      nutritionAwaitsRecipe: 'تُحسب بمجرد أن تحتوي الوصفة على مكوّنات بكميات.',
      tabNutrition: 'القيم الغذائية',
      nutritionTitle: 'القيم الغذائية ومسببات الحساسية',
      nutritionSub: 'تُحسب من الوصفات وبطاقات المخزون، وتُنشر في القائمة عندما تكتمل بطاقة الطبق. لا شيء يُدخل هنا.',
      nutritionProgress: '{done} / {total} مكتملة',
      nutritionFilterAll: 'الكل',
      nutritionFilterTodo: 'للإكمال',
      nutritionFilterDone: 'مكتملة',
      nutritionFilterHidden: 'مخفية',
      nutritionFilterEmpty: 'لا طبق في هذه الحالة.',
      nutritionNoRecipe: 'بدون وصفة',
      nutritionNoRecipeHint: 'أضف الوصفة للحساب.',
      nutritionMissingShort: 'غير مكتمل: {n} مكوّن(ات) لإكمالها في المخزون',
      nutritionVisibleToggle: 'ظاهرة',
      nutritionHiddenToggle: 'مخفية',
      nutritionDisabledNotice: 'القيم الغذائية معطّلة لهذا المحل (إعداد المشغّل): لا يُنشر شيء في القائمة، وتبقى البطاقات محسوبة هنا.',
      nutritionHidden: 'القيم الغذائية مخفية',
      nutritionDisabled: 'القيم الغذائية معطلة',
      nutritionMissing: 'غير مكتمل: {n} مكونات بدون بطاقة غذائية مكتملة',
      nutritionFix: 'الإكمال في المخزون',
      nutritionAllergens: 'مسببات الحساسية',
      nutritionNone: 'لا يوجد',
      nutritionIndicative: 'قيم تقريبية لكل حصة، بدون الخيارات',
      nutritionHide: 'إخفاء القيم الغذائية لهذا الطبق',
      nutritionHideHint: 'تبقى الوصفة محسوبة، لكن الزبائن لن يروا هذه القيم.',
      allergen_gluten: 'الغلوتين', allergen_crustaces: 'القشريات', allergen_oeufs: 'البيض', allergen_poissons: 'السمك',
      allergen_arachides: 'الفول السوداني', allergen_soja: 'الصويا', allergen_lait: 'الحليب', allergen_fruits_a_coque: 'المكسرات',
      allergen_celeri: 'الكرفس', allergen_moutarde: 'الخردل', allergen_sesame: 'السمسم', allergen_sulfites: 'الكبريتيت',
      allergen_lupin: 'الترمس', allergen_mollusques: 'الرخويات',
      perfTitle: 'أداء المنتجات',
      perfSub: 'الشعبية، رقم المعاملات والمساهمة · آخر 30 يوماً · بيانات حقيقية من الصندوق.',
      daysCount: '{n} يوماً',
      rangeLabel: 'من {from} إلى {to} · أيام العمل',
      menuItemsOnly: 'منتجات القائمة الحالية فقط',
      freeAmountItem: 'منتج بمبلغ حر',
      freeAmountSection: 'مبلغ حر · خارج القائمة',
      offMenuSection: 'خارج القائمة الحالية',
      freeAmountReadout: 'لا يمكن ربطه بوصفة',
      offMenuReadout: 'منتج محذوف أو معاد تسميته أو غير مطابق',
      ledgerGross: 'المبيعات الإجمالية',
      ledgerTickets: '{n} تذكرة',
      ledgerRefunds: 'المبالغ المستردة',
      ledgerRefundCount: '{n} استرداد',
      ledgerNet: 'صافي المداخيل',
      ledgerNetSub: 'المبيعات الإجمالية ناقص المستردات',
      ledgerEligible: 'مداخيل قابلة لتحليل الوصفات',
      ledgerEligibleSub: '{share} من الإجمالي · منتجات القائمة فقط',
      ledgerLoading: 'سجل المبيعات ما زال قيد التحميل على هذا الجهاز. هذه الأرقام جزئية وليست 30 يوماً كاملة.',
      ledgerUnknown: 'لا يمكن لهذا الجهاز تأكيد اكتمال سجل المبيعات. اعتبر هذه الأرقام جزئية.',
      ledgerDuplicates: 'تم استبعاد {n} تسوية مكررة ({amount}): نفس التذكرة وصلت أكثر من مرة بنفس الوقت والمبلغ والمنتجات.',
      ledgerOffMenu: '{amount} من سطور المنتجات خارج القائمة الحالية، منها {free} بمبلغ حر. تحتسب في المبيعات لكن لا يمكن ربطها بوصفة.',
      ledgerUnitemised: '{amount} من المبيعات غير مفسرة بسطور المنتجات (رسوم خدمة، أو {n} تذكرة بدون تفاصيل).',
    ledgerDiscounts: '{amount} تخفيضات على التذكرة، موزعة بالتناسب على سطور تذكرتها، كما في وعاء الضريبة على القيمة المضافة.',
    ledgerVatBasis: 'المساهمة محسوبة دون الضريبة على القيمة المضافة ({rate} % مدرجة في الأسعار).',
    ledgerTodayCost: 'هذه المبيعات لم تثبّت تكلفتها: تُطبَّق التكلفة الحالية لكل طبق على الماضي. أي تغيير في سعر الشراء سيغيّر هذه المساهمات.',
    costSrcRecipe: 'وصفة',
    costSrcFrozen: 'تكلفة مثبتة عند البيع',
    costSrcFlat: 'تكلفة مُدخلة',
    costSrcVariant: 'سعر الشراء',
    costObserved: 'ملاحَظة {amount}',
    salesTitle: 'المبيعات حسب الفئة والمنتج',
    salesSub: 'ما حصّله كل سطر من التذكرة، شاملاً الضريبة، بعد توزيع خصم التذكرة على سطورها. تحتفظ الوجبة المركبة بسعرها؛ ومكوناتها تُحتسب بالكمية فقط.',
    salesPeriodAria: 'الفترة',
    salesPresetToday: 'اليوم',
    salesPresetYesterday: 'أمس',
    salesPreset7: '7 أيام',
    salesPreset30: '30 يوماً',
    salesPresetMonth: 'هذا الشهر',
    salesPresetLastMonth: 'الشهر الماضي',
    salesDayLabel: '{day} · يوم عمل',
    salesAvgTicket: 'متوسط التذكرة',
    salesAvgTicketSub: 'المبيعات الإجمالية ÷ التذاكر',
    salesByCategory: 'حسب الفئة',
    salesByItem: 'حسب المنتج',
    salesColCategory: 'الفئة',
    salesColQty: 'المبيع',
    salesColRevenue: 'المحصّل',
    salesColShare: 'الحصة',
    salesColAvgPrice: 'متوسط السعر',
    salesItemsCount: '{n} منتجات',
    salesItemsCount1: 'منتج واحد',
    salesInFormula: '{n} ضمن وجبة مركبة',
    salesAtZero: '{n} بـ 0 درهم',
    salesUnsold: '{n} منتجات من القائمة لم تُبع خلال هذه الفترة.',
    salesUnsold1: 'منتج واحد من القائمة لم يُبع خلال هذه الفترة.',
    salesNone: 'لا مبيعات في هذه الفترة',
    salesNoneDesc: 'اختر فترة أخرى، أو عد بعد الخدمة القادمة.',
    salesLoading: 'سجل المبيعات ما زال قيد التحميل على هذا الجهاز. هذه الأرقام جزئية لهذه الفترة.',
    salesOffline: 'غير متصل: هذه هي المبيعات الموجودة على هذا الجهاز. ستكتمل عند عودة الاتصال.',
    salesError: 'تعذرت قراءة المبيعات على هذا الجهاز. أعد تحميل الصفحة؛ لم يتغير شيء.',
    salesShareNote: 'الحصص محسوبة من سطور المنتجات ({amount}). المستردات والمبالغ بدون تفاصيل موجودة في الشريط أعلاه، لا في هذه الجداول.',
      ledgerRefundLines: 'المستردات تنقص صافي المداخيل ولا تحذف منتجاً بمنتج من الجدول أدناه.',
      noItemsToAnalyze: 'لا توجد منتجات للتحليل',
      noItemsToAnalyzeDesc: 'أضف أطباقك في القائمة والإضافات. سيظهر الأداء بعد أولى المبيعات.',
      noSalesYet: 'لا توجد مبيعات بعد لكل منتج',
      noSalesYetDesc: 'بمجرد تسجيل الصندوق للتذاكر المفصلة، يصنف Kiwi الأطباق تلقائياً.',
      completeRecipesForProfit: 'أكمل الوصفات لمعرفة مساهمة كل طبق',
      completeRecipesForProfitDesc: 'تم استلام المبيعات. تنقص تكلفة الأطباق لمقارنة مساهمة كل منها.',
      analyzedRevenue: 'رقم المعاملات المحلل',
      itemsSold: 'منتجات مباعة',
      grossProfitCalc: 'المساهمة المحسوبة',
      recipesSoldAndCosted: '{n} وصفة مباعة ومسعرة',
      costCoverage: 'تغطية التكاليف',
      costCoverageSub: 'نسبة المبيعات ذات الوصفة المكتملة',
      grossProfitPerItem: 'المساهمة لكل منتج',
      popularityXDays: 'الشعبية · المبيعات خلال {n} يوماً',
      perfDotSizeHint: 'حجم النقطة = رقم المعاملات',
      perfAxesHint: 'الخطوط = 70 % من الحصة العادلة للمبيعات، ومتوسط مساهمة قائمتك مرجّحاً بالمبيعات',
      perfClickHint: 'انقر على منتج لفتح وصفته',
      quadStar: 'نجوم (Stars)',
      quadStarHint: 'شعبية بمساهمة عالية',
      quadStarAction: 'إبرازها',
      quadPlow: 'أحصنة الجر (Plowhorses)',
      quadPlowHint: 'شعبية بمساهمة منخفضة',
      quadPlowAction: 'مراجعة السعر أو التكلفة',
      quadPuzzle: 'ألغاز (Puzzles)',
      quadPuzzleHint: 'مساهمة عالية وطلب قليل',
      quadPuzzleAction: 'تحسين الموضع',
      quadDog: 'أعباء (Dogs)',
      quadDogHint: 'طلب ضعيف ومساهمة منخفضة',
      quadDogAction: 'إعادة العمل أو الحذف',
      matrixLabelStar: 'نجوم (STARS)',
      matrixHintStar: 'مساهمة عالية · حجم مبيعات قوي',
      matrixLabelPlow: 'للتحسين',
      matrixHintPlow: 'شعبي · مساهمة ضعيفة',
      matrixLabelPuzzle: 'للتطوير',
      matrixHintPuzzle: 'مساهمة عالية · حجم مبيعات ضعيف',
      matrixLabelDog: 'للمراجعة',
      matrixHintDog: 'مساهمة وحجم مبيعات ضعيفان',
      legendStar: 'نجوم',
      legendPlow: 'للتحسين',
      legendPuzzle: 'للتطوير',
      legendDog: 'للمراجعة',
      colItem: 'المنتج',
      colSold: 'المباع',
      colRevenue: 'رقم المعاملات',
      colRevenueDesc: 'رقم المعاملات',
      colUnitCost: 'التكلفة / منتج',
      colProfit: 'المساهمة',
      colProfitDesc: 'مساهمة',
      colMargin: 'نسبة المساهمة',
      colMarginDesc: 'نسبة المساهمة',
      colReadout: 'الحالة',
      completeRecipeLink: 'استكمال الوصفة',
      estimateLabel: 'بطاقة التكلفة · {amount}',
      estimateStale: 'أسعار أقدم من 90 يوماً',
      estimateIncomplete: 'بطاقة غير مكتملة',
      insightsTitle: 'ما يجب فعله',
      insightsSub: 'مستخلصة من المبيعات والتكاليف أعلاه. لا يتغيّر شيء دونك.',
      insightUncosted: '{amount} من المبيعات بلا تكلفة معروفة ({n} أطباق): أكمل وصفاتها لمعرفة مساهمتها.',
      insightObservedGap: '{item}: التكلفة الملاحَظة {observed}، الوصفة {theory} ({gap}). راجع الكميات المستعملة والهدر.',
      insightEstimateGap: '{item}: بطاقة التكلفة تقول {estimate} والوصفة {theory} ({gap}). إحداهما لم تعد محدّثة.',
      insightPlow: '{items}: طلب كثير ومساهمة منخفضة. راجع السعر أو الحصة.',
      insightPuzzle: '{items}: مساهمة عالية وطلب قليل. أبرزها في القائمة ولدى النُدُل.',
      insightStale: 'بطاقات تكلفة بأسعار شراء أقدم من 90 يوماً: {items}. حدّث الأسعار.',
      insightNone: 'لا شيء يستدعي الانتباه في هذه الفترة.',
      insightOpenSheet: 'فتح بطاقات التكلفة',
      rxTitle: 'وصفة · {name}',
      rxDesc: '{cat} · سعر البيع {price}',
      rxCostPortion: 'التكلفة لكل حصة',
      rxPrice: 'سعر البيع',
      rxContribution: 'المساهمة لكل حصة',
      rxFoodCost: 'تكلفة المواد',
      rxObserved: 'التكلفة الملاحَظة',
      rxObservedWait: 'بعد أولى المبيعات المتتبَّعة في المخزون',
      rxHT: 'دون الضريبة',
      rxOfPrice: 'من سعر البيع',
      rxStatusOk: 'وصفة محسوبة',
      rxStatusTodo: 'وصفة غير مكتملة',
      rxStatusWatch: 'تكلفة تحت المراقبة',
      rxStatusGap: 'فرق يجب التحقق منه',
      rxOkHint: 'ستُقارن التكلفة الملاحَظة بهذه الوصفة بعد أولى المبيعات.',
      rxGapUp: '{gap} فوق التكلفة المتوقعة. راجع الحصص وسحوبات المخزون.',
      rxGapDown: '{gap} تحت التكلفة المتوقعة. راجع الحصص وسحوبات المخزون.',
      rxMissing: '{n} للإكمال: {names}',
      rxToStock: 'إكمال في المخزون',
      rxComposition: 'المكوّنات',
      rxCompositionSub: 'كميات الوصفة كاملة. تتحكم في التكلفة والمخزون والتغذية.',
      rxPortions: 'الحصص',
      rxPrep: 'التحضير',
      rxMin: 'د',
      rxIngredient: 'المكوّن',
      rxQty: 'الكمية',
      rxLineCost: 'التكلفة',
      rxLinked: 'في المخزون · {price} / {unit}',
      rxUnlinked: 'غير موجود في المخزون',
      rxNoPrice: 'بلا سعر في المخزون',
      rxUnitMismatch: 'وحدة غير قابلة للتحويل إلى المخزون ({unit})',
      rxNoQty: 'الكمية ناقصة',
      rxAdd: 'إضافة مكوّن',
      rxRemove: 'إزالة {name}',
      rxIngPh: 'مكوّن من المخزون',
      rxChoose: 'الوحدة',
      rxMethod: 'طريقة التحضير',
      rxSteps: 'الخطوات',
      rxStepsPh: 'خطوة في كل سطر',
      rxNotes: 'ملاحظات الفريق',
      rxNotesPh: 'مسببات الحساسية، المقاسات، التقديم…',
      rxNoStock: 'أضف موادك الأولية في المخزون أولاً: سعرها هو ما يحدد تكلفة الوصفة.',
      rxToastQtyT: 'كميات ناقصة',
      rxToastQty: 'أضف مكوّناً واحداً على الأقل مع كمية.',
      rxToastUnitT: 'وحدات ناقصة',
      rxToastUnit: 'اختر وحدة لكل مكوّن.',
      rxSavedT: 'تم حفظ الوصفة',
      rxSaved: 'تم تحديث المخزون والتكاليف والتغذية.',
      rxAtLeast: 'على الأقل {amount}',
      rxAtLeastSub: 'الأسطر بلا تكلفة معروفة غير محسوبة.',
      itRule: 'يختار الزبون من {min} إلى {max}',
      itAlone: 'منفرداً · {price}',
      itChoiceOne: 'خيار واحد',
      itChoiceCount: '{n} خيارات',
      itCollapse: 'طي المرحلة',
      itExpand: 'فتح المرحلة',
      itAddChoice: 'إضافة خيار',
      itSecItem: 'الصنف',
      itSecItemHelp: 'ما يراه الزبون في القائمة وما يدفعه.',
      itSecOptionsHelp: 'المجموعات المعروضة عند طلب هذا الصنف: درجة الطهي، الصلصة، الطبق الجانبي.',
      itSecFormula: 'قائمة مجمعة',
      itPrice: 'السعر',
      itDescPh: 'مثال: حساء الحمص والعدس، يقدم مع التمر.',
      itNameRequired: 'أدخل اسم الصنف لحفظه.',
      itApplyTpl: 'نسخ',
      itSaveTpl: 'حفظ كنموذج',
      itPhoto: 'صورة',
      itVideo: 'فيديو',
      itAvailHelp: 'عند الإيقاف يصبح الصنف غير متاح (86) ولا يمكن طلبه.',
      itRuleMinMax: 'الحد الأدنى ({min}) أكبر من الحد الأقصى ({max}).',
      itStepNoChoice: 'أضف طبقًا واحدًا على الأقل لهذه المرحلة.',
      itStepTooFew: '{n} أطباق لحد أدنى قدره {min}: أضف أطباقًا أو اخفض الحد الأدنى.',
      itNoStep: 'لا توجد مراحل بعد. أضف مرحلة أدناه.',
      itFormulaCopied: 'تم نسخ القائمة',
      itFormulaEmpty: 'قائمة فارغة',
      itFormulaEmptyHelp: 'أضف خياراً واحداً على الأقل قبل حفظها كنموذج.',
      itTemplateName: 'اسم النموذج',
      itFormulaSaved: 'تم حفظ النموذج',
      itSaved: 'تم تحديث القائمة',
      itNoMedia: 'لا صورة ولا فيديو',
      itMediaRemoved: 'تمت إزالة الوسائط. احفظ للتأكيد.',
      itDefaultStep: 'اختيار',
      itUploadUnavailable: 'تخزين الوسائط غير متاح.',
      itUploading: 'جارٍ الرفع…',
      itUploadReady: 'الوسائط جاهزة. احفظ للاحتفاظ بها.',
      itUploadFailed: 'تعذر الرفع. حاول مجدداً.',
      mxTitle: 'مصفوفة القائمة',
      mxSub: 'كل نقطة طبق بيع وله تكلفة. إلى اليمين: يُباع أكثر. إلى الأعلى: يساهم أكثر لكل وحدة. الطبق شائع إذا بلغ 70 % على الأقل من حصته العادلة من المبيعات، ومربح إذا بلغت مساهمته متوسط قائمتك المرجّح بالمبيعات.',
      mxMedianQty: 'شائع ابتداءً من {n} مبيعة',
      mxMedianProfit: 'المتوسط · {amount}',
      mxPerUnit: '{amount} للوحدة',
      mxSoldN: '{n} مبيعة',
      mxMore: '+ {n} أخرى',
      mxEmptyQuad: 'لا طبق هنا',
      mxTooFew: 'يلزم طبقان على الأقل بيعا ولهما تكلفة كاملة للمقارنة بينهما. أكمل وصفات الأطباق التي تبيعها.',
      mxCluster: '{n} أطباق في الموضع نفسه',
      mxBasis: 'محسوب على {n} أطباق',
      mxAxisY: 'المساهمة لكل منتج',
      mxAxisX: 'المبيعات · آخر {n} يوماً',
      mxSize: 'حجم النقطة = المبيعات',
      mxRateSub: 'من مبيعات الأطباق المحسوبة',
      perfDetail: 'التفاصيل حسب المنتج',
      pairsTitle: 'يُطلب معاً غالباً',
      pairsSub: 'أطباق تجتمع على نفس التذكرة أكثر مما تفسّره الصدفة. مادة لتركيب قائمة ثابتة أو لتدريب الفريق على اقتراح الطبق الثاني.',
      pairsFew: 'التذاكر غير كافية بعد: {n} من أصل {min} مطلوبة.',
      pairsNone: 'لا يتكرر أي زوج أكثر من الصدفة في هذه الفترة.',
      pairsLine: '{pct} من التذاكر التي فيها {a} فيها أيضاً {b}',
      pairsMeta: 'معاً على {n} تذكرة · {lift}× الصدفة',
      mxContribution: 'مساهمة {amount}',
      recipeDraftTitle: 'مسودة غير محفوظة',
      recipeDraftFrom: 'مأخوذة من بطاقة التكلفة «{name}». راجع كل مكوّن مقابل مخزونك ثم احفظ: لا يتغير شيء قبل ذلك.',
      recipeDraftExisting: 'الوصفة الحالية تبقى كما هي حتى تحفظ.',
      insightOpenRecipe: 'فتح الوصفة',
      insightUncosted1: '{amount} من المبيعات بلا تكلفة معروفة (طبق واحد): أكمل وصفته لمعرفة مساهمته.',
      marginMissing: 'المساهمة غير معروفة',
      noSaleRecorded: 'لا توجد مبيعات',
      hoursTitle: 'الأداء حسب أوقات اليوم',
      hoursSub: 'ما المنتجات التي تباع ومتى · آخر {n} يوماً · بيانات حقيقية من الصندوق',
      hoursObserved: 'ساعات المبيعات الفعلية · أوقات العمل غير محددة',
      setHoursPrompt: 'حدد أوقات عمل المطعم',
      setHoursPromptDesc: 'ينشئ Kiwi فترات اليوم بناءً على الأوقات المسجلة دون اختلاق أي فترة.',
      noServiceToAnalyze: 'لا توجد فترة للتحليل',
      noServiceToAnalyzeDesc: 'أوقات العمل الحالية لا تتقاطع مع الصباح أو الظهيرة أو المساء. تحقق من أوقات العمل في الإعدادات.',
      generatedRevenue: 'المدخول المحقق',
      inPeriod: 'خلال هذه الفترة',
      topItem: 'أفضل منتج',
      top10Items: 'أفضل 10 منتجات · {label}',
      noSalesInPeriod: 'لا توجد مبيعات بعد في هذه الفترة',
      noSalesInPeriodDesc: 'ستظهر المبيعات المفصلة هنا تلقائياً.',
      itemsWithPeak: 'منتجات ذات ذروة طلب',
      peakInsightTag: 'تحليل KIWI · {label}',
      peakInsightTitle: '{item} يقود هذه الفترة',
      peakInsightBody: '{qty} وحدة، أي ما يمثل {share}% من المنتجات المباعة خلال هذه الفترة. {peakShare}% من مبيعاته تتم خلال {period}.',
      peakNotableBody: '{share}% من مبيعاته البالغة {total} تتم خلال {period} ({hours}).',
      alerts86Title: 'تنبيهات 86',
      alerts86Sub: 'المنتجات غير المتاحة المشتركة مع الصندوق و OrderPro.',
      reactivate: 'إعادة تفعيل',
      no86Alerts: 'لا توجد تنبيهات 86.',
      unavailableBadge: '86 · غير متاح',
      nfcTitle: 'رموز NFC',
      nfcSub: 'إدارة الرموز التي تفتح قائمة OrderPro.',
      nfcUnavailable: 'رموز NFC غير متاحة',
      nfcUnavailableDesc: 'قم بتفعيل OrderPro لهذا المتجر لإدارة رموزه.',
      editSectionTitle: 'تعديل القسم',
      newSectionTitle: 'قسم جديد',
      sectionNameLabel: 'اسم القسم',
      sectionNamePlaceholder: 'مثال: مشروبات',
      stationLabel: 'محطة التحضير',
      cancelBtn: 'إلغاء',
      saveBtn: 'حفظ',
      doneBtn: 'تم',
      editItemTitle: 'تعديل · {name}',
      newItemTitle: 'منتج جديد',
      nameLabel: 'الاسم',
      priceLabel: 'السعر (MAD)',
      sectionLabel: 'القسم',
      availabilityLabel: 'التوفر',
      availableOpt: 'متاح',
      unavailableOpt: '86 · غير متاح',
      descLabel: 'الوصف',
      mediaLabel: 'صورة أو فيديو',
      addPhotoBtn: 'إضافة صورة',
      addVideoBtn: 'إضافة فيديو',
      removeMediaBtn: 'إزالة',
      mediaStatusKept: 'تم الاحتفاظ بالوسائط الحالية.',
      noMediaStatus: 'لا توجد وسائط.',
      itemOptionsLabel: 'خيارات هذا المنتج',
      createOptGroupFirst: 'أنشئ أولاً مجموعة خيارات.',
      isFormulaLabel: 'قائمة مجمعة / وجبة مركبة (مراحل للاختيار)',
      isFormulaHelp: 'تتيح تكوين قائمة ذات مراحل (مقبلات، طبق رئيسي، مشروب...) عند تسجيل الطلب.',
      formulaTemplatePlaceholder: 'اختر نموذجاً مسجلاً…',
      noFormulaTemplates: 'لا توجد نماذج مسجلة',
      copyTemplateBtn: 'نسخ إلى هذا المنتج',
      saveTemplateBtn: 'حفظ هذه القائمة كنموذج قابل لإعادة الاستخدام',
      addStepBtn: 'إضافة مرحلة',
      stepTitlePlaceholder: 'عنوان المرحلة (مثال: المشروب)',
      minLabel: 'الحد الأدنى',
      maxLabel: 'الحد الأقصى',
      noChoicesInStep: 'لا توجد خيارات في هذه المرحلة.',
      chooseItemPlaceholder: 'اختر منتجاً…',
      addChoiceBtn: 'إضافة',
      noItemsOnMenuFormulaNotice: 'لا توجد منتجات في القائمة بعد. أنشئ منتجاتك أولاً ثم عد لتركيب الوجبة المركبة.',
      saveAndCreateItemBtn: 'حفظ وإنشاء منتج',
      allChosenNotice: 'جميع منتجات القائمة معروضة بالفعل في هذه المرحلة.',
      editGroupTitle: 'تعديل مجموعة الخيارات',
      newGroupTitle: 'مجموعة خيارات جديدة',
      groupNameLabel: 'اسم المجموعة',
      groupNamePlaceholder: 'مثال: درجة الطهي، الإضافة، الحجم',
      groupTypeLabel: 'نوع الاختيار',
      groupRequiredLabel: 'الإلزامية',
      groupRequiredOpt: 'إلزامي (خيار واحد على الأقل)',
      groupOptionalOpt: 'اختياري (يمكن تجاوزه)',
      choicesLabel: 'الخيارات',
      addChoicePlaceholder: 'مثال: مطهو جيداً، بطاطس، كبير',
      addChoiceBtnLabel: 'إضافة خيار',
      ogOptional: 'اختياري',
      ogRequired: 'إلزامي',
      ogRuleOneReq: 'عند الطلب، يختار الزبون خياراً واحداً بالضبط.',
      ogRuleOneOpt: 'عند الطلب، يختار الزبون خياراً واحداً، أو لا شيء.',
      ogRuleManyReq: 'عند الطلب، يختار الزبون خياراً واحداً على الأقل.',
      ogRuleManyOpt: 'عند الطلب، يختار الزبون ما يشاء من الخيارات، أو لا شيء.',
      ogChoicesHelp: 'يُضاف المبلغ الإضافي إلى سعر الصنف. اتركه فارغاً إذا كان الخيار مشمولاً.',
      ogMark: 'علامة',
      ogMarkPick: 'اختر علامة',
      ogNoMark: 'بدون علامة',
      ogMarkHelp: 'العلامة رمز تعبيري يظهر على شاشة المطبخ. اختيارية.',
      ogChoiceName: 'الخيار',
      ogSupplement: 'مبلغ إضافي',
      ogRemoveChoice: 'إزالة هذا الخيار',
      ogNameRequired: 'أعطِ المجموعة اسماً.',
      ogChoicesRequired: 'أضف خياراً واحداً على الأقل باسم.',
      ogChoiceUnnamed: 'سمِّ كل خيار، أو أزله.',
      confirmDeleteDefault: 'سيؤدي هذا إلى حذف هذا العنصر نهائياً.',
      extraPricePlaceholder: 'سعر إضافي (MAD)',
      newSubcategoryTitle: 'تصنيف فرعي جديد',
      subNamePlaceholder: 'الاسم (مثال: كوكيز، كيك، كلاسيكيات)',
      renameSubcategoryTitle: 'إعادة تسمية التصنيف الفرعي',
      newNameLabel: 'الاسم الجديد',
      deleteSubcategoryConfirm: 'حذف « {name} » ؟',
      deleteSubcategoryDesc: 'سيبقى {n} منتج في هذا القسم وسينتقل إلى "غير مصنف".',
      deleteCategoryConfirm: 'حذف قسم « {name} » ؟',
      deleteCategoryDesc: 'سيتم حذف هذا القسم ومنتجاته البالغ عددها {n} نهائياً.',
      deleteItemConfirm: 'حذف « {name} » ؟',
      deleteGroupConfirm: 'حذف « {name} » ؟',
      addStationTitle: 'إضافة محطة تحضير',
      renameStationTitle: 'إعادة تسمية المحطة',
      stationNameLabel: 'اسم المحطة',
      deleteStationConfirm: 'حذف « {name} » ؟',
      stationDefault: 'هذه المحطة',
      scanUnavailable: 'المسح غير متوفر',
      reloadPage: 'أعد تحميل الصفحة.',
      createSubFirstToast: 'أنشئ فئة فرعية أولاً',
      useAddSubHelp: 'استخدم « + تصنيف فرعي ».',
      allClassifiedToast: 'تم تصنيف كل المنتجات',
      noUnclassifiedItems: 'لا توجد منتجات بدون تصنيف فرعي.',
      classifyTag: 'تصنيف',
      classifyTitle: 'تصنيف المنتجات',
      articlesWithoutSub: 'منتجات بدون تصنيف فرعي',
      articleWithoutSub: 'منتج بدون تصنيف فرعي',
      classifyInstantSaveNotice: 'يتم حفظ كل اختيار فوراً.',
      chooseSelectPlaceholder: 'اختيار',
      sectionsTitle: 'الأقسام',
      availableToggle: 'متاح للبيع: {name}',
      newItemShort: 'منتج',
      emptySectionText: 'لا توجد منتجات في هذا القسم بعد.',
    },
    fr: {
      title: 'Menu & modificateurs',
      loading: 'Chargement du menu…',
      home: 'Accueil',
      articles: 'articles',
      article: 'article',
      sections: 'sections',
      section: 'section',
      tabMenu: 'Menu & modificateurs',
      tabStations: 'Postes de préparation',
      tabRecipes: 'Recettes',
      tabPerformance: 'Performance',
      tabHours: 'Heures de pointe',
      tabAlerts: 'Alertes 86',
      tabNfc: 'Tags NFC',
      tabCaisse: 'Réglages caisse',
      tabPromos: 'Promotions',
      caisseTitle: 'Réglages caisse',
      caisseSub: 'Livraison, conditions de devis ou formats de gâteau : ce que la carte ne dit pas, lu par votre caisse.',
      scanMenu: 'Scanner un menu',
      importExcel: 'Importer Excel',
      translateMenu: 'Traductions',
      tabI18n: 'Traductions',
      i18nTitle: 'La carte dans la langue de chacun',
      i18nReview: 'Relisez chaque langue avant de partager la carte, surtout les allergènes et les ingrédients. Les traductions automatiques sont des suggestions. Corrigez une cellule pour valider votre formulation, puis relisez-la après toute modification du texte source.',
      i18nHint: 'Kiwi AI traduit uniquement les nouveautés et les modifications dans les langues choisies pour cette carte ; le texte d’origine n’est jamais modifié. Corrigez une cellule pour la reprendre : une correction n’est plus jamais écrasée.',
      i18nFill: 'Traduire ce qui manque',
      i18nRedo: 'Tout retraduire',
      i18nRedoConfirm: 'Retraduire toute la carte ?',
      i18nRedoDesc: 'Vos corrections manuelles sont conservées.',
      i18nAddLang: 'Ajouter une langue au menu',
      i18nChooseLang: 'Choisissez la langue dont vos clients ont besoin',
      i18nChooseHint: 'La langue est traduite une fois, puis reste modifiable.',
      i18nClosePicker: 'Fermer',
      i18nAvailable: '{n} langues disponibles',
      i18nRemoveLang: 'Retirer',
      i18nRemoveConfirm: 'Retirer cette langue ?',
      i18nRemoveManual: '{n} correction(s) manuelle(s) seront supprimées définitivement.',
      i18nOriginal: 'Texte d’origine',
      i18nSections: 'Sections',
      i18nItems: 'Articles',
      i18nOptions: 'Options',
      i18nDesc: 'description',
      i18nStatusOk: 'validés',
      i18nStatusUnreviewed: 'à vérifier',
      i18nApprove: 'Valider le texte et les allergènes',
      i18nStatusStale: 'à revoir',
      i18nStatusMissing: 'manquants',
      i18nStatusManual: 'corrigé à la main',
      i18nUpToDate: 'Toutes les traductions sont à jour.',
      i18nDone: '{n} traduction(s) ajoutée(s).',
      i18nQuota: 'Quota de traduction atteint pour aujourd’hui. Reprise automatique plus tard.',
      i18nError: 'Traduction impossible pour le moment. Nouvel essai automatique dans quelques minutes.',
      i18nDemo: 'Les traductions automatiques sont réservées aux comptes commerçants connectés.',
      i18nBusy: 'Traduction en cours · {n} entrée(s)',
      i18nEmpty: 'Ajoutez des articles pour les traduire.',
      all: 'Tous',
      allWithCount: 'Tout · {n}',
      uncategorizedWithCount: 'À classer · {n}',
      addSubCat: '+ Sous-catégorie',
      classifyCount: 'Classer {n} article{s}',
      rename: 'Renommer',
      editGroup: 'Modifier les choix',
      delete: 'Supprimer',
      withoutSubcat: 'Sans sous-catégorie',
      noSection: 'Sans section',
      kitchen: 'Cuisine',
      counter: 'Comptoir',
      stepCount: '{n} étape(s)',
      optGroupCount: '{n} groupe(s) d’options',
      reuse: 'Réutiliser',
      standalone: 'Vendable individuellement',
      formulaOnly: 'Désactivé, l’article est réservé aux formules et n’apparaît plus seul sur la carte.',
      formulaChoicePhoto: 'Afficher la photo dans les formules',
      formulaChoicePhotoHelp: 'Dans OrderPro, la photo de cet article apparaît lorsqu’il devient un choix de formule.',
      archive: 'Archiver',
      restore: 'Restaurer',
      archived: 'Archivé',
      formulaOnlyBadge: 'Réservé aux formules',
      step: 'Étape',
      extra: 'Supplément',
      deleteStep: 'Supprimer cette étape',
      removeChoice: 'Retirer ce choix',
      selectionRule: 'Règle de sélection',
      archivedGroup: 'Articles archivés',
      formula: 'FORMULE',
      searchPlaceholder: 'Rechercher un article…',
      moveLeft: '← Avant',
      moveRight: 'Après →',
      renameSection: 'Renommer la section',
      reorderDishes: 'Réordonner les plats',
      moveDish: 'Déplacer le plat',
      reorderPick: 'Section',
      reorderHint: 'Glissez un plat ou choisissez sa position. La caisse, le menu QR et les commandes en ligne suivent cet ordre.',
      deleteSection: 'Supprimer la section',
      newSection: '+ Nouvelle section',
      newItem: '+ Nouvel article',
      emptyMenuTitle: 'Votre menu est vide',
      emptyMenuDesc: 'Créez une section, puis ajoutez votre premier article. Aucun contenu de démonstration ne sera ajouté.',
      createSectionBtn: 'Créer une section',
      emptyItemsDesc: 'Vos sections sont prêtes. Ajoutez votre premier article. Aucun contenu de démonstration ne sera ajouté.',
      addFirstItemBtn: 'Ajouter un article',
      noItemMatch: 'Aucun article ne correspond.',
      modAndOpts: 'Modificateurs & options',
      newGroupBtn: '+ Nouveau groupe d’options',
      noOptGroups: 'Aucun groupe d’options.',
      required: 'Obligatoire',
      optional: 'Optionnel',
      manyChoices: 'Plusieurs choix',
      oneChoice: 'Un seul choix',
      usedByCount: 'Utilisé par {n} article(s)',
      noChoices: 'Aucun choix',
      stationsTitle: 'Postes de préparation',
      stationsSub: 'Une section, un poste. Tous les tickets restent visibles dans l’onglet Toutes du KDS.',
      addStation: 'Ajouter un poste',
      defaultStationFallback: 'Cuisine · reçoit le reste',
      routingBySection: 'Routage par section',
      defaultRoute: '{name} · par défaut',
      addFirstStation: 'Ajoutez votre premier poste.',
      createSectionsForRouting: 'Créez des sections pour définir leur routage.',
      recipesTitle: 'Recettes & coûts par plat',
      recipesSub: 'Définissez les quantités exactes pour relier chaque vente au stock et calculer vos marges.',
      recipesCompletedCount: '{done} / {total} recettes complétées',
      ingredientCount: '{n} ingrédient(s)',
      viewAndEdit: 'Voir et modifier',
      complete: 'Compléter',
      costSummaryPortion: '{cost} MAD / portion',
      missingCostOrQty: 'Quantités ou coûts à compléter',
      addItemsFirst: 'Ajoutez d’abord des articles.',
      statusToComplete: 'À compléter',
      statusCostIncomplete: 'Coût incomplet',
      statusCosted: 'Recette chiffrée',
      statusCheckStock: 'Stock à vérifier',
      statusToMonitor: 'À surveiller',
      statusCostCompliant: 'Coût conforme',
      nutritionComplete: 'Nutrition complète',
      nutritionIncomplete: 'Nutrition incomplète',
      nutritionShort: 'Nutrition',
      tabNutrition: 'Nutrition',
      nutritionTitle: 'Nutrition et allergènes',
      nutritionSub: 'Calculées depuis les recettes et les fiches du stock ; publiées sur la carte dès que la fiche du plat est complète. Rien ne se saisit ici.',
      nutritionProgress: '{done} / {total} fiches complètes',
      nutritionFilterAll: 'Toutes',
      nutritionFilterTodo: 'À compléter',
      nutritionFilterDone: 'Complètes',
      nutritionFilterHidden: 'Masquées',
      nutritionFilterEmpty: 'Aucun plat dans cet état.',
      nutritionNoRecipe: 'Pas de recette',
      nutritionNoRecipeHint: 'Ajoutez la recette pour calculer.',
      nutritionMissingShort: 'Incomplet : {n} ingrédient(s) à compléter dans Stock',
      nutritionVisibleToggle: 'Visible',
      nutritionHiddenToggle: 'Masquée',
      nutritionDisabledNotice: 'La nutrition est désactivée pour cet établissement (réglage opérateur) : rien n’est publié sur la carte, les fiches restent calculées ici.',
      nutritionHidden: 'Nutrition masquée',
      nutritionAwaitsRecipe: 'Calculée dès que la recette a des ingrédients avec leurs quantités.',
      nutritionDisabled: 'Nutrition désactivée',
      nutritionMissing: 'Incomplet : {n} ingrédient(s) sans fiche nutrition complète',
      nutritionFix: 'Compléter dans Stock',
      nutritionAllergens: 'Allergènes',
      nutritionNone: 'aucun',
      nutritionIndicative: 'Valeurs indicatives par portion, hors options',
      nutritionHide: 'Masquer la nutrition pour ce plat',
      nutritionHideHint: 'La recette reste calculée, mais les clients ne verront pas ces valeurs.',
      allergen_gluten: 'Gluten', allergen_crustaces: 'Crustacés', allergen_oeufs: 'Œufs', allergen_poissons: 'Poissons',
      allergen_arachides: 'Arachides', allergen_soja: 'Soja', allergen_lait: 'Lait', allergen_fruits_a_coque: 'Fruits à coque',
      allergen_celeri: 'Céleri', allergen_moutarde: 'Moutarde', allergen_sesame: 'Sésame', allergen_sulfites: 'Sulfites',
      allergen_lupin: 'Lupin', allergen_mollusques: 'Mollusques',
      perfTitle: 'Performance des articles',
      perfSub: 'Popularité, chiffre d’affaires et contribution · 30 derniers jours · données réelles de la caisse.',
      daysCount: '{n} jours',
      rangeLabel: 'Du {from} au {to} · journées commerciales',
      menuItemsOnly: 'plats de la carte actuelle uniquement',
      freeAmountItem: 'Article libre',
      freeAmountSection: 'Montant libre · hors carte',
      offMenuSection: 'Hors de la carte actuelle',
      freeAmountReadout: 'Aucune recette possible',
      offMenuReadout: 'Plat retiré, renommé ou non reconnu',
      ledgerGross: 'Ventes brutes',
      ledgerTickets: '{n} tickets',
      ledgerTickets1: '{n} ticket',
      ledgerRefunds: 'Remboursements',
      ledgerRefundCount: '{n} remboursements',
      ledgerRefundCount1: '{n} remboursement',
      ledgerNet: 'Chiffre d’affaires net',
      ledgerNetSub: 'ventes brutes moins remboursements',
      ledgerEligible: 'CA analysable en recettes',
      ledgerEligibleSub: '{share} des ventes brutes · plats de la carte',
      ledgerLoading: 'L’historique des ventes est encore en cours de chargement sur cet appareil. Ces chiffres sont partiels, pas 30 jours complets.',
      ledgerUnknown: 'Cet appareil ne peut pas confirmer que l’historique des ventes est complet. Considérez ces chiffres comme partiels.',
      ledgerDuplicates: '{n} règlement(s) en double exclu(s) ({amount}) : le même ticket est arrivé plusieurs fois, à la même milliseconde, avec le même montant et les mêmes articles.',
      ledgerOffMenu: '{amount} de lignes sont hors de la carte actuelle, dont {free} en articles libres. Elles comptent dans les ventes mais ne peuvent pas avoir de recette.',
      ledgerUnitemised: '{amount} de ventes ne sont pas expliqués par les lignes d’articles (frais de service, ou {n} tickets sans détail).',
    ledgerDiscounts: '{amount} de remises au ticket, réparties au prorata sur les lignes de leur ticket, comme la base de TVA.',
    ledgerVatBasis: 'Contribution calculée hors TVA ({rate} % incluse dans les prix).',
    ledgerTodayCost: 'Ces ventes n’ont pas gelé leur coût : le coût actuel de chaque plat est appliqué au passé. Un changement de prix d’achat modifiera ces contributions.',
    costSrcRecipe: 'Recette',
    costSrcFrozen: 'Coût gelé à la vente',
    costSrcFlat: 'Coût saisi',
    costSrcVariant: 'Prix d’achat',
    costObserved: 'observé {amount}',
    salesTitle: 'Ventes par catégorie et par article',
    salesSub: 'Ce que chaque ligne de ticket a encaissé, TTC, après répartition des remises du ticket sur ses lignes. Une formule garde son prix ; ses composants ne comptent qu’en quantité.',
    salesPeriodAria: 'Période',
    salesPresetToday: 'Aujourd’hui',
    salesPresetYesterday: 'Hier',
    salesPreset7: '7 jours',
    salesPreset30: '30 jours',
    salesPresetMonth: 'Ce mois-ci',
    salesPresetLastMonth: 'Mois dernier',
    salesDayLabel: '{day} · journée commerciale',
    salesAvgTicket: 'Ticket moyen',
    salesAvgTicketSub: 'ventes brutes ÷ tickets',
    salesByCategory: 'Par catégorie',
    salesByItem: 'Par article',
    salesColCategory: 'Catégorie',
    salesColQty: 'Vendus',
    salesColRevenue: 'Encaissé',
    salesColShare: 'Part',
    salesColAvgPrice: 'Prix moyen',
    salesItemsCount: '{n} articles',
    salesItemsCount1: '{n} article',
    salesInFormula: '{n} en formule',
    salesAtZero: '{n} à 0 MAD',
    salesUnsold: '{n} plats de la carte sans vente sur la période.',
    salesUnsold1: '{n} plat de la carte sans vente sur la période.',
    salesNone: 'Aucune vente sur cette période',
    salesNoneDesc: 'Choisissez une autre période, ou revenez après le prochain service.',
    salesLoading: 'L’historique des ventes est encore en cours de chargement sur cet appareil. Ces chiffres sont partiels pour cette période.',
    salesOffline: 'Hors ligne : ce sont les ventes que cet appareil détient. Elles seront complétées à la reconnexion.',
    salesError: 'Les ventes n’ont pas pu être lues sur cet appareil. Rechargez la page ; rien n’a été modifié.',
    salesShareNote: 'Les parts portent sur les lignes d’articles ({amount}). Remboursements et montants sans détail sont dans le bandeau ci-dessus, pas dans ces tableaux.',
      ledgerRefundLines: 'Les remboursements réduisent le chiffre net. Ils ne sont pas retirés plat par plat du tableau ci-dessous.',
      noItemsToAnalyze: 'Aucun article à analyser',
      noItemsToAnalyzeDesc: 'Ajoutez vos plats dans Menu & modificateurs. Les performances apparaîtront après les premières ventes.',
      noSalesYet: 'Pas encore de ventes par article',
      noSalesYetDesc: 'Dès que la caisse enregistre des tickets détaillés, Kiwi classe automatiquement les plats.',
      completeRecipesForProfit: 'Complétez les recettes pour voir la contribution de chaque plat',
      completeRecipesForProfitDesc: 'Les ventes sont bien reçues. Il manque le coût de chaque plat pour comparer ce que chacun rapporte.',
      analyzedRevenue: 'CA des plats analysés',
      itemsSold: 'articles vendus',
      itemSold: 'article vendu',
      grossProfitCalc: 'Contribution calculée',
      recipesSoldAndCosted: '{n} recette(s) vendue(s) et chiffrée(s)',
      costCoverage: 'Couverture des coûts',
      costCoverageSub: 'part du CA avec recette complète',
      grossProfitPerItem: 'Contribution par article',
      popularityXDays: 'Popularité · ventes sur {n} jours',
      perfDotSizeHint: 'Taille du point = chiffre d’affaires',
      perfAxesHint: 'Repères = 70 % d’une part équitable des ventes, et la contribution moyenne de votre carte pondérée par les ventes',
      perfClickHint: 'Cliquez sur un article pour ouvrir sa recette',
      quadStar: 'Stars',
      quadStarHint: 'Populaires, forte contribution',
      quadStarAction: 'À mettre en avant',
      quadPlow: 'Plowhorses',
      quadPlowHint: 'Populaires, contribution faible',
      quadPlowAction: 'Revoir coût ou prix',
      quadPuzzle: 'Puzzles',
      quadPuzzleHint: 'Forte contribution, peu commandés',
      quadPuzzleAction: 'Mieux les positionner',
      quadDog: 'Dogs',
      quadDogHint: 'Peu commandés, contribution faible',
      quadDogAction: 'Retravailler ou retirer',
      matrixLabelStar: 'STARS',
      matrixHintStar: 'Forte contribution · volume fort',
      matrixLabelPlow: 'À OPTIMISER',
      matrixHintPlow: 'Populaire · contribution faible',
      matrixLabelPuzzle: 'À DÉVELOPPER',
      matrixHintPuzzle: 'Forte contribution · volume faible',
      matrixLabelDog: 'À REVOIR',
      matrixHintDog: 'Contribution et volume faibles',
      legendStar: 'Stars',
      legendPlow: 'À optimiser',
      legendPuzzle: 'À développer',
      legendDog: 'À revoir',
      colItem: 'Article',
      colSold: 'Vendus',
      colRevenue: 'Chiffre d’affaires',
      colRevenueDesc: 'de CA',
      colUnitCost: 'Coût / article',
      colProfit: 'Contribution',
      colProfitDesc: 'de contribution',
      colMargin: 'Taux de contribution',
      colMarginDesc: 'de taux de contribution',
      colReadout: 'Lecture',
      completeRecipeLink: 'Compléter la recette',
      estimateLabel: 'Fiche de coût · {amount}',
      estimateStale: 'prix de plus de 90 jours',
      estimateIncomplete: 'fiche incomplète',
      insightsTitle: 'À faire',
      insightsSub: 'Tiré des ventes et des coûts ci-dessus. Rien ne change sans vous.',
      insightUncosted: '{amount} de ventes sans coût connu ({n} plats) : complétez leur recette pour voir ce qu’ils rapportent.',
      insightObservedGap: '{item} : coût observé {observed}, recette {theory} ({gap}). Vérifiez les quantités utilisées et les pertes.',
      insightEstimateGap: '{item} : la fiche de coût dit {estimate}, la recette {theory} ({gap}). L’une des deux n’est plus à jour.',
      insightPlow: '{items} : très commandés, contribution faible. Revoyez le prix ou la portion.',
      insightPuzzle: '{items} : forte contribution, peu commandés. Mettez-les en avant sur la carte et auprès des serveurs.',
      insightStale: 'Fiches de coût aux prix d’achat de plus de 90 jours : {items}. Mettez les prix à jour.',
      insightNone: 'Rien à signaler sur cette période.',
      insightOpenSheet: 'Ouvrir les fiches de coût',
      rxTitle: 'Recette · {name}',
      rxDesc: '{cat} · {price} prix de vente',
      rxCostPortion: 'Coût par portion',
      rxPrice: 'Prix de vente',
      rxContribution: 'Contribution par portion',
      rxFoodCost: 'Coût matière',
      rxObserved: 'Coût observé',
      rxObservedWait: 'Après les premières ventes suivies en stock',
      rxHT: 'hors TVA',
      rxOfPrice: 'du prix de vente',
      rxStatusOk: 'Recette chiffrée',
      rxStatusTodo: 'Recette à compléter',
      rxStatusWatch: 'Coût à surveiller',
      rxStatusGap: 'Écart à vérifier',
      rxOkHint: 'Le coût observé se comparera à cette recette après les premières ventes.',
      rxGapUp: '{gap} au-dessus du coût prévu. Contrôlez les portions et les sorties de stock.',
      rxGapDown: '{gap} sous le coût prévu. Contrôlez les portions et les sorties de stock.',
      rxMissing: '{n} à compléter : {names}',
      rxToStock: 'Compléter dans Stock',
      rxComposition: 'Composition',
      rxCompositionSub: 'Quantités pour toute la recette. Elles pilotent le coût, le stock et la nutrition.',
      rxPortions: 'Portions',
      rxPrep: 'Préparation',
      rxMin: 'min',
      rxIngredient: 'Ingrédient',
      rxQty: 'Quantité',
      rxLineCost: 'Coût',
      rxLinked: 'En stock · {price} / {unit}',
      rxUnlinked: 'Pas dans le stock',
      rxNoPrice: 'Sans prix dans le stock',
      rxUnitMismatch: 'Unité non convertible vers le stock ({unit})',
      rxNoQty: 'Quantité manquante',
      rxAdd: 'Ajouter un ingrédient',
      rxRemove: 'Retirer {name}',
      rxIngPh: 'Ingrédient du stock',
      rxChoose: 'Unité',
      rxMethod: 'Méthode',
      rxSteps: 'Étapes',
      rxStepsPh: 'Une étape par ligne',
      rxNotes: 'Notes d’équipe',
      rxNotesPh: 'Allergènes, calibrage, dressage…',
      rxNoStock: 'Ajoutez d’abord vos matières premières dans Stock : leur prix est ce qui chiffre la recette.',
      rxToastQtyT: 'Quantités manquantes',
      rxToastQty: 'Ajoutez au moins un ingrédient avec une quantité.',
      rxToastUnitT: 'Unités manquantes',
      rxToastUnit: 'Choisissez une unité pour chaque ingrédient.',
      rxSavedT: 'Recette enregistrée',
      rxSaved: 'Stock, coûts et nutrition mis à jour.',
      rxAtLeast: 'au moins {amount}',
      rxAtLeastSub: 'Les lignes sans coût connu ne sont pas comptées.',
      itRule: 'Le client en choisit {min} à {max}',
      itAlone: 'À la carte · {price}',
      itChoiceOne: '1 choix',
      itChoiceCount: '{n} choix',
      itCollapse: 'Replier l’étape',
      itExpand: 'Déplier l’étape',
      itAddChoice: 'Ajouter un choix',
      itSecItem: 'Article',
      itSecItemHelp: 'Ce que le client voit sur la carte et ce qu’il paie.',
      itSecOptionsHelp: 'Les groupes proposés quand on commande cet article : cuisson, sauce, accompagnement.',
      itSecFormula: 'Formule',
      itPrice: 'Prix',
      itDescPh: 'Ex. Soupe de pois chiches et lentilles, servie avec des dattes.',
      itNameRequired: 'Donnez un nom à l’article pour l’enregistrer.',
      itApplyTpl: 'Copier',
      itSaveTpl: 'Enregistrer comme modèle',
      itPhoto: 'Photo',
      itVideo: 'Vidéo',
      itAvailHelp: 'Désactivé, l’article passe en rupture (86) et ne se commande plus.',
      itRuleMinMax: 'Le minimum ({min}) dépasse le maximum ({max}).',
      itStepNoChoice: 'Ajoutez au moins un plat à cette étape.',
      itStepTooFew: '{n} plats pour un minimum de {min} : ajoutez des plats ou baissez le minimum.',
      itStepTooFew1: '{n} plat pour un minimum de {min} : ajoutez des plats ou baissez le minimum.',
      itNoStep: 'Aucune étape. Ajoutez-en une ci-dessous.',
      itFormulaCopied: 'Formule copiée',
      itFormulaEmpty: 'Formule vide',
      itFormulaEmptyHelp: 'Ajoutez au moins un choix avant de l’enregistrer comme modèle.',
      itTemplateName: 'Nom du modèle',
      itFormulaSaved: 'Modèle enregistré',
      itSaved: 'Carte mise à jour',
      itNoMedia: 'Aucune photo ni vidéo',
      itMediaRemoved: 'Média retiré. Enregistrez pour confirmer.',
      itDefaultStep: 'Choix',
      itUploadUnavailable: 'Stockage des médias indisponible.',
      itUploading: 'Envoi…',
      itUploadReady: 'Média prêt. Enregistrez pour le garder.',
      itUploadFailed: 'Envoi impossible. Réessayez.',
      mxTitle: 'Matrice de la carte',
      mxSub: 'Chaque point est un plat vendu et chiffré. Plus à droite : il se vend plus. Plus haut : il rapporte plus par article. Populaire : au moins 70 % de sa part équitable des ventes. Rentable : au moins la contribution moyenne de votre carte, pondérée par ce qui se vend.',
      mxMedianQty: 'populaire dès {n} vendus',
      mxMedianProfit: 'moyenne · {amount}',
      mxPerUnit: '{amount} par article',
      mxSoldN: '{n} vendus',
      mxMore: '+ {n} autres',
      mxEmptyQuad: 'Aucun plat ici',
      mxTooFew: 'Il faut au moins deux plats vendus et entièrement chiffrés pour les comparer. Complétez les recettes des plats que vous vendez.',
      mxCluster: '{n} plats au même endroit',
      mxBasis: 'Calculé sur {n} plats',
      mxAxisY: 'Contribution par article',
      mxAxisX: 'Vendus · {n} derniers jours',
      mxSize: 'Taille du point = chiffre d’affaires',
      mxRateSub: 'du chiffre d’affaires des plats chiffrés',
      perfDetail: 'Détail par article',
      pairsTitle: 'Souvent pris ensemble',
      pairsSub: 'Les plats qui se retrouvent sur un même ticket plus souvent que le hasard. De quoi composer une formule, ou apprendre à l’équipe à proposer le second.',
      pairsFew: 'Pas encore assez de tickets pour le dire : {n} sur les {min} nécessaires.',
      pairsNone: 'Aucune paire ne revient plus souvent que le hasard sur cette période.',
      pairsLine: '{pct} des tickets avec {a} prennent aussi {b}',
      pairsMeta: 'ensemble sur {n} tickets · {lift}× le hasard',
      mxContribution: '{amount} de contribution',
      recipeDraftTitle: 'Brouillon, non enregistré',
      recipeDraftFrom: 'Tiré de la fiche de coût « {name} ». Vérifiez chaque ingrédient face à votre stock, puis enregistrez : d’ici là, rien ne change.',
      recipeDraftExisting: 'La recette actuelle reste en place tant que vous n’enregistrez pas.',
      insightOpenRecipe: 'Ouvrir la recette',
      insightUncosted1: '{amount} de ventes sans coût connu (1 plat) : complétez sa recette pour voir ce qu’il rapporte.',
      marginMissing: 'Contribution inconnue',
      noSaleRecorded: 'Aucune vente',
      hoursTitle: 'Performance par moment de la journée',
      hoursSub: 'Quels articles se vendent quand · {n} derniers jours · données réelles de la caisse',
      hoursObserved: 'Heures réelles des ventes · horaires d’ouverture non renseignés',
      setHoursPrompt: 'Renseignez les horaires du restaurant',
      setHoursPromptDesc: 'Kiwi crée les moments de la journée à partir des horaires enregistrés. Aucun créneau n’est inventé.',
      noServiceToAnalyze: 'Aucun service à analyser',
      noServiceToAnalyzeDesc: 'Les horaires actuels ne croisent ni le matin, ni le midi, ni le soir. Vérifiez les horaires du restaurant dans Réglages.',
      generatedRevenue: 'CA généré',
      inPeriod: 'sur le créneau',
      topItem: 'Top article',
      top10Items: 'Top 10 articles · {label}',
      noSalesInPeriod: 'Pas encore de ventes sur ce créneau',
      noSalesInPeriodDesc: 'Les ventes détaillées apparaîtront ici automatiquement.',
      itemsWithPeak: 'Articles avec un moment fort',
      peakInsightTag: 'LECTURE KIWI · {label}',
      peakInsightTitle: '{item} porte ce service',
      peakInsightBody: '{qty} unité(s), soit {share} % des articles vendus sur ce créneau. {peakShare} % de ses ventes analysées ont lieu pendant {period}.',
      peakNotableBody: '{share} % de ses {total} ventes ont lieu pendant {period} ({hours}).',
      alerts86Title: 'Alertes 86',
      alerts86Sub: 'Indisponibilités partagées avec la caisse et OrderPro.',
      reactivate: 'Réactiver',
      no86Alerts: 'Aucune alerte 86.',
      unavailableBadge: '86 · indisponible',
      nfcTitle: 'Tags NFC',
      nfcSub: 'Gérez les tags qui ouvrent votre menu OrderPro.',
      nfcUnavailable: 'Tags NFC indisponibles',
      nfcUnavailableDesc: 'Activez OrderPro pour cet établissement afin de gérer ses tags.',
      editSectionTitle: 'Modifier la section',
      newSectionTitle: 'Nouvelle section',
      sectionNameLabel: 'Nom de la section',
      sectionNamePlaceholder: 'ex. Boissons',
      stationLabel: 'Poste de préparation',
      cancelBtn: 'Annuler',
      saveBtn: 'Enregistrer',
      doneBtn: 'Terminé',
      editItemTitle: 'Modifier · {name}',
      newItemTitle: 'Nouvel article',
      nameLabel: 'Nom',
      priceLabel: 'Prix (MAD)',
      sectionLabel: 'Section',
      availabilityLabel: 'Disponibilité',
      availableOpt: 'Disponible',
      unavailableOpt: '86 · indisponible',
      descLabel: 'Description',
      mediaLabel: 'Photo ou vidéo',
      addPhotoBtn: 'Ajouter une photo',
      addVideoBtn: 'Ajouter une vidéo',
      removeMediaBtn: 'Retirer',
      mediaStatusKept: 'Média actuel conservé.',
      noMediaStatus: 'Aucun média.',
      itemOptionsLabel: 'Options de cet article',
      createOptGroupFirst: 'Créez d’abord un groupe d’options.',
      isFormulaLabel: 'Formule / menu composé (étapes au choix)',
      isFormulaHelp: 'Permet de composer un menu avec étapes (entrée, plat, boisson...) lors de la prise de commande.',
      formulaTemplatePlaceholder: 'Choisir une formule déjà enregistrée…',
      noFormulaTemplates: 'Aucune formule enregistrée',
      copyTemplateBtn: 'Copier dans cet article',
      saveTemplateBtn: 'Enregistrer cette formule comme modèle réutilisable',
      addStepBtn: 'Ajouter une étape',
      stepTitlePlaceholder: 'Titre de l\'étape (ex. La boisson)',
      minLabel: 'Min',
      maxLabel: 'Max',
      noChoicesInStep: 'Aucun choix dans cette étape.',
      chooseItemPlaceholder: 'Choisir un article…',
      addChoiceBtn: 'Ajouter',
      noItemsOnMenuFormulaNotice: 'Aucun produit sur la carte pour l\'instant. Créez d\'abord vos produits (ex. Café noir, Croissant), puis revenez composer la formule : les choix se sélectionnent dans la liste, jamais à la main.',
      saveAndCreateItemBtn: 'Enregistrer et créer un produit',
      allChosenNotice: 'Tous les produits de la carte sont déjà proposés dans cette étape.',
      editGroupTitle: 'Modifier le groupe d’options',
      newGroupTitle: 'Nouveau groupe d’options',
      groupNameLabel: 'Nom du groupe',
      groupNamePlaceholder: 'ex. Cuisson, Accompagnement, Taille',
      groupTypeLabel: 'Type de choix',
      groupRequiredLabel: 'Obligation',
      groupRequiredOpt: 'Obligatoire (au moins 1 choix)',
      groupOptionalOpt: 'Optionnel (le client peut ignorer)',
      choicesLabel: 'Choix proposés',
      addChoicePlaceholder: 'ex. Saignant, Frites, Grand',
      addChoiceBtnLabel: 'Ajouter un choix',
      ogOptional: 'Facultatif',
      ogRequired: 'Obligatoire',
      ogRuleOneReq: 'À la commande, le client choisit exactement une option.',
      ogRuleOneOpt: 'À la commande, le client choisit une option, ou aucune.',
      ogRuleManyReq: 'À la commande, le client choisit au moins une option.',
      ogRuleManyOpt: "À la commande, le client choisit autant d'options qu'il veut, ou aucune.",
      ogChoicesHelp: "Le supplément s'ajoute au prix de l'article. Laissez vide quand le choix est inclus.",
      ogMark: 'Repère',
      ogMarkPick: 'Choisir un repère',
      ogNoMark: 'Aucun repère',
      ogMarkHelp: "Le repère est un emoji affiché sur l'écran cuisine. Facultatif.",
      ogChoiceName: 'Choix',
      ogSupplement: 'Supplément',
      ogRemoveChoice: 'Retirer ce choix',
      ogNameRequired: 'Donnez un nom au groupe.',
      ogChoicesRequired: 'Ajoutez au moins un choix avec un nom.',
      ogChoiceUnnamed: 'Nommez chaque choix, ou retirez-le.',
      confirmDeleteDefault: 'Cette action supprimera définitivement cet élément.',
      extraPricePlaceholder: 'Supplément (MAD)',
      newSubcategoryTitle: 'Nouvelle sous-catégorie',
      subNamePlaceholder: 'Nom (ex. Cookies, Gâteaux, Classics)',
      renameSubcategoryTitle: 'Renommer la sous-catégorie',
      newNameLabel: 'Nouveau nom',
      deleteSubcategoryConfirm: 'Supprimer « {name} » ?',
      deleteSubcategoryDesc: '{n} article(s) resteront dans la section et passeront dans « À classer ».',
      deleteCategoryConfirm: 'Supprimer la section « {name} » ?',
      deleteCategoryDesc: 'Cette section et ses {n} article(s) seront supprimés définitivement.',
      deleteItemConfirm: 'Supprimer « {name} » ?',
      deleteGroupConfirm: 'Supprimer « {name} » ?',
      addStationTitle: 'Ajouter un poste',
      renameStationTitle: 'Renommer le poste',
      stationNameLabel: 'Nom du poste',
      deleteStationConfirm: 'Supprimer « {name} » ?',
      stationDefault: 'ce poste',
      scanUnavailable: 'Scan indisponible',
      reloadPage: 'Rechargez la page.',
      createSubFirstToast: 'Créez d’abord une sous-catégorie',
      useAddSubHelp: 'Utilisez « + Sous-catégorie ».',
      allClassifiedToast: 'Tout est classé',
      noUnclassifiedItems: 'Aucun article sans sous-catégorie.',
      classifyTag: 'CLASSEMENT',
      classifyTitle: 'Classer les articles',
      articlesWithoutSub: 'articles sans sous-catégorie',
      articleWithoutSub: 'article sans sous-catégorie',
      classifyInstantSaveNotice: 'Chaque choix est enregistré immédiatement.',
      chooseSelectPlaceholder: 'Choisir',
      sectionsTitle: 'Sections',
      availableToggle: 'En vente : {name}',
      newItemShort: 'Article',
      emptySectionText: 'Aucun article dans cette section pour l’instant.',
    }
  };

  const lang=()=>{
    try{
      return (window.KiwiI18n?.getLang?.())||(window.KiwiMenuI18n?.lang?.())||(typeof localStorage!=='undefined'?localStorage.getItem('kiwiLang'):'')||'fr';
    }catch(_){return 'fr';}
  };
  function ui(key, params) {
    const l = lang();
    /* "1 tickets", "0 remboursements": a count takes the singular key
       (`key1`) when one exists. French counts 0 and 1 as singular. */
    if (params && typeof params.n === 'number' && (l === 'fr' ? Math.abs(params.n) < 2 : params.n === 1)) {
      const one = (UI_I18N[l] && UI_I18N[l][key + '1']) || (l === 'fr' && UI_I18N.fr[key + '1']);
      if (one) key = key + '1';
    }
    let text = (UI_I18N[l] && UI_I18N[l][key]) || (UI_I18N.fr && UI_I18N.fr[key]) || key;
    if (params) {
      for (const [k, v] of Object.entries(params)) {
        text = text.replace(new RegExp(`\\{${k}\\}`, 'g'), v);
      }
    }
    return text;
  }
  const t=(str)=>window.KiwiMenuI18n?window.KiwiMenuI18n.t(str,lang()):str;
  const icons={caisse:'calculate',menu:'menu',languages:'translate',station:'skillet',book:'menu_book',leaf:'eco',chart:'bar_chart',clock:'schedule',alert:'warning',tag:'sell',promo:'percent',plus:'add',edit:'edit',trash:'delete',archive:'archive',restore:'settings_backup_restore',more:'more_vert'};
  const catalogText=(key,fr)=>window.KiwiCatalogUI?.text(key,fr)||fr;
  const catalogLabel=(key,fr)=>window.KiwiCatalogUI?.label(key,fr)||esc(fr);
  const catalogIcon=(name)=>`<img class="catalog-icon" draggable="false" src="assets/icons/material/${name}.svg" alt="" aria-hidden="true"/>`;
  const ic=(n)=>`<i data-icon="${icons[n]||icons.menu}" style="width:14px;height:14px" aria-hidden="true"></i>`;
  const pickerSearchIcon='<svg viewBox="0 -960 960 960" aria-hidden="true"><path d="M784-120 532-372q-30 24-69 38t-83 14q-109 0-184.5-75.5T120-580q0-109 75.5-184.5T380-840q109 0 184.5 75.5T640-580q0 44-14 83t-38 69l252 252-56 56ZM380-400q75 0 127.5-52.5T560-580q0-75-52.5-127.5T380-760q-75 0-127.5 52.5T200-580q0 75 52.5 127.5T380-400Z"/></svg>';
  const pickerChevronIcon='<svg viewBox="0 -960 960 960" aria-hidden="true"><path d="M480-360 280-560l56-56 144 144 144-144 56 56-200 200Z"/></svg>';
  const toast=(t,d,type='success')=>window.Kiwi?.toast?.(t,{desc:d||'',type});
  const TAB_ICONS={menu:'restaurant',i18n:'translate',stations:'soup_kitchen',recipes:'menu_book',nutrition:'eco',performance:'bar_chart',hours:'schedule',alerts:'warning',nfc:'nfc',caisse:'point_of_sale',promos:'sell'};
  /* The open tab is the page's own state, never the DOM's: a re-render, a
     store notification or a poller tick repaints the same tab (#0149). It also
     survives leaving the page and a reload within the session. */
  function setTab(k){tab=k;try{sessionStorage.setItem('kiwiMenuTab',k);}catch(_){}}
  function tabList(){
    return [['menu',ui('tabMenu')],['i18n',ui('tabI18n')],['stations',ui('tabStations')],['recipes',ui('tabRecipes')],['nutrition',ui('tabNutrition')]].concat(promosOn()?[['promos',ui('tabPromos')]]:[]).concat([['alerts',ui('tabAlerts')],['nfc',ui('tabNfc')]]).concat(caisseOn()?[['caisse',ui('tabCaisse')]]:[]);
  }
  /* #0149 · Nine tabs do not fit a phone. A sideways strip hides most of them
     and moves under the thumb, so on a phone one button names the open tab
     and lists every tab on tap. Wider screens keep the strip. */
  function tabPicker(){
    const n=D().items.filter(x=>x.avail===false).length,cur=tabList().find(([id])=>id===tab)||tabList()[0];
    return `<button type="button" class="rmw-tabpick" data-action="rmw-tab-pick" aria-haspopup="dialog">${catalogIcon(TAB_ICONS[cur[0]])}<span class="rmw-tabpick-label">${esc(cur[1])}</span>${n&&cur[0]!=='alerts'?`<span class="mi-tab-badge" aria-label="${esc(ui('tabAlerts'))}">${n}</span>`:''}${catalogIcon('expand_more')}</button>`;
  }
  function openTabPicker(){
    const n=D().items.filter(x=>x.avail===false).length;
    const rows=tabList().map(([id,l])=>`<button type="button" class="rmw-tabpick-row${tab===id?' on':''}" data-pick="${id}"${tab===id?' aria-current="page"':''}>${catalogIcon(TAB_ICONS[id])}<span>${esc(l)}</span>${id==='alerts'&&n?`<span class="mi-tab-badge">${n}</span>`:''}${tab===id?catalogIcon('check'):''}</button>`).join('');
    const m=modal({tag:ui("title"),body:`<div class="rmw-tabpick-list">${rows}</div>`,width:420});
    if(!m?.el)return;
    m.el.addEventListener('click',e=>{const b=e.target.closest('[data-pick]');if(!b)return;if(ANALYSIS_TABS[b.dataset.pick]){m.close();openAnalysis(b.dataset.pick);return;}setTab(b.dataset.pick);m.close();render();$('[data-menu-root]')?.scrollIntoView({block:'start'});});
  }
  function tabs(){
    const n=D().items.filter(x=>x.avail===false).length;
    return [
      ['menu', ui('tabMenu'), 'menu'],
      ['i18n', ui('tabI18n'), 'languages'],
      ['stations', ui('tabStations'), 'station'],
      ['recipes', ui('tabRecipes'), 'book'],
      ['nutrition', ui('tabNutrition'), 'leaf'],
    ].concat(promosOn()?[['promos', ui('tabPromos'), 'promo']]:[]).concat([
      ['alerts', ui('tabAlerts'), 'alert'],
      ['nfc', ui('tabNfc'), 'tag']
    ]).concat(caisseOn()?[['caisse', ui('tabCaisse'), 'caisse']]:[]).map(([id,l,i])=>`<button class="mi-pill${tab===id?' on':''}" data-action="rmw-tab" data-tab="${id}">${ic(i)}<span>${esc(l)}</span>${id==='alerts'&&n?`<span class="mi-tab-badge">${n}</span>`:''}</button>`).join('');
  }
  let readyTimer=0,readyTries=0;
  function show(forceRestaurantRoute=false){
    if(!forceRestaurantRoute&&!isRestaurant())return false;
    window.Kiwi?.pageShell?.('menu');document.body.classList.add('page-menu');$$('.sidebar nav a').forEach(a=>a.classList.toggle('active',a.dataset.nav==='menu'));window.Kiwi?.breadcrumb?.(()=>ui('title'));
    const root=$('[data-menu-root]');if(root)root.hidden=false;
    if(!S()||!isRestaurant()){
      if(root)root.innerHTML=`<div class="mi-head"><div><div class="mi-title">${esc(ui('title'))}</div><div class="mi-sub">${esc(ui('loading'))}</div></div></div>`;
      clearTimeout(readyTimer);
      if(readyTries++>100){readyTries=0;if(!isRestaurant()&&legacyMenuHandler){legacyMenuHandler();}return true;}
      readyTimer=setTimeout(()=>{if(document.body.classList.contains('page-menu'))show(true);},50);
      return true;
    }
    clearTimeout(readyTimer);readyTries=0;render();return true;
  }
  function render(){
    if(!isRestaurant())return;
    const root=$('[data-menu-root]');if(!root)return;
    /* #0149 · a full innerHTML swap resets every pill row to scrollLeft 0, so
       tapping a tab visually "jumped back to the first tab". Keep each row
       where the thumb left it, then bring the active tab into view. */
    if(!tabList().some(([id])=>id===tab))tab='menu';
    /* A switch or a row button keeps the keyboard focus across the repaint
       its own click caused. */
    const was=document.activeElement,focusKey=was&&root.contains?.(was)&&was.dataset?.rmwCommand?`[data-rmw-command="${was.dataset.rmwCommand}"][data-arg="${String(was.dataset.arg||'').replace(/["\\]/g,'\\$&')}"]`:null;
    const pillRows = (root.querySelectorAll ? Array.from(root.querySelectorAll('.mi-pill-row')) : []);
    const scrolls = pillRows.map(r => r.scrollLeft || 0);
    const d=D(),v=window.KiwiVenue?.getCurrentVenueData?.()||{};
    root.hidden=false;
    const itemCountStr = d.items.length === 1 ? `1 ${ui('article')}` : `${d.items.length} ${ui('articles')}`;
    const catCountStr = d.cats.length === 1 ? `1 ${ui('section')}` : `${d.cats.length} ${ui('sections')}`;
    const html=`<div class="mi-head"><div><div class="mi-title">${esc(ui('title'))}</div><div class="mi-sub">${itemCountStr} · ${catCountStr} · ${esc(v.name||'')}</div></div><div class="mi-head-acts"><button class="btn-slim" data-action="rmw-menu-scan">${esc(ui('scanMenu'))}</button><button data-activation=write class="btn-slim" data-action="mx-import">${esc(ui('importExcel'))}</button></div></div><div class="mi-filters"><div class="mi-pill-row">${tabs()}</div>${tabPicker()}</div><div class="mi-panel" data-rmw-panel>${panel()}</div>`;
    if(window.KiwiCatalogUI)window.KiwiCatalogUI.replace(root,html);else root.innerHTML=html;
    /* Fresh nodes: the pre-swap rows captured above are detached by the
       replacement, so re-query after painting. */
    (root.querySelectorAll ? Array.from(root.querySelectorAll('.mi-pill-row')) : []).forEach((row, i) => {
      if (scrolls[i]) row.scrollLeft = scrolls[i];
      /* The selected tab stays in view with its outline, even when it lives
         past the right edge. Only scrolls rows that actually overflow. */
      if (row.scrollWidth > row.clientWidth + 1) {
        const on = row.querySelector('.mi-pill.on');
        if (on) { try { on.scrollIntoView({ block: 'nearest', inline: 'center' }); } catch (_) {} }
      }
    });
    if(focusKey&&document.activeElement!==root.querySelector(focusKey))root.querySelector(focusKey)?.focus({preventScroll:true});
    stickyTop(root);
    if(tab==='nfc')window.KiwiOrderProPanel?.mount?.($('[data-rmw-nfc]',root));
    if(tab==='caisse')window.KiwiFoodTradeSettings?.mount?.($('[data-rmw-caisse]',root));
    if(tab==='promos')window.KiwiMenuPromosPanel?.mount?.($('[data-rmw-promos]',root));
  }
  /* The bar holding search and "New item" sticks under the dashboard's own
     sticky header, whatever height the skin gives it. */
  function stickyTop(root){
    const tb=document.querySelector?.('#kw-main > .topbar')||document.querySelector?.('.topbar');let top=0;
    if(tb&&typeof getComputedStyle==='function'&&tb.getBoundingClientRect){const cs=getComputedStyle(tb);if((cs.position==='sticky'||cs.position==='fixed')&&cs.display!=='none')top=Math.max(0,Math.round(tb.getBoundingClientRect().height));}
    root.style?.setProperty?.('--rmw-top',top+'px');
  }
  function panel(){return ({i18n:i18nPanel,stations:stationsPanel,recipes:recipesPanel,nutrition:nutritionPanel,alerts:alertsPanel,nfc:nfcPanel,caisse:caissePanel,promos:promosPanel}[tab]||menuPanel)();}
  /* Performance et Heures de pointe vivent désormais dans « Analyse du menu »
     (finance.js) : Menu & modificateurs garde la configuration de la carte.
     Les panneaux restent ici, inchangés, et la page d'analyse les rend par
     KiwiRestaurantMenuWorkspace.analysis. Un lien vers l'ancien onglet y mène. */
  const ANALYSIS_TABS={performance:1,hours:1};
  function openAnalysis(k){
    if(window.KiwiFinance?.open){window.KiwiFinance.open(k);return true;}
    return false;
  }
  function analysisActive(){return !!(window.KiwiFinance?.isActive?.());}
  function shownItems(){const q=query.trim().toLowerCase();return D().items.filter(x=>(filter==='all'||x.catId===filter)&&(filter==='all'||!subFilter||(subFilter==='__none'?!x.subId:x.subId===subFilter))&&(!q||`${t(x.name)} ${x.name} ${x.desc||''}`.toLowerCase().includes(q)));}
  const subsOf=(cid)=>cat(cid)?.sub||[];
  function subChips(){
    if(filter==='all')return '';
    const subs=subsOf(filter),all=D().items.filter(x=>x.catId===filter);
    const none=all.filter(x=>!x.subId).length;
    const chip=(id,l,on)=>`<button class="mi-subchip${on?' on':''}" data-action="rmw-sub-filter" data-sub="${id}">${l}</button>`;
    let h=chip('',ui('allWithCount', { n: all.length }),!subFilter)+subs.map(s=>chip(s.id,`${esc(t(s.name))} · ${all.filter(x=>x.subId===s.id).length}`,subFilter===s.id)).join('');
    if(subs.length&&none)h+=chip('__none',ui('uncategorizedWithCount', { n: none }),subFilter==='__none');
    h+=`<button data-activation=write class="mi-subchip add" data-action="rmw-sub-add" data-arg="${filter}">${esc(ui('addSubCat'))}</button>`;
    if(subs.length&&none)h+=`<button class="mi-subchip add" data-action="rmw-classify" data-arg="${filter}">${ic('edit')} ${esc(ui('classifyCount', { n: none, s: none > 1 ? 's' : '' }))}</button>`;
    if(subFilter&&subFilter!=='__none'&&subs.some(s=>s.id===subFilter)){
      h+=`<button class="mi-subchip add" data-action="rmw-sub-rename" data-arg="${filter}::${subFilter}">${ic('edit')} ${esc(ui('rename'))}</button><button data-activation=write class="mi-subchip add danger" data-action="rmw-sub-delete" data-arg="${filter}::${subFilter}">${ic('trash')} ${esc(ui('delete'))}</button>`;
    }
    return `<div class="mi-subchips">${h}</div>`;
  }
  const countLabel=(n)=>`${n} ${n>1?ui('articles'):ui('article')}`;
  /* Menu shell (2026-10-19, #0114 #0149 #0150 #0151). Sections sit on a rail
     beside the dishes (a pill row under 900 px, lensed by liquid-lens.js through
     .mi-pill-row). A dish is one row that answers what a service asks of it:
     its price, whether it can be sold right now (the switch is the 86), and how
     many option groups the till will ask for. Search and "New item" ride a bar
     that stays on screen while the list scrolls. The editors behind a row
     (openItem, openGroup, the actions sheet) are the ones of 12 October. */
  const MSVG={add:'M440-440H200v-80h240v-240h80v240h240v80H520v240h-80v-240Z',tune:'M440-120v-240h80v80h320v80H520v80h-80Zm-320-80v-80h240v80H120Zm160-160v-80H120v-80h160v-80h80v240h-80Zm160-80v-80h400v80H440Zm160-160v-240h80v80h160v80H680v80h-80Zm-480-80v-80h400v80H120Z'};
  const msvg=(n)=>`<svg class="rmw-msvg" viewBox="0 -960 960 960" aria-hidden="true"><path d="${MSVG[n]}"/></svg>`;
  function rowsHtml(list){
    const flat=()=>`<div class="rmw-rows">${list.map(row).join('')}</div>`;
    if(query.trim()||subFilter)return flat();
    /* #0151 · "All" reads as the printed menu: each section under its own
       heading, which opens that section. */
    if(filter==='all'){
      const d=D(),known=new Set(d.cats.map(c=>c.id));
      const groups=d.cats.map(c=>({id:c.id,label:t(c.name),items:list.filter(x=>x.catId===c.id)})).filter(g=>g.items.length);
      const loose=list.filter(x=>!known.has(x.catId));
      if(loose.length)groups.push({id:'',label:ui('withoutSubcat'),items:loose});
      if(groups.length<2)return flat();
      return groups.map(g=>`<div class="rmw-sec">${g.id?`<button type="button" class="rmw-sec-head" data-action="rmw-cat-filter" data-cat="${esc(g.id)}">`:'<div class="rmw-sec-head">'}<span>${esc(g.label)}</span><small>${countLabel(g.items.length)}</small>${g.id?`${catalogIcon('chevron_right')}</button>`:'</div>'}<div class="rmw-rows">${g.items.map(row).join('')}</div></div>`).join('');
    }
    const subs=subsOf(filter);
    if(!subs.length)return flat();
    const groups=subs.map(s=>({id:s.id,label:t(s.name),items:list.filter(x=>x.subId===s.id)})).filter(g=>g.items.length);
    const rest=list.filter(x=>!x.subId||!subs.some(s=>s.id===x.subId));
    if(rest.length)groups.push({id:'__none',label:ui('withoutSubcat'),items:rest,muted:true});
    if(groups.length<2)return flat();
    return groups.map(g=>`<div class="rmw-sec rmw-sec-sub"><button type="button" class="rmw-sec-head${g.muted?' muted':''}" data-action="rmw-sub-filter" data-sub="${g.id}"><span>${esc(g.label)}</span><small>${countLabel(g.items.length)}</small>${catalogIcon('chevron_right')}</button><div class="rmw-rows">${g.items.map(row).join('')}</div></div>`).join('');
  }
  function row(x){
    const name=t(x.name),off=x.avail===false,n=(x.opts||[]).length,meta=[];
    if(x.archived)meta.push(`<b class="rmw-row-state">${esc(ui('archived'))}</b>`);
    else if(off)meta.push(`<b class="rmw-row-state">${esc(ui('unavailableBadge'))}</b>`);
    if(x.desc)meta.push(esc(t(x.desc)));
    if(x.formula)meta.push(`${esc(ui('formula'))} · ${esc(ui('stepCount',{n:(x.formula.slots||[]).length}))}`);
    if(x.formulaOnly)meta.push(esc(ui('formulaOnlyBadge')));
    const nutri=nutritionCardPill(x).replace(/^ · /,'');if(nutri)meta.push(nutri);
    const thumb=x.photo?`<img class="rmw-row-thumb" src="${esc(x.photo)}" alt="" loading="lazy"/>`:'';
    const mods=esc(ui('optGroupCount',{n}));
    return `<div class="rmw-row${off?' rmw-off':''}${x.archived?' rmw-archived':''}" data-rmw-row="${esc(x.id)}">
      <button data-activation=write type="button" class="rmw-row-main" data-rmw-command="edit" data-arg="${esc(x.id)}" aria-label="${esc(ui('editItemTitle',{name}))}">${thumb}<span class="rmw-row-text"><span class="rmw-row-name">${esc(name)}</span>${meta.length?`<span class="catalog-item-meta">${meta.join(' · ')}</span>`:''}</span></button>
      <span class="rmw-row-price">${cash(x.price)}</span>
      <span class="rmw-row-mods${n?'':' none'}" title="${mods}">${msvg('tune')}<b aria-hidden="true">${n}</b><span class="rmw-sr">${mods}</span></span>
      <button type="button" class="rmw-avail" role="switch" aria-checked="${!off&&!x.archived}" data-rmw-command="avail" data-arg="${esc(x.id)}" aria-label="${esc(ui('availableToggle',{name}))}"${x.archived?' disabled':''}><span></span></button>
      <button type="button" class="catalog-more rmw-row-more" data-rmw-command="actions" data-arg="${esc(x.id)}" aria-label="${esc(catalogText('itemActions','Actions de l’article'))}: ${esc(name)}">${catalogIcon('more_vert')}</button>
    </div>`;
  }
  function openClassify(cid){
    const subs=subsOf(cid);
    if(!subs.length){toast(ui('createSubFirstToast'),ui('useAddSubHelp'),'info');return;}
    const pending=D().items.filter(x=>x.catId===cid&&!x.subId);
    if(!pending.length){toast(ui('allClassifiedToast'),ui('noUnclassifiedItems'),'info');return;}
    const opts=subs.map(s=>`<option value="${s.id}">${esc(t(s.name))}</option>`).join('');
    const helpPending = pending.length > 1 ? `${pending.length} ${ui('articlesWithoutSub')}` : `1 ${ui('articleWithoutSub')}`;
    const m=modal({tag:ui('classifyTag'),title:`${esc(ui('classifyTitle'))} · ${esc(t(cat(cid)?.name)||'')}`,width:560,body:`<div class="kf-help" style="margin-bottom:10px;">${helpPending}. ${esc(ui('classifyInstantSaveNotice'))}</div><div class="mi-classify-list" tabindex="0" role="region" aria-label="${esc(ui('classifyTitle'))}">${pending.map(x=>`<div class="mi-classify-row" data-mcr="${x.id}"><span class="mi-classify-name">${esc(t(x.name))}</span><select class="kf-input" aria-label="${esc(ui('sectionLabel'))}: ${esc(t(x.name))}" data-rmw-classify-sub="${x.id}"><option value="">· ${esc(ui('chooseSelectPlaceholder'))} ·</option>${opts}</select></div>`).join('')}</div>`,foot:`<button class="eq-cta-gradient" data-done>${esc(ui('doneBtn'))}</button>`});
    m.el.addEventListener('change',e=>{const sel=e.target.closest('[data-rmw-classify-sub]');if(!sel||!sel.value)return;S().updateItem(sel.dataset.rmwClassifySub,{subId:sel.value});sel.closest('[data-mcr]')?.classList.add('done');});
    $('[data-done]',m.el).onclick=()=>{m.close();render();};
  }
  function groupCard(g){
    const used=D().items.filter(x=>(x.opts||[]).includes(g.id)).length;
    const gName=t(g.name);
    const choicesHtml=(g.choices||[]).map(c=>`<span class="mi-group-opt-pill">${esc(c.emoji||'')} ${esc(t(c.name))}${c.price?` <span class="price">+${cash(c.price)}</span>`:''}</span>`).join('')||esc(ui('noChoices'));
    return `<div class="mi-group-card"><div class="mi-group-card-head"><span class="mi-group-card-name">${esc(gName)}</span><span class="mi-group-card-pill ${g.required?'req':'opt'}">${esc(g.required?ui('required'):ui('optional'))}</span><span class="mi-group-card-pill mode">${esc(g.kind==='many'?ui('manyChoices'):ui('oneChoice'))}</span></div><div class="mi-group-card-opts">${choicesHtml}</div><div class="mi-group-card-scope">${esc(ui('usedByCount', { n: used }))}</div><div class="mi-group-card-acts"><button data-activation=write class="btn-slim" data-action="rmw-group-edit" data-arg="${g.id}">${ic('edit')} ${esc(ui('editGroup'))}</button><button data-activation=write class="btn-slim danger" data-action="rmw-group-delete" data-arg="${g.id}">${ic('trash')} ${esc(ui('delete'))}</button></div></div>`;
  }
  function menuPanel(){
    searchStyle();shellStyle();
    if(filter!=='all'&&!cat(filter)){filter='all';subFilter=null;}
    const d=D(),list=shownItems(),selected=filter==='all'?null:cat(filter);
    const pill=(id,label,n)=>`<button class="mi-pill${filter===id?' on':''}" data-action="rmw-cat-filter" data-cat="${esc(id)}"><span class="rmw-cat-name">${esc(label)}</span><small>${n}</small></button>`;
    const rail=`<nav class="rmw-rail" aria-label="${esc(ui('sectionsTitle'))}"><div class="rmw-rail-head"><span>${esc(ui('sectionsTitle'))}</span><button type="button" class="catalog-more rmw-rail-acts" data-action="rmw-section-actions" aria-label="${esc(catalogText('sectionActions','Actions des sections'))}">${msvg('tune')}</button></div><div class="mi-pill-row rmw-cats">${pill('all',ui('all'),d.items.length)}${d.cats.map(c=>pill(c.id,t(c.name),d.items.filter(x=>x.catId===c.id).length)).join('')}</div><button data-activation=write type="button" class="rmw-rail-add" data-action="rmw-cat-add">${msvg('add')}<span>${esc(ui('newSection').replace(/^\+\s*/,''))}</span></button></nav>`;
    const searching=!!query.trim();
    const empty=(title,more='')=>`<div class="rmw-empty rmw-empty-note"><b>${esc(title)}</b>${more}</div>`;
    const body=d.items.length?(list.length?rowsHtml(list):searching?empty(ui('noItemMatch')):empty(ui('emptySectionText'),`<button data-activation=write class="btn-slim primary" data-action="rmw-item-add">${esc(ui('addFirstItemBtn'))}</button>`)):`<div class="rmw-empty" style="display:flex;flex-direction:column;align-items:center;padding:48px 20px;"><div style="width:48px;height:48px;border-radius:14px;background:rgba(11,110,79,0.10);border:1px solid rgba(11,110,79,0.18);color:var(--atlas);display:grid;place-items:center;margin-bottom:16px;"><svg width="24" height="24" viewBox="0 -960 960 960" fill="currentColor"><path d="M200-80q-33 0-56.5-23.5T120-160v-451q-18-11-29-28.5T80-680v-120q0-33 23.5-56.5T160-880h640q33 0 56.5 23.5T880-800v120q0 23-11 40.5T840-611v451q0 33-23.5 56.5T760-80H200Zm0-520v440h560v-440H200Zm-40-80h640v-120H160v120Zm200 280h240v-80H360v80Zm120 20Z"/></svg></div><h3 style="font-family:var(--sans);font-weight:600;font-size:18px;color:var(--ink);margin:0 0 6px;letter-spacing:-0.015em;">${esc(ui('emptyMenuTitle'))}</h3><p style="font-size:13px;color:var(--n-500);margin:0 0 18px;line-height:1.55;max-width:380px;text-align:center;">${esc(ui((d.cats||[]).length?'emptyItemsDesc':'emptyMenuDesc'))}</p>${(d.cats||[]).length?`<button data-activation=write class="btn-slim primary" data-action="rmw-item-add">${esc(ui('addFirstItemBtn'))}</button>`:`<button data-activation=write class="btn-slim primary" data-action="rmw-cat-add">${esc(ui('createSectionBtn'))}</button>`}</div>`;
    const resultLabel=searching?`${list.length} / ${d.items.length}`:`${d.items.length}`;
    const searchIcon='<svg viewBox="0 -960 960 960" aria-hidden="true"><path d="M784-120 532-372q-30 24-69 38t-83 14q-109 0-184.5-75.5T120-580q0-109 75.5-184.5T380-840q109 0 184.5 75.5T640-580q0 44-14 83t-38 69l252 252-56 56ZM380-400q75 0 127.5-52.5T560-580q0-75-52.5-127.5T380-760q-75 0-127.5 52.5T200-580q0 75 52.5 127.5T380-400Z"/></svg>';
    const bar=`<div class="rmw-bar"><label class="rmw-menu-search${searching?' has-query':''}"><span class="rmw-menu-search-icon">${searchIcon}</span><input type="search" value="${esc(query)}" placeholder="${esc(ui('searchPlaceholder'))}" aria-label="${esc(ui('searchPlaceholder'))}" autocomplete="off" data-rmw-search/><span class="rmw-menu-search-count" aria-live="polite"><strong>${resultLabel}</strong><small>${(searching?list.length:d.items.length)>1?catalogLabel(searching?'results':'items',searching?'résultats':'articles'):catalogLabel(searching?'result':'item',searching?'résultat':'article')}</small></span></label><button data-activation=write type="button" class="rmw-add" data-action="rmw-item-add" aria-label="${esc(ui('newItem').replace(/^\+\s*/,''))}">${msvg('add')}<span class="rmw-add-long">${esc(ui('newItem').replace(/^\+\s*/,''))}</span><span class="rmw-add-short" aria-hidden="true">${esc(ui('newItemShort'))}</span></button></div>`;
    const grouped=filter==='all'&&!searching&&!subFilter&&d.items.length&&list.length;
    const head=grouped?'':`<div class="rmw-list-head"><h3>${esc(selected?t(selected.name):ui('all'))}</h3><small>${esc(countLabel(list.length))}</small></div>`;
    return `<section class="mi-section rmw-shell"><div class="rmw-layout">${rail}<div class="rmw-main">${bar}${head}${subChips()}${body}</div></div></section><section class="mi-section"><div class="mi-section-head"><h3>${esc(ui('modAndOpts'))}</h3><button data-activation=write class="btn-slim primary" data-action="rmw-group-add">${ic('plus')} ${esc(ui('newGroupBtn').replace(/^\+\s*/,''))}</button></div><div class="mi-groups-grid">${d.opts.map(groupCard).join('')||`<div class="rmw-empty">${esc(ui('noOptGroups'))}</div>`}</div></section>`;
  }
  function stationsPanel(){
    const d=D(),kid=S().kitchenId(venue());
    const cards=d.stations.map(s=>{
      const cats=d.cats.filter(c=>(c.station||kid)===s.id);
      const catCountStr = cats.length === 1 ? `1 ${ui('section')}` : `${cats.length} ${ui('sections')}`;
      return `<div class="mi-station mi-station-card"><div class="mi-station-top"><span class="mi-st-dot on" style="background:${esc(s.color||'#1F5D3C')}"></span><span class="mi-station-name">${esc(t(s.name))}</span>${s.id===kid?`<span class="mi-group-card-pill req">${esc(ui('defaultStationFallback'))}</span>`:''}</div><div class="mi-station-routed">${catCountStr} · ${cats.map(c=>esc(t(c.name))).join(', ')}</div><div class="mi-group-card-acts"><button data-activation=write class="btn-slim" data-action="rmw-station-edit" data-arg="${s.id}">${ic('edit')} ${esc(ui('rename'))}</button>${s.id!==kid?`<button data-activation=write class="btn-slim danger" data-action="rmw-station-delete" data-arg="${s.id}">${ic('trash')} ${esc(ui('delete'))}</button>`:''}</div></div>`;
    }).join('');
    const routes=d.cats.map(c=>`<div class="rmw-route"><b>${esc(t(c.name))}</b><select aria-label="${esc(ui('stationLabel'))}: ${esc(t(c.name))}" data-rmw-route="${c.id}"><option value="">${esc(ui('defaultRoute', { name: t(station(kid)?.name)||ui('kitchen') }))}</option>${d.stations.filter(s=>s.id!==kid).map(s=>`<option value="${s.id}"${c.station===s.id?' selected':''}>${esc(t(s.name))}</option>`).join('')}</select></div>`).join('');
    return `<section class="mi-section"><div class="mi-recettes-head"><div><div class="mi-title">${esc(ui('stationsTitle'))}</div><div class="mi-sub">${esc(ui('stationsSub'))}</div></div><button data-activation=write class="btn-slim primary" data-action="rmw-station-add">${ic('plus')} ${esc(ui('addStation'))}</button></div><div class="mi-stations">${cards||`<div class="rmw-empty">${esc(ui('addFirstStation'))}</div>`}</div><div class="mi-section-head"><h3>${esc(ui('routingBySection'))}</h3></div><div class="rmw-routes">${routes||`<div class="rmw-empty">${esc(ui('createSectionsForRouting'))}</div>`}</div></section>`;
  }
  function recipeStatus(m,r){
    if(!r?.ingredients?.length)return['opt',ui('statusToComplete')];
    if(!m?.costComplete)return['opt',ui('statusCostIncomplete')];
    if(m.actualCost==null)return['req',ui('statusCosted')];
    const gap=Math.abs(m.variancePct||0);
    return gap>15?['opt',ui('statusCheckStock')]:gap>5?['opt',ui('statusToMonitor')]:['req',ui('statusCostCompliant')];
  }
  function nutritionStatus(x){
    if(!menuNutritionFeature())return['mode',ui('nutritionDisabled')];
    if(x.hideNutrition)return['mode',ui('nutritionHidden')];
    return x.nutritionComplete===true?['req',ui('nutritionComplete')]:['opt',ui('nutritionIncomplete')];
  }
  function nutritionPill(x){const [cls,label]=nutritionStatus(x);return `<span class="mi-group-card-pill rmw-nutrition-pill ${cls}">${esc(label)}</span>`;}
  /* Sur la carte, la place manque (le pied porte déjà « N groupe(s) d’options » et
     le bouton Disponible) : un point coloré + un mot, l’état complet en info-bulle ;
     quand la fiche est complète on affiche les kcal, plus utiles que le mot.
     Rien du tout si l’opérateur a coupé la nutrition pour ce commerçant. */
  function nutritionCardPill(x){if(!menuNutritionFeature())return'';const [cls,label]=nutritionStatus(x);const kcal=x.nutritionComplete===true&&x.nutrition&&Number.isFinite(+x.nutrition.kcal)?Math.round(+x.nutrition.kcal):null;const text=kcal!=null?`${kcal} kcal`:ui('nutritionShort');return ` · <span class="rmw-nutri-dot ${cls}" title="${esc(label)}"><i></i>${esc(text)}</span>`;}
  function recipesPanel(){
    const api=window.KiwiRestaurantRecipes,items=D().items,done=items.filter(x=>api?.get(x.id,x.name,venue())?.ingredients?.length).length;
    return `<section class="mi-section"><div class="mi-recettes-head"><div><div class="mi-title">${esc(ui('recipesTitle'))}</div><div class="mi-sub">${esc(ui('recipesSub'))}</div></div><div class="mi-recettes-progress"><div class="mi-recettes-progress-l">${esc(ui('recipesCompletedCount', { done, total: items.length }))}</div><div class="mi-recettes-progress-bar"><i style="width:${items.length?done/items.length*100:0}%"></i></div></div></div><div class="rmw-recipe-list">${items.map(x=>{const r=api?.get(x.id,x.name,venue()),m=r?api?.metrics(x,r,venue()):null,[cls,label]=recipeStatus(m,r);return `<div class="rmw-recipe-card"><div><div class="rmw-recipe-name">${esc(t(x.name))}</div><div class="rmw-recipe-meta">${esc(ui('ingredientCount', { n: r?.ingredients?.length||0 }))}${r?.prepMinutes?` · ${r.prepMinutes} min`:''}</div></div><div class="rmw-recipe-result"><span class="mi-group-card-pill ${cls}">${esc(label)}</span>${nutritionPill(x)}${m?.costComplete?`<small>${esc(ui('costSummaryPortion', { cost: m.theoreticalCost.toFixed(2) }))}</small>`:`<small>${esc(ui('missingCostOrQty'))}</small>`}</div><button data-activation=write class="btn-slim${r?'':' primary'}" data-action="rmw-recipe-edit" data-arg="${x.id}">${esc(r?ui('viewAndEdit'):ui('complete'))} →</button></div>`;}).join('')||`<div class="rmw-empty">${esc(ui('addItemsFirst'))}</div>`}</div></section>`;
  }
  /* Onglet Nutrition : une ligne par plat, l'état de la fiche (complète, à
     compléter, masquée), les valeurs par portion et les allergènes, le
     commutateur Visible/Masquée et le lien vers la recette. Tout est calculé
     depuis les recettes + fiches du stock ; rien n'est saisi ici. */
  function nutritionPanel(){
    const api=window.KiwiRestaurantRecipes,items=D().items,feature=menuNutritionFeature();
    const rows=items.map(x=>{const r=api?.get(x.id,x.name,venue());const res=r&&r.ingredients?.length?api.nutrition(r,x.id):null;const missing=res?[...new Set([...res.missingNutrition,...res.missingConversion,...res.missingAllergens])]:[];const state=x.hideNutrition?'hidden':(res&&res.complete?'done':'todo');return {x,r,res,missing,state};});
    const count=k=>rows.filter(o=>k==='all'||o.state===k).length,done=count('done');
    const list=rows.filter(o=>nutriFilter==='all'||o.state===nutriFilter);
    const pills=[['all',ui('nutritionFilterAll')],['todo',ui('nutritionFilterTodo')],['done',ui('nutritionFilterDone')],['hidden',ui('nutritionFilterHidden')]].map(([k,l])=>`<button class="mi-pill${nutriFilter===k?' on':''}" data-action="rmw-nutrition-filter" data-arg="${k}">${esc(l)}<span class="mi-tab-badge">${count(k)}</span></button>`).join('');
    const row=o=>{const {x,r,res,missing,state}=o;const cat=D().cats.find(c=>c.id===x.catId);let values;
      if(!r||!r.ingredients?.length)values=`<span class="rmw-nutri-muted">${esc(ui('nutritionNoRecipe'))} · ${esc(ui('nutritionNoRecipeHint'))}</span>`;
      else if(res&&res.complete)values=`<div class="rmw-nutrition-values"><bdi dir="ltr">${res.nutrition.kcal} kcal</bdi><bdi dir="ltr">P ${res.nutrition.protein} g</bdi><bdi dir="ltr">G ${res.nutrition.carbs} g</bdi><bdi dir="ltr">L ${res.nutrition.fat} g</bdi></div><div class="rmw-nutri-allergens">${res.allergens.length?res.allergens.map(k=>`<span>${esc(ui(`allergen_${k}`))}</span>`).join(''):`<span class="rmw-nutri-muted">${esc(ui('nutritionAllergens'))} : ${esc(ui('nutritionNone'))}</span>`}</div>`;
      else values=`<span class="rmw-nutri-muted">${esc(ui('nutritionMissingShort',{n:missing.length}))}</span>`;
      const stateLabel=state==='hidden'?ui('nutritionHidden'):state==='done'?ui('nutritionComplete'):ui('nutritionIncomplete');
      return `<div class="rmw-recipe-card rmw-nutri-row ${state}"><div><div class="rmw-recipe-name">${esc(t(x.name))}</div><div class="rmw-recipe-meta">${esc(cat?t(cat.name):'')}${r?.ingredients?.length?` · ${esc(ui('ingredientCount',{n:r.ingredients.length}))}`:''}</div></div><div class="rmw-nutri-values"><span class="rmw-nutri-dot ${state==='done'?'req':state==='hidden'?'mode':'opt'}"><i></i>${esc(stateLabel)}</span>${values}</div><div class="rmw-nutri-acts"><button class="mi-state-toggle" role="switch" aria-checked="${x.hideNutrition?'false':'true'}" data-action="rmw-nutrition-hide" data-arg="${x.id}" title="${esc(ui('nutritionHideHint'))}">${esc(x.hideNutrition?ui('nutritionHiddenToggle'):ui('nutritionVisibleToggle'))}</button><button data-activation=write class="btn-slim${state==='todo'?' primary':''}" data-action="rmw-recipe-edit" data-arg="${x.id}">${esc(state==='todo'?ui('complete'):ui('viewAndEdit'))} →</button></div></div>`;};
    return `<section class="mi-section"><div class="mi-recettes-head"><div><div class="mi-title">${esc(ui('nutritionTitle'))}</div><div class="mi-sub">${esc(ui('nutritionSub'))}</div></div><div class="mi-recettes-progress"><div class="mi-recettes-progress-l">${esc(ui('nutritionProgress',{done,total:items.length}))}</div><div class="mi-recettes-progress-bar"><i style="width:${items.length?done/items.length*100:0}%"></i></div></div></div>${feature?'':`<div class="rmw-nutri-notice">${esc(ui('nutritionDisabledNotice'))}</div>`}<div class="rmw-nutri-filters">${pills}</div><div class="rmw-recipe-list">${list.map(row).join('')||`<div class="rmw-empty">${esc(items.length?ui('nutritionFilterEmpty'):ui('addItemsFirst'))}</div>`}</div></section>`;
  }
  function sales(){try{return window.KiwiSales?.list?.(venue())||[];}catch(_){return[];}}
  const norm=(v)=>String(v==null?'':v).trim().toLocaleLowerCase('fr').normalize('NFD').replace(/[\u0300-\u036f]/g,'');
  /* IDs survive option labels and duplicate names (adult/kids menus). Never
   * let a Map's last duplicate silently claim another dish's sales. */
  function saleLineMatcher(rows){
    const byId=new Map(rows.map(r=>[String(r.item.id),r]));
    return line=>{
      const id=line?.itemId??line?.id??line?.i;
      if(id!=null&&byId.has(String(id)))return byId.get(String(id));
      const name=norm(line?.baseName||line?.bn||line?.name||line?.n);
      let candidates=rows.filter(r=>norm(r.item.name)===name);
      if(!candidates.length)candidates=rows.filter(r=>name.startsWith(norm(r.item.name)+' ('));
      const category=norm(line?.cat||line?.category||line?.c);
      if(category&&candidates.length>1)candidates=candidates.filter(r=>category===norm(cat(r.item.catId)?.name)||category===norm(r.item.catId));
      return candidates.length===1?candidates[0]:null;
    };
  }
  function median(values){if(!values.length)return 0;const a=[...values].sort((x,y)=>x-y),m=Math.floor(a.length/2);return a.length%2?a[m]:(a[m-1]+a[m])/2;}
  /* ── La période analysée ──
   * « 30 derniers jours » = les 30 journées COMMERCIALES qui finissent
   * aujourd'hui, dans le fuseau et avec le seuil de journée du commerce
   * (KiwiDayReport : Africa/Casablanca, 5 h par défaut). L'ancienne fenêtre
   * glissait sur now − 30×24 h dans le fuseau du navigateur : elle coupait une
   * journée en deux et ne correspondait à aucun rapport journalier. */
  function analysisWindow(days=30){
    const DR=window.KiwiDayReport,now=Date.now();
    try{
      if(DR?.today&&DR?.dayBounds&&DR?.shiftDay){
        const last=DR.today(),first=DR.shiftDay(last,-(days-1)),from=DR.dayBounds(first).from,end=DR.dayBounds(last).to;
        if(Number.isFinite(from)&&Number.isFinite(end)&&end>from)return{from,to:Math.min(end,now+5*60e3),first,last,zone:DR.timezone?.()||'Africa/Casablanca',days,exact:true};
      }
    }catch(_){}
    return{from:now-days*864e5,to:now,first:'',last:'',zone:'',days,exact:false};
  }
  function rangeLabel(w){
    if(!w.exact)return ui('daysCount',{n:w.days});
    const fmt=(day)=>{const [y,m,d]=day.split('-').map(Number);return new (globalThis.KiwiZoneLaw?.DateTimeFormat || Intl.DateTimeFormat)(lang()==='ar'?'ar-MA':lang()==='en'?'en-GB':'fr-FR',{day:'numeric',month:'short',year:'numeric',timeZone:'UTC'}).format(new Date(Date.UTC(y,m-1,d)));};
    return ui('rangeLabel',{from:fmt(w.first),to:fmt(w.last)});
  }
  /* Le flux du tableau de bord ne sert l'historique qu'au rythme de ses pages
   * (curseur). Tant que la reprise n'a pas atteint sa dernière page, la liste
   * locale n'est qu'un extrait : on le dit au lieu de l'appeler « 30 jours ». */
  function feedCompleteness(){
    try{const st=window.KiwiLive?.status?.();if(!st)return 'unknown';return st.backfillComplete?'complete':'loading';}catch(_){return 'unknown';}
  }

  /* Le coût d'un plat de la carte selon sa fiche technique (coût théorique).
     Le coût observé (consommation réelle du stock) reste à part : il ne
     remplace jamais le théorique dans le profit, il s'affiche à côté. */
  function recipeCostResolver(rows){
    const match=saleLineMatcher(rows),api=window.KiwiRestaurantRecipes,cache=new Map();
    const of=(row)=>{const id=String(row.item.id);if(cache.has(id))return cache.get(id);let hit=null;try{const recipe=api?.get?.(row.item.id,row.item.name,venue());const m=recipe?api?.metrics?.(row.item,recipe,venue()):null;if(m?.costComplete&&+m.theoreticalCost>0)hit={mad:+m.theoreticalCost,src:'recipe',observed:m.actualCost==null?null:+m.actualCost};}catch(_){hit=null;}cache.set(id,hit);return hit;};
    return {match,of,line:(l)=>{const row=match(l);return row?of(row):null;}};
  }
  /* Le registre de la période : KiwiCost.ledger, le même moteur que la vue
     d'ensemble d'« Analyse du menu ». Annulations, doublons, remboursements,
     remises et TVA y suivent les mêmes règles ; aucune copie ici. */
  function menuLedger(w,rows){
    const C=window.KiwiCost;if(!C?.ledger)return null;
    rows=rows||D().items.map(x=>({item:x}));
    const R=recipeCostResolver(rows);
    let refunds=[];try{refunds=window.KiwiRefunds?.list?.(venue())||[];}catch(_){refunds=[];}
    return C.ledger(sales(),{from:w.from,to:w.to,refunds,lineCost:R.line,fallbackPrice:(l)=>R.match(l)?.item.price});
  }
  const COST_SRC={recipe:'costSrcRecipe',frozen:'costSrcFrozen',flat:'costSrcFlat',variant:'costSrcVariant'};
  function performanceData(days=30){
    const w=analysisWindow(days),items=D().items.map(x=>({item:x,qty:0,pricedQty:0,costedQty:0,revenue:0,net:0,cost:0,todayCostQty:0,srcs:{},unitCost:null,unitProfit:null,profit:null,marginPct:null,quadrant:null,costSource:null,observedCost:null}));
    const R=recipeCostResolver(items),offMenu=new Map();
    const L=menuLedger(w,items)||{grossN:0,gross:0,refundN:0,refunds:0,net:0,dupN:0,dupAmt:0,unitemisedN:0,unitemisedAmt:0,collected:0,discounts:0,lines:[],basis:{mode:'none'}};
    const ledger={grossN:L.grossN,gross:L.gross,refundN:L.refundN,refunds:L.refunds,net:L.net,itemised:L.collected,attributed:0,offMenu:0,freeAmount:0,unitemisedN:L.unitemisedN,unitemised:L.unitemisedAmt,discounts:L.discounts,dupN:L.dupN,dupAmt:L.dupAmt,todayCostQty:0,basis:L.basis,completeness:feedCompleteness()};
    L.lines.forEach(x=>{
      const line=x.line,qty=x.qty,row=R.match(line);
      if(row){
        row.qty+=qty;row.revenue+=x.collected;row.net+=x.net;ledger.attributed+=x.collected;
        if(x.collected>0){row.pricedQty+=qty;if(x.cost!=null){row.costedQty+=qty;row.cost+=x.cost;row.srcs[x.src]=(row.srcs[x.src]||0)+qty;if(!x.frozen){row.todayCostQty+=qty;ledger.todayCostQty+=qty;}}}
        return;
      }
      /* Hors de la carte actuelle : article libre, plat retiré ou renommé,
         nom ambigu sans id. Jamais jeté, jamais rattaché au hasard. */
      const id=String(line?.itemId??line?.i??line?.id??''),name=String(line?.baseName||line?.bn||line?.name||line?.n||'').trim();
      const free=id==='libre'||/^article libre$/i.test(name);
      const k=free?'libre':(id?'id:'+id:'name:'+norm(name));
      const o=offMenu.get(k)||{key:k,id,name:free?ui('freeAmountItem'):(name||ui('article')),free,qty:0,revenue:0};
      o.qty+=qty;o.revenue+=x.collected;offMenu.set(k,o);ledger.offMenu+=x.collected;if(free)ledger.freeAmount+=x.collected;
    });
    items.forEach(row=>{
      /* Un plat n'a un profit que si CHAQUE unité vendue à un prix a un coût :
         un coût partiel donnerait un profit inventé. HT quand la TVA est
         incluse dans les prix (KiwiCost.basis). */
      if(row.pricedQty>0&&row.costedQty===row.pricedQty){
        row.unitCost=row.cost/row.costedQty;
        const top=Object.entries(row.srcs).sort((a,b)=>b[1]-a[1])[0];
        row.costSource=top&&COST_SRC[top[0]]?ui(COST_SRC[top[0]]):'';
        row.unitProfit=row.net/row.pricedQty-row.unitCost;
        row.profit=row.net-row.cost;
        row.marginPct=row.net>0?row.profit/row.net*100:null;
      }
      const rc=R.of(row);if(rc){row.theoCost=rc.mad;if(rc.observed!=null)row.observedCost=rc.observed;}
    });
    const measured=items.filter(x=>x.qty>0&&x.unitProfit!=null&&Number.isFinite(x.unitProfit));
    /* Les deux seuils de l'ingénierie de menu (Kasavana et Smith, 1982), pas
       des médianes. Une médiane coupe TOUJOURS la carte en deux : une carte où
       chaque plat se vend bien rangeait quand même la moitié en « peu
       populaire ». Ici, un plat est populaire s'il fait au moins 70 % de sa part
       équitable des ventes (1/n), et rentable si sa contribution par article
       atteint la moyenne PONDÉRÉE par les ventes, celle de la carte entière.
       Les noms de champs restent medQty/medProfit pour ne rien casser. */
    const soldQty=measured.reduce((n,x)=>n+x.qty,0);
    const medQty=measured.length?0.7*soldQty/measured.length:0;
    const medProfit=soldQty?measured.reduce((n,x)=>n+x.unitProfit*x.qty,0)/soldQty:0;
    measured.forEach(x=>{const popular=x.qty>=medQty,profitable=x.unitProfit>=medProfit;x.quadrant=popular&&profitable?'star':popular?'plow':profitable?'puzzle':'dog';});
    /* `totalRevenue` = le CA des plats de la carte, seul périmètre où une
       recette peut exister. Ce n'est PAS le chiffre d'affaires du commerce :
       celui-ci est `ledger.gross` / `ledger.net`. */
    const totalRevenue=items.reduce((n,x)=>n+x.revenue,0),costedRevenue=measured.reduce((n,x)=>n+x.revenue,0),grossProfit=measured.reduce((n,x)=>n+x.profit,0);
    return {items,measured,medQty,medProfit,totalRevenue,costedRevenue,grossProfit,coverage:totalRevenue?costedRevenue/totalRevenue*100:0,days,window:w,ledger,offMenu:[...offMenu.values()].sort((a,b)=>b.revenue-a.revenue)};
  }
  function perfQuads(){
    return {
      star:{title:ui('legendStar'),hint:ui('quadStarHint'),action:ui('quadStarAction')},
      plow:{title:ui('legendPlow'),hint:ui('quadPlowHint'),action:ui('quadPlowAction')},
      puzzle:{title:ui('legendPuzzle'),hint:ui('quadPuzzleHint'),action:ui('quadPuzzleAction')},
      dog:{title:ui('legendDog'),hint:ui('quadDogHint'),action:ui('quadDogAction')},
    };
  }
  const pct1=(v)=>(window.KiwiNumber?.format(v,{minimumFractionDigits:1,maximumFractionDigits:1})??(+v).toLocaleString(lang()==='ar'?'ar-MA':lang()==='en'?'en-GB':'fr-FR',{minimumFractionDigits:1,maximumFractionDigits:1}))+' %';
  const perfNum=(v)=>window.KiwiNumber?.format(v,{})??(+v).toLocaleString(lang()==='ar'?'ar-MA':lang()==='en'?'en-GB':'fr-FR',{maximumFractionDigits:2});
  /* La matrice de la carte. Échelles linéaires (une racine écrasait tout
     contre le bord droit), marge intérieure pour qu'aucun point ne colle au
     cadre, chaque plat nommé à côté de son point quand la place le permet,
     plats superposés regroupés en un seul point numéroté. Le placement des
     noms se calcule sur une toile nominale : sur téléphone, seuls les plus
     gros chiffres d'affaires gardent leur nom, la liste des quadrants
     nomme tout le reste. */
  const MX_W=680,MX_H=340;
  function perfMatrixLayout(p){
    const pts=[...p.measured].sort((a,b)=>b.revenue-a.revenue);
    const maxQ=Math.max(...pts.map(r=>r.qty)),ups=pts.map(r=>r.unitProfit),maxP=Math.max(0,...ups),minP=Math.min(0,...ups),maxRev=Math.max(1,...pts.map(r=>r.revenue));
    const xMax=(maxQ||1)*1.1,yMin=minP<0?minP*1.2:0,yMax=(maxP>0?maxP:1)*1.18;
    const X=(v)=>4+92*(v/xMax),Y=(v)=>5+88*((v-yMin)/(yMax-yMin));
    const clusters=[];
    pts.forEach(r=>{
      const x=X(r.qty),y=Y(r.unitProfit),size=12+Math.sqrt(r.revenue/maxRev)*16,px=x/100*MX_W,py=y/100*MX_H;
      const hit=clusters.find(c=>Math.hypot(c.px-px,c.py-py)<(c.size+size)*0.3);
      if(hit){hit.members.push(r);hit.size=Math.min(34,hit.size+3);return;}
      clusters.push({x,y,px,py,size,members:[r],quadrant:r.quadrant});
    });
    const boxes=[],hits=(b)=>b.x0<0||b.y0<0||b.x1>MX_W||b.y1>MX_H||boxes.some(o=>b.x0<o.x1&&b.x1>o.x0&&b.y0<o.y1&&b.y1>o.y0)||clusters.some(c=>{const r=c.size/2;return b.x0<c.px+r&&b.x1>c.px-r&&b.y0<c.py+r&&b.y1>c.py-r;});
    clusters.forEach((c,i)=>{
      const first=t(c.members[0].item.name),text=c.members.length>1?`${first} +${c.members.length-1}`:first;
      const w=Math.min(150,text.length*6.3+14),h=18,r=c.size/2;
      const cand={r:{x0:c.px+r+5,x1:c.px+r+5+w,y0:c.py-h/2,y1:c.py+h/2},l:{x0:c.px-r-5-w,x1:c.px-r-5,y0:c.py-h/2,y1:c.py+h/2},t:{x0:c.px-w/2,x1:c.px+w/2,y0:c.py+r+4,y1:c.py+r+4+h},b:{x0:c.px-w/2,x1:c.px+w/2,y0:c.py-r-4-h,y1:c.py-r-4}};
      const own=clusters.filter(o=>o!==c);
      const free=(bx)=>!(bx.x0<0||bx.y0<0||bx.x1>MX_W||bx.y1>MX_H||boxes.some(o=>bx.x0<o.x1&&bx.x1>o.x0&&bx.y0<o.y1&&bx.y1>o.y0)||own.some(o=>{const rr=o.size/2;return bx.x0<o.px+rr&&bx.x1>o.px-rr&&bx.y0<o.py+rr&&bx.y1>o.py-rr;}));
      const pos=['r','l','t','b'].find(k=>free(cand[k]));
      if(pos){boxes.push(cand[pos]);c.label={text,pos,keep:i<3};}
    });
    return {clusters,vx:X(p.medQty),hy:Y(p.medProfit),zero:yMin<0?Y(0):null};
  }
  function performanceMatrix(p){
    if(p.measured.length<2)return `<section class="mi-section rmw-mx"><div class="rmw-mx-head"><div><h3>${esc(ui('mxTitle'))}</h3></div></div><div class="rmw-mx-few"><p>${esc(ui('mxTooFew'))}</p></div></section>`;
    const quads=perfQuads(),M=perfMatrixLayout(p),pc=(v)=>v.toFixed(2)+'%';
    const ZL={star:'matrixLabelStar',plow:'matrixLabelPlow',puzzle:'matrixLabelPuzzle',dog:'matrixLabelDog'},zone=(k,css)=>`<div class="rmw-mx-zone ${k}" style="${css}"><em>${esc(ui(ZL[k]))}</em></div>`;
    const zones=zone('puzzle',`left:0;top:0;width:${pc(M.vx)};height:${pc(100-M.hy)}`)+zone('star',`left:${pc(M.vx)};right:0;top:0;height:${pc(100-M.hy)}`)+zone('dog',`left:0;bottom:0;width:${pc(M.vx)};height:${pc(M.hy)}`)+zone('plow',`left:${pc(M.vx)};right:0;bottom:0;height:${pc(M.hy)}`);
    const tipRow=(r)=>`<span class="rmw-mx-tip-row"><b>${esc(t(r.item.name))}</b><small>${esc(ui('mxSoldN',{n:perfNum(r.qty)}))} · ${cash(r.revenue)} ${esc(ui('colRevenueDesc'))}</small><small>${esc(ui('mxPerUnit',{amount:cash(r.unitProfit)}))} · ${r.marginPct==null?'·':pct1(r.marginPct)} ${esc(ui('colMarginDesc'))}</small></span>`;
    const dots=M.clusters.map((c,i)=>{
      const one=c.members.length===1,r=c.members[0],q=quads[c.quadrant];
      const side=(c.x>72?' end':c.x<28?' start':'')+(c.y>62?' down':'');
      const name=one?t(r.item.name):ui('mxCluster',{n:c.members.length});
      const tip=`<span class="rmw-mx-tip" role="tooltip"><em>${esc(q.title)}</em>${one?'':`<strong>${esc(name)}</strong>`}${c.members.map(tipRow).join('')}</span>`;
      const attrs=one?` data-action="rmw-recipe-edit" data-arg="${esc(r.item.id)}"`:'';
      const dot=`<button type="button" class="rmw-mx-dot ${c.quadrant}${side}" style="left:${pc(c.x)};bottom:${pc(c.y)};--s:${c.size.toFixed(1)}px;z-index:${10+i}"${attrs} aria-label="${esc(name+' · '+q.title)}">${one?'':`<b>${c.members.length}</b>`}${tip}</button>`;
      const lab=c.label?`<span class="rmw-mx-lab ${c.label.pos}${c.label.keep?' keep':''}" style="left:${pc(c.x)};bottom:${pc(c.y)};--r:${(c.size/2).toFixed(1)}px" aria-hidden="true">${esc(c.label.text)}</span>`:'';
      return dot+lab;
    }).join('');
    const med=`<i class="rmw-mx-med v" style="left:${pc(M.vx)}"><span>${esc(ui('mxMedianQty',{n:perfNum(Math.round(p.medQty*10)/10)}))}</span></i><i class="rmw-mx-med h" style="bottom:${pc(M.hy)}"><span>${esc(ui('mxMedianProfit',{amount:cash(Math.round(p.medProfit*100)/100)}))}</span></i>${M.zero!=null?`<i class="rmw-mx-zero" style="bottom:${pc(M.zero)}"><span>0 MAD</span></i>`:''}`;
    return `<section class="mi-section rmw-mx" data-mx><div class="rmw-mx-head"><div><h3>${esc(ui('mxTitle'))}</h3><p>${esc(ui('mxSub'))}</p></div><div class="rmw-mx-key"><span><i style="width:8px;height:8px"></i><i style="width:14px;height:14px"></i>${esc(ui('mxSize'))}</span><span>${esc(ui('mxBasis',{n:p.measured.length}))}</span></div></div><div class="rmw-mx-body"><figure class="rmw-mx-chart"><figcaption class="rmw-mx-axis y">${esc(ui('mxAxisY'))}</figcaption><div class="rmw-mx-plot" dir="ltr"><div class="rmw-mx-zones">${zones}</div>${med}${dots}</div><div class="rmw-mx-axis x">${esc(ui('mxAxisX',{n:p.days}))}</div></figure>${perfQuadPanel(p,quads)}</div></section>`;
  }
  /* Les quatre quadrants, rangés comme sur la matrice : chaque plat nommé,
     cliquable vers sa recette, avec ses deux chiffres. */
  function perfQuadPanel(p,quads){
    return `<div class="rmw-mx-quads">${['puzzle','star','dog','plow'].map(k=>{
      const list=p.measured.filter(x=>x.quadrant===k).sort((a,b)=>b.profit-a.profit),total=list.reduce((n,x)=>n+x.profit,0);
      const rows=list.slice(0,4).map(x=>`<li><button data-activation=write type="button" data-action="rmw-recipe-edit" data-arg="${esc(x.item.id)}">${esc(t(x.item.name))}</button><small>${esc(ui('mxSoldN',{n:perfNum(x.qty)}))} · ${esc(ui('mxPerUnit',{amount:cash(x.unitProfit)}))}</small></li>`).join('');
      return `<article class="rmw-mx-q ${k}" data-quad="${k}"><header><i></i><b>${esc(quads[k].title)}</b><span>${list.length}</span></header><p>${esc(quads[k].hint)}</p>${list.length?`<ul>${rows}</ul>${list.length>4?`<small class="more">${esc(ui('mxMore',{n:list.length-4}))}</small>`:''}<footer><b>${esc(quads[k].action)}</b><span>${esc(ui('mxContribution',{amount:cash(total)}))}</span></footer>`:`<p class="none">${esc(ui('mxEmptyQuad'))}</p>`}</article>`;
    }).join('')}</div>`;
  }
  /* Le registre de la période, AVANT l'analyse par plat : ventes brutes,
     remboursements, net, puis la part que les recettes peuvent expliquer.
     Chaque écart entre ces chiffres est nommé ; aucun sous-ensemble n'est
     présenté comme le chiffre d'affaires du commerce. */
  function perfLedger(p){
    const L=p.ledger,share=L.gross>0?Math.round(L.attributed/L.gross*100)+' %':'·',notes=ledgerNotes(L,'ledgerLoading');
    const costed=p.measured.length,costedNet=p.measured.reduce((n,x)=>n+x.net,0),rate=costed&&costedNet>0?p.grossProfit/costedNet*100:null;
    const sold=p.items.reduce((n,x)=>n+x.qty,0),cov=p.totalRevenue?Math.max(0,Math.min(100,p.coverage)):0;
    const soldLabel=ui(sold===1?'itemSold':'itemsSold');
    return `<section class="rmw-sum" data-ledger-gross="${L.gross.toFixed(2)}" data-ledger-net="${L.net.toFixed(2)}"><div class="rmw-sum-kpis"><div><span>${esc(ui('analyzedRevenue'))}</span><b>${cash(p.totalRevenue)}</b><small>${perfNum(sold)} ${esc(soldLabel)} · ${esc(ui('menuItemsOnly'))}</small></div><div><span>${esc(ui('grossProfitCalc'))}</span><b>${costed?cash(p.grossProfit):'·'}</b><small>${esc(ui('recipesSoldAndCosted',{n:costed}))}</small></div><div><span>${esc(ui('colMargin'))}</span><b>${rate==null?'·':pct1(rate)}</b><small>${esc(ui('mxRateSub'))}</small></div><div><span>${esc(ui('costCoverage'))}</span><b>${p.totalRevenue?p.coverage.toFixed(0)+' %':'·'}</b><i class="rmw-sum-bar"><i style="width:${cov.toFixed(1)}%"></i></i><small>${esc(ui('costCoverageSub'))}</small></div></div><div class="rmw-sum-recon"><span class="rmw-sum-i"><span>${esc(ui('ledgerGross'))}</span><b>${cash(L.gross)}</b><small>${esc(ui('ledgerTickets',{n:L.grossN}))}</small></span><i aria-hidden="true">·</i><span class="rmw-sum-i"><span>${esc(ui('ledgerRefunds'))}</span><b>${L.refunds?'− '+cash(L.refunds):cash(0)}</b></span><i aria-hidden="true">=</i><span class="rmw-sum-i"><span>${esc(ui('ledgerNet'))}</span><b>${cash(L.net)}</b></span><i aria-hidden="true">·</i><span class="rmw-sum-i"><span>${esc(ui('ledgerEligible'))}</span><b>${cash(L.attributed)}</b><small>${esc(share)}</small></span></div>${notes.length?`<div class="rmw-perf-notes">${notes.join('')}</div>`:''}</section>`;
  }
  /* Les remarques du registre, communes à la Performance et aux Ventes : ce
     qui manque, ce qui est écarté, ce qui n'est pas attribué. */
  function ledgerNotes(L,loadingKey){
    const notes=[];
    if(L.completeness==='loading')notes.push(`<p class="warn">${esc(ui(loadingKey))}</p>`);
    else if(L.completeness==='unknown')notes.push(`<p class="warn">${esc(ui('ledgerUnknown'))}</p>`);
    if(L.dupN)notes.push(`<p>${esc(ui('ledgerDuplicates',{n:L.dupN,amount:cash(L.dupAmt)}))}</p>`);
    if(L.offMenu)notes.push(`<p>${esc(ui('ledgerOffMenu',{amount:cash(L.offMenu),free:cash(L.freeAmount)}))}</p>`);
    if(Math.abs(L.unitemised)>=0.01)notes.push(`<p>${esc(ui('ledgerUnitemised',{amount:cash(L.unitemised),n:L.unitemisedN}))}</p>`);
    if(L.discounts>=0.01)notes.push(`<p>${esc(ui('ledgerDiscounts',{amount:cash(L.discounts)}))}</p>`);
    if(L.basis&&L.basis.mode==='rate'&&L.basis.included)notes.push(`<p>${esc(ui('ledgerVatBasis',{rate:L.basis.rate}))}</p>`);
    if(L.todayCostQty>0)notes.push(`<p>${esc(ui('ledgerTodayCost'))}</p>`);
    if(L.refunds)notes.push(`<p>${esc(ui('ledgerRefundLines'))}</p>`);
    return notes;
  }
  /* #0150 · On a phone each table row becomes a card. The column names ride
     on the table as CSS strings so every cell stays labelled once the header
     is hidden, without touching the cells themselves. */
  function perfLabels(){
    return ['colItem','colSold','colRevenue','colUnitCost','colProfit','colMargin','colReadout'].map((k,i)=>`--l${i+1}:${JSON.stringify(ui(k))}`).join(';');
  }
  /* Coût simple (option) : l'estimation d'une fiche de coût liée au plat.
     Affichée À CÔTÉ du coût de la recette et du coût observé, jamais à leur
     place : elle n'entre dans aucune contribution ni aucun quadrant. */
  function costEstimates(){try{return window.KiwiSimpleFoodCost?.estimates?.()||null;}catch(_){return null;}}
  function estimateNote(est,r){
    const e=est&&est[String(r.item.id)];if(!e)return '';
    const known=e.complete&&e.perPortion!=null,flag=known&&e.stale?ui('estimateStale'):'';
    return `<small class="rmw-perf-est" data-estimate="${esc(r.item.id)}">${esc(ui('estimateLabel',{amount:known?cash(e.perPortion):ui('estimateIncomplete')}))}${flag?' · '+esc(flag):''}</small>`;
  }
  /* « À faire » : des constats tirés des chiffres affichés au-dessus, chacun
     avec son action. Rien n'est inventé : un plat sans coût complet ne donne
     ni écart ni quadrant, il apparaît dans « ventes sans coût ». */
  const GAP_PCT=15;
  function perfInsights(p,est){
    const out=[],names=(list)=>list.slice(0,3).map(x=>t(x.item.name)).join(', ');
    const gap=(a,b)=>(a-b)/b*100,fmtGap=(g)=>(g>0?'+':'−')+Math.abs(g).toFixed(0)+'\u00a0%';
    const uncosted=p.items.filter(x=>x.pricedQty>0&&x.unitCost==null).sort((a,b)=>b.revenue-a.revenue);
    if(uncosted.length)out.push({key:'uncosted',amount:uncosted.reduce((n,x)=>n+x.revenue,0),text:ui(uncosted.length===1?'insightUncosted1':'insightUncosted',{amount:cash(uncosted.reduce((n,x)=>n+x.revenue,0)),n:uncosted.length}),item:uncosted[0].item});
    p.items.filter(x=>x.qty>0&&x.theoCost>0&&x.observedCost!=null&&Math.abs(gap(x.observedCost,x.theoCost))>=GAP_PCT)
      .sort((a,b)=>Math.abs(gap(b.observedCost,b.theoCost))*b.qty-Math.abs(gap(a.observedCost,a.theoCost))*a.qty).slice(0,3)
      .forEach(x=>out.push({key:'observed',text:ui('insightObservedGap',{item:t(x.item.name),observed:cash(x.observedCost),theory:cash(x.theoCost),gap:fmtGap(gap(x.observedCost,x.theoCost))}),item:x.item}));
    if(est)p.items.filter(x=>x.theoCost>0&&est[String(x.item.id)]?.perPortion>0&&Math.abs(gap(est[String(x.item.id)].perPortion,x.theoCost))>=GAP_PCT).slice(0,3)
      .forEach(x=>{const e=est[String(x.item.id)];out.push({key:'estimate',text:ui('insightEstimateGap',{item:t(x.item.name),estimate:cash(e.perPortion),theory:cash(x.theoCost),gap:fmtGap(gap(e.perPortion,x.theoCost))}),item:x.item});});
    const plow=p.measured.filter(x=>x.quadrant==='plow').sort((a,b)=>b.qty-a.qty);
    if(plow.length)out.push({key:'plow',text:ui('insightPlow',{items:names(plow)}),item:plow[0].item});
    const puzzle=p.measured.filter(x=>x.quadrant==='puzzle').sort((a,b)=>b.unitProfit-a.unitProfit);
    if(puzzle.length)out.push({key:'puzzle',text:ui('insightPuzzle',{items:names(puzzle)})});
    if(est){const stale=Object.values(est).filter(e=>e.stale);if(stale.length)out.push({key:'stale',text:ui('insightStale',{items:stale.slice(0,3).map(e=>e.name).join(', ')}),sheets:true});}
    return out;
  }
  function insightsBlock(list){
    const li=list.map(x=>`<li data-insight="${x.key}"><p>${esc(x.text)}</p>${x.item?`<button data-activation=write class="rmw-perf-link" data-action="rmw-recipe-edit" data-arg="${esc(x.item.id)}">${esc(ui(x.key==='uncosted'?'completeRecipeLink':'insightOpenRecipe'))}</button>`:x.sheets?`<button class="rmw-perf-link" data-fin-tab="cost">${esc(ui('insightOpenSheet'))}</button>`:''}</li>`).join('');
    return `<section class="mi-section rmw-perf-insights"><div class="mi-section-head"><h3>${esc(ui('insightsTitle'))}</h3></div><p class="rmw-perf-insights-sub">${esc(ui('insightsSub'))}</p>${list.length?`<ul>${li}</ul>`:`<p class="rmw-perf-insights-none">${esc(ui('insightNone'))}</p>`}</section>`;
  }
  /* ═══ SOUVENT PRIS ENSEMBLE ═══════════════════════════════════════════════
     Sur les tickets de la période (le même registre KiwiCost.ledger :
     annulations, doublons et remboursements déjà écartés), les paires de plats
     de la carte qui se retrouvent sur un même ticket. Une paire n'est citée
     que si elle revient sur PAIR_MIN_TOGETHER tickets au moins ET plus souvent
     que le hasard (lift = n(A et B) × N ÷ (n(A) × n(B)) ≥ PAIR_MIN_LIFT) : deux
     plats très vendus se croisent forcément, ça ne dit rien. Les lignes à
     0 MAD (un choix dans une formule) sont ignorées : la formule les impose,
     ce n'est pas le client qui les associe. Sous PAIR_MIN_TICKETS tickets, on
     dit qu'on ne sait pas encore. */
  const PAIR_MIN_TICKETS=40,PAIR_MIN_TOGETHER=5,PAIR_MIN_LIFT=1.2,PAIR_SHOWN=5;
  function pairsData(days=30){
    const w=analysisWindow(days),rows=D().items.map(x=>({item:x})),match=saleLineMatcher(rows);
    const L=menuLedger(w,rows),byTicket=new Map();
    (L?L.lines:[]).forEach(x=>{
      if(!(x.listed>0))return;
      const row=match(x.line);if(!row)return;
      const k=x.saleId||('ts:'+x.ts);
      if(!byTicket.has(k))byTicket.set(k,new Set());
      byTicket.get(k).add(String(row.item.id));
    });
    const N=byTicket.size,nOf=new Map(),nPair=new Map(),byId=new Map(rows.map(r=>[String(r.item.id),r.item]));
    byTicket.forEach(set=>{
      const ids=[...set].sort();
      ids.forEach(id=>nOf.set(id,(nOf.get(id)||0)+1));
      for(let i=0;i<ids.length;i++)for(let j=i+1;j<ids.length;j++){const k=ids[i]+'\u0000'+ids[j];nPair.set(k,(nPair.get(k)||0)+1);}
    });
    const pairs=[];
    if(N>=PAIR_MIN_TICKETS)nPair.forEach((n,k)=>{
      if(n<PAIR_MIN_TOGETHER)return;
      const [a,b]=k.split('\u0000'),na=nOf.get(a),nb=nOf.get(b),lift=n*N/(na*nb);
      if(!(lift>=PAIR_MIN_LIFT))return;
      /* Le sens le plus parlant : le plat le moins vendu appelle l'autre. */
      const [from,to,nf]=na<=nb?[a,b,na]:[b,a,nb];
      pairs.push({from:byId.get(from),to:byId.get(to),together:n,share:n/nf,lift});
    });
    pairs.sort((x,y)=>y.together-x.together||y.lift-x.lift);
    return {window:w,tickets:N,enough:N>=PAIR_MIN_TICKETS,min:PAIR_MIN_TICKETS,pairs:pairs.slice(0,PAIR_SHOWN)};
  }
  function pairsBlock(){
    const q=pairsData(30),num=(v,o)=>window.KiwiNumber?.format(v,o||{})??(+v).toLocaleString(lang()==='ar'?'ar-MA':lang()==='en'?'en-GB':'fr-FR',o||{});
    const body=!q.enough?`<p class="rmw-perf-insights-none" data-pairs-few="${q.tickets}">${esc(ui('pairsFew',{n:num(q.tickets),min:num(q.min)}))}</p>`
      :!q.pairs.length?`<p class="rmw-perf-insights-none" data-pairs-none>${esc(ui('pairsNone'))}</p>`
      :`<ul>${q.pairs.map(x=>`<li data-pair="${esc(x.from.id)}|${esc(x.to.id)}"><p>${esc(ui('pairsLine',{pct:num(Math.round(x.share*100))+' %',a:'\u0001',b:'\u0002'})).replace('\u0001',`<bdi>${esc(t(x.from.name))}</bdi>`).replace('\u0002',`<bdi>${esc(t(x.to.name))}</bdi>`)}<small style="display:block;color:var(--n-500);margin-top:2px;">${esc(ui('pairsMeta',{n:num(x.together),lift:num(x.lift,{minimumFractionDigits:1,maximumFractionDigits:1})}))}</small></p></li>`).join('')}</ul>`;
    return `<section class="mi-section rmw-perf-insights" data-pairs><div class="mi-section-head"><h3>${esc(ui('pairsTitle'))}</h3></div><p class="rmw-perf-insights-sub">${esc(ui('pairsSub'))}</p>${body}</section>`;
  }
  function performancePanel(){
    const p=performanceData(30),costed=p.measured.length,est=costEstimates(),quads=perfQuads();
    const rows=[...p.items].sort((a,b)=>b.profit-a.profit||b.revenue-a.revenue).map(r=>{const itName=t(r.item.name),catName=cat(r.item.catId)?.name?t(cat(r.item.catId).name):ui('noSection');return `<tr><td><b>${esc(itName)}</b><small>${esc(catName)}</small></td><td>${(window.KiwiNumber?.format(r.qty, {}) ?? r.qty.toLocaleString(document.documentElement?.lang === 'en' ? 'en-GB' : 'fr-FR', {}))}</td><td>${cash(r.revenue)}</td><td>${r.unitCost==null?'<button data-activation=write class="rmw-perf-link" data-action="rmw-recipe-edit" data-arg="'+esc(r.item.id)+'">'+esc(ui('completeRecipeLink'))+'</button>':`${cash(r.unitCost)}<small>${esc(r.costSource)}${r.observedCost!=null?' · '+esc(ui('costObserved',{amount:cash(r.observedCost)})):''}</small>`}${estimateNote(est,r)}</td><td>${r.profit==null?'·':cash(r.profit)}</td><td>${r.marginPct==null?'·':`<span class="rmw-perf-margin ${r.marginPct>=65?'hi':r.marginPct>=50?'mid':'lo'}">${pct1(r.marginPct)}</span>`}</td><td>${r.quadrant?quads[r.quadrant].title:(r.qty?ui('marginMissing'):ui('noSaleRecorded'))}</td></tr>`;}).join('');
    const offRows=p.offMenu.map(o=>`<tr class="rmw-perf-off"><td><b>${esc(o.name)}</b><small>${esc(o.free?ui('freeAmountSection'):ui('offMenuSection'))}</small></td><td>${(window.KiwiNumber?.format(o.qty, {}) ?? o.qty.toLocaleString(document.documentElement?.lang === 'en' ? 'en-GB' : 'fr-FR', {}))}</td><td>${cash(o.revenue)}</td><td>·</td><td>·</td><td>·</td><td>${esc(o.free?ui('freeAmountReadout'):ui('offMenuReadout'))}</td></tr>`).join('');
    if(!p.items.length)return `<section class="mi-section"><div class="rmw-empty"><h3>${esc(ui('noItemsToAnalyze'))}</h3><p>${esc(ui('noItemsToAnalyzeDesc'))}</p></div></section>`;
    const emptySales=!p.items.some(x=>x.qty>0)&&!p.offMenu.length&&!p.ledger.grossN;
    const head=`<div class="rmw-perf-head"><div><h2>${esc(ui('perfTitle'))}</h2><p>${esc(ui('perfSub'))}</p></div><div class="rmw-perf-period" title="${esc(p.window.zone||'')}">${esc(rangeLabel(p.window))}</div></div>`;
    if(emptySales)return `<div class="rmw-performance">${head}<section class="mi-section"><div class="rmw-empty"><h3>${esc(ui('noSalesYet'))}</h3><p>${esc(ui('noSalesYetDesc'))}</p></div></section></div>`;
    const matrix=costed?performanceMatrix(p):`<section class="mi-section rmw-mx"><div class="rmw-empty"><h3>${esc(ui('completeRecipesForProfit'))}</h3><p>${esc(ui('completeRecipesForProfitDesc'))}</p></div></section>`;
    return `<div class="rmw-performance">${head}${perfLedger(p)}${matrix}${insightsBlock(perfInsights(p,est))}${pairsBlock()}<section class="mi-section"><div class="mi-section-head"><h3>${esc(ui('perfDetail'))}</h3></div><div class="mi-list-wrap" tabindex="0" role="region" aria-label="${esc(ui('perfDetail'))}"><table class="mi-list rmw-perf-table" style="${esc(perfLabels())}"><thead><tr><th>${esc(ui('colItem'))}</th><th>${esc(ui('colSold'))}</th><th>${esc(ui('colRevenue'))}</th><th>${esc(ui('colUnitCost'))}</th><th>${esc(ui('colProfit'))}</th><th>${esc(ui('colMargin'))}</th><th>${esc(ui('colReadout'))}</th></tr></thead><tbody>${rows}${offRows}</tbody></table></div></section></div>`;
  }
  /* ═══ VENTES PAR CATÉGORIE ET PAR ARTICLE ═══════════════════════════════
     Le même registre que la Performance (KiwiCost.ledger) : annulations,
     doublons, remboursements, remises et TVA y suivent les mêmes règles. Ici
     on ne parle que d'argent encaissé, jamais de coût. Six périodes, toutes en
     journées commerciales (coupure 5 h, fuseau du commerce) : « Ce mois-ci »
     part du 1er à 5 h, « Mois dernier » est le mois civil précédent entier. */
  const SALES_PRESETS=['today','yesterday','d7','d30','month','lastMonth'];
  const SALES_LABEL={today:'salesPresetToday',yesterday:'salesPresetYesterday',d7:'salesPreset7',d30:'salesPreset30',month:'salesPresetMonth',lastMonth:'salesPresetLastMonth'};
  let salesPeriod='d30';
  try{const saved=localStorage.getItem('kiwiMenuSalesPeriod');if(SALES_PRESETS.includes(saved))salesPeriod=saved;}catch(_){}
  function salesWindow(id){
    const DR=window.KiwiDayReport,now=Date.now(),cap=now+5*60e3;
    try{
      if(DR?.today&&DR?.dayBounds&&DR?.shiftDay){
        const today=DR.today();let first=today,last=today;
        if(id==='yesterday')first=last=DR.shiftDay(today,-1);
        else if(id==='d7')first=DR.shiftDay(today,-6);
        else if(id==='d30')first=DR.shiftDay(today,-29);
        else if(id==='month')first=today.slice(0,8)+'01';
        else if(id==='lastMonth'){last=DR.shiftDay(today.slice(0,8)+'01',-1);first=last.slice(0,8)+'01';}
        const from=DR.dayBounds(first).from,end=DR.dayBounds(last).to;
        if(Number.isFinite(from)&&Number.isFinite(end)&&end>from)return{id,from,to:Math.min(end,cap),first,last,zone:DR.timezone?.()||'Africa/Casablanca',exact:true};
      }
    }catch(_){}
    /* Sans le module du rapport journalier : minuit de l'appareil, et la
       période est nommée sans dates pour ne rien affirmer de faux. */
    const d=new Date();d.setHours(0,0,0,0);const t=d.getTime(),y=d.getFullYear(),m=d.getMonth();
    const span={today:[t,now],yesterday:[t-864e5,t],d7:[t-6*864e5,now],d30:[t-29*864e5,now],month:[new Date(y,m,1).getTime(),now],lastMonth:[new Date(y,m-1,1).getTime(),new Date(y,m,1).getTime()]}[id]||[t-29*864e5,now];
    return{id,from:span[0],to:span[1],first:'',last:'',zone:'',exact:false};
  }
  function salesRangeLabel(w){
    if(!w.exact)return ui(SALES_LABEL[w.id]||'salesPreset30');
    if(w.first===w.last){const [y,m,d]=w.first.split('-').map(Number);return ui('salesDayLabel',{day:new (globalThis.KiwiZoneLaw?.DateTimeFormat || Intl.DateTimeFormat)(lang()==='ar'?'ar-MA':lang()==='en'?'en-GB':'fr-FR',{weekday:'short',day:'numeric',month:'short',year:'numeric',timeZone:'UTC'}).format(new Date(Date.UTC(y,m-1,d)))});}
    return rangeLabel(w);
  }
  function salesData(id){
    const w=salesWindow(id),items=D().items.map(x=>({item:x,qty:0,pricedQty:0,formulaQty:0,zeroQty:0,revenue:0}));
    const L=menuLedger(w,items);
    if(!L)return null;
    const match=saleLineMatcher(items),offMenu=new Map();let attributed=0,offAmt=0,freeAmt=0;
    L.lines.forEach(x=>{
      const row=match(x.line);
      if(row){
        row.qty+=x.qty;row.revenue+=x.collected;attributed+=x.collected;
        if(x.collected>0)row.pricedQty+=x.qty;
        else if(String(x.kind||x.line?.kind||'')==='formula-part')row.formulaQty+=x.qty;
        else row.zeroQty+=x.qty;
        return;
      }
      const line=x.line,lid=String(line?.itemId??line?.i??line?.id??''),name=String(line?.baseName||line?.bn||line?.name||line?.n||'').trim();
      const free=lid==='libre'||/^article libre$/i.test(name),k=free?'libre':(lid?'id:'+lid:'name:'+norm(name));
      const o=offMenu.get(k)||{key:k,name:free?ui('freeAmountItem'):(name||ui('article')),free,qty:0,revenue:0};
      o.qty+=x.qty;o.revenue+=x.collected;offMenu.set(k,o);offAmt+=x.collected;if(free)freeAmt+=x.collected;
    });
    const cats=new Map();
    items.filter(r=>r.qty>0).forEach(r=>{
      const c=cat(r.item.catId),key=c?'c:'+c.id:'none';
      const g=cats.get(key)||{key,name:c?.name?t(c.name):ui('noSection'),qty:0,revenue:0,n:0};
      g.qty+=r.qty;g.revenue+=r.revenue;g.n++;cats.set(key,g);
    });
    [...offMenu.values()].forEach(o=>{
      const key=o.free?'free':'off',g=cats.get(key)||{key,name:ui(o.free?'freeAmountSection':'offMenuSection'),qty:0,revenue:0,n:0,off:true};
      g.qty+=o.qty;g.revenue+=o.revenue;g.n++;cats.set(key,g);
    });
    const ledger={grossN:L.grossN,gross:L.gross,refundN:L.refundN,refunds:L.refunds,net:L.net,attributed,offMenu:0,offAmt,freeAmount:freeAmt,unitemisedN:L.unitemisedN,unitemised:L.unitemisedAmt,discounts:L.discounts,dupN:L.dupN,dupAmt:L.dupAmt,todayCostQty:0,basis:{mode:'none'},completeness:feedCompleteness()};
    const byRev=(a,b)=>b.revenue-a.revenue||b.qty-a.qty;
    return{window:w,ledger,itemised:L.collected,
      categories:[...cats.values()].sort((a,b)=>(a.off?1:0)-(b.off?1:0)||byRev(a,b)),
      items:items.filter(r=>r.qty>0).sort(byRev),
      offMenu:[...offMenu.values()].sort(byRev),
      unsold:items.filter(r=>!r.qty&&!r.item.archived&&r.item.avail!==false).length};
  }
  function salesPanel(){
    const pills=SALES_PRESETS.map(k=>`<button class="mi-pill${k===salesPeriod?' on':''}" type="button" role="tab" aria-selected="${k===salesPeriod}" data-action="rmw-sales-period" data-period="${k}">${esc(ui(SALES_LABEL[k]))}</button>`).join('');
    let p=null;try{p=salesData(salesPeriod);}catch(_){p=null;}
    const head=`<section class="mi-section"><div class="mi-recettes-head"><div><div class="mi-title">${esc(ui('salesTitle'))}</div><div class="mi-sub">${esc(ui('salesSub'))}</div></div>${p?`<div class="rmw-perf-period" data-sales-from="${p.window.from}" data-sales-to="${p.window.to}" title="${esc(p.window.zone||'')}">${esc(salesRangeLabel(p.window))}</div>`:''}</div><div class="mi-pill-row rmw-sales-pills" role="tablist" aria-label="${esc(ui('salesPeriodAria'))}">${pills}</div></section>`;
    if(!p)return `<div class="rmw-sales" data-sales-state="error">${head}<section class="mi-section"><div class="rmw-empty"><h3>${esc(ui('salesError'))}</h3></div></section></div>`;
    const L=p.ledger,notes=ledgerNotes(L,'salesLoading');
    let offline=false;try{offline=navigator.onLine===false;}catch(_){}
    if(offline)notes.unshift(`<p class="warn">${esc(ui('salesOffline'))}</p>`);
    const num=(v)=>window.KiwiNumber?.format(v,{})??v.toLocaleString(lang()==='en'?'en-GB':'fr-FR');
    const pct=(v)=>p.itemised>0?(v/p.itemised*100).toFixed(v/p.itemised*100<10?1:0)+' %':'·';
    const strip=`<div class="rmw-perf-ledger rmw-sales-ledger" data-ledger-gross="${L.gross.toFixed(2)}" data-ledger-net="${L.net.toFixed(2)}"><div><span>${esc(ui('ledgerGross'))}</span><b>${cash(L.gross)}</b><small>${esc(ui('ledgerTickets',{n:L.grossN}))}</small></div><div><span>${esc(ui('ledgerRefunds'))}</span><b>${L.refunds?'− '+cash(L.refunds):cash(0)}</b><small>${esc(ui('ledgerRefundCount',{n:L.refundN}))}</small></div><div><span>${esc(ui('ledgerNet'))}</span><b>${cash(L.net)}</b><small>${esc(ui('ledgerNetSub'))}</small></div><div><span>${esc(ui('salesAvgTicket'))}</span><b>${L.grossN?cash(L.gross/L.grossN):'·'}</b><small>${esc(ui('salesAvgTicketSub'))}</small></div></div>${notes.length?`<div class="rmw-perf-notes">${notes.join('')}</div>`:''}`;
    if(!L.grossN&&!p.items.length&&!p.offMenu.length){
      const empty=!D().items.length?`<h3>${esc(ui('noItemsToAnalyze'))}</h3><p>${esc(ui('noItemsToAnalyzeDesc'))}</p>`:`<h3>${esc(ui('salesNone'))}</h3><p>${esc(ui('salesNoneDesc'))}</p>`;
      return `<div class="rmw-sales" data-sales-state="${L.completeness==='loading'?'loading':'empty'}">${head}${strip}<section class="mi-section"><div class="rmw-empty">${empty}</div></section></div>`;
    }
    const max=Math.max(1,...p.categories.map(g=>g.revenue));
    const catRows=p.categories.map(g=>`<tr class="${g.off?'rmw-perf-off':''}" data-sales-cat="${esc(g.key)}"><td><b>${esc(g.name)}</b><small>${esc(ui('salesItemsCount',{n:g.n}))}</small></td><td>${num(g.qty)}</td><td>${cash(g.revenue)}</td><td><div class="rmw-sales-share"><i style="width:${(Math.max(0,g.revenue)/max*100).toFixed(1)}%"></i><span>${pct(g.revenue)}</span></div></td></tr>`).join('');
    const itemRow=(name,sub,r,off)=>{const extra=[];if(r.formulaQty)extra.push(ui('salesInFormula',{n:num(r.formulaQty)}));if(r.zeroQty)extra.push(ui('salesAtZero',{n:num(r.zeroQty)}));return `<tr class="${off?'rmw-perf-off':''}"><td><b>${esc(name)}</b><small>${esc(sub)}</small></td><td>${num(r.qty)}${extra.length?`<small>${esc(extra.join(' · '))}</small>`:''}</td><td>${cash(r.revenue)}</td><td>${pct(r.revenue)}</td><td>${r.pricedQty?cash(r.revenue/r.pricedQty):'·'}</td></tr>`;};
    const itemRows=p.items.map(r=>itemRow(t(r.item.name),cat(r.item.catId)?.name?t(cat(r.item.catId).name):ui('noSection'),r,false)).join('')+p.offMenu.map(o=>itemRow(o.name,ui(o.free?'freeAmountSection':'offMenuSection'),{qty:o.qty,revenue:o.revenue,pricedQty:o.revenue>0?o.qty:0},true)).join('');
    const lbl=(keys)=>keys.map((k,i)=>`--l${i+1}:${JSON.stringify(ui(k))}`).join(';');
    return `<div class="rmw-sales" data-sales-state="ready">${head}${strip}
      <section class="mi-section"><div class="mi-section-head"><h3>${esc(ui('salesByCategory'))}</h3></div><div class="mi-list-wrap" tabindex="0" role="region" aria-label="${esc(ui('salesByCategory'))}"><table class="mi-list rmw-sales-table" style="${esc(lbl(['salesColCategory','salesColQty','salesColRevenue','salesColShare']))}"><thead><tr><th>${esc(ui('salesColCategory'))}</th><th>${esc(ui('salesColQty'))}</th><th>${esc(ui('salesColRevenue'))}</th><th>${esc(ui('salesColShare'))}</th></tr></thead><tbody>${catRows}</tbody></table></div></section>
      <section class="mi-section"><div class="mi-section-head"><h3>${esc(ui('salesByItem'))}</h3></div><div class="mi-list-wrap" tabindex="0" role="region" aria-label="${esc(ui('salesByItem'))}"><table class="mi-list rmw-sales-table" style="${esc(lbl(['colItem','salesColQty','salesColRevenue','salesColShare','salesColAvgPrice']))}"><thead><tr><th>${esc(ui('colItem'))}</th><th>${esc(ui('salesColQty'))}</th><th>${esc(ui('salesColRevenue'))}</th><th>${esc(ui('salesColShare'))}</th><th>${esc(ui('salesColAvgPrice'))}</th></tr></thead><tbody>${itemRows}</tbody></table></div>
      <div class="rmw-perf-notes"><p>${esc(ui('salesShareNote',{amount:cash(p.itemised)}))}</p>${p.unsold?`<p>${esc(ui('salesUnsold',{n:p.unsold}))}</p>`:''}</div></section></div>`;
  }
  function salesStyle(){if($('#rmw-sales-css'))return;const s=document.createElement('style');s.id='rmw-sales-css';s.textContent=`
.rmw-sales-pills{margin-top:14px}
.rmw-sales-table td small{display:block;margin-top:3px;color:var(--n-500);font-size:11px}
.rmw-sales-table td:not(:first-child),.rmw-sales-table th:not(:first-child){text-align:end;font-variant-numeric:tabular-nums;white-space:nowrap}
.rmw-sales-share{display:flex;align-items:center;justify-content:flex-end;gap:10px}
.rmw-sales-share i{display:block;height:6px;min-width:2px;max-width:120px;flex:0 1 120px;border-radius:999px;background:var(--atlas)}
.rmw-sales-share span{min-width:44px}
@media (max-width:720px){.rmw-sales-table thead{display:none}.rmw-sales-table,.rmw-sales-table tbody{display:block}.rmw-sales-table tr{display:grid;grid-template-columns:1fr 1fr;gap:6px 12px;padding:12px 0;border-bottom:1px solid var(--n-200)}.rmw-sales-table td{display:block;text-align:start!important;padding:0}.rmw-sales-table td:first-child{grid-column:1/-1}.rmw-sales-table td:nth-child(2)::before{content:var(--l2);display:block;font:10px var(--mono);letter-spacing:.06em;text-transform:uppercase;color:var(--n-500)}.rmw-sales-table td:nth-child(3)::before{content:var(--l3);display:block;font:10px var(--mono);letter-spacing:.06em;text-transform:uppercase;color:var(--n-500)}.rmw-sales-table td:nth-child(4)::before{content:var(--l4);display:block;font:10px var(--mono);letter-spacing:.06em;text-transform:uppercase;color:var(--n-500)}.rmw-sales-table td:nth-child(5)::before{content:var(--l5);display:block;font:10px var(--mono);letter-spacing:.06em;text-transform:uppercase;color:var(--n-500)}.rmw-sales-share{justify-content:flex-start}}
`;document.head.appendChild(s);}
  const SERVICE_WINDOWS=[
    {id:'matin',name:'Matin',from:5*60,to:11*60},
    {id:'midi',name:'Midi',from:11*60,to:15*60},
    {id:'apresmidi',name:'Après-midi',from:15*60,to:19*60},
    {id:'soir',name:'Soir',from:19*60,to:29*60},
  ];
  function minuteLabel(value){const m=((Math.round(value)%1440)+1440)%1440,h=Math.floor(m/60),mm=m%60;return `${String(h).padStart(2,'0')}h${mm?String(mm).padStart(2,'0'):''}`;}
  function openingSpans(){
    const api=window.KiwiHours,doc=api?.get?.(venue());
    if(!api?.isConfigured?.(venue())||!doc?.week)return [];
    const spans=[];
    (api.DAYS||Object.keys(doc.week)).forEach(day=>{
      const d=doc.week[day];
      if(!d?.open)return;
      (d.periods||[]).forEach(p=>{
        const from=api.toMin?.(p.from),duration=api.span?.(p);
        if(from==null||!duration)return;
        spans.push({from,to:from+duration});
        /* A service entered as 00:00–02:00 belongs to the evening analysis
         * too, even when it is stored as a separate post-midnight period. */
        if(from<5*60)spans.push({from:from+1440,to:from+duration+1440});
      });
    });
    return spans;
  }
  function servicePeriods(){
    const spans=openingSpans();
    return SERVICE_WINDOWS.map(service=>{
      const overlaps=spans.map(span=>({from:Math.max(span.from,service.from),to:Math.min(span.to,service.to)})).filter(x=>x.to>x.from);
      if(!overlaps.length)return null;
      const from=Math.min(...overlaps.map(x=>x.from)),to=Math.max(...overlaps.map(x=>x.to));
      return {...service,from,to,label:`${service.name} (${minuteLabel(from)}-${minuteLabel(to)})`};
    }).filter(Boolean);
  }
  /* L'heure d'une vente dans le fuseau du COMMERCE, pas du navigateur : un
     tableau de bord ouvert depuis Paris rangeait le coup de feu de 21 h
     marocain dans la case 22 h. */
  let zoneClock=null,zoneClockZone='';
  function merchantMinute(ts){
    const zone=(()=>{try{return window.KiwiDayReport?.timezone?.()||'';}catch(_){return '';}})();
    if(!zone){const d=new Date(ts);return d.getHours()*60+d.getMinutes();}
    if(!zoneClock||zoneClockZone!==zone){try{zoneClock=new (globalThis.KiwiZoneLaw?.DateTimeFormat || Intl.DateTimeFormat)('en-GB',{timeZone:zone,hour:'2-digit',minute:'2-digit',hourCycle:'h23'});zoneClockZone=zone;}catch(_){zoneClock=null;const d=new Date(ts);return d.getHours()*60+d.getMinutes();}}
    const parts=zoneClock.formatToParts(new Date(ts));let h=0,m=0;parts.forEach(x=>{if(x.type==='hour')h=+x.value;if(x.type==='minute')m=+x.value;});return (h%24)*60+m;
  }
  function minuteInService(ts,service){const plain=merchantMinute(ts),m=service.to>1440&&plain<service.to-1440?plain+1440:plain;return m>=service.from&&m<service.to;}
  /* Les lignes du même registre que la Performance (KiwiCost.ledger) :
     annulations, doublons et remises y suivent les mêmes règles. */
  function hoursData(periods,selected,days=30,L=null){
    const rows=D().items.map(x=>({item:x,qty:0,revenue:0,byPeriod:{}})),match=saleLineMatcher(rows),w=analysisWindow(days);
    L=L||menuLedger(w);
    (L?L.lines:[]).forEach(x=>{
      const service=periods.find(p=>minuteInService(x.ts,p));if(!service)return;
      const row=match(x.line);if(!row||!x.qty)return;
      row.byPeriod[service.id]=(row.byPeriod[service.id]||0)+x.qty;
      if(service.id===selected.id){row.qty+=x.qty;row.revenue+=x.collected;}
    });
    const ranked=rows.filter(x=>x.qty>0).sort((a,b)=>b.qty-a.qty||b.revenue-a.revenue),totalQty=ranked.reduce((n,x)=>n+x.qty,0),totalRevenue=ranked.reduce((n,x)=>n+x.revenue,0);
    const notable=rows.map(row=>{const total=Object.values(row.byPeriod).reduce((n,x)=>n+x,0),best=periods.slice().sort((a,b)=>(row.byPeriod[b.id]||0)-(row.byPeriod[a.id]||0))[0],qty=best?(row.byPeriod[best.id]||0):0;return{row,total,best,qty,share:total?qty/total*100:0};}).filter(x=>x.total>=2&&x.share>=Math.max(55,100/periods.length+15)).sort((a,b)=>b.share-a.share||b.total-a.total).slice(0,5);
    return {ranked,totalQty,totalRevenue,top:ranked[0]||null,notable,days};
  }
  function hoursPanel(){
    const api=window.KiwiHours;
    /* Missing configuration must not hide recorded sales. Hourly buckets
     * describe timestamps, not assumed opening hours. */
    const configured=api?.isConfigured?.(venue());
    const L=menuLedger(analysisWindow(30)),recent=configured?[]:(L?L.lines:[]);
    const periods=configured?servicePeriods():Array.from({length:24},(_,h)=>({id:'hour-'+h,name:minuteLabel(h*60),from:h*60,to:(h+1)*60,label:`${minuteLabel(h*60)}-${minuteLabel((h+1)*60)}`})).filter(p=>recent.some(s=>minuteInService(+s.ts,p)));
    if(!periods.length)return `<section class="mi-section"><div class="rmw-empty"><h3>${esc(ui(configured?'noServiceToAnalyze':'noSalesYet'))}</h3><p>${esc(ui(configured?'noServiceToAnalyzeDesc':'noSalesYetDesc'))}</p></div></section>`;
    if(!periods.some(x=>x.id===hoursPeriod))hoursPeriod=configured?periods[0].id:periods.map(p=>({id:p.id,qty:hoursData(periods,p,30,L).totalQty})).sort((a,b)=>b.qty-a.qty)[0].id;
    const selected=periods.find(x=>x.id===hoursPeriod)||periods[0],data=hoursData(periods,selected,30,L),max=Math.max(1,...data.ranked.slice(0,10).map(x=>x.qty));
    const pills=periods.map(p=>`<button class="mi-pill${p.id===selected.id?' on':''}" data-action="rmw-hours-period" data-period="${p.id}">${esc(p.label)}</button>`).join('');
    const bars=data.ranked.slice(0,10).map(row=>`<div class="rmw-hours-row"><div class="rmw-hours-name" title="${esc(t(row.item.name))}">${esc(t(row.item.name))}</div><div class="rmw-hours-track"><i style="width:${(row.qty/max*100).toFixed(1)}%"></i></div><b>${(window.KiwiNumber?.format(row.qty, {}) ?? row.qty.toLocaleString(document.documentElement?.lang === 'en' ? 'en-GB' : 'fr-FR', {}))}</b></div>`).join('');
    const totalForTop=data.top?Object.values(data.top.byPeriod).reduce((n,x)=>n+x,0):0,topShare=data.top&&totalForTop?data.top.qty/totalForTop*100:0;
    const insight=data.top?`<div class="rmw-hours-insight"><span>${esc(ui('peakInsightTag', { label: selected.label }))}</span><h3>${esc(ui('peakInsightTitle', { item: t(data.top.item.name) }))}</h3><p>${esc(ui('peakInsightBody', { qty: (window.KiwiNumber?.format(data.top.qty, {}) ?? data.top.qty.toLocaleString(document.documentElement?.lang === 'en' ? 'en-GB' : 'fr-FR', {})), share: (data.top.qty/data.totalQty*100).toFixed(0), peakShare: topShare.toFixed(0), period: selected.name.toLowerCase() }))}</p></div>`:'';
    const notable=data.notable.map(x=>`<div class="rmw-hours-notable"><i></i><div><b>${esc(t(x.row.item.name))}</b><span>${esc(ui('peakNotableBody', { share: x.share.toFixed(0), total: (window.KiwiNumber?.format(x.total, {}) ?? x.total.toLocaleString(document.documentElement?.lang === 'en' ? 'en-GB' : 'fr-FR', {})), period: x.best.name.toLowerCase(), hours: `${minuteLabel(x.best.from)}-${minuteLabel(x.best.to)}` }))}</span></div></div>`).join('');
    const topQtyStr = data.top ? `${(window.KiwiNumber?.format(data.top.qty, {}) ?? data.top.qty.toLocaleString(document.documentElement?.lang === 'en' ? 'en-GB' : 'fr-FR', {}))} ${data.top.qty !== 1 ? ui('articles') : ui('article')}` : ui('noSaleRecorded');
    return `<div class="rmw-hours-page"><section class="mi-section"><div class="mi-section-head"><div><h3>${esc(ui('hoursTitle'))}</h3><div class="mi-section-sub">${esc(ui('hoursSub', { n: data.days }))} · ${esc(rangeLabel(analysisWindow(data.days)))}${configured?'':` · ${esc(ui('hoursObserved'))}`}</div></div></div><div class="mi-pill-row rmw-hours-pills">${pills}</div><div class="rmw-hours-kpis"><div><span>${esc(ui('itemsSold'))}</span><b>${(window.KiwiNumber?.format(data.totalQty, {}) ?? data.totalQty.toLocaleString(document.documentElement?.lang === 'en' ? 'en-GB' : 'fr-FR', {}))}</b><small>${esc(selected.label)}</small></div><div><span>${esc(ui('generatedRevenue'))}</span><b>${cash(data.totalRevenue)}</b><small>${esc(ui('inPeriod'))}</small></div><div><span>${esc(ui('topItem'))}</span><b>${data.top?esc(t(data.top.item.name)):'·'}</b><small>${esc(topQtyStr)}</small></div></div><div class="rmw-hours-list-title">${esc(ui('top10Items', { label: selected.label }))}</div>${bars?`<div class="rmw-hours-bars">${bars}</div>`:`<div class="rmw-empty"><h3>${esc(ui('noSalesInPeriod'))}</h3><p>${esc(ui('noSalesInPeriodDesc'))}</p></div>`}</section>${insight}${notable?`<section class="mi-section"><div class="mi-section-head"><h3>${esc(ui('itemsWithPeak'))}</h3></div><div class="rmw-hours-notables">${notable}</div></section>`:''}</div>`;
  }
  function alertsPanel(){
    const rows=D().items.filter(x=>x.avail===false).map(x=>`<div class="mi-group-card"><div class="mi-group-card-head"><span class="mi-group-card-name">${esc(t(x.name))}</span><span class="mi-group-card-pill req">${esc(ui('unavailableBadge'))}</span></div><button data-activation=write class="btn-slim primary" data-action="rmw-reactivate" data-arg="${x.id}">${esc(ui('reactivate'))}</button></div>`).join('');
    return `<section class="mi-section"><div class="mi-title">${esc(ui('alerts86Title'))}</div><div class="mi-sub">${esc(ui('alerts86Sub'))}</div><div class="mi-groups-grid">${rows||`<div class="rmw-empty">${esc(ui('no86Alerts'))}</div>`}</div></section>`;
  }
  /* Réglages de caisse des métiers de bouche (pizzeria, traiteur, boulangerie) :
     l'onglet n'existe que là, et seulement en vrai (assets/food-trade-settings.js). */
  const caisseOn=()=>!!window.KiwiFoodTradeSettings?.enabled?.();
  /* Promotions de la carte (assets/menu-promos-dashboard.js) : la règle, son
     éditeur et le prix appliqué par la caisse, l'appli Serveur et le serveur. */
  const promosOn=()=>!!window.KiwiMenuPromosPanel?.enabled?.();
  function promosPanel(){return `<div data-rmw-promos>${window.KiwiMenuPromosPanel?.html?.()||''}</div>`;}
  function caissePanel(){
    return `<section class="mi-section"><div class="mi-title">${esc(ui('caisseTitle'))}</div><div class="mi-sub">${esc(ui('caisseSub'))}</div><div data-rmw-caisse></div></section>`;
  }
  function nfcPanel(){
    const on=!!window.KiwiOrderProPanel?.enabled?.();
    return `<section class="mi-section"><div class="mi-title">${esc(ui('nfcTitle'))}</div><div class="mi-sub">${esc(ui('nfcSub'))}</div>${on?'<div class="rmw-nfc" data-rmw-nfc></div>':`<div class="rmw-empty"><h3>${esc(ui('nfcUnavailable'))}</h3><p>${esc(ui('nfcUnavailableDesc'))}</p></div>`}</section>`;
  }
  const modal=(o)=>window.Kiwi?.modal?.(o);
  function ask(title,label,value,save){const m=modal({title,width:460,body:`<label class="kf-label">${esc(label)}</label><input class="kf-input" data-value value="${esc(value||'')}"/>`,foot:`<button class="kb ghost" data-cancel>${esc(ui('cancelBtn'))}</button><button data-activation=write class="eq-cta-gradient" data-save>${esc(ui('saveBtn'))}</button>`});$('[data-cancel]',m.el).onclick=m.close;$('[data-save]',m.el).onclick=()=>{const v=$('[data-value]',m.el).value.trim();if(!v)return;save(v);m.close();render();};$('[data-value]',m.el).focus();}
  function openCategory(x){
    const d=D(),kid=S().kitchenId(venue());
    const m=modal({title:x?ui('editSectionTitle'):ui('newSectionTitle'),width:500,body:`<div class="kf-group"><label class="kf-label" for="rmw-section-name">${esc(ui('sectionNameLabel'))}</label><input id="rmw-section-name" class="kf-input" data-name value="${esc(x?.name||'')}" placeholder="${esc(ui('sectionNamePlaceholder'))}"/></div>${x?`<div class="kf-group"><label class="kf-label" for="rmw-section-station">${esc(ui('stationLabel'))}</label><select id="rmw-section-station" class="kf-input" data-station><option value="">${esc(ui('defaultRoute', { name: t(station(kid)?.name)||ui('kitchen') }))}</option>${d.stations.filter(s=>s.id!==kid).map(s=>`<option value="${s.id}"${x.station===s.id?' selected':''}>${esc(t(s.name))}</option>`).join('')}</select></div>`:''}`,foot:`<button class="kb ghost" data-cancel>${esc(ui('cancelBtn'))}</button><button data-activation=write class="eq-cta-gradient" data-save>${esc(ui('saveBtn'))}</button>`});
    $('[data-cancel]',m.el).onclick=m.close;$('[data-save]',m.el).onclick=()=>{const n=$('[data-name]',m.el).value.trim();if(!n)return;if(x){S().renameCategory(x.id,n);S().setCategoryStation(x.id,$('[data-station]',m.el).value);}else S().addCategory(n);m.close();render();};
  }
  async function upload(file,kind,status){if(!file)return'';if(!window.KiwiOrderPro?.uploadMedia){status.textContent=ui('itUploadUnavailable');return'';}status.textContent=ui('itUploading');try{const r=await window.KiwiOrderPro.uploadMedia(file,{kind}),u=typeof r==='string'?r:r?.url||'';status.textContent=u?ui('itUploadReady'):(window.KiwiOrderPro.uploadError?window.KiwiOrderPro.uploadError(r):ui('itUploadFailed'));return u;}catch(_){status.textContent=ui('itUploadFailed');return'';}}
  /* L'éditeur d'article : la fiche à gauche (article, options, formule), la
     photo et ce qui décide de la visibilité à droite. Même feuille que
     l'éditeur de recette (rmw-recipe-modal) : opaque, un seul style de champ,
     des interrupteurs pour ce qui est oui ou non, des icônes Material. */
  const IT_ICON={add:'M440-440H200v-80h240v-240h80v240h240v80H520v240h-80v-240Z',close:'m256-200-56-56 224-224-224-224 56-56 224 224 224-224 56 56-224 224 224 224-56 56-224-224-224 224Z',del:'M280-120q-33 0-56.5-23.5T200-200v-520h-40v-80h200v-40h240v40h200v80h-40v520q0 33-23.5 56.5T680-120H280Zm400-600H280v520h400v-520ZM360-280h80v-360h-80v360Zm160 0h80v-360h-80v360ZM280-720v520-520Z',check:'M382-240 154-468l57-57 171 171 367-367 57 57-424 424Z',photo:'M480-480ZM200-120q-33 0-56.5-23.5T120-200v-560q0-33 23.5-56.5T200-840h320v80H200v560h560v-320h80v320q0 33-23.5 56.5T760-120H200Zm40-160h480L570-480 450-320l-90-120-120 160Zm440-320v-80h-80v-80h80v-80h80v80h80v80h-80v80h-80Z',image:'M200-120q-33 0-56.5-23.5T120-200v-560q0-33 23.5-56.5T200-840h560q33 0 56.5 23.5T840-760v560q0 33-23.5 56.5T760-120H200Zm0-80h560v-560H200v560Zm40-80h480L570-480 450-320l-90-120-120 160Zm-40 80v-560 560Z'};
  const itSvg=(k)=>`<svg viewBox="0 -960 960 960" aria-hidden="true"><path d="${IT_ICON[k]}"/></svg>`;
  function openItem(x){
    const d=D();if(!d.cats.length){openCategory(null);return;}
    let photo=x?.photo||'',video=x?.video||'';
    const availableItems=(d.items||[]).filter(it=>(!x||it.id!==x.id)&&!it.archived);
    const archivedItems=(d.items||[]).filter(it=>it&&it.archived&&(!x||it.id!==x.id));
    const formulaTemplates=[...(d.formulaTemplates||[]).filter(t=>t?.formula?.slots?.length).map(t=>({id:'template:'+t.id,name:t.name,formula:t.formula})),...(d.items||[]).filter(it=>it.formula?.slots?.length).map(it=>({id:'item:'+it.id,name:`${t(it.name)}`,formula:it.formula}))];
    let formulaSlots=x?.formula?.slots?JSON.parse(JSON.stringify(x.formula.slots)):[],expandedFormulaSlot=formulaSlots.length?0:-1;
    // « Le client en choisit {min} à {max} » : la règle se lit comme une phrase, les deux nombres sont les champs.
    const ruleHtml=(slot,si)=>ui('itRule').split(/(\{min\}|\{max\})/).map(part=>part==='{min}'?`<input class="rmw-st-num" type="number" min="0" max="10" inputmode="numeric" data-slot-min="${si}" value="${slot.min!=null?slot.min:1}" aria-label="${esc(ui('minLabel'))}"/>`:part==='{max}'?`<input class="rmw-st-num" type="number" min="1" max="10" inputmode="numeric" data-slot-max="${si}" value="${slot.max!=null?slot.max:1}" aria-label="${esc(ui('maxLabel'))}"/>`:part?`<span>${esc(part)}</span>`:'').join('');
    const slotRowHtml=(slot,si)=>{
      const open=expandedFormulaSlot===si,n=(slot.choices||[]).length;
      const choicesHtml=(slot.choices||[]).map((ch,ci)=>{const hit=d.items.find(it=>it.id===ch.itemId),name=hit?t(hit.name):ch.itemId;return `<div class="rmw-st-choice" data-si="${si}" data-ci="${ci}"><span class="rmw-st-n">${ci+1}</span><span class="rmw-st-name"><b>${esc(name)}</b>${hit?`<small>${esc(ui('itAlone',{price:cash(hit.price)}))}</small>`:''}</span><label class="rmw-st-extra"><span>${esc(ui('extra'))}</span><span class="rmw-rx-suffix rmw-st-plus"><em>+</em><input class="rmw-rx-in" type="number" min="0" step="0.5" inputmode="decimal" data-ch-extra="${si}-${ci}" value="${+ch.extra||0}"/><i>MAD</i></span></label><button type="button" class="rmw-rx-del" data-del-choice="${si}-${ci}" aria-label="${esc(ui('removeChoice'))}">${itSvg('close')}</button></div>`;}).join('');
      const avToAdd=availableItems.filter(it=>!(slot.choices||[]).some(c=>c.itemId===it.id));
      const pickerOption=(it,category)=>{const sub=category&&(category.sub||[]).find(entry=>entry.id===it.subId),context=sub?t(sub.name):(category?t(category.name):ui('noSection')),search=`${t(it.name)||''} ${category?t(category.name):''} ${sub?t(sub.name):''}`.toLocaleLowerCase();return `<button type="button" class="rmw-formula-picker-option" role="option" data-rmw-picker-item="${esc(it.id)}" data-rmw-picker-si="${si}" data-picker-search="${esc(search)}"><span class="rmw-formula-picker-option-copy"><strong>${esc(t(it.name))}</strong><small>${esc(context)}</small></span><span class="rmw-formula-picker-price">${cash(it.price)}</span><span class="rmw-formula-picker-add">${itSvg('add')}</span></button>`;};
      const pickerGroups=d.cats.map(category=>{const items=avToAdd.filter(it=>it.catId===category.id);return items.length?`<section class="rmw-formula-picker-group" data-picker-group><div class="rmw-formula-picker-group-title">${esc(t(category.name))}</div>${items.map(it=>pickerOption(it,category)).join('')}</section>`:'';}).join(''),uncategorized=avToAdd.filter(it=>!d.cats.some(category=>category.id===it.catId)),pickerGroupsHtml=pickerGroups+(uncategorized.length?`<section class="rmw-formula-picker-group" data-picker-group><div class="rmw-formula-picker-group-title">${esc(ui('noSection'))}</div>${uncategorized.map(it=>pickerOption(it,null)).join('')}</section>`:'');
      let addBarHtml='';
      if(availableItems.length===0)addBarHtml=`<div class="rmw-st-note"><p>${esc(ui('noItemsOnMenuFormulaNotice'))}</p><button data-activation=write type="button" class="rmw-rx-link" data-f-save-and-create>${esc(ui('saveAndCreateItemBtn'))}</button></div>`;
      else if(avToAdd.length===0)addBarHtml=`<div class="rmw-st-note"><p>${esc(ui('allChosenNotice'))}</p></div>`;
      else addBarHtml=`<div class="rmw-st-add"><button type="button" class="rmw-st-pick" data-rmw-picker-toggle="${si}" aria-haspopup="listbox" aria-expanded="false">${itSvg('add')}<span>${esc(ui('itAddChoice'))}</span></button><div class="rmw-formula-picker" data-rmw-picker-panel="${si}" role="listbox" aria-label="${esc(ui('chooseItemPlaceholder'))}" hidden><div class="rmw-formula-picker-search"><label>${pickerSearchIcon}<input type="search" data-rmw-picker-search="${si}" placeholder="${esc(ui('searchPlaceholder'))}" autocomplete="off"/></label></div><div class="rmw-formula-picker-results" tabindex="0" role="region" aria-label="${esc(ui('chooseItemPlaceholder'))}">${pickerGroupsHtml}<div class="rmw-formula-picker-empty" data-picker-empty hidden>${esc(ui('noItemMatch'))}</div></div></div></div>`;
      return `<div class="rmw-st${open?' is-open':''}" data-slot-idx="${si}"><div class="rmw-st-head"><span class="rmw-st-kicker">${esc(ui('step'))} ${si+1}</span><div class="rmw-st-acts"><span class="rmw-st-sum">${esc(ui(n===1?'itChoiceOne':'itChoiceCount',{n}))}</span><button type="button" class="rmw-st-btn" data-slot-toggle="${si}" aria-expanded="${open?'true':'false'}" aria-label="${esc(ui(open?'itCollapse':'itExpand'))}">${pickerChevronIcon}</button><button type="button" class="rmw-st-btn danger" data-del-slot="${si}" aria-label="${esc(ui('deleteStep'))}">${itSvg('del')}</button></div><input class="rmw-st-title" data-slot-label="${si}" value="${esc(slot.label||'')}" placeholder="${esc(ui('stepTitlePlaceholder'))}" aria-label="${esc(ui('step'))} ${si+1}"/><div class="rmw-st-rule" role="group" aria-label="${esc(ui('selectionRule'))}">${ruleHtml(slot,si)}</div><p class="rmw-it-err rmw-st-err" id="rmw-st-err-${si}" data-slot-err="${si}" aria-live="polite" hidden></p></div><div class="rmw-st-body"${open?'':' hidden'}>${choicesHtml?`<div class="rmw-st-list">${choicesHtml}</div>`:`<p class="rmw-st-empty">${esc(ui('noChoicesInStep'))}</p>`}${addBarHtml}</div></div>`;
    };
    const toggle=(attr,on,label,help)=>`<label class="rmw-it-tg"><span class="rmw-it-tg-txt"><b>${esc(label)}</b><small>${esc(help)}</small></span><input type="checkbox" role="switch" ${attr}${on?' checked':''}/><span class="rmw-it-sw" aria-hidden="true"></span></label>`;
    const mediaTile=()=>photo?`<img src="${esc(photo)}" alt="">`:video?`<video src="${esc(video)}" muted playsinline loop autoplay></video>`:`<span class="rmw-it-ph">${itSvg('image')}<small>${esc(ui('itNoMedia'))}</small></span>`;
    const optsHtml=d.opts.length?`<div class="rmw-it-chips">${d.opts.map(g=>{const n=(g.choices||[]).length;return `<label class="rmw-it-chip"><input type="checkbox" data-opt="${g.id}"${(x?.opts||[]).includes(g.id)?' checked':''}/><span class="rmw-it-chip-box">${itSvg('check')}</span><span class="rmw-it-chip-txt"><b>${esc(t(g.name))}</b>${n?`<small>${esc(ui(n===1?'itChoiceOne':'itChoiceCount',{n}))}</small>`:''}</span></label>`;}).join('')}</div>`:`<p class="rmw-rx-hint">${esc(ui('createOptGroupFirst'))}</p>`;
    const tplHtml=formulaTemplates.length?`<div class="rmw-it-tpl"><select class="rmw-rx-unit" data-formula-template data-kiwi-native-select aria-label="${esc(ui('formulaTemplatePlaceholder'))}"><option value="">${esc(ui('formulaTemplatePlaceholder'))}</option>${formulaTemplates.map(it=>`<option value="${it.id}">${esc(it.name)}</option>`).join('')}</select><button type="button" class="rmw-it-sbtn" data-apply-formula-template>${esc(ui('itApplyTpl'))}</button></div>`:'';
    const m=modal({title:x?ui('editItemTitle',{name:t(x.name)}):ui('newItemTitle'),width:980,body:`<div class="rmw-it">
      <div class="rmw-rx-main">
        <section class="rmw-rx-sec"><div class="rmw-rx-sec-head"><div><h4>${esc(ui('itSecItem'))}</h4><p>${esc(ui('itSecItemHelp'))}</p></div></div>
          <div class="rmw-it-grid">
            <label class="rmw-it-f"><span>${esc(ui('nameLabel'))}</span><input class="rmw-rx-in" data-name value="${esc(x?.name||'')}" autocomplete="off"/><em class="rmw-it-err" data-name-err hidden>${esc(ui('itNameRequired'))}</em></label>
            <label class="rmw-it-f"><span>${esc(ui('itPrice'))}</span><span class="rmw-rx-suffix"><input class="rmw-rx-in" type="number" min="0" step="0.01" inputmode="decimal" data-price value="${+x?.price||0}"/><i>MAD</i></span></label>
            <label class="rmw-it-f rmw-it-full"><span>${esc(ui('sectionLabel'))}</span><select class="rmw-rx-unit" data-cat data-kiwi-native-select>${d.cats.map(c=>`<option value="${c.id}"${x?.catId===c.id?' selected':''}>${esc(t(c.name))}</option>`).join('')}</select></label>
            <label class="rmw-it-f rmw-it-full"><span>${esc(ui('descLabel'))}</span><textarea class="rmw-rx-in" data-desc rows="3" placeholder="${esc(ui('itDescPh'))}">${esc(x?.desc||'')}</textarea></label>
          </div>
        </section>
        <section class="rmw-rx-sec"><div class="rmw-rx-sec-head"><div><h4>${esc(ui('itemOptionsLabel'))}</h4><p>${esc(ui('itSecOptionsHelp'))}</p></div></div>${optsHtml}</section>
        <section class="rmw-rx-sec rmw-it-formula"><div class="rmw-rx-sec-head"><div><h4>${esc(ui('itSecFormula'))}</h4><p>${esc(ui('isFormulaHelp'))}</p></div><label class="rmw-it-tg bare"><input type="checkbox" role="switch" data-is-formula aria-label="${esc(ui('isFormulaLabel'))}"${formulaSlots.length?' checked':''}/><span class="rmw-it-sw" aria-hidden="true"></span></label></div>
          <div class="rmw-formula-builder rmw-it-builder" data-formula-wrap${formulaSlots.length?'':' hidden'}>${tplHtml}<div data-slots-wrap class="rmw-it-steps"></div>
            <div class="rmw-it-formula-foot"><button data-activation=write type="button" class="rmw-rx-add" data-add-slot>${itSvg('add')}<span>${esc(ui('addStepBtn'))}</span></button><button data-activation=write type="button" class="rmw-rx-link" data-save-formula-template>${esc(ui('itSaveTpl'))}</button></div>
            ${archivedItems.length?`<details class="rmw-archived-group"><summary>${esc(ui('archivedGroup'))} · ${archivedItems.length}</summary>${archivedItems.map(it=>`<button type="button" disabled>${esc(t(it.name))}</button>`).join('')}</details>`:''}
          </div>
        </section>
      </div>
      <aside class="rmw-rx-side rmw-it-side">
        <div class="rmw-it-media" data-media-tile>${mediaTile()}</div>
        <div class="rmw-it-macts"><label class="rmw-it-mbtn">${itSvg('photo')}<span>${esc(ui('itPhoto'))}</span><input hidden type="file" accept="image/*" data-photo/></label><label class="rmw-it-mbtn"><span>${esc(ui('itVideo'))}</span><input hidden type="file" accept="video/*" data-video/></label><button type="button" class="rmw-it-mbtn ghost" data-media-remove${photo||video?'':' hidden'}>${esc(ui('removeMediaBtn'))}</button></div>
        <p class="rmw-it-mstatus" data-media-status aria-live="polite"></p>
        <div class="rmw-it-tgs">${toggle('data-avail',x?.avail!==false,ui('availableOpt'),ui('itAvailHelp'))}${toggle('data-standalone',!x?.formulaOnly,ui('standalone'),ui('formulaOnly'))}${toggle('data-formula-choice-photo',!!x?.showPhotoInFormulas,ui('formulaChoicePhoto'),ui('formulaChoicePhotoHelp'))}</div>
      </aside>
    </div>`,foot:(x?`<button class="kb ghost danger rmw-it-archive" data-archive>${esc(x.archived?ui('restore'):ui('archive'))}</button>`:'')+`<button class="kb ghost" data-cancel>${esc(ui('cancelBtn'))}</button><button data-activation=write class="eq-cta-gradient" data-save>${esc(ui('saveBtn'))}</button>`});
    recipeStyle();itemStyle();
    m.el.classList.add('rmw-item-workspace','rmw-recipe-modal');
    const sheet=$('.kiwi-modal',m.el),body=$('.kiwi-modal-body',m.el);
    body?.addEventListener('scroll',()=>sheet?.classList.toggle('rmw-scrolled',body.scrollTop>4),{passive:true});
    const isFormulaCb=$('[data-is-formula]',m.el),formulaWrap=$('[data-formula-wrap]',m.el),slotsWrap=$('[data-slots-wrap]',m.el);
    /* A step the till cannot complete was saved silently: min above max was
       clamped, a titled step with no dish was dropped by the server (the dish
       could stop being a formula), and 3 required out of 2 dishes blocked the
       order. Each problem is now said in the step and described on its fields. */
    const slotProblem=slot=>{const n=(slot.choices||[]).length,min=slot.min!=null?+slot.min:1,max=slot.max!=null?+slot.max:1;if(!(slot.label||'').trim()&&!n)return null;if(min>max)return{msg:ui('itRuleMinMax',{min,max}),fields:['min','max']};if(!n)return{msg:ui('itStepNoChoice'),fields:[]};if(n<min)return{msg:ui('itStepTooFew',{n,min}),fields:['min']};return null;};
    const showSlotError=si=>{const slot=formulaSlots[si],err=$(`[data-slot-err="${si}"]`,slotsWrap);if(!slot||!err)return null;const problem=isFormulaCb.checked?slotProblem(slot):null,msg=problem?problem.msg:'';if(err.textContent!==msg)err.textContent=msg;err.hidden=!msg;
      const fields={min:$(`[data-slot-min="${si}"]`,slotsWrap),max:$(`[data-slot-max="${si}"]`,slotsWrap),pick:$(`[data-rmw-picker-toggle="${si}"]`,slotsWrap)};
      for(const [k,f] of Object.entries(fields)){if(!f)continue;const ids=(f.getAttribute('aria-describedby')||'').split(/\s+/).filter(x=>x&&x!==err.id);if(msg)ids.push(err.id);if(ids.length)f.setAttribute('aria-describedby',ids.join(' '));else f.removeAttribute('aria-describedby');if(k!=='pick'){if(problem&&problem.fields.includes(k))f.setAttribute('aria-invalid','true');else f.removeAttribute('aria-invalid');}}
      return problem;};
    const renderSlots=(focusSel)=>{if(!slotsWrap)return;slotsWrap.innerHTML=formulaSlots.map(slotRowHtml).join('')||`<p class="rmw-st-empty">${esc(ui('itNoStep'))}</p>`;formulaSlots.forEach((_,si)=>showSlotError(si));
      /* The rebuild removed the control the keyboard was on: put focus back on its successor. */
      if(focusSel){const sels=Array.isArray(focusSel)?focusSel:[focusSel];for(const sel of sels){const el=sel&&$(sel,m.el);if(el){el.focus();break;}}}};
    const formulaTemplateSelect=$('[data-formula-template]',m.el),applyFormulaTemplate=$('[data-apply-formula-template]',m.el);
    if(applyFormulaTemplate)applyFormulaTemplate.onclick=()=>{const template=formulaTemplates.find(it=>it.id===formulaTemplateSelect?.value);if(!template)return;formulaSlots=JSON.parse(JSON.stringify(template.formula.slots));expandedFormulaSlot=formulaSlots.length?0:-1;isFormulaCb.checked=true;if(formulaWrap)formulaWrap.hidden=false;renderSlots();toast(ui('itFormulaCopied'),template.name);};
    const saveFormulaTemplateBtn=$('[data-save-formula-template]',m.el);
    if(saveFormulaTemplateBtn)saveFormulaTemplateBtn.onclick=()=>{const clean={slots:JSON.parse(JSON.stringify(formulaSlots))};if(!clean.slots.some(s=>s?.choices?.length)){toast(ui('itFormulaEmpty'),ui('itFormulaEmptyHelp'),'warn');return;}ask(ui('saveTemplateBtn'),ui('itTemplateName'),x?.name||'',name=>{S().saveFormulaTemplate(name,clean);toast(ui('itFormulaSaved'),name);});};
    isFormulaCb.onchange=()=>{const on=!!isFormulaCb.checked;if(on&&!formulaSlots.length){formulaSlots.push({id:'sl_1',label:'',min:1,max:1,choices:[]});expandedFormulaSlot=0;}if(formulaWrap)formulaWrap.hidden=!on;renderSlots();};
    $('[data-add-slot]',m.el).onclick=()=>{if(formulaSlots.length>=10)return;formulaSlots.push({id:'sl_'+(formulaSlots.length+1),label:'',min:1,max:1,choices:[]});expandedFormulaSlot=formulaSlots.length-1;renderSlots();$(`[data-slot-label="${formulaSlots.length-1}"]`,slotsWrap)?.focus();};
    slotsWrap.addEventListener('input',e=>{
      const pickerSearch=e.target.closest('[data-rmw-picker-search]');
      if(pickerSearch){const panel=pickerSearch.closest('[data-rmw-picker-panel]'),term=pickerSearch.value.trim().toLocaleLowerCase();let visible=0;panel.querySelectorAll('[data-picker-search]').forEach(option=>{const match=!term||(option.dataset.pickerSearch||'').includes(term);option.hidden=!match;if(match)visible+=1;});panel.querySelectorAll('[data-picker-group]').forEach(group=>{group.hidden=!group.querySelector('[data-picker-search]:not([hidden])');});const empty=panel.querySelector('[data-picker-empty]');if(empty)empty.hidden=visible!==0;return;}
      const lbl=e.target.closest('[data-slot-label]');if(lbl){const si=+lbl.dataset.slotLabel;if(formulaSlots[si])formulaSlots[si].label=lbl.value;showSlotError(si);return;}
      const min=e.target.closest('[data-slot-min]');if(min){const si=+min.dataset.slotMin;if(formulaSlots[si])formulaSlots[si].min=Math.max(0,Math.min(10,+min.value||0));showSlotError(si);return;}
      const max=e.target.closest('[data-slot-max]');if(max){const si=+max.dataset.slotMax;if(formulaSlots[si])formulaSlots[si].max=Math.max(1,Math.min(10,+max.value||1));showSlotError(si);return;}
      const ext=e.target.closest('[data-ch-extra]');if(ext){const [si,ci]=ext.dataset.chExtra.split('-').map(Number);if(formulaSlots[si]?.choices?.[ci])formulaSlots[si].choices[ci].extra=Math.max(0,+ext.value||0);}
    });
    const closePickers=()=>{$$('[data-rmw-picker-panel]',slotsWrap).forEach(panel=>{panel.hidden=true;panel.classList.remove('is-floating');panel.removeAttribute('style');});$$('[data-rmw-picker-toggle]',slotsWrap).forEach(trigger=>trigger.setAttribute('aria-expanded','false'));};
    slotsWrap.addEventListener('click',e=>{
      if(e.target.closest('[data-f-save-and-create]')){saveItem(()=>{openItem(null);});return;}
      const st=e.target.closest('[data-slot-toggle]');if(st){const si=+st.dataset.slotToggle;expandedFormulaSlot=expandedFormulaSlot===si?-1:si;renderSlots(`[data-slot-toggle="${si}"]`);return;}
      const ds=e.target.closest('[data-del-slot]');if(ds){const si=+ds.dataset.delSlot;formulaSlots.splice(si,1);if(expandedFormulaSlot===si)expandedFormulaSlot=Math.min(si,formulaSlots.length-1);else if(expandedFormulaSlot>si)expandedFormulaSlot-=1;renderSlots([`[data-del-slot="${Math.min(si,formulaSlots.length-1)}"]`,'[data-add-slot]']);return;}
      const dc=e.target.closest('[data-del-choice]');if(dc){const [si,ci]=dc.dataset.delChoice.split('-').map(Number);if(formulaSlots[si]?.choices){formulaSlots[si].choices.splice(ci,1);renderSlots([`[data-del-choice="${si}-${Math.min(ci,formulaSlots[si].choices.length-1)}"]`,`[data-rmw-picker-toggle="${si}"]`,`[data-slot-min="${si}"]`]);}return;}
      const pickerToggle=e.target.closest('[data-rmw-picker-toggle]');
      if(pickerToggle){const panel=$(`[data-rmw-picker-panel="${pickerToggle.dataset.rmwPickerToggle}"]`,slotsWrap),willOpen=panel&&panel.hidden;closePickers();if(panel&&willOpen){panel.hidden=false;panel.classList.add('is-floating');pickerToggle.setAttribute('aria-expanded','true');const r=pickerToggle.getBoundingClientRect(),w=Math.min(Math.max(r.width,520),innerWidth-24);panel.style.width=w+'px';panel.style.left=Math.max(12,Math.min(r.left,innerWidth-w-12))+'px';const h=Math.min(panel.scrollHeight,460),below=innerHeight-r.bottom;panel.style.top=(below>=Math.min(h,320)?r.bottom+8:Math.max(12,r.top-h-8))+'px';requestAnimationFrame(()=>$('[data-rmw-picker-search]',panel)?.focus());}return;}
      const pickerItem=e.target.closest('[data-rmw-picker-item]');
      if(pickerItem){const si=+pickerItem.dataset.rmwPickerSi,pid=pickerItem.dataset.rmwPickerItem;if(pid&&formulaSlots[si]){formulaSlots[si].choices=formulaSlots[si].choices||[];if(formulaSlots[si].choices.length<20&&!formulaSlots[si].choices.some(choice=>choice.itemId===pid)){formulaSlots[si].choices.push({itemId:pid,extra:0});renderSlots(`[data-rmw-picker-toggle="${si}"]`);}}return;}
    });
    slotsWrap.addEventListener('keydown',e=>{if(e.key==='ArrowDown'||e.key==='ArrowUp'){const panel=e.target.closest('[data-rmw-picker-panel]');if(!panel)return;const opts=[...panel.querySelectorAll('[data-rmw-picker-item]')].filter(o=>!o.hidden&&!o.closest('[data-picker-group]')?.hidden);if(!opts.length)return;e.preventDefault();const at=opts.indexOf(document.activeElement);const next=e.key==='ArrowDown'?(at<0?0:Math.min(opts.length-1,at+1)):(at<=0?-1:at-1);if(next<0)$('[data-rmw-picker-search]',panel)?.focus();else opts[next].focus();return;}if(e.key!=='Escape')return;const panel=e.target.closest('[data-rmw-picker-panel]');if(!panel||panel.hidden)return;/* Escape closes the picker, not the dish editor and its unsaved work. */e.__kiwiEscTaken=true;const si=panel.dataset.rmwPickerPanel;panel.hidden=true;const trigger=$(`[data-rmw-picker-toggle="${si}"]`,slotsWrap);trigger?.setAttribute('aria-expanded','false');trigger?.focus();});
    m.el.addEventListener('click',e=>{if(e.target.closest('.rmw-st-add'))return;closePickers();});
    renderSlots();
    const archiveBtn=$('[data-archive]',m.el);
    if(archiveBtn)archiveBtn.onclick=()=>{S().updateItem(x.id,{archived:!x.archived});m.close();render();toast(ui('itSaved'),t(x.name));};
    const status=$('[data-media-status]',m.el),tile=$('[data-media-tile]',m.el),removeBtn=$('[data-media-remove]',m.el);
    const showMedia=()=>{tile.innerHTML=mediaTile();removeBtn.hidden=!(photo||video);};
    $('[data-photo]',m.el).onchange=async e=>{const u=await upload(e.target.files[0],'image',status);if(u){photo=u;video='';showMedia();}e.target.value='';};
    $('[data-video]',m.el).onchange=async e=>{const u=await upload(e.target.files[0],'video',status);if(u){video=u;photo='';showMedia();}e.target.value='';};
    removeBtn.onclick=()=>{photo='';video='';showMedia();status.textContent=ui('itMediaRemoved');};
    $('[data-cancel]',m.el).onclick=m.close;
    const nameInput=$('[data-name]',m.el),nameErr=$('[data-name-err]',m.el);
    nameInput.addEventListener('input',()=>{if(nameInput.value.trim()){nameErr.hidden=true;nameInput.removeAttribute('aria-invalid');}});
    const saveItem=(onSuccess)=>{
      const name=nameInput.value.trim();
      // Un nom vide n'enregistre rien : le dire, au lieu d'un bouton qui ne répond pas.
      if(!name){nameErr.hidden=false;nameInput.setAttribute('aria-invalid','true');nameInput.focus();return;}
      if(isFormulaCb.checked){const bad=formulaSlots.findIndex(slotProblem);if(bad>=0){if(expandedFormulaSlot!==bad){expandedFormulaSlot=bad;renderSlots();}const problem=showSlotError(bad);const target=problem.fields.length?$(`[data-slot-min="${bad}"]`,slotsWrap):($(`[data-rmw-picker-toggle="${bad}"]`,slotsWrap)||$('[data-f-save-and-create]',slotsWrap)||$(`[data-slot-label="${bad}"]`,slotsWrap));target?.scrollIntoView?.({block:'center'});target?.focus();return;}}
      const validSlots=isFormulaCb.checked?formulaSlots.filter(s=>(s.label||'').trim()||(s.choices&&s.choices.length)).map(s=>({id:s.id||'sl_'+Math.random().toString(36).slice(2,6),label:s.label||ui('itDefaultStep'),min:s.min!=null?s.min:1,max:s.max!=null?s.max:1,choices:(s.choices||[]).map(c=>({itemId:c.itemId,extra:window.KiwiMenuRules.nonnegative(c.extra)}))})):[];
      const p={name,price:+$('[data-price]',m.el).value||0,catId:$('[data-cat]',m.el).value,desc:$('[data-desc]',m.el).value,avail:!!$('[data-avail]',m.el).checked,formulaOnly:!$('[data-standalone]',m.el).checked,showPhotoInFormulas:!!$('[data-formula-choice-photo]',m.el)?.checked,archived:!!x?.archived,photo,video,opts:$$('[data-opt]:checked',m.el).map(e=>e.dataset.opt),formula:validSlots.length?{slots:validSlots}:null};
      x?S().updateItem(x.id,p):S().addItem(p);m.close();render();toast(ui('itSaved'),name);
      if(typeof onSuccess==='function')onSuccess();
    };
    $('[data-save]',m.el).onclick=()=>saveItem();
  }
  /* Repère (KDS emoji) picker. It sat at « left: innerWidth − 390 », off the
     left edge of a phone, said « Aucun repère » in French under EN and AR, and
     stayed open until something was picked: no Escape, no click-away. */
  function emojiPicker(button){
    $$('.rmw-emoji-pop').forEach(x=>x.remove());
    const all=S().optionEmojis?.()||[],p=document.createElement('div'),r=button.getBoundingClientRect();
    p.className='rmw-emoji-pop';p.setAttribute('role','dialog');p.setAttribute('aria-label',ui('ogMarkPick'));
    p.innerHTML=`<button type="button" data-emoji="" class="rmw-none">${esc(ui('ogNoMark'))}</button>${all.map(e=>`<button type="button" data-emoji="${esc(e)}">${esc(e)}</button>`).join('')}`;
    document.body.appendChild(p);
    const w=p.offsetWidth,h=p.offsetHeight;
    p.style.left=Math.max(8,Math.min(r.left,innerWidth-w-8))+'px';
    p.style.top=(r.bottom+6+h>innerHeight-8?Math.max(8,r.top-6-h):r.bottom+6)+'px';
    const close=()=>{p.remove();document.removeEventListener('pointerdown',away,true);document.removeEventListener('keydown',key,true);};
    const away=e=>{if(!p.contains(e.target)&&!button.contains(e.target))close();};
    const key=e=>{if(e.key==='Escape'){e.stopPropagation();close();button.focus();}};
    setTimeout(()=>{document.addEventListener('pointerdown',away,true);document.addEventListener('keydown',key,true);},0);
    p.onclick=e=>{const b=e.target.closest('[data-emoji]');if(!b)return;const v=b.dataset.emoji||'';button.dataset.value=v;button.innerHTML=v?esc(v):itSvg('add');button.classList.toggle('has',!!v);close();button.focus();};
    p.querySelector('button')?.focus();
  }
  function choiceRow(c){const price=+c?.price||0;return `<div class="rmw-og-row" data-choice data-id="${esc(c?.id||'')}"><button type="button" class="rmw-og-mark${c?.emoji?' has':''}" data-emoji-btn data-value="${esc(c?.emoji||'')}" aria-label="${esc(ui('ogMarkPick'))}">${c?.emoji?esc(c.emoji):itSvg('add')}</button><input class="rmw-rx-in" data-choice-name placeholder="${esc(ui('addChoicePlaceholder'))}" value="${esc(c?.name||'')}" aria-label="${esc(ui('ogChoiceName'))}" autocomplete="off"/><span class="rmw-rx-suffix"><input class="rmw-rx-in" type="number" min="0" step="0.01" inputmode="decimal" data-choice-price value="${price>0?price:''}" placeholder="0" aria-label="${esc(ui('ogSupplement'))}"/><i>MAD</i></span><button class="rmw-rx-del" type="button" data-choice-del aria-label="${esc(ui('ogRemoveChoice'))}">${itSvg('close')}</button></div>`;}
  /* Option group editor (2026-10-12). Two selects, a French-only help line,
     unlabelled price boxes pre-filled with « 0 », and a « Enregistrer » that
     did nothing at all when the name or every choice was empty. Now: the two
     rules are segmented controls on the liquid lens, a sentence says what the
     order screens will enforce (caisse, serveur, QR and the order API all read
     kind and required the same way), and errors sit under what they concern. */
  function openGroup(g){
    recipeStyle();itemStyle();groupStyle();
    const kind=g?.kind==='many'?'many':'one',req=g?.required?'1':'0';
    const seg=(name,val,opts)=>`<div class="rmw-og-seg" role="radiogroup" aria-labelledby="rmw-og-${name}-l" data-og-seg="${name}">${opts.map(([v,l])=>`<label class="rmw-og-segi${v===val?' on':''}"><input type="radio" name="rmw-og-${name}" value="${v}"${v===val?' checked':''}/><span>${esc(l)}</span></label>`).join('')}</div>`;
    const m=modal({title:g?ui('editGroupTitle'):ui('newGroupTitle'),width:680,body:`<div class="rmw-og">
      <section class="rmw-rx-sec">
        <div class="rmw-og-grid">
          <label class="rmw-it-f rmw-og-wide"><span>${esc(ui('groupNameLabel'))}</span><input class="rmw-rx-in" data-name value="${esc(g?.name||'')}" placeholder="${esc(ui('groupNamePlaceholder'))}" autocomplete="off"/><em class="rmw-it-err" data-og-err="name" hidden></em></label>
          <div class="rmw-it-f"><span id="rmw-og-kind-l">${esc(ui('groupTypeLabel'))}</span>${seg('kind',kind,[['one',ui('oneChoice')],['many',ui('manyChoices')]])}</div>
          <div class="rmw-it-f"><span id="rmw-og-req-l">${esc(ui('groupRequiredLabel'))}</span>${seg('req',req,[['0',ui('ogOptional')],['1',ui('ogRequired')]])}</div>
        </div>
        <p class="rmw-og-rule" data-og-rule aria-live="polite"></p>
      </section>
      <section class="rmw-rx-sec">
        <div class="rmw-rx-sec-head"><div><h4>${esc(ui('choicesLabel'))}</h4><p>${esc(ui('ogChoicesHelp'))}</p></div></div>
        <div class="rmw-og-cols" aria-hidden="true"><span>${esc(ui('ogMark'))}</span><span>${esc(ui('ogChoiceName'))}</span><span>${esc(ui('ogSupplement'))}</span><span></span></div>
        <div data-choices>${(g?.choices||[]).map(choiceRow).join('')||choiceRow(null)}</div>
        <em class="rmw-it-err rmw-og-choices-err" data-og-err="choices" hidden></em>
        <button data-activation=write class="rmw-rx-add" type="button" data-choice-add>${itSvg('add')}<span>${esc(ui('addChoiceBtnLabel'))}</span></button>
        <p class="rmw-og-hint">${esc(ui('ogMarkHelp'))}</p>
      </section>
    </div>`,foot:`<button class="kb ghost" data-cancel>${esc(ui('cancelBtn'))}</button><button data-activation=write class="eq-cta-gradient" data-save>${esc(ui('saveBtn'))}</button>`});
    m.el.classList.add('rmw-recipe-modal','rmw-og-modal');
    const wrap=$('[data-choices]',m.el),nameEl=$('[data-name]',m.el);
    const picked=(name)=>$(`input[name="rmw-og-${name}"]:checked`,m.el)?.value;
    const rule=()=>{const many=picked('kind')==='many',must=picked('req')==='1';$('[data-og-rule]',m.el).textContent=ui(many?(must?'ogRuleManyReq':'ogRuleManyOpt'):(must?'ogRuleOneReq':'ogRuleOneOpt'));};
    const setErr=(k,msg)=>{const e=$(`[data-og-err="${k}"]`,m.el);if(e){e.textContent=msg||'';e.hidden=!msg;}if(k==='name'){if(msg)nameEl.setAttribute('aria-invalid','true');else nameEl.removeAttribute('aria-invalid');}};
    rule();
    m.el.addEventListener('change',e=>{const s=e.target.closest('[data-og-seg]');if(!s)return;$$('.rmw-og-segi',s).forEach(l=>l.classList.toggle('on',!!$('input',l).checked));rule();});
    m.el.addEventListener('input',e=>{if(e.target===nameEl&&nameEl.value.trim())setErr('name','');if(e.target.matches('[data-choice-name]')&&e.target.value.trim()){e.target.removeAttribute('aria-invalid');if(!$$('[data-choice-name][aria-invalid="true"]',wrap).length)setErr('choices','');}});
    $('[data-choice-add]',m.el).onclick=()=>{wrap.insertAdjacentHTML('beforeend',choiceRow(null));$('[data-choice-name]',wrap.lastElementChild)?.focus();};
    wrap.onclick=e=>{const del=e.target.closest('[data-choice-del]');if(del){const row=del.closest('[data-choice]');if($$('[data-choice]',wrap).length>1){const next=row.nextElementSibling||row.previousElementSibling;row.remove();$('[data-choice-name]',next)?.focus();}else{row.dataset.id='';$('[data-choice-name]',row).value='';$('[data-choice-price]',row).value='';const b=$('[data-emoji-btn]',row);b.dataset.value='';b.innerHTML=itSvg('add');b.classList.remove('has');$('[data-choice-name]',row).focus();}return;}const b=e.target.closest('[data-emoji-btn]');if(b)emojiPicker(b);};
    $('[data-cancel]',m.el).onclick=m.close;
    $('[data-save]',m.el).onclick=()=>{
      const name=nameEl.value.trim();
      const all=$$('[data-choice]',wrap).map(r=>({el:r,id:r.dataset.id,name:$('[data-choice-name]',r).value.trim(),price:Math.max(0,+$('[data-choice-price]',r).value||0),emoji:$('[data-emoji-btn]',r).dataset.value||''}));
      const unnamed=all.filter(x=>!x.name&&(x.price>0||x.emoji)),rows=all.filter(x=>x.name);
      all.forEach(x=>{const inp=$('[data-choice-name]',x.el);if(unnamed.includes(x))inp.setAttribute('aria-invalid','true');else inp.removeAttribute('aria-invalid');});
      setErr('name',name?'':ui('ogNameRequired'));
      setErr('choices',unnamed.length?ui('ogChoiceUnnamed'):rows.length?'':ui('ogChoicesRequired'));
      if(!name){nameEl.focus();return;}
      if(unnamed.length){$('[data-choice-name]',unnamed[0].el).focus();return;}
      if(!rows.length){$('[data-choice-name]',wrap)?.focus();return;}
      const kindV=picked('kind')==='many'?'many':'one',required=picked('req')==='1';
      let id=g?.id;
      if(g){S().updateOptGroup(id,{name,kind:kindV,required});(g.choices||[]).filter(c=>!rows.some(x=>x.id===c.id)).forEach(c=>S().deleteOptChoice(id,c.id));rows.forEach(x=>x.id?S().updateOptChoice(id,x.id,{name:x.name,price:x.price,emoji:x.emoji}):S().addOptChoice(id,x.name,x.price,x.emoji));}
      else{S().addOptGroup(name);id=D().opts.at(-1)?.id;S().updateOptGroup(id,{kind:kindV,required});rows.forEach(x=>S().addOptChoice(id,x.name,x.price,x.emoji));}
      m.close();render();
    };
    setTimeout(()=>{if(!g)nameEl.focus();},60);
  }
  function groupStyle(){if($('#rmw-og-css'))return;const s=document.createElement('style');s.id='rmw-og-css';s.textContent=`
.rmw-og{display:grid;gap:14px;color:var(--ink)}
.rmw-og-grid{display:grid;grid-template-columns:minmax(0,1fr) minmax(0,1fr);gap:14px 12px;align-items:start}
.rmw-og-wide{grid-column:1/-1}
.rmw-og .rmw-it-f{grid-template-columns:minmax(0,1fr)}
.rmw-og-seg{position:relative;display:flex;gap:2px;width:100%;box-sizing:border-box;padding:3px;border-radius:12px;background:color-mix(in srgb,var(--ink) 6%,var(--rx-field))}
.rmw-og-segi{position:relative;flex:1 1 0;min-width:0;cursor:pointer}
.rmw-og-segi input{position:absolute;inset:0;width:100%;height:100%;margin:0;opacity:0;cursor:pointer}
.rmw-og-segi span{display:flex;align-items:center;justify-content:center;height:34px;padding:0 10px;border-radius:9px;font:500 13px var(--sans);color:var(--n-600);white-space:nowrap;overflow:hidden;text-overflow:ellipsis;transition:color 160ms}
.rmw-og-segi.on span{color:var(--ink);font-weight:600}
.rmw-og-seg:not([data-kw-lens]) .rmw-og-segi.on span{background:var(--surface);box-shadow:0 1px 2px rgba(0,0,0,.06)}
.rmw-og-segi input:focus-visible+span{box-shadow:0 0 0 2px var(--atlas)}
.rmw-og-rule{display:flex;align-items:center;gap:9px;margin:14px 0 0;padding:10px 12px;border-radius:10px;background:color-mix(in srgb,var(--atlas) 7%,var(--rx-field));color:var(--n-700);font-size:12.5px;line-height:1.45}
.rmw-og-rule::before{content:'';flex:none;width:6px;height:6px;border-radius:50%;background:var(--atlas)}
.rmw-og-cols,.rmw-og-row{display:grid;grid-template-columns:44px minmax(0,1fr) 132px 32px;gap:8px;align-items:center}
.rmw-og-cols{padding:0 2px 6px;border-bottom:1px solid var(--n-200);font-size:11px;font-weight:600;color:var(--n-500)}
.rmw-og-row{padding:8px 0;border-bottom:1px solid var(--n-200)}
.rmw-og-mark{width:44px;height:38px;display:grid;place-items:center;padding:0;border:1px dashed var(--n-300);border-radius:10px;background:var(--rx-field);color:var(--n-500);font-size:20px;line-height:1;cursor:pointer;transition:border-color 140ms,color 140ms}
.rmw-og-mark.has{border-style:solid;border-color:var(--n-200)}
.rmw-og-mark svg{width:16px;height:16px;fill:currentColor}
.rmw-og-mark:hover,.rmw-og-mark:focus-visible{border-color:var(--atlas);color:var(--atlas);outline:0}
.rmw-og-row .rmw-rx-suffix .rmw-rx-in{padding-inline-end:42px;text-align:end}
.rmw-og-row .rmw-rx-del svg{width:16px;height:16px;fill:currentColor}
.rmw-og-row .rmw-rx-del:hover{color:#cb5238;background:color-mix(in srgb,#cb5238 9%,transparent)}
.rmw-og .rmw-rx-in[aria-invalid="true"]{border-color:#cb5238;box-shadow:0 0 0 3px color-mix(in srgb,#cb5238 14%,transparent)}
.rmw-og .rmw-it-err[hidden]{display:none}
.rmw-og-choices-err{display:block;margin-top:10px}
.rmw-og-hint{margin:12px 0 0;font-size:11.5px;line-height:1.45;color:var(--n-500)}
/* The picker lives on <body>, outside the sheet: it needs its own opaque surface (the skin's --surface is translucent). */
.rmw-emoji-pop{max-width:calc(100vw - 16px);box-sizing:border-box;background:var(--paper)!important;-webkit-backdrop-filter:none!important;backdrop-filter:none!important}
html[data-theme="dark"] .rmw-emoji-pop{background:#151C18!important;border-color:rgba(255,255,255,.1)}
.rmw-emoji-pop button:focus-visible{outline:2px solid var(--atlas);outline-offset:1px}
@media(max-width:620px){.rmw-og-grid{grid-template-columns:1fr}.rmw-og-cols{display:none}.rmw-og-row{grid-template-columns:44px minmax(0,1fr) 32px;grid-template-areas:"mark name del" ". price .";row-gap:8px}.rmw-og-row>.rmw-og-mark{grid-area:mark}.rmw-og-row>[data-choice-name]{grid-area:name}.rmw-og-row>.rmw-rx-suffix{grid-area:price}.rmw-og-row>.rmw-rx-del{grid-area:del}.rmw-og .rmw-rx-in{font-size:16px}}
`;document.head.appendChild(s);}
  /* Unités courtes dans la liste (« g », « kg », « Botte ») : le libellé long
     « Gramme (g) » était tronqué en « Gramme (... » dans une cellule étroite. */
  function recipeUnitOptions(value){const api=window.KiwiRestaurantUnits,selected=api?.normalize?.(value,'')||'';return `<option value="">${esc(ui('rxChoose'))}</option>${(api?.list?.()||[]).map(unit=>`<option value="${esc(unit.id)}" title="${esc(unit.label)}"${unit.id===selected?' selected':''}>${esc(unit.family==='mass'||unit.family==='volume'?unit.id:unit.label)}</option>`).join('')}`;}
  function recipeIngredientRow(line,idx){const name=line?.name||'';return `<div class="rmw-rx-row" data-recipe-ing data-stock-id="${esc(line?.stockId||'')}"><div class="rmw-rx-name"><input class="rmw-rx-in" list="rmw-stock-ingredients" data-ing-name value="${esc(name)}" placeholder="${esc(ui('rxIngPh'))}" aria-label="${esc(ui('rxIngredient'))}"/><small data-ing-meta></small></div><div class="rmw-rx-qty"><input class="rmw-rx-in" type="number" inputmode="decimal" min="0" step="0.001" data-ing-qty value="${+line?.qty||0}" placeholder="0" aria-label="${esc(ui('rxQty'))}"/><select class="rmw-rx-unit" data-ing-unit data-kiwi-native-select aria-label="${esc(ui('rxChoose'))}">${recipeUnitOptions(line?.unit)}</select></div><div class="rmw-rx-cost" data-ing-cost>·</div><button data-activation=write class="rmw-rx-del" type="button" data-ing-delete aria-label="${esc(ui('rxRemove',{name:name||ui('rxIngredient')}))}"><svg viewBox="0 -960 960 960" aria-hidden="true"><path fill="currentColor" d="m256-200-56-56 224-224-224-224 56-56 224 224 224-224 56 56-224 224 224 224-56 56-224-224-224 224Z"/></svg></button></div>`;}
  /* L'état d'une ligne, tel que le stock le voit : liée, sans prix, unité
     incompatible, quantité absente. Le coût de ligne n'est jamais inventé. */
  function recipeLineInfo(row,api,inv){
    const units=window.KiwiRestaurantUnits,name=$('[data-ing-name]',row).value.trim(),qty=Math.max(0,+$('[data-ing-qty]',row).value||0),unit=units?.normalize?.($('[data-ing-unit]',row).value,'')||'';
    if(!name)return{empty:true};
    const hit=inv.find(s=>String(s.id)===row.dataset.stockId)||inv.find(s=>String(s.name).trim().toLowerCase()===name.toLowerCase());
    let info=null;try{info=api.ingredientInfo?.({stockId:hit?.id||'',name,qty,unit},venue())||null;}catch(_){info=null;}
    const stock=info?.stock||hit||null;
    if(!stock)return{name,state:'unlinked',meta:ui('rxUnlinked')};
    if(info?.cost==null)return{name,state:'noprice',meta:ui('rxNoPrice')};
    if(!(qty>0))return{name,state:'noqty',meta:ui('rxLinked',{price:cash(info.cost),unit:info.stockUnit||stock.unit||''})};
    if(info.quantityInStockUnit==null)return{name,state:'unit',meta:ui('rxUnitMismatch',{unit:info.stockUnit||stock.unit||''})};
    return{name,state:'ok',cost:info.lineCost,meta:ui('rxLinked',{price:cash(info.cost),unit:info.stockUnit||stock.unit||''})};
  }
  function recipeNutrition(draft,api,hide){const n=api.nutrition?.(draft,venue()),hasLines=(draft.ingredients||[]).some(l=>+l.qty>0),missing=n?[...new Set([...(n.missingNutrition||[]),...(n.missingConversion||[]),...(n.missingAllergens||[])])]:[];const toggle=`<label class="rmw-nutri-toggle" title="${esc(ui('nutritionHideHint'))}"><input type="checkbox" data-hide-nutrition${hide?' checked':''}/><span>${esc(ui('nutritionHide'))}</span></label>`;let nutrition;if(!hasLines)nutrition=`<div class="rmw-nutrition-state empty"><div class="rmw-nutri-head"><span class="rmw-nutri-dot mode"><i></i>${esc(ui('nutritionShort'))}</span><span class="rmw-nutri-muted">${esc(ui('nutritionAwaitsRecipe'))}</span></div>${toggle}</div>`;else if(n?.complete)nutrition=`<div class="rmw-nutrition-state complete"><div class="rmw-nutri-head"><span class="rmw-nutri-dot req"><i></i>${esc(ui('nutritionComplete'))}</span>${toggle}</div><div class="rmw-nutrition-values"><bdi dir="ltr">${n.nutrition.kcal} kcal</bdi><bdi dir="ltr">P ${n.nutrition.protein} g</bdi><bdi dir="ltr">G ${n.nutrition.carbs} g</bdi><bdi dir="ltr">L ${n.nutrition.fat} g</bdi></div><div class="rmw-nutrition-allergens"><b>${esc(ui('nutritionAllergens'))}</b><span>${esc(n.allergens.length?n.allergens.map(key=>ui(`allergen_${key}`)).join(' · '):ui('nutritionNone'))}</span></div><small>${esc(ui('nutritionIndicative'))}</small></div>`;else nutrition=`<div class="rmw-nutrition-state incomplete"><div class="rmw-nutri-head"><span class="rmw-nutri-dot opt"><i></i>${esc(ui('nutritionIncomplete'))}</span><span class="rmw-nutri-muted">${esc(ui('nutritionMissing',{n:missing.length}))}</span></div><div class="rmw-nutri-head-acts"><button class="btn-slim" type="button" data-nutrition-fix>${esc(ui('nutritionFix'))}</button>${toggle}</div></div>`;return nutrition;}
  /* Le panneau de droite : ce que la recette coûte et rapporte, par portion,
     sur la même base que l'Analyse du menu (KiwiCost.marginOf : hors TVA
     quand les prix l'incluent). Inconnu : « · », jamais un zéro. */
  function recipeSummary(x,draft,api,hide,lines){
    const m=api.metrics(x,draft,venue()),price=+x.price||0,C=window.KiwiCost;
    const cost=m.costComplete?m.theoreticalCost:null,mg=cost!=null&&C?.marginOf?C.marginOf(price,cost):null;
    let vatIn=false;try{const b=C?.basis?.();vatIn=!!(b&&b.mode==='rate'&&b.included);}catch(_){vatIn=false;}
    const todo=(lines||[]).filter(l=>!l.empty&&l.state!=='ok');
    const known=(lines||[]).reduce((n,l)=>n+(l.cost>0?l.cost:0),0)/Math.max(1,+draft.portions||1);
    let cls='todo',title=ui('rxStatusTodo'),detail=todo.length?ui('rxMissing',{n:todo.length,names:todo.slice(0,4).map(l=>l.name).join(', ')+(todo.length>4?'…':'')}):'';
    if(m.costComplete){cls='ok';title=ui('rxStatusOk');detail=ui('rxOkHint');}
    if(m.costComplete&&m.actualCost!=null){const gap=Math.abs(m.variancePct||0),g=window.KiwiNumber?.format(gap,{maximumFractionDigits:0})??Math.round(gap);cls=gap>15?'gap':gap>5?'watch':'ok';title=ui(gap>15?'rxStatusGap':gap>5?'rxStatusWatch':'rxStatusOk');detail=ui(m.variancePct>0?'rxGapUp':'rxGapDown',{gap:g+' %'});}
    const ht=vatIn?` <em>${esc(ui('rxHT'))}</em>`:'';
    const fc=mg?pct1(100-mg.pct):'·';
    return `<div class="rmw-rx-status ${cls}"><b>${esc(title)}</b>${detail?`<span>${esc(detail)}</span>`:''}${todo.length?`<button type="button" class="rmw-rx-link" data-nutrition-fix>${esc(ui('rxToStock'))}</button>`:''}</div>
      <div class="rmw-rx-hero${cost==null?' partial':''}"><span>${esc(ui('rxCostPortion'))}</span><b>${cost!=null?cash(cost):known>0?esc(ui('rxAtLeast',{amount:cash(known)})):'·'}</b>${cost==null&&known>0?`<small>${esc(ui('rxAtLeastSub'))}</small>`:''}</div>
      <dl class="rmw-rx-facts"><div><dt>${esc(ui('rxPrice'))}</dt><dd>${price?cash(price):'·'}</dd></div><div><dt>${esc(ui('rxContribution'))}${ht}</dt><dd class="${mg&&mg.profit<0?'neg':''}">${mg?cash(mg.profit):'·'}</dd></div><div><dt>${esc(ui('rxFoodCost'))}${ht}</dt><dd>${fc}</dd></div><div><dt>${esc(ui('rxObserved'))}</dt><dd>${m.actualCost!=null?cash(m.actualCost):`<small>${esc(ui('rxObservedWait'))}</small>`}</dd></div></dl>
      ${recipeNutrition(draft,api,hide)}`;
  }
  function recipeDraft(root,x,api){const inv=api.inventory(venue()),units=window.KiwiRestaurantUnits;return{itemName:x.name,portions:Math.max(1,+$('[data-portions]',root)?.value||1),prepMinutes:Math.max(0,+$('[data-minutes]',root)?.value||0),ingredients:$$('[data-recipe-ing]',root).map(row=>{const name=$('[data-ing-name]',row).value.trim(),hit=inv.find(s=>String(s.id)===row.dataset.stockId)||inv.find(s=>String(s.name).trim().toLowerCase()===name.toLowerCase());return{stockId:hit?.id||'',name,qty:Math.max(0,+$('[data-ing-qty]',row).value||0),unit:units?.normalize?.($('[data-ing-unit]',row).value||hit?.unit,'')||''};}).filter(line=>line.name||line.stockId),steps:$('[data-steps]',root)?.value.split('\n').map(v=>v.trim()).filter(Boolean)||[],note:$('[data-note]',root)?.value||''};}
  function openRecipe(x,seed,from){const api=window.KiwiRestaurantRecipes,had=!!api?.get(x.id,x.name,venue()),r=seed||api?.get(x.id,x.name,venue())||{portions:1,prepMinutes:0,ingredients:[],steps:[],note:''},inv=api?.inventory(venue())||[];const rows=r.ingredients.length?r.ingredients:[{stockId:'',name:'',qty:0,unit:''}];recipeStyle();const catName=cat(x.catId)?.name?t(cat(x.catId).name):'';const m=modal({title:ui('rxTitle',{name:t(x.name)}),desc:esc(ui('rxDesc',{cat:catName,price:cash(x.price)}).replace(/^ · /,'')),width:1080,body:`<div class="rmw-rx">${seed?`<div class="rmw-rx-draft" data-recipe-draft><b>${esc(ui('recipeDraftTitle'))}</b><span>${esc(ui('recipeDraftFrom',{name:from?.sheet||''}))}${had?' '+esc(ui('recipeDraftExisting')):''}</span></div>`:''}<datalist id="rmw-stock-ingredients">${inv.map(s=>`<option value="${esc(s.name)}">${esc(s.unit||'')} · ${cash(s.costPerUnit)}</option>`).join('')}</datalist><div class="rmw-rx-main"><section class="rmw-rx-sec"><header class="rmw-rx-sec-head"><div><h4>${esc(ui('rxComposition'))}</h4><p>${esc(ui('rxCompositionSub'))}</p></div><div class="rmw-rx-meta"><label><span>${esc(ui('rxPortions'))}</span><input class="rmw-rx-in" type="number" inputmode="numeric" min="1" step="1" data-portions value="${r.portions||1}"/></label><label><span>${esc(ui('rxPrep'))}</span><span class="rmw-rx-suffix"><input class="rmw-rx-in" type="number" inputmode="numeric" min="0" step="1" data-minutes value="${r.prepMinutes||0}"/><i>${esc(ui('rxMin'))}</i></span></label></div></header><div class="rmw-rx-cols" aria-hidden="true"><span>${esc(ui('rxIngredient'))}</span><span>${esc(ui('rxQty'))}</span><span>${esc(ui('rxLineCost'))}</span><span></span></div><div data-recipe-ingredients>${rows.map(recipeIngredientRow).join('')}</div><button data-activation=write class="rmw-rx-add" type="button" data-ing-add><svg viewBox="0 -960 960 960" aria-hidden="true"><path fill="currentColor" d="M440-440H200v-80h240v-240h80v240h240v80H520v240h-80v-240Z"/></svg><span>${esc(ui('rxAdd'))}</span></button>${inv.length?'':`<p class="rmw-rx-hint">${esc(ui('rxNoStock'))}</p>`}</section><section class="rmw-rx-sec"><header class="rmw-rx-sec-head"><div><h4>${esc(ui('rxMethod'))}</h4></div></header><div class="rmw-rx-notes"><label><span>${esc(ui('rxSteps'))}</span><textarea class="rmw-rx-in" data-steps placeholder="${esc(ui('rxStepsPh'))}">${esc((r.steps||[]).join('\n'))}</textarea></label><label><span>${esc(ui('rxNotes'))}</span><textarea class="rmw-rx-in" data-note placeholder="${esc(ui('rxNotesPh'))}">${esc(r.note||'')}</textarea></label></div></section></div><aside class="rmw-rx-side" data-recipe-summary></aside></div>`,foot:`<button class="kb ghost" data-cancel>${esc(ui('cancelBtn'))}</button><button data-activation=write class="eq-cta-gradient" data-save>${esc(ui('saveBtn'))}</button>`});m.el.classList.add('rmw-recipe-modal');let hideDraft=!!x.hideNutrition;const wrap=$('[data-recipe-ingredients]',m.el),refresh=()=>{const info=$$('[data-recipe-ing]',m.el).map(row=>{const li=recipeLineInfo(row,api,inv),meta=$('[data-ing-meta]',row),costEl=$('[data-ing-cost]',row);row.dataset.state=li.empty?'':li.state;if(meta)meta.textContent=li.empty?'':li.meta;if(costEl)costEl.textContent=li.cost!=null?cash(li.cost):'·';return li;});$('[data-recipe-summary]',m.el).innerHTML=recipeSummary(x,recipeDraft(m.el,x,api),api,hideDraft,info);};refresh();m.el.addEventListener('change',e=>{if(e.target.matches('[data-hide-nutrition]')){hideDraft=!!e.target.checked;return;}if(e.target.matches('[data-ing-unit]'))refresh();});m.el.addEventListener('input',e=>{if(e.target.matches('[data-hide-nutrition]'))return;const row=e.target.closest('[data-recipe-ing]');if(row&&e.target.matches('[data-ing-name]')){const hit=inv.find(s=>String(s.name).trim().toLowerCase()===e.target.value.trim().toLowerCase());row.dataset.stockId=hit?.id||'';if(hit&&$('[data-ing-unit]',row))$('[data-ing-unit]',row).value=window.KiwiRestaurantUnits?.normalize?.(hit.unit)||hit.unit||'unité';}refresh();});m.el.addEventListener('click',e=>{if(!e.target.closest('[data-nutrition-fix]'))return;m.close();window.Kiwi?.handlers?.['nav-stock']?.();});wrap.onclick=e=>{const del=e.target.closest('[data-ing-delete]');if(!del)return;del.closest('[data-recipe-ing]').remove();if(!wrap.children.length)wrap.insertAdjacentHTML('beforeend',recipeIngredientRow({},0));refresh();};$('[data-ing-add]',m.el).onclick=()=>{wrap.insertAdjacentHTML('beforeend',recipeIngredientRow({},wrap.children.length));$('[data-ing-name]',wrap.lastElementChild).focus();};$('[data-cancel]',m.el).onclick=m.close;$('[data-save]',m.el).onclick=()=>{const draft=recipeDraft(m.el,x,api);if(!draft.ingredients.some(line=>line.qty>0)){toast(ui('rxToastQtyT'),ui('rxToastQty'),'warn');return;}if(draft.ingredients.some(line=>!line.unit)){toast(ui('rxToastUnitT'),ui('rxToastUnit'),'warn');return;}S().updateItem(x.id,{hideNutrition:hideDraft});api.save(x.id,draft,venue());m.close();render();toast(ui('rxSavedT'),ui('rxSaved'));};}
  function confirm(title,run,detail=ui('confirmDeleteDefault')){const m=modal({title,width:440,body:`<p>${esc(detail)}</p>`,foot:`<button class="kb ghost" data-cancel>${esc(ui('cancelBtn'))}</button><button class="kb danger" data-confirm>${esc(ui('delete'))}</button>`});$('[data-cancel]',m.el).onclick=m.close;$('[data-confirm]',m.el).onclick=()=>{run();m.close();render();};}
  let legacyMenuHandler=null;
  function restaurantMenuHandler(){
    /* The sidebar only exposes nav-menu for restaurant venues. Claim the route
     * immediately, even while MenuStore/venue hydration is still in flight, so
     * the legacy renderer can never flash on the first click after login. */
    if(isRestaurant()||document.querySelector('.sidebar nav a[data-nav="menu"]')){show(true);return;}
    if(legacyMenuHandler)return legacyMenuHandler.apply(this,arguments);
  }
  /* ═══════════════ Traductions de la carte (assets/menu-i18n.js) ═══════════════
   * La carte est traduite UNE FOIS par Kiwi AI, entrée par entrée, langue par
   * langue, et seulement pour ce qui manque ou a changé (KiwiMenuI18n.needs) ;
   * le libellé du patron n'est JAMAIS remplacé · la traduction vit à côté
   * (entity.i18n). Déclenchement : automatique 2,5 s après un changement de la
   * carte (import, scan, saisie), et à la main depuis l'onglet « Traductions »
   * où chaque cellule se corrige (une correction n'est plus jamais écrasée).
   * Sans session réelle (démo) : rien ne part sur le réseau. */
  let i18nBusy=false,i18nTimer=0,i18nCooldown=0,i18nProgress='',i18nChooserOpen=false;
  const I18N_BATCH=40;
  // Allumé par défaut ; l'opérateur le coupe dans kiwi-admin (features.menuLangs === false).
  const menuLangFeature=()=>window.KiwiConfig?.features?.menuLangs!==false;
  const menuNutritionFeature=()=>window.KiwiConfig?.features?.menuNutrition!==false;
  const I18N_LANG_LABELS={
    fr:{es:'Espagnol',de:'Allemand',it:'Italien',pt:'Portugais',nl:'Néerlandais',ru:'Russe','zh-Hans':'Chinois simplifié','zh-Hant':'Chinois traditionnel',ja:'Japonais',ko:'Coréen',tr:'Turc',he:'Hébreu',pl:'Polonais',sv:'Suédois',no:'Norvégien',da:'Danois',hi:'Hindi',id:'Indonésien',el:'Grec',uk:'Ukrainien'},
    en:{es:'Spanish',de:'German',it:'Italian',pt:'Portuguese',nl:'Dutch',ru:'Russian','zh-Hans':'Simplified Chinese','zh-Hant':'Traditional Chinese',ja:'Japanese',ko:'Korean',tr:'Turkish',he:'Hebrew',pl:'Polish',sv:'Swedish',no:'Norwegian',da:'Danish',hi:'Hindi',id:'Indonesian',el:'Greek',uk:'Ukrainian'},
    ar:{es:'الإسبانية',de:'الألمانية',it:'الإيطالية',pt:'البرتغالية',nl:'الهولندية',ru:'الروسية','zh-Hans':'الصينية المبسطة','zh-Hant':'الصينية التقليدية',ja:'اليابانية',ko:'الكورية',tr:'التركية',he:'العبرية',pl:'البولندية',sv:'السويدية',no:'النرويجية',da:'الدنماركية',hi:'الهندية',id:'الإندونيسية',el:'اليونانية',uk:'الأوكرانية'},
  };
  function menuLangLabel(code){const l=String(document.documentElement?.lang||'fr').toLowerCase().split('-')[0];return (I18N_LANG_LABELS[l]||I18N_LANG_LABELS.fr)[code]||code;}
  const realSession=()=>{try{return !!(window.KiwiEnv&&window.KiwiEnv.isReal&&window.KiwiEnv.isReal());}catch(_){return false;}};
  function i18nChunks(need){
    const out=[];let cur={cats:[],items:[],opts:[],n:0};
    const push=(k,e,w)=>{if(cur.n&&cur.n+w>I18N_BATCH){out.push(cur);cur={cats:[],items:[],opts:[],n:0};}cur[k].push(e);cur.n+=w;};
    (need.cats||[]).forEach(c=>push('cats',c,1+(c.sub||[]).length));
    (need.opts||[]).forEach(g=>push('opts',g,1+(g.choices||[]).length));
    (need.items||[]).forEach(it=>push('items',it,1));
    if(cur.n)out.push(cur);
    return out;
  }
  function i18nRefreshPanel(){if(tab==='i18n'){const p=$('[data-rmw-panel]');if(p)p.innerHTML=i18nPanel();}}
  async function ensureTranslations(o){
    o=o||{};
    const M=window.KiwiMenuI18n;if(!M||i18nBusy)return;
    if(!realSession()){if(!o.silent)toast(ui('i18nDemo'),'','info');return;}
    if(o.silent&&Date.now()<i18nCooldown)return;
    const d=D();
    if(!d.items.length&&!d.cats.length){if(!o.silent)toast(ui('i18nEmpty'),'','info');return;}
    const targets=(o.langs&&o.langs.length?o.langs:(menuLangFeature()?M.langs(d):M.LANGS)).map(M.asLang).filter(Boolean);
    const need=M.needs(d,targets,{force:o.force||false});
    const total=targets.reduce((n,l)=>n+(need[l]?need[l].count:0),0);
    if(!total){if(!o.silent)toast(ui('i18nUpToDate'),'','success');return;}
    i18nBusy=true;let written=0,failed='';
    const slug=venue()||'';
    i18nProgress=ui('i18nBusy',{n:total});i18nRefreshPanel();
    try{
      for(const lang of targets){
        if(!need[lang]||!need[lang].count)continue;
        for(const chunk of i18nChunks(need[lang])){
          let res=null;
          try{
            res=await fetch('/api/ai/menu-translate',{method:'POST',headers:{'Content-Type':'application/json',Accept:'application/json'},
              body:JSON.stringify({merchant:slug,targetLang:lang,cats:chunk.cats,items:chunk.items,opts:chunk.opts})});
          }catch(_){failed='network';break;}
          if(res.status===429){failed='quota';break;}
          let data=null;try{data=await res.json();}catch(_){}
          if(!res.ok||!data||!data.ok){failed=(data&&(data.error||data.reason))||'error';break;}
          // Le store écrit entity.i18n et republie la carte (menu-catalog.js → schedulePublish).
          written+=S().setI18n(lang,data,{force:o.force||false})||0;
        }
        if(failed)break;
      }
    }finally{i18nBusy=false;i18nProgress='';}
    if(failed){
      i18nCooldown=Date.now()+(failed==='quota'?6*3600e3:10*60e3);
      if(!o.silent)toast(failed==='quota'?ui('i18nQuota'):ui('i18nError'),'','warn');
    }else if(!o.silent){toast(ui('i18nDone',{n:written}),'','success');}
    if(document.body.classList.contains('page-menu'))render();
  }
  function scheduleAutoTranslate(){
    clearTimeout(i18nTimer);
    i18nTimer=setTimeout(()=>{if(isRestaurant())ensureTranslations({silent:true});},2500);
  }
  function i18nPanel(){
    i18nStyle();
    const M=window.KiwiMenuI18n,d=D();
    if(!M)return `<div class="rmw-empty"><p>${esc(ui('reloadPage'))}</p></div>`;
    const L=menuLangFeature()?M.langs(d):M.LANGS,sum=M.summary(d,L);
    const available=M.EXTRA.filter(l=>!L.includes(l));
    const picker=menuLangFeature()?`<div class="rmw-lang-select"><button type="button" class="rmw-lang-trigger" data-action="rmw-i18n-toggle" aria-expanded="${i18nChooserOpen?'true':'false'}"${available.length?'':' disabled'}><span class="rmw-lang-trigger-plus">+</span><span><b>${esc(ui('i18nAddLang'))}</b><small>${esc(ui('i18nAvailable',{n:available.length}))}</small></span></button>${i18nChooserOpen&&available.length?`<section class="rmw-lang-popover"><div class="rmw-lang-popover-head"><div><b>${esc(ui('i18nChooseLang'))}</b><span>${esc(ui('i18nChooseHint'))}</span></div><button type="button" data-action="rmw-i18n-toggle">${esc(ui('i18nClosePicker'))}</button></div><div class="rmw-lang-grid">${available.map(l=>`<button data-activation=write type="button" data-action="rmw-i18n-add" data-arg="${l}"><span class="rmw-lang-code">${esc(l)}</span><span class="rmw-lang-copy"><b>${esc(menuLangLabel(l))}</b><small dir="${M.rtl(l)?'rtl':'ltr'}">${esc(M.NAMES[l])}</small></span><span class="rmw-lang-add">+</span></button>`).join('')}</div></section>`:''}</div>`:'';
    const head=`<div class="rmw-i18n-head"><div><div class="rmw-i18n-title">${esc(ui('i18nTitle'))}</div><p class="rmw-i18n-hint">${esc(ui('i18nHint'))}</p></div><div class="rmw-i18n-acts"><button class="btn-slim" data-action="rmw-i18n-fill"${i18nBusy?' disabled':''}>${esc(ui('i18nFill'))}</button><button class="btn-slim" data-action="rmw-i18n-redo"${i18nBusy?' disabled':''}>${esc(ui('i18nRedo'))}</button></div></div>${picker}<p class="rmw-i18n-hint" role="note">${esc(ui('i18nReview'))}</p>`;
    const stats=`<div class="rmw-i18n-stats">${L.map(l=>{const s=sum[l],extra=M.EXTRA.includes(l),label=extra?menuLangLabel(l):(M.NAMES[l]||l),native=extra&&M.NAMES[l]!==label?M.NAMES[l]:'';return `<div class="rmw-i18n-stat"><span class="rmw-i18n-stat-name"><b>${esc(label)}</b>${native?`<small dir="${M.rtl(l)?'rtl':'ltr'}">${esc(native)}</small>`:''}</span><span>${s.ok+s.manual}/${s.total} ${esc(ui('i18nStatusOk'))}</span>${s.unreviewed?`<span class="is-stale">${s.unreviewed} ${esc(ui('i18nStatusUnreviewed'))}</span>`:''}${s.stale?`<span class="is-stale">${s.stale} ${esc(ui('i18nStatusStale'))}</span>`:''}${s.missing?`<span class="is-missing">${s.missing} ${esc(ui('i18nStatusMissing'))}</span>`:''}${extra?`<button type="button" data-action="rmw-i18n-remove" data-arg="${l}" title="${esc(ui('i18nRemoveLang'))}" aria-label="${esc(ui('i18nRemoveLang'))} ${esc(label)}">×</button>`:''}</div>`;}).join('')}${i18nProgress?`<div class="rmw-i18n-busy"><span class="rmw-i18n-spin" aria-hidden="true"></span>${esc(i18nProgress)}</div>`:''}</div>`;
    const stLabel=(st)=>ui('i18nStatus'+st.charAt(0).toUpperCase()+st.slice(1));
    const cell=(kind,id,sub,e,l,field)=>{
      const x=e.i18n&&e.i18n[l];const st=M.status(e,l);
      const val=x?(field==='desc'?(x.desc||''):(x.name||'')):'';
      return `<td class="st-${st}"><input type="text" data-rmw-i18n data-kind="${kind}" data-id="${esc(id)}" data-sub="${esc(sub||'')}" data-lang="${l}" data-field="${field}" value="${esc(val)}" placeholder="${st==='stale'?esc(stLabel('stale')):''}" title="${esc(stLabel(st))}" dir="${M.rtl(l)?'rtl':'ltr'}" />${st==='unreviewed'||st==='stale'?`<span>${esc(stLabel(st))}</span><button type="button" data-action="rmw-i18n-approve" data-kind="${kind}" data-id="${esc(id)}" data-sub="${esc(sub||'')}" data-lang="${l}">${esc(ui('i18nApprove'))}</button>`:''}</td>`;
    };
    const row=(kind,id,sub,e,mark,field)=>`<tr><td class="rmw-i18n-src">${mark?`<span class="rmw-i18n-kind">${esc(mark)}</span>`:''}${esc(field==='desc'?(e.desc||''):e.name)}</td>${L.map(l=>cell(kind,id,sub,e,l,field||'name')).join('')}</tr>`;
    const rows=[];
    const section=(t)=>rows.push(`<tr class="rmw-i18n-section"><td colspan="${1+L.length}">${esc(t)}</td></tr>`);
    if(d.cats.length){section(ui('i18nSections'));d.cats.forEach(c=>{rows.push(row('cat',c.id,'',c,''));(c.sub||[]).forEach(s=>rows.push(row('sub',c.id,s.id,s,'↳')));});}
    const items=d.items.filter(x=>!x.archived);
    if(items.length){section(ui('i18nItems'));items.forEach(it=>{rows.push(row('item',it.id,'',it,''));if(it.desc)rows.push(row('item',it.id,'',it,ui('i18nDesc'),'desc'));if(it.allergens?.length)rows.push(`<tr><td>${esc(it.allergens.map(k=>UI_I18N.fr['allergen_'+k]||k).join(' · '))}</td>${L.map(l=>`<td>${esc(it.allergens.map(k=>(UI_I18N[l]||UI_I18N.en)['allergen_'+k]||k).join(' · '))}</td>`).join('')}</tr>`);});}
    if((d.opts||[]).length){section(ui('i18nOptions'));d.opts.forEach(g=>{rows.push(row('opt',g.id,'',g,''));(g.choices||[]).forEach(c=>rows.push(row('choice',g.id,c.id,c,'↳')));});}
    if(!rows.length)return head+`<div class="rmw-empty"><p>${esc(ui('i18nEmpty'))}</p></div>`;
    return head+stats+`<div class="rmw-i18n-wrap" tabindex="0" role="region" aria-label="${esc(ui('i18nTitle'))}"><table class="rmw-i18n"><thead><tr><th>${esc(ui('i18nOriginal'))}</th>${L.map(l=>`<th>${esc(M.NAMES[l]||l)}</th>`).join('')}</tr></thead><tbody>${rows.join('')}</tbody></table></div>`;
  }
  function onI18nEdit(input){
    const k=input.dataset;const v=input.value;
    const patch=k.field==='desc'?{desc:v}:{name:v};
    S().setI18nEntry(k.kind,k.id,k.sub||null,k.lang,patch);
    i18nRefreshPanel();
  }
  function i18nStyle(){if($('#rmw-i18n-css'))return;const s=document.createElement('style');s.id='rmw-i18n-css';s.textContent=`
.rmw-i18n-head{display:flex;align-items:flex-end;justify-content:space-between;gap:16px;flex-wrap:wrap;margin:0 0 14px}
.rmw-i18n-title{font:650 16px var(--sans);letter-spacing:-.01em;color:var(--ink)}
.rmw-i18n-hint{max-width:70ch;margin:4px 0 0;font-size:12px;line-height:1.45;color:var(--n-500)}
.rmw-i18n-acts{display:flex;gap:8px;flex-wrap:wrap}
.rmw-lang-select{margin:0 0 16px}
.rmw-lang-trigger{display:inline-flex;align-items:center;gap:10px;min-height:48px;padding:7px 14px 7px 8px;border:1px solid color-mix(in srgb,var(--atlas) 30%,var(--n-200));border-radius:13px;background:color-mix(in srgb,var(--atlas) 7%,var(--surface));color:var(--ink);text-align:start;cursor:pointer}
.rmw-lang-trigger:hover{border-color:var(--atlas);background:color-mix(in srgb,var(--atlas) 11%,var(--surface))}
.rmw-lang-trigger:disabled{opacity:.48;cursor:default}
.rmw-lang-trigger-plus{display:grid;place-items:center;width:32px;height:32px;border-radius:9px;background:var(--atlas);color:var(--paper);font:500 22px/1 var(--sans)}
.rmw-lang-trigger>span:last-child{display:grid;gap:2px}
.rmw-lang-trigger b{font:650 12px var(--sans)}
.rmw-lang-trigger small{color:var(--n-500);font:500 10px var(--sans)}
.rmw-lang-popover{margin-top:9px;padding:14px;border:1px solid var(--n-200);border-radius:16px;background:var(--paper-soft);box-shadow:0 16px 40px rgba(0,0,0,.12)}
.rmw-lang-popover-head{display:flex;align-items:flex-start;justify-content:space-between;gap:16px;margin-bottom:12px}
.rmw-lang-popover-head>div{display:grid;gap:3px}
.rmw-lang-popover-head b{font:650 13px var(--sans);color:var(--ink)}
.rmw-lang-popover-head span{font-size:11px;color:var(--n-500)}
.rmw-lang-popover-head button{border:0;background:transparent;color:var(--n-500);font:600 11px var(--sans);cursor:pointer}
.rmw-lang-grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(185px,1fr));gap:7px}
.rmw-lang-grid>button{display:grid;grid-template-columns:34px 1fr 24px;align-items:center;gap:9px;min-height:56px;padding:7px 9px;border:1px solid var(--n-200);border-radius:11px;background:var(--surface);color:var(--ink);text-align:start;cursor:pointer}
.rmw-lang-grid>button:hover{border-color:var(--atlas);background:color-mix(in srgb,var(--atlas) 7%,var(--surface));transform:translateY(-1px)}
.rmw-lang-code{display:grid;place-items:center;min-height:30px;border-radius:8px;background:var(--paper-soft);color:var(--n-500);font:650 9px var(--mono);text-transform:uppercase}
.rmw-lang-copy{display:grid;gap:2px;min-width:0}
.rmw-lang-copy b{overflow:hidden;color:var(--ink);font:650 12px var(--sans);text-overflow:ellipsis;white-space:nowrap}
.rmw-lang-copy small{overflow:hidden;color:var(--n-500);font:500 11px var(--sans);text-overflow:ellipsis;white-space:nowrap}
.rmw-lang-add{display:grid;place-items:center;width:23px;height:23px;border-radius:7px;background:color-mix(in srgb,var(--atlas) 12%,var(--surface));color:var(--atlas);font:600 16px/1 var(--sans)}
.rmw-i18n-stats{display:flex;gap:10px;flex-wrap:wrap;align-items:center;margin:0 0 14px}
.rmw-i18n-stat{display:flex;gap:10px;align-items:center;padding:8px 9px 8px 13px;border:1px solid var(--n-200);border-radius:11px;background:var(--surface);font-size:12px;color:var(--n-500)}
.rmw-i18n-stat b{color:var(--ink);font-weight:650}
.rmw-i18n-stat-name{display:grid;gap:1px}
.rmw-i18n-stat-name small{color:var(--n-500);font:500 10px var(--sans)}
.rmw-i18n-stat>button{display:grid;place-items:center;width:25px;height:25px;margin-inline-start:2px;border:0;border-radius:7px;background:var(--paper-soft);color:var(--n-500);font:500 15px/1 var(--sans);cursor:pointer}
.rmw-i18n-stat>button:hover{background:color-mix(in srgb,#c94835 12%,var(--surface));color:#b94b38}
.rmw-i18n-stat .is-stale{color:#a77617}.rmw-i18n-stat .is-missing{color:#b94b38}
.rmw-i18n-busy{display:flex;align-items:center;gap:8px;font-size:12px;color:var(--atlas)}
.rmw-i18n-spin{width:14px;height:14px;border:2px solid var(--n-200);border-top-color:var(--atlas);border-radius:50%;animation:rmw-spin .8s linear infinite}
.rmw-i18n-wrap{overflow:auto;border:1px solid var(--n-200);border-radius:13px;background:var(--surface)}
table.rmw-i18n{width:100%;border-collapse:collapse;min-width:760px;font-size:12.5px}
table.rmw-i18n th{position:sticky;top:0;z-index:1;padding:10px 12px;text-align:start;font:700 10px var(--mono);letter-spacing:.08em;text-transform:uppercase;color:var(--n-500);background:var(--paper-soft);border-bottom:1px solid var(--n-200)}
table.rmw-i18n td{padding:4px 8px;border-bottom:1px solid var(--n-200);vertical-align:middle}
table.rmw-i18n tr:last-child td{border-bottom:0}
table.rmw-i18n .rmw-i18n-section td{padding:10px 12px 6px;font:700 10px var(--mono);letter-spacing:.1em;text-transform:uppercase;color:var(--atlas);background:color-mix(in srgb,var(--atlas) 5%,var(--surface))}
table.rmw-i18n .rmw-i18n-src{min-width:180px;max-width:300px;padding-inline-start:12px;color:var(--ink);font-weight:550}
.rmw-i18n-kind{display:inline-block;margin-inline-end:7px;color:var(--n-500);font-weight:500}
table.rmw-i18n input{width:100%;min-width:170px;height:34px;padding:0 10px;border:1px solid transparent;border-radius:8px;background:transparent;color:var(--ink);font:500 12.5px var(--sans)}
table.rmw-i18n input:hover{border-color:var(--n-200)}
table.rmw-i18n input:focus{outline:0;border-color:var(--atlas);background:var(--paper-soft)}
table.rmw-i18n td.st-missing input{background:color-mix(in srgb,#b94b38 6%,transparent)}
table.rmw-i18n td.st-stale input{background:color-mix(in srgb,#a77617 8%,transparent)}
table.rmw-i18n td.st-manual input{border-inline-start:3px solid var(--atlas)}
@media(max-width:700px){.rmw-lang-trigger{width:100%}.rmw-lang-popover{padding:10px}.rmw-lang-popover-head{align-items:center}.rmw-lang-popover-head span{display:none}.rmw-lang-grid{grid-template-columns:1fr 1fr}.rmw-lang-grid>button{grid-template-columns:30px 1fr 22px;min-height:52px;padding:6px}.rmw-lang-code{font-size:11px}}
@media(max-width:430px){.rmw-lang-grid{grid-template-columns:1fr}}
`;document.head.appendChild(s);}
  function wire(){
    const H=window.Kiwi?.handlers;if(!H)return false;
    H['rmw-section-actions']=()=>openSectionActions();
    H['rmw-tab']=e=>{const k=e.dataset.tab;if(ANALYSIS_TABS[k]&&openAnalysis(k))return;if(ANALYSIS_TABS[k])return;setTab(k);render();};
    H['rmw-tab-pick']=()=>openTabPicker();
    H['rmw-sales-period']=e=>{const k=e.dataset.period;if(!SALES_PRESETS.includes(k))return;salesPeriod=k;try{localStorage.setItem('kiwiMenuSalesPeriod',k);}catch(_){}if(analysisActive())window.KiwiFinance.render();};
    H['rmw-hours-period']=e=>{hoursPeriod=e.dataset.period;if(analysisActive())window.KiwiFinance.render();else render();};
    H['rmw-cat-filter']=e=>{filter=e.dataset.cat;subFilter=null;render();};
    H['rmw-cat-move']=(_e,arg)=>{const[id,delta]=String(arg||'').split('::');S().moveCategory(id,+delta);};
    H['rmw-sub-filter']=e=>{subFilter=e.dataset.sub||null;render();};
    H['rmw-sub-add']=(_e,cid)=>ask(ui('newSubcategoryTitle'),ui('subNamePlaceholder'),'',v=>{S().addSubcategory(cid||filter,v);subFilter=null;});
    H['rmw-sub-rename']=(_e,arg)=>{const[cid,sid]=String(arg||'').split('::'),s=(cat(cid)?.sub||[]).find(x=>x.id===sid);if(s)ask(ui('renameSubcategoryTitle'),ui('newNameLabel'),s.name,v=>S().renameSubcategory(cid,sid,v));};
    H['rmw-sub-delete']=(_e,arg)=>{const[cid,sid]=String(arg||'').split('::'),s=(cat(cid)?.sub||[]).find(x=>x.id===sid),n=D().items.filter(x=>x.catId===cid&&x.subId===sid).length;if(s)confirm(ui('deleteSubcategoryConfirm', { name: s.name }),()=>{S().deleteSubcategory(cid,sid);subFilter=null;},ui('deleteSubcategoryDesc', { n }));};
    H['rmw-classify']=(_e,cid)=>openClassify(cid||filter);
    H['rmw-cat-add']=()=>openCategory(null);
    H['rmw-cat-edit']=(_e,id)=>{const c=cat(id);if(c)openCategory(c);};
    H['rmw-cat-delete']=(_e,id)=>{const c=cat(id),n=D().items.filter(x=>x.catId===id).length;if(c)confirm(ui('deleteCategoryConfirm', { name: c.name }),()=>{S().deleteCategory(id);filter='all';subFilter=null;},ui('deleteCategoryDesc', { n }));};
    H['rmw-item-add']=()=>openItem(null);
    H['rmw-item-edit']=(_e,id)=>openItem(item(id));
    H['rmw-item-more']=(_e,id)=>{openItemMenu=openItemMenu===id?null:id;render();};
    H['rmw-item-avail']=(_e,id)=>{const x=item(id);if(x&&!x.archived)S().updateItem(id,{avail:x.avail===false});};
    H['rmw-item-archive']=(_e,id)=>{const x=item(id);openItemMenu=null;if(x)S().updateItem(id,{archived:!x.archived});};
    H['rmw-item-delete']=(_e,id)=>{const x=item(id);openItemMenu=null;if(x)confirm(ui('deleteItemConfirm', { name: x.name }),()=>S().deleteItem(id));};
    H['rmw-group-add']=()=>openGroup(null);
    H['rmw-group-edit']=(_e,id)=>openGroup(group(id));
    H['rmw-group-delete']=(_e,id)=>{const g=group(id);if(g)confirm(ui('deleteGroupConfirm', { name: g.name }),()=>S().deleteOptGroup(id));};
    H['rmw-station-add']=()=>ask(ui('addStationTitle'),ui('stationNameLabel'),'',v=>S().addStation(v));
    H['rmw-station-edit']=(_e,id)=>ask(ui('renameStationTitle'),ui('stationNameLabel'),station(id)?.name,v=>S().renameStation(id,v));
    H['rmw-station-delete']=(_e,id)=>confirm(ui('deleteStationConfirm', { name: station(id)?.name||ui('stationDefault') }),()=>S().deleteStation(id));
    H['rmw-recipe-edit']=(_e,id)=>{const x=item(id);if(x)openRecipe(x);};
    H['rmw-nutrition-filter']=(_e,k)=>{nutriFilter=k||'all';render();};
    H['rmw-nutrition-hide']=(_e,id)=>{const x=item(id);if(!x)return;S().updateItem(id,{hideNutrition:x.hideNutrition!==true});render();toast(ui('nutritionTitle'),x.hideNutrition?ui('nutritionVisibleToggle'):ui('nutritionHiddenToggle'));};
    H['rmw-reactivate']=(_e,id)=>{S().updateItem(id,{avail:true});render();};
    H['rmw-menu-scan']=()=>{if(window.KiwiMenuScan?.open)window.KiwiMenuScan.open({onDone:()=>render()});else window.Kiwi?.toast?.(ui('scanUnavailable'),{type:'warn',desc:ui('reloadPage')});};
    H['rmw-menu-translate']=()=>{setTab('i18n');render();};
    H['rmw-i18n-approve']=(el)=>{const k=el.dataset;S().setI18nEntry(k.kind,k.id,k.sub||null,k.lang,{});i18nRefreshPanel();};
    H['rmw-i18n-fill']=()=>ensureTranslations({silent:false});
    H['rmw-i18n-redo']=()=>confirm(ui('i18nRedoConfirm'),()=>{S().clearI18n(null,true);ensureTranslations({silent:false,force:true});},ui('i18nRedoDesc'));
    H['rmw-i18n-toggle']=()=>{i18nChooserOpen=!i18nChooserOpen;i18nRefreshPanel();};
    H['rmw-i18n-add']=(_e,lang)=>{const M=window.KiwiMenuI18n,l=M?.asLang(lang);if(!l||M.LANGS.includes(l))return;i18nChooserOpen=false;S().setLanguages(M.langs({langs:M.langs(D()).concat(l)}));render();ensureTranslations({silent:false,langs:[l]});};
    H['rmw-i18n-remove']=(_e,lang)=>{const M=window.KiwiMenuI18n,l=M?.asLang(lang);if(!l||M.LANGS.includes(l))return;const run=()=>{S().clearI18n(l,false);S().setLanguages(M.langs({langs:M.langs(D()).filter(x=>x!==l)}));render();};const s=M.summary(D(),[l])[l];if(s&&s.manual)confirm(ui('i18nRemoveConfirm'),run,ui('i18nRemoveManual',{n:s.manual}));else run();};
    if(H['nav-menu']!==restaurantMenuHandler){legacyMenuHandler=H['nav-menu']||legacyMenuHandler;H['nav-menu']=restaurantMenuHandler;}
    return true;
  }
  document.addEventListener('click',e=>{if(openItemMenu&&!e.target.closest('[data-rmw-menu-root]')){openItemMenu=null;if(document.body.classList.contains('page-menu'))render();}});
  document.addEventListener('keydown',e=>{if(e.key==='Escape'&&openItemMenu){openItemMenu=null;if(document.body.classList.contains('page-menu'))render();}});
  function bind(){if(uiBound)return;uiBound=true;document.addEventListener('input',e=>{if(e.target.matches('[data-rmw-search]')){query=e.target.value;const p=$('[data-rmw-panel]');if(!p)return;/* Le panneau est reconstruit en entier a chaque frappe : le champ qui porte
     le focus est detruit, la saisie s'arretait donc apres une seule lettre.
     On rend le focus au nouveau champ en replacant le curseur ou il etait. */
const pos=e.target.selectionStart;const html=menuPanel();if(window.KiwiCatalogUI)window.KiwiCatalogUI.replace(p,html);else p.innerHTML=html;const next=$('[data-rmw-search]',p);if(next){next.focus();try{next.setSelectionRange(pos,pos);}catch(_){}}}});document.addEventListener('change',e=>{if(e.target.matches('[data-rmw-route]')){S().setCategoryStation(e.target.dataset.rmwRoute,e.target.value);render();}else if(e.target.matches('[data-rmw-i18n]')){onI18nEdit(e.target);}});window.addEventListener('click',e=>{const control=e.target.closest?.('[data-action^="rmw-"]');if(control){wire();let handler=window.Kiwi?.handlers?.[control.dataset.action];if(control.dataset.action==='rmw-formula-duplicate'&&typeof handler!=='function')handler=(_el,id)=>{const before=new Set(D().items.map(it=>it.id));S().duplicateItem(id);const copy=D().items.find(it=>!before.has(it.id));if(copy)openItem(copy);};if(typeof handler==='function'){e.preventDefault();e.stopImmediatePropagation();handler(control,control.dataset.arg);return;}}const a=e.target.closest?.('[data-nav="menu"]');if(a){e.preventDefault();show(true);}},true);}
  function style(){if($('#rmw-css'))return;const s=document.createElement('style');s.id='rmw-css';s.textContent=`@keyframes rmw-spin{to{transform:rotate(360deg)}}.mi-card{position:relative;overflow:visible;cursor:pointer}.mi-card:focus-visible{outline:3px solid color-mix(in srgb,var(--atlas) 25%,transparent);outline-offset:2px}.mi-card button,.mi-card [role="switch"]{cursor:pointer}.rmw-menu-open,.mi-card:has(.rmw-card-menu[open]){z-index:30}.mi-card-top{min-height:42px;padding-inline-end:0;align-items:flex-start}.mi-card-cat{min-width:0;overflow:hidden;display:-webkit-box;-webkit-box-orient:vertical;-webkit-line-clamp:2;line-height:1.45}.mi-card-top .mi-tag{flex:0 0 auto;white-space:nowrap}.mi-card-foot>span:first-child{min-width:0;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}.mi-card-foot .mi-card-acts{flex:0 0 auto}.rmw-nutri-dot{display:inline-flex;align-items:center;gap:5px;vertical-align:baseline;color:var(--n-500)}.rmw-nutri-dot>i{width:7px;height:7px;border-radius:50%;background:var(--n-400,var(--n-300));flex:0 0 auto}.rmw-nutri-dot.req{color:var(--atlas)}.rmw-nutri-dot.req>i{background:var(--atlas)}.rmw-nutri-dot.opt>i{background:#c9921c}.rmw-nutri-dot.mode>i{background:var(--n-300)}.mi-card-acts{align-items:center}.rmw-card-menu{position:relative;inset:auto;margin-inline-start:auto;flex:0 0 auto;z-index:5}.rmw-more-btn{width:36px;height:36px;list-style:none;padding:0;border:1px solid transparent;border-radius:9px;background:color-mix(in srgb,var(--surface) 82%,transparent);color:var(--n-500);display:grid;place-items:center;cursor:pointer;transition:background 140ms,border-color 140ms,color 140ms,transform 140ms}.rmw-more-btn:hover,.rmw-card-menu[open]>.rmw-more-btn{background:var(--paper-soft);border-color:var(--n-300);color:var(--ink)}.rmw-more-btn:active{transform:scale(.94)}.rmw-more-btn::-webkit-details-marker{display:none}.rmw-more-btn svg{width:17px;height:17px}.rmw-action-pop{position:absolute;inset-block-start:42px;inset-inline-end:0;width:174px;padding:6px;display:grid;gap:3px;background:color-mix(in srgb,var(--surface) 92%,transparent);border:1px solid var(--n-200);border-radius:13px;box-shadow:0 18px 48px -16px rgba(0,0,0,.48),0 4px 14px rgba(0,0,0,.14);backdrop-filter:blur(18px);-webkit-backdrop-filter:blur(18px);animation:rmw-menu-in 150ms cubic-bezier(.2,.8,.2,1);transform-origin:top right}.rmw-action-pop button{width:100%;min-height:38px;padding:8px 10px;border:0;border-radius:9px;background:transparent;color:var(--ink);display:flex;align-items:center;gap:10px;font:600 12px var(--sans);text-align:start;cursor:pointer;transition:background 120ms,color 120ms}.rmw-action-pop button:hover{background:color-mix(in srgb,var(--atlas) 11%,transparent);color:var(--atlas)}.rmw-action-pop button.danger{color:var(--danger)}.rmw-action-pop button.danger:hover{background:color-mix(in srgb,var(--danger) 12%,transparent)}.rmw-action-pop svg{width:16px;height:16px;flex:0 0 auto}@keyframes rmw-menu-in{from{opacity:0;transform:translateY(-5px) scale(.96)}to{opacity:1;transform:none}}.rmw-empty{text-align:center;color:var(--n-500);padding:34px 18px}.rmw-empty h3{color:var(--ink);margin:0 0 8px}.rmw-empty p{max-width:560px;margin:0 auto 18px;line-height:1.5}.rmw-nfc{margin-top:28px}.rmw-media{width:100%;height:120px;object-fit:cover;border-radius:10px;margin-bottom:10px}.rmw-off{opacity:.58}.rmw-archived{opacity:.68;border-style:dashed}.mi-state-toggle{min-height:30px;padding:5px 9px;border:1px solid var(--n-200);border-radius:999px;background:var(--surface);color:var(--atlas);font:600 10px var(--mono);cursor:pointer}.mi-state-toggle[aria-checked="false"]{color:var(--n-500)}.rmw-archived-group{padding:9px 11px;border:1px dashed var(--n-300);border-radius:10px}.rmw-archived-group summary{cursor:pointer;font-size:12px;color:var(--n-500)}.rmw-archived-group button{margin:7px 5px 0 0;padding:6px 9px;border:1px solid var(--n-200);border-radius:8px;background:var(--paper-soft);color:var(--n-500)}.rmw-routes{display:grid;gap:8px}.rmw-route{display:grid;grid-template-columns:minmax(180px,1fr) minmax(220px,360px);align-items:center;gap:18px;padding:13px;border-bottom:1px solid var(--n-200)}.rmw-route select{border:1px solid var(--n-200);border-radius:10px;padding:10px;background:var(--surface);color:var(--ink)}.rmw-emoji-btn{width:46px;min-width:46px;border:1px solid var(--n-200);border-radius:10px;background:var(--paper-soft);font-size:22px;cursor:pointer}.rmw-emoji-pop{position:fixed;z-index:100000;width:370px;max-height:310px;overflow:auto;padding:10px;background:var(--surface);border:1px solid var(--n-200);border-radius:14px;box-shadow:0 20px 55px #0003;display:grid;grid-template-columns:repeat(8,1fr);gap:5px}.rmw-emoji-pop button{height:38px;border:0;border-radius:7px;background:transparent;font-size:21px;cursor:pointer}.rmw-emoji-pop .rmw-none{grid-column:1/-1;font:12px var(--sans);border:1px solid var(--n-200)}.rmw-emoji-pop button:hover{background:var(--mint-soft)}.rmw-textarea{min-height:120px}.rmw-hours{display:flex;align-items:flex-end;gap:8px;min-height:170px;overflow:auto;padding:25px 4px 0}.rmw-hour{min-width:34px;display:flex;flex-direction:column;align-items:center;gap:5px;font-size:11px;color:var(--n-500)}.rmw-hour i{width:22px;background:var(--atlas);border-radius:5px 5px 1px 1px}.rmw-hour b{font-size:11px;color:var(--ink)}.rmw-recipe-list{display:grid;gap:8px;margin-top:22px}.rmw-recipe-card{display:grid;grid-template-columns:minmax(180px,1fr) minmax(180px,auto) auto;align-items:center;gap:18px;padding:15px 16px;background:var(--surface);border:1px solid var(--n-200);border-radius:12px}.rmw-recipe-name{font-weight:650;color:var(--ink)}.rmw-recipe-meta,.rmw-recipe-result small{display:block;margin-top:4px;font-size:11.5px;color:var(--n-500)}.rmw-recipe-result{text-align:right}.rmw-recipe-modal .kiwi-modal,.rmw-recipe-modal [role=dialog]{background:var(--paper)}.rmw-recipe-modal .kiwi-modal-body{padding-bottom:18px}.rmw-recipe-modal .kiwi-modal-foot{position:sticky;bottom:0;z-index:2;background:var(--paper);border-top:1px solid var(--n-200)}.rmw-performance{display:grid;grid-template-columns:minmax(0,1fr);gap:18px}.rmw-performance>*,.rmw-perf-matrix{min-width:0;max-width:100%}.rmw-perf-legend{overflow-x:auto}.rmw-perf-legend>span{flex:none;white-space:nowrap}.rmw-perf-period{padding:8px 13px;border:1px solid var(--n-200);border-radius:999px;background:var(--paper-soft);font-size:12px;color:var(--n-600)}.rmw-perf-ledger{display:grid;grid-template-columns:repeat(4,minmax(0,1fr));gap:12px;margin-bottom:12px}.rmw-perf-ledger>div{display:grid;gap:7px;padding:17px 18px;background:var(--surface);border:1px solid var(--n-200);border-radius:13px}.rmw-perf-ledger span{font:10px var(--mono);letter-spacing:.06em;text-transform:uppercase;color:var(--n-500)}.rmw-perf-ledger b{font-size:22px;letter-spacing:-.03em;font-variant-numeric:tabular-nums}.rmw-perf-ledger small{color:var(--n-500)}.rmw-perf-notes{display:grid;gap:6px;margin:0 0 12px;padding:12px 16px;border:1px solid var(--n-200);border-radius:13px;background:var(--paper-soft);font-size:12.5px;color:var(--n-600)}.rmw-perf-notes p{margin:0}.rmw-perf-notes p.warn{color:var(--danger,#9F3028);font-weight:600}.rmw-perf-off td{color:var(--n-600)}@media (max-width:900px){.rmw-perf-ledger{grid-template-columns:1fr 1fr}}.rmw-perf-kpis{display:grid;grid-template-columns:repeat(3,1fr);gap:12px}.rmw-perf-kpis>div{display:grid;gap:7px;padding:17px 18px;background:var(--surface);border:1px solid var(--n-200);border-radius:13px}.rmw-perf-kpis span{font:10px var(--mono);letter-spacing:.06em;text-transform:uppercase;color:var(--n-500)}.rmw-perf-kpis b{font-size:24px;letter-spacing:-.03em}.rmw-perf-kpis small{color:var(--n-500)}.rmw-perf-matrix{position:relative;margin-top:26px;padding:0 0 25px 35px}.rmw-perf-plot{position:relative;height:390px;border-left:1px solid var(--n-300);border-bottom:1px solid var(--n-300);background:linear-gradient(90deg,transparent 49.85%,var(--n-200) 50%,transparent 50.15%),linear-gradient(0deg,transparent 49.85%,var(--n-200) 50%,transparent 50.15%),#fff;border-radius:4px 12px 4px 4px}.rmw-perf-y{position:absolute;left:-128px;top:190px;width:290px;transform:rotate(-90deg);text-align:center;font-size:11px;color:var(--n-500)}.rmw-perf-x{text-align:center;margin-top:9px;font-size:11px;color:var(--n-500)}.rmw-perf-caption{text-align:center;margin-top:7px;font-size:11px;color:var(--n-500)}.rmw-perf-v,.rmw-perf-h{position:absolute;z-index:0;background:var(--n-300);opacity:.7}.rmw-perf-v{top:0;bottom:0;width:1px}.rmw-perf-h{left:0;right:0;height:1px}.rmw-perf-label{position:absolute;z-index:0;font:700 12px var(--mono);letter-spacing:.04em;pointer-events:none}.rmw-perf-label small{display:block;margin-top:3px;font:10px var(--sans);letter-spacing:0;color:var(--n-500)}.rmw-perf-label.puzzle{left:18px;top:16px}.rmw-perf-label.star{right:18px;top:16px;text-align:right}.rmw-perf-label.dog{left:18px;bottom:16px}.rmw-perf-label.plow{right:18px;bottom:16px;text-align:right}.rmw-perf-dot{position:absolute;transform:translate(-50%,50%);border:2px solid #fff;border-radius:50%;box-shadow:0 2px 9px #0003;cursor:pointer}.rmw-perf-dot.star{background:#1d9c67}.rmw-perf-dot.plow{background:#d49a25}.rmw-perf-dot.puzzle{background:#357fad}.rmw-perf-dot.dog{background:#cb5238}.rmw-perf-dot>span{display:none;position:absolute;left:50%;bottom:calc(100% + 8px);width:max-content;max-width:240px;transform:translateX(-50%);padding:9px 11px;border-radius:8px;background:#101612;color:#fff;text-align:left;font:11px/1.5 var(--sans);box-shadow:0 8px 24px #0004}.rmw-perf-dot:hover>span,.rmw-perf-dot:focus>span{display:block}.rmw-perf-quads{display:grid;grid-template-columns:repeat(4,1fr);gap:10px}.rmw-perf-q{display:grid;gap:8px;padding:16px;background:var(--surface);border:1px solid var(--n-200);border-top:3px solid var(--n-300);border-radius:11px}.rmw-perf-q.star{border-top-color:#1d9c67}.rmw-perf-q.plow{border-top-color:#d49a25}.rmw-perf-q.puzzle{border-top-color:#357fad}.rmw-perf-q.dog{border-top-color:#cb5238}.rmw-perf-q h4{margin:0;font:700 11px var(--mono);letter-spacing:.06em}.rmw-perf-q strong{font-size:21px}.rmw-perf-q p,.rmw-perf-q div{margin:0;font-size:11px;color:var(--n-500);line-height:1.45}.rmw-perf-q div span{display:block;font:9px var(--mono);letter-spacing:.05em;text-transform:uppercase}.rmw-perf-q footer{display:grid;gap:3px;padding-top:9px;border-top:1px solid var(--n-200);font-size:11px}.rmw-perf-q footer b{font-size:14px}.rmw-perf-q footer small{color:var(--n-500)}.rmw-perf-table td small{display:block;margin-top:3px;color:var(--n-500);font-size:11px}.rmw-perf-margin{display:inline-block;padding:4px 7px;border-radius:999px;font-weight:700}.rmw-perf-margin.hi{background:#d9f4e6;color:#14734a}.rmw-perf-margin.mid{background:#fff0c9;color:#8c620a}.rmw-perf-margin.lo{background:#ffe0da;color:#a83b27}.rmw-perf-link{padding:0;border:0;background:none;color:var(--atlas);font:inherit;text-decoration:underline;cursor:pointer}.rmw-item-workspace .kiwi-modal,.rmw-item-workspace [role=dialog],.rmw-item-workspace.kiwi-modal,.rmw-item-workspace[role=dialog]{max-height:calc(100vh - 24px);display:grid;grid-template-rows:auto minmax(0,1fr) auto;overflow:hidden}.rmw-item-workspace .kiwi-modal-body{min-height:0;overflow:auto;padding-bottom:28px}.rmw-item-workspace .kiwi-modal-foot{position:sticky;bottom:0;z-index:8;border-top:1px solid var(--n-200);background:color-mix(in srgb,var(--paper) 94%,transparent);backdrop-filter:blur(18px);box-shadow:0 -18px 38px -34px rgba(0,0,0,.7)}.rmw-formula-builder{gap:16px!important}.rmw-formula-picker-search svg{width:18px;height:18px;fill:currentColor}.rmw-formula-picker{margin-top:8px;overflow:hidden;border:1px solid var(--n-200);border-radius:16px;background:var(--surface);box-shadow:0 18px 44px -30px rgba(0,0,0,.48)}.rmw-formula-picker.is-floating{position:fixed;z-index:100005;max-height:min(460px,calc(100vh - 24px));margin:0;border-radius:18px;box-shadow:0 26px 80px -28px rgba(0,0,0,.78);backdrop-filter:blur(24px);animation:kiwi-picker-in .15s cubic-bezier(.2,.8,.2,1) both}@keyframes kiwi-picker-in{from{opacity:0;transform:translateY(-5px) scale(.985)}to{opacity:1;transform:none}}.rmw-formula-picker[hidden]{display:none}.rmw-formula-picker-search{position:sticky;top:0;z-index:2;padding:10px;border-bottom:1px solid var(--n-200);background:color-mix(in srgb,var(--surface) 94%,transparent);backdrop-filter:blur(14px)}.rmw-formula-picker-search label{height:39px;padding:0 11px;display:flex;align-items:center;gap:8px;border:1px solid var(--n-200);border-radius:11px;background:var(--paper-soft);color:var(--n-500)}.rmw-formula-picker-search input{width:100%;height:100%;padding:0;border:0;outline:0;background:transparent;color:var(--ink);font:500 12.5px var(--sans)}.rmw-formula-picker-results{max-height:292px;overflow:auto;padding:5px 7px 8px;scrollbar-width:thin;scrollbar-color:var(--n-300) transparent}.rmw-formula-picker-group{padding:5px 0 0}.rmw-formula-picker-group[hidden],.rmw-formula-picker-option[hidden]{display:none}.rmw-formula-picker-group-title{padding:7px 9px 5px;color:var(--n-500);font:700 9px var(--mono);letter-spacing:.1em;text-transform:uppercase}.rmw-formula-picker-option{width:100%;min-height:46px;padding:7px 9px;display:grid;grid-template-columns:minmax(0,1fr) auto 24px;align-items:center;gap:10px;border:0;border-radius:11px;background:transparent;color:var(--ink);text-align:start;cursor:pointer}.rmw-formula-picker-option:hover,.rmw-formula-picker-option:focus-visible{outline:0;background:color-mix(in srgb,var(--atlas) 10%,transparent)}.rmw-formula-picker-option-copy{min-width:0;display:grid;gap:2px}.rmw-formula-picker-option-copy strong{overflow:hidden;font:600 12.5px var(--sans);text-overflow:ellipsis;white-space:nowrap}.rmw-formula-picker-option-copy small{overflow:hidden;color:var(--n-500);font-size:11px;text-overflow:ellipsis;white-space:nowrap}.rmw-formula-picker-price{color:var(--n-600);font:600 10.5px var(--mono);white-space:nowrap}.rmw-formula-picker-add{width:22px;height:22px;display:grid;place-items:center;border-radius:7px;background:color-mix(in srgb,var(--atlas) 12%,transparent);color:var(--atlas)}.rmw-formula-picker-empty{padding:22px 14px;color:var(--n-500);font-size:11.5px;text-align:center}@media(max-width:700px){.rmw-formula-picker.is-floating{inset:auto 8px 8px!important;width:auto!important;max-height:72dvh}}@media(max-width:900px){.rmw-perf-kpis{grid-template-columns:1fr}.rmw-perf-quads{grid-template-columns:1fr 1fr}.rmw-perf-plot{height:300px}}@media(max-width:800px){.rmw-route{grid-template-columns:1fr}.rmw-recipe-card{grid-template-columns:1fr}.rmw-recipe-result{text-align:left}.rmw-perf-quads{grid-template-columns:1fr}/* #0150 · téléphone : la table 7 colonnes défilait la page entière au lieu de défiler dans son cadre ; l'axe Y pivoté du matrix sortait à gauche ; la grille des heures gardait un minimum trop large. */.mi-list-wrap{overflow-x:auto;-webkit-overflow-scrolling:touch;overscroll-behavior-x:contain}@media(max-width:700px){.rmw-perf-y{position:static;transform:none;width:auto;text-align:left;margin-bottom:10px}.rmw-perf-matrix{padding:18px}.rmw-hours-row{grid-template-columns:minmax(96px,140px) minmax(110px,1fr) 46px;gap:10px}}`;document.head.appendChild(s);}
  function nutritionStyle(){if($('#rmw-nutrition-css'))return;const s=document.createElement('style');s.id='rmw-nutrition-css';s.textContent=`
.rmw-nutrition-pill{margin-inline-start:6px;font-size:11px;white-space:nowrap}.mi-card-foot .rmw-nutrition-pill{display:inline-flex;vertical-align:middle}.rmw-recipe-result .rmw-nutrition-pill{margin-inline-start:6px}
.rmw-nutrition-state{display:grid;gap:10px;padding:14px 15px;border:1px solid var(--n-200);border-radius:14px;background:var(--surface)}.rmw-nutrition-state.complete{border-color:color-mix(in srgb,var(--atlas) 30%,var(--n-200));background:color-mix(in srgb,var(--atlas) 6%,var(--surface))}.rmw-nutrition-state.incomplete{grid-template-columns:minmax(0,1fr) auto;align-items:center}.rmw-nutrition-state.incomplete>b{font-size:12px}.rmw-nutrition-values{display:flex;flex-wrap:wrap;gap:7px}.rmw-nutrition-values bdi{padding:6px 8px;border:1px solid var(--n-200);border-radius:8px;background:var(--paper-soft);font:650 11px var(--mono)}.rmw-nutrition-allergens{display:flex;flex-wrap:wrap;gap:7px;font-size:11.5px}.rmw-nutrition-allergens span,.rmw-nutrition-state small{color:var(--n-500)}
.rmw-nutrition-hide{display:flex;align-items:flex-start;gap:10px;padding:13px 15px;border:1px solid var(--n-200);border-radius:14px;background:var(--paper-soft);cursor:pointer}.rmw-nutrition-hide input{width:18px;height:18px;margin-top:1px;accent-color:var(--atlas)}.rmw-nutrition-hide span{display:grid;gap:3px}.rmw-nutrition-hide b{font-size:12.5px}.rmw-nutrition-hide small{color:var(--n-500);font-size:11px;line-height:1.4}
@media(max-width:620px){.rmw-nutrition-state.incomplete{grid-template-columns:1fr}.rmw-nutrition-state.incomplete .btn-slim{width:100%;justify-content:center}.mi-card-foot .rmw-nutrition-pill{display:none}}
.rmw-nutri-filters{display:flex;flex-wrap:wrap;gap:6px;margin:14px 0 12px}.rmw-nutri-filters .mi-pill{display:inline-flex;align-items:center;gap:6px}.rmw-nutri-notice{margin-top:12px;padding:11px 13px;border:1px dashed var(--n-300);border-radius:12px;color:var(--n-500);font-size:12px;line-height:1.45}.rmw-recipe-card.rmw-nutri-row{grid-template-columns:minmax(170px,1fr) minmax(240px,1.4fr) auto}.rmw-nutri-values{display:grid;gap:6px;font-size:12px}.rmw-nutri-values .rmw-nutrition-values{gap:9px;font:600 12px var(--mono);color:var(--ink)}.rmw-nutri-allergens{display:flex;flex-wrap:wrap;gap:5px;font-size:11px}.rmw-nutri-allergens>span{padding:2px 7px;border:1px solid var(--n-200);border-radius:999px;color:var(--n-600)}.rmw-nutri-muted{color:var(--n-500);font-size:11.5px;line-height:1.45}.rmw-nutri-acts{display:flex;align-items:center;gap:8px;justify-self:end}.rmw-nutri-row.hidden{opacity:.72}@media(max-width:800px){.rmw-recipe-card.rmw-nutri-row{grid-template-columns:1fr}.rmw-nutri-acts{justify-self:start}}
.rmw-nutrition-state.empty,.rmw-nutrition-state.incomplete{grid-template-columns:minmax(0,1fr) auto;align-items:center}.rmw-nutri-head{display:flex;flex-wrap:wrap;align-items:center;gap:6px 12px;min-width:0}.rmw-nutri-head .rmw-nutri-dot{font-weight:600;color:var(--ink)}.rmw-nutri-head-acts{display:flex;align-items:center;gap:10px;flex-wrap:wrap;justify-content:flex-end}.rmw-nutrition-state.complete .rmw-nutri-head{justify-content:space-between}.rmw-nutri-toggle{display:inline-flex;align-items:center;gap:7px;color:var(--n-500);font-size:11.5px;cursor:pointer;white-space:nowrap}.rmw-nutri-toggle input{width:15px;height:15px;margin:0;accent-color:var(--atlas)}
`;document.head.appendChild(s)}
  function shellStyle(){if($('#rmw-shell-css'))return;const s=document.createElement('style');s.id='rmw-shell-css';s.textContent=`
html body:not(#kno) .rmw-shell{overflow:visible!important}
html body:not(#kno) .rmw-layout{display:grid;grid-template-columns:minmax(0,1fr);gap:14px;min-width:0}
html body:not(#kno) .rmw-main{display:flex;flex-direction:column;gap:10px;min-width:0}
html body:not(#kno) .rmw-msvg{width:20px;height:20px;fill:currentColor;flex:0 0 auto}
html body:not(#kno) .rmw-sr{position:absolute;width:1px;height:1px;margin:-1px;overflow:hidden;clip:rect(0 0 0 0);white-space:nowrap}
html body:not(#kno) .rmw-bar{position:sticky;top:var(--rmw-top,0px);z-index:8;display:grid;grid-template-columns:minmax(0,1fr) auto;align-items:center;gap:10px;margin:-6px 0 0;padding:6px 0 8px;background:linear-gradient(var(--surface),var(--surface)),var(--paper)}
html body:not(#kno) .rmw-bar .rmw-menu-search{width:100%;min-height:48px;padding:4px 10px 4px 6px;border-radius:14px;box-shadow:none}
html body:not(#kno) .rmw-bar .rmw-menu-search-icon{width:36px;height:36px}
html body:not(#kno) .rmw-add{display:inline-flex;align-items:center;justify-content:center;gap:6px;min-height:48px!important;padding:0 18px 0 14px;border:0;border-radius:14px;background:var(--atlas);color:var(--paper);font:600 14px/1 var(--sans);white-space:nowrap}
html body:not(#kno) .rmw-add:hover{background:var(--riad)}
html body:not(#kno) .rmw-add-short{display:none}
html body:not(#kno) .rmw-list-head{display:flex;align-items:baseline;gap:8px;min-width:0;margin-top:4px}
html body:not(#kno) .rmw-list-head h3{margin:0;font:650 17px/1.25 var(--sans);letter-spacing:-.01em;color:var(--ink);overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
html body:not(#kno) .rmw-list-head small{font:500 12.5px/1.3 var(--sans);color:var(--n-500);white-space:nowrap}
html body:not(#kno) .rmw-rail{display:grid;grid-template-columns:minmax(0,1fr) 44px;align-items:center;gap:8px;min-width:0}
html body:not(#kno) .rmw-rail-head{display:contents}
html body:not(#kno) .rmw-rail-head>span,html body:not(#kno) .rmw-rail-add{display:none}
html body:not(#kno) .rmw-rail-acts{grid-column:2;grid-row:1;display:grid;place-items:center;width:44px;height:44px;padding:0;border:1px solid var(--n-200);border-radius:12px;background:var(--surface);color:var(--ink)}
html body:not(#kno) .rmw-cats{grid-column:1;grid-row:1;display:flex;gap:6px;min-width:0;overflow-x:auto;scrollbar-width:none;padding:2px;margin:0;border:0;background:transparent}
html body:not(#kno) .rmw-cats::-webkit-scrollbar{display:none}
html body:not(#kno) .rmw-cats .mi-pill{flex:0 0 auto;display:inline-flex;align-items:center;gap:7px;min-height:44px;padding:0 14px;border-radius:999px;white-space:nowrap}
html body:not(#kno) .rmw-cats .mi-pill small{font:600 11.5px/1 var(--sans);font-variant-numeric:tabular-nums;color:var(--n-500)}
html body:not(#kno) .rmw-cats.catalog-rail .mi-pill.on{color:var(--atlas)!important;font-weight:650}
html body:not(#kno) .rmw-cats .mi-pill.on small{color:var(--atlas)}
html body:not(#kno) .rmw-rows{display:flex;flex-direction:column;border:1px solid var(--n-200);border-radius:14px;background:var(--surface);overflow:hidden}
html body:not(#kno) .rmw-row{display:grid;grid-template-columns:minmax(0,1fr) auto 52px 52px 44px;align-items:center;gap:4px;min-height:64px;padding:0 6px 0 0;border-top:1px solid var(--n-200)}
html body:not(#kno) .rmw-row:first-child{border-top:0}
html body:not(#kno) .rmw-row-main{display:flex;align-items:center;gap:12px;min-width:0;min-height:64px!important;padding:10px 8px 10px 14px;border:0;background:transparent;color:var(--ink);text-align:start;font:inherit}
html body:not(#kno) .rmw-row-main:hover{background:var(--paper-soft)}
html body:not(#kno) .rmw-row-thumb{width:44px;height:44px;flex:0 0 auto;border-radius:10px;object-fit:cover;background:var(--paper-soft)}
html body:not(#kno) .rmw-row-text{display:flex;flex-direction:column;gap:3px;min-width:0}
html body:not(#kno) .rmw-row-name{font:600 14.5px/1.3 var(--sans);color:var(--ink);overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
html body:not(#kno) .rmw-row .catalog-item-meta{max-width:100%}
html body:not(#kno) .rmw-row-state{font-weight:650;color:var(--warning)}
html body:not(#kno) .rmw-row-price{padding:0 8px;font:650 14.5px/1.2 var(--sans);font-variant-numeric:tabular-nums;color:var(--atlas);white-space:nowrap;unicode-bidi:isolate;text-align:end}
html[data-theme="dark"] body:not(#kno) .rmw-row-price{color:var(--ink)}
html body:not(#kno) .rmw-row-mods{display:inline-flex;align-items:center;justify-content:center;gap:3px;height:28px;border-radius:999px;background:color-mix(in srgb,var(--atlas) 10%,transparent);color:var(--atlas);font:650 12px/1 var(--sans);font-variant-numeric:tabular-nums}
html body:not(#kno) .rmw-row-mods .rmw-msvg{width:15px;height:15px}
html body:not(#kno) .rmw-row-mods.none{background:transparent;color:var(--n-400,var(--n-500))}
html body:not(#kno) .rmw-avail{position:relative;display:grid;place-items:center;width:52px;height:44px;padding:0;border:0;background:transparent}
html body:not(#kno) .rmw-avail>span{position:relative;width:40px;height:24px;border-radius:999px;background:var(--n-300);transition:background .18s ease}
html body:not(#kno) .rmw-avail>span::after{content:'';position:absolute;top:3px;inset-inline-start:3px;width:18px;height:18px;border-radius:50%;background:#F7F5F0;box-shadow:0 1px 3px rgba(10,15,13,.3);transition:transform .22s cubic-bezier(0.34,1.45,0.5,1)}
html body:not(#kno) .rmw-avail[aria-checked="true"]>span{background:var(--atlas)}
html body:not(#kno) .rmw-avail[aria-checked="true"]>span::after{transform:translateX(16px)}
html[dir="rtl"] body:not(#kno) .rmw-avail[aria-checked="true"]>span::after{transform:translateX(-16px)}
html body:not(#kno) .rmw-avail:disabled{opacity:.4;cursor:not-allowed}
html body:not(#kno) .rmw-row-more{width:44px;height:44px;padding:0;border:0;background:transparent;opacity:.65}
html body:not(#kno) .rmw-row.rmw-off :is(.rmw-row-name,.rmw-row-price,.rmw-row-thumb),html body:not(#kno) .rmw-row.rmw-archived :is(.rmw-row-name,.rmw-row-price,.rmw-row-thumb,.rmw-row-mods){opacity:.5}
html body:not(#kno) .rmw-shell .rmw-sec+.rmw-sec{margin-block-start:14px}
html body:not(#kno) .rmw-empty-note{display:flex;flex-direction:column;align-items:center;gap:12px;padding:36px 20px;border:1px dashed var(--n-300);border-radius:14px;color:var(--n-500);text-align:center;font-size:13.5px}
html body:not(#kno) .rmw-empty-note b{font-weight:600;color:var(--ink)}
@media(max-width:620px){
html body:not(#kno) .rmw-row{grid-template-columns:minmax(0,1fr) auto 52px 44px;grid-template-areas:"main price avail more" "main mods avail more";row-gap:0;padding:0}
html body:not(#kno) .rmw-row-main{grid-area:main;padding-inline-start:12px}
html body:not(#kno) .rmw-row-price{grid-area:price;align-self:end;padding:0 4px}
html body:not(#kno) .rmw-row-mods{grid-area:mods;align-self:start;justify-self:end;height:22px;padding:0 7px;margin:3px 4px 0}
html body:not(#kno) .rmw-avail{grid-area:avail}
html body:not(#kno) .rmw-row-more{grid-area:more}
html body:not(#kno) .rmw-add{padding:0 14px 0 10px}
html body:not(#kno) .rmw-add-long{display:none}
html body:not(#kno) .rmw-add-short{display:inline}
html body:not(#kno) .rmw-bar .rmw-menu-search-count{display:none}
}
@media(min-width:900px){
html body:not(#kno) .rmw-layout{grid-template-columns:clamp(180px,22%,240px) minmax(0,1fr);gap:20px;align-items:start}
html body:not(#kno) .rmw-rail{position:sticky;top:calc(var(--rmw-top,0px) + 8px);display:flex;flex-direction:column;align-items:stretch;gap:6px}
html body:not(#kno) .rmw-rail-head{display:flex;align-items:center;justify-content:space-between;gap:8px;padding-inline-start:6px}
html body:not(#kno) .rmw-rail-head>span{display:block;font:650 12px/1.3 var(--sans);letter-spacing:.02em;color:var(--n-500)}
html body:not(#kno) .rmw-rail-acts{border:0;background:transparent}
html body:not(#kno) .rmw-cats{flex-direction:column;overflow:visible;gap:2px;padding:0}
html body:not(#kno) .rmw-cats .mi-pill{justify-content:space-between;width:100%;border-radius:12px;text-align:start}
html body:not(#kno) .rmw-cat-name{min-width:0;overflow:hidden;text-overflow:ellipsis}
html body:not(#kno) .rmw-rail-add{display:flex;align-items:center;gap:8px;min-height:44px;padding:0 12px;border:1px dashed var(--n-300);border-radius:12px;background:transparent;color:var(--n-600,var(--ink));font:600 13px/1 var(--sans)}
html body:not(#kno) .rmw-rail-add:hover{border-color:var(--atlas);color:var(--atlas)}
html body:not(#kno) [data-menu-root] .mi-filters>.mi-pill-row.catalog-rail{flex-wrap:wrap!important;overflow:visible!important}
}
`;document.head.appendChild(s)}
  function searchStyle(){if($('#rmw-menu-search-css'))return;const s=document.createElement('style');s.id='rmw-menu-search-css';s.textContent=`
.rmw-search-toolbar{padding:0!important;background:transparent!important;border:0!important}
.rmw-menu-search{width:min(100%,760px);min-height:54px;display:grid;grid-template-columns:38px minmax(0,1fr) auto;align-items:center;gap:11px;padding:7px 10px;border:1px solid var(--n-200);border-radius:16px;background:color-mix(in srgb,var(--surface) 92%,var(--paper-soft));box-shadow:0 1px 0 rgba(255,255,255,.04),0 12px 32px -30px rgba(0,0,0,.75);cursor:text;transition:border-color .16s ease,background .16s ease,box-shadow .16s ease,transform .16s ease}
.rmw-menu-search:hover{border-color:color-mix(in srgb,var(--atlas) 30%,var(--n-200));background:var(--surface)}
.rmw-menu-search:focus-within{border-color:color-mix(in srgb,var(--atlas) 72%,var(--n-200));background:var(--surface);box-shadow:0 0 0 3px color-mix(in srgb,var(--atlas) 13%,transparent),0 18px 42px -32px rgba(0,0,0,.75)}
.rmw-menu-search-icon{width:38px;height:38px;display:grid;place-items:center;border-radius:12px;background:color-mix(in srgb,var(--atlas) 10%,transparent);color:var(--atlas);transition:background .16s ease,transform .16s ease}
.rmw-menu-search:focus-within .rmw-menu-search-icon{background:color-mix(in srgb,var(--atlas) 16%,transparent);transform:scale(1.03)}
.rmw-menu-search-icon svg{width:19px;height:19px;fill:currentColor}
.rmw-menu-search input{min-width:0;width:100%;height:38px;padding:0;border:0!important;outline:0!important;background:transparent!important;color:var(--ink);font:550 14px var(--sans);letter-spacing:-.005em;box-shadow:none!important;-webkit-appearance:none;appearance:none}
.rmw-menu-search input::placeholder{color:var(--n-500);opacity:.8}
.rmw-menu-search input::-webkit-search-cancel-button{width:18px;height:18px;margin-inline:8px 2px;cursor:pointer;opacity:.62}
.rmw-menu-search-count{min-width:66px;display:grid;grid-template-columns:auto auto;align-items:baseline;justify-content:end;gap:4px;padding:7px 9px;border-radius:10px;background:var(--paper-soft);color:var(--n-500);white-space:nowrap;transition:background .16s ease,color .16s ease}
.rmw-menu-search-count strong{color:var(--ink);font:700 11px var(--mono)}
.rmw-menu-search-count small{font:600 9px var(--mono);letter-spacing:.02em}
.rmw-menu-search.has-query .rmw-menu-search-count{background:color-mix(in srgb,var(--atlas) 10%,transparent);color:var(--atlas)}
.rmw-menu-search.has-query .rmw-menu-search-count strong{color:var(--atlas)}
@media(max-width:620px){.rmw-menu-search{width:100%;grid-template-columns:36px minmax(0,1fr);min-height:50px;padding:6px 9px;border-radius:14px}.rmw-menu-search-icon{width:36px;height:36px}.rmw-menu-search-count{display:none}}
`;document.head.appendChild(s)}
  function recipeStyle(){if($('#rmw-recipe-css'))return;const s=document.createElement('style');s.id='rmw-recipe-css';s.textContent=`
.kiwi-backdrop.rmw-recipe-modal{background:color-mix(in srgb,#0A0F0D 46%,transparent)!important;backdrop-filter:none!important;-webkit-backdrop-filter:none!important}
.kiwi-backdrop.rmw-recipe-modal .kiwi-modal.kiwi-modal{--rx-bg:var(--paper);--rx-card:color-mix(in srgb,var(--paper) 55%,#fff);--rx-field:var(--paper);background:var(--rx-bg)!important;backdrop-filter:none!important;-webkit-backdrop-filter:none!important;border:1px solid var(--n-200);box-shadow:0 30px 80px -30px rgba(0,0,0,.5)}
html[data-theme="dark"] .kiwi-backdrop.rmw-recipe-modal .kiwi-modal.kiwi-modal{--rx-bg:#0F1512;--rx-card:#151C18;--rx-field:#0B100E}
.kiwi-backdrop.rmw-recipe-modal .kiwi-modal-foot.kiwi-modal-foot{background:var(--rx-bg)!important;backdrop-filter:none!important;-webkit-backdrop-filter:none!important;border-top:1px solid var(--n-200)}
.rmw-rx{display:grid;grid-template-columns:minmax(0,1fr) 300px;gap:22px;align-items:start;color:var(--ink)}
.rmw-rx-draft{grid-column:1/-1;display:grid;gap:3px;padding:11px 14px;border-radius:12px;background:color-mix(in srgb,#d49a25 14%,var(--rx-card));font-size:12.5px}
.rmw-rx-draft span{color:var(--n-600)}
.rmw-rx-main{display:grid;gap:18px;min-width:0}
.rmw-rx-sec{min-width:0;padding:18px;border:1px solid var(--n-200);border-radius:14px;background:var(--rx-card)}
.rmw-rx-sec-head{display:flex;align-items:flex-start;justify-content:space-between;gap:16px;margin-bottom:14px}
.rmw-rx-sec-head h4{margin:0;font:650 15px var(--sans);color:var(--ink)}
.rmw-rx-sec-head p{max-width:46ch;margin:4px 0 0;font-size:12px;line-height:1.45;color:var(--n-500)}
.rmw-rx-meta{display:flex;gap:10px;flex:0 0 auto}
.rmw-rx-meta label,.rmw-rx-notes label{display:grid;gap:5px;font-size:11.5px;font-weight:600;color:var(--n-600)}
.rmw-rx-meta .rmw-rx-in{width:84px}
.rmw-rx-in{box-sizing:border-box;width:100%;height:38px;padding:0 11px;border:1px solid var(--n-200);border-radius:10px;background:var(--rx-field);color:var(--ink);font:500 13.5px var(--sans);font-variant-numeric:tabular-nums;transition:border-color 140ms,box-shadow 140ms}
.rmw-rx-in:focus{outline:0;border-color:var(--atlas);box-shadow:0 0 0 3px color-mix(in srgb,var(--atlas) 16%,transparent)}
textarea.rmw-rx-in{height:auto;min-height:92px;padding:10px 11px;line-height:1.5;resize:vertical}
.rmw-rx-suffix{position:relative;display:block}
.rmw-rx-suffix .rmw-rx-in{padding-inline-end:34px}
.rmw-rx-suffix i{position:absolute;inset-inline-end:10px;top:50%;transform:translateY(-50%);font:500 11.5px var(--sans);font-style:normal;color:var(--n-500);pointer-events:none}
.rmw-rx-cols,.rmw-rx-row{display:grid;grid-template-columns:minmax(0,1fr) 168px 92px 32px;gap:10px;align-items:start}
.rmw-rx-cols{padding:0 2px 6px;border-bottom:1px solid var(--n-200);font-size:11px;font-weight:600;color:var(--n-500)}
.rmw-rx-cols span:nth-child(3){text-align:end}
.rmw-rx-row{padding:9px 0;border-bottom:1px solid var(--n-200)}
.rmw-rx-name{display:grid;gap:4px;min-width:0}
.rmw-rx-name small{min-height:15px;font-size:11px;line-height:15px;color:var(--n-500)}
.rmw-rx-row[data-state="unlinked"] .rmw-rx-name small,.rmw-rx-row[data-state="noprice"] .rmw-rx-name small,.rmw-rx-row[data-state="unit"] .rmw-rx-name small,.rmw-rx-row[data-state="noqty"] .rmw-rx-name small{color:#a8730f}
.rmw-rx-row[data-state="unit"] .rmw-rx-unit,.rmw-rx-row[data-state="noqty"] .rmw-rx-qty .rmw-rx-in{border-color:color-mix(in srgb,#d49a25 60%,var(--n-200))}
.rmw-rx-qty{display:grid;grid-template-columns:minmax(0,1fr) 78px;gap:6px}
.rmw-rx-unit{box-sizing:border-box;width:100%;height:38px;padding:0 24px 0 9px;border:1px solid var(--n-200);border-radius:10px;background-color:var(--rx-field);color:var(--ink);font:500 13px var(--sans);appearance:none;-webkit-appearance:none;background-image:linear-gradient(45deg,transparent 50%,var(--n-500) 50%),linear-gradient(135deg,var(--n-500) 50%,transparent 50%);background-position:calc(100% - 13px) 17px,calc(100% - 9px) 17px;background-size:4px 4px;background-repeat:no-repeat;cursor:pointer}
[dir="rtl"] .rmw-rx-unit{padding:0 9px 0 24px;background-position:13px 17px,9px 17px}
/* Vexel repaints every select with a background shorthand, which erases the chevron: restate it inside the sheet. */
.kiwi-backdrop.rmw-recipe-modal select.rmw-rx-unit{background-image:linear-gradient(45deg,transparent 50%,var(--n-500) 50%),linear-gradient(135deg,var(--n-500) 50%,transparent 50%)!important;background-position:calc(100% - 15px) 50%,calc(100% - 11px) 50%!important;background-size:4px 4px!important;background-repeat:no-repeat!important;padding-inline-end:28px!important}
[dir="rtl"] .kiwi-backdrop.rmw-recipe-modal select.rmw-rx-unit{background-position:15px 50%,11px 50%!important}
.rmw-rx-unit:focus{outline:0;border-color:var(--atlas);box-shadow:0 0 0 3px color-mix(in srgb,var(--atlas) 16%,transparent)}
.rmw-rx-cost{height:38px;display:flex;align-items:center;justify-content:flex-end;font:600 13px var(--sans);font-variant-numeric:tabular-nums;color:var(--ink)}
.rmw-rx-del{width:32px;height:38px;display:grid;place-items:center;padding:0;border:0;border-radius:9px;background:transparent;color:var(--n-500);cursor:pointer}
.rmw-rx-del svg,.rmw-rx-add svg{width:18px;height:18px}
.rmw-rx-del:hover,.rmw-rx-del:focus-visible{outline:0;background:color-mix(in srgb,var(--danger,#b94b38) 10%,transparent);color:var(--danger,#b94b38)}
.rmw-rx-add{display:inline-flex;align-items:center;gap:7px;margin-top:12px;padding:8px 12px 8px 9px;border:1px dashed var(--n-300);border-radius:10px;background:transparent;color:var(--atlas);font:600 13px var(--sans);cursor:pointer}
.rmw-rx-add:hover{border-style:solid;background:color-mix(in srgb,var(--atlas) 6%,transparent)}
.rmw-rx-hint{margin:12px 0 0;font-size:12px;color:var(--n-500)}
.rmw-rx-notes{display:grid;grid-template-columns:1fr 1fr;gap:12px}
.rmw-rx-side{position:sticky;top:0;display:grid;gap:14px;padding:18px;border:1px solid var(--n-200);border-radius:14px;background:var(--rx-card)}
.rmw-rx-status{display:grid;gap:4px;padding:10px 12px;border-radius:10px;background:var(--rx-bg);font-size:12px;line-height:1.45;color:var(--n-600)}
.rmw-rx-status b{display:flex;align-items:center;gap:7px;font-size:13px;color:var(--ink)}
.rmw-rx-status b:before{content:'';width:8px;height:8px;border-radius:50%;background:var(--n-400,var(--n-500))}
.rmw-rx-status.ok b:before{background:var(--atlas)}.rmw-rx-status.watch b:before,.rmw-rx-status.todo b:before{background:#d49a25}.rmw-rx-status.gap b:before{background:#cb5238}
.rmw-rx-link{justify-self:start;padding:0;border:0;background:none;color:var(--atlas);font:600 12px var(--sans);text-decoration:underline;cursor:pointer}
.rmw-rx-hero{display:grid;gap:2px}
.rmw-rx-hero span{font-size:12px;font-weight:600;color:var(--n-500)}
.rmw-rx-hero b{font:650 30px/1.1 var(--sans);letter-spacing:-.03em;font-variant-numeric:tabular-nums;color:var(--ink)}
.rmw-rx-facts{display:grid;gap:0;margin:0}
.rmw-rx-facts>div{display:flex;align-items:baseline;justify-content:space-between;gap:12px;padding:9px 0;border-top:1px solid var(--n-200)}
.rmw-rx-facts dt{font-size:12.5px;color:var(--n-600)}.rmw-rx-facts dt em{font-style:normal;font-size:11px;color:var(--n-500)}
.rmw-rx-facts dd{margin:0;font:600 13.5px var(--sans);font-variant-numeric:tabular-nums;text-align:end;color:var(--ink)}
.rmw-rx-facts dd small{display:block;max-width:150px;font:400 11px/1.35 var(--sans);color:var(--n-500)}
.rmw-rx-facts dd.neg{color:#cb5238}
.rmw-rx-hero.partial b{font-size:22px;color:var(--n-600)}.rmw-rx-hero small{font-size:11px;line-height:1.4;color:var(--n-500)}
.rmw-rx-side .rmw-nutrition-state{display:grid!important;grid-template-columns:1fr!important;gap:8px!important;padding:12px 0 0!important;border:0!important;border-top:1px solid var(--n-200)!important;border-radius:0!important;background:none!important}
.rmw-rx-side .rmw-nutri-head,.rmw-rx-side .rmw-nutri-head-acts{display:flex!important;flex-direction:column!important;align-items:flex-start!important;gap:6px!important;width:100%}
.rmw-rx-side .rmw-nutri-head-acts .btn-slim{width:100%;justify-content:center}
.rmw-rx-side .rmw-nutri-muted{font-size:11.5px;line-height:1.4}
@media(max-width:900px){.rmw-rx{grid-template-columns:1fr}.rmw-rx-side{position:static;order:-1}.rmw-rx-draft{order:-2}}
@media(max-width:620px){.rmw-rx-sec{padding:14px}.rmw-rx-sec-head{flex-direction:column}.rmw-rx-cols{display:none}.rmw-rx-row{grid-template-columns:minmax(0,1fr) 32px;gap:8px}.rmw-rx-name{grid-column:1}.rmw-rx-del{grid-column:2;grid-row:1}.rmw-rx-qty{grid-column:1}.rmw-rx-cost{grid-column:2;grid-row:2;justify-content:flex-end;font-size:12px;height:38px}.rmw-rx-notes{grid-template-columns:1fr}}
`;document.head.appendChild(s);}
  function itemStyle(){if($('#rmw-item-css'))return;const s=document.createElement('style');s.id='rmw-item-css';s.textContent=`
.rmw-item-workspace .kiwi-modal-head{transition:box-shadow 160ms}
.rmw-item-workspace .kiwi-modal.rmw-scrolled .kiwi-modal-head{box-shadow:0 1px 0 var(--n-200)}
.rmw-item-workspace .rmw-it-archive{margin-inline-end:auto}
.rmw-it{display:grid;grid-template-columns:minmax(0,1fr) 284px;gap:20px;align-items:start;color:var(--ink)}
.rmw-it :is(input,select,textarea).rmw-rx-in,.rmw-it select.rmw-rx-unit{background-color:var(--rx-field)!important;border:1px solid var(--n-200)!important;border-radius:10px!important;box-shadow:none}
.rmw-it :is(input,select,textarea).rmw-rx-in:focus,.rmw-it select.rmw-rx-unit:focus{border-color:var(--atlas)!important;box-shadow:0 0 0 3px color-mix(in srgb,var(--atlas) 16%,transparent)}
.rmw-it-grid{display:grid;grid-template-columns:minmax(0,1fr) 180px;gap:14px 12px;align-items:start}
.rmw-it-f{display:grid;gap:6px;align-content:start;min-width:0;font-size:12px;font-weight:600;color:var(--n-600)}
.rmw-it-full{grid-column:1/-1}
.rmw-it-f .rmw-rx-unit{height:40px}
.rmw-it-f .rmw-rx-in{height:40px;font-size:14px}
.rmw-it-f textarea.rmw-rx-in{height:auto;min-height:84px}
.rmw-it-f [data-name]{font-weight:600}
.rmw-it .rmw-it-f input.rmw-rx-in[aria-invalid="true"]{border-color:#cb5238!important;box-shadow:0 0 0 3px color-mix(in srgb,#cb5238 14%,transparent)!important}
.rmw-it-err{font:500 11.5px var(--sans);font-style:normal;color:#cb5238}
.rmw-it-chips{display:flex;flex-wrap:wrap;gap:8px}
.rmw-it-chip{position:relative;display:inline-flex;align-items:center;gap:9px;min-height:40px;padding:6px 14px 6px 8px;border:1px solid var(--n-200);border-radius:12px;background:var(--rx-field);cursor:pointer;transition:border-color 140ms,background-color 140ms}
.rmw-it-chip:hover{border-color:var(--n-300)}
.rmw-it-chip input{position:absolute;opacity:0;width:1px;height:1px;pointer-events:none}
.rmw-it-chip-box{width:20px;height:20px;flex:0 0 auto;display:grid;place-items:center;border:1.5px solid var(--n-300);border-radius:6px;color:transparent;transition:background-color 140ms,border-color 140ms,color 140ms}
.rmw-it-chip-box svg{width:15px;height:15px;fill:currentColor}
.rmw-it-chip-txt{display:grid;gap:1px;line-height:1.2}
.rmw-it-chip-txt b{font:600 13px var(--sans);color:var(--ink)}
.rmw-it-chip-txt small{font-size:11px;color:var(--n-500)}
.rmw-it-chip:has(input:checked){border-color:color-mix(in srgb,var(--atlas) 45%,var(--n-200));background:color-mix(in srgb,var(--atlas) 7%,var(--rx-field))}
.rmw-it-chip input:checked+.rmw-it-chip-box{background:var(--atlas);border-color:var(--atlas);color:var(--paper)}
.rmw-it-chip:has(input:focus-visible){box-shadow:0 0 0 3px color-mix(in srgb,var(--atlas) 20%,transparent)}
.rmw-it-tg{display:flex;align-items:flex-start;justify-content:space-between;gap:14px;cursor:pointer}
.rmw-it-tg input{position:absolute;opacity:0;width:1px;height:1px;pointer-events:none}
.rmw-it-tg-txt{display:grid;gap:3px;min-width:0}
.rmw-it-tg-txt b{font:600 13px var(--sans);color:var(--ink)}
.rmw-it-tg-txt small{font-size:11.5px;line-height:1.4;color:var(--n-500)}
.rmw-it-sw{position:relative;width:38px;height:22px;flex:0 0 auto;margin-top:1px;border-radius:999px;background:var(--n-300);transition:background-color 180ms}
.rmw-it-sw:after{content:'';position:absolute;top:3px;inset-inline-start:3px;width:16px;height:16px;border-radius:50%;background:#fff;box-shadow:0 1px 2px rgba(0,0,0,.25);transition:transform 310ms cubic-bezier(0.34,1.45,0.5,1)}
.rmw-it-tg input:checked+.rmw-it-sw{background:var(--atlas)}
.rmw-it-tg input:checked+.rmw-it-sw:after{transform:translateX(16px)}
[dir="rtl"] .rmw-it-tg input:checked+.rmw-it-sw:after{transform:translateX(-16px)}
.rmw-it-tg input:focus-visible+.rmw-it-sw{box-shadow:0 0 0 3px color-mix(in srgb,var(--atlas) 22%,transparent)}
.rmw-it-tg.bare{flex:0 0 auto;margin-top:2px}
.rmw-it-side{gap:12px}
.rmw-it-media{position:relative;aspect-ratio:4/3;overflow:hidden;display:grid;place-items:center;border-radius:12px;background:var(--rx-bg);border:1px solid var(--n-200)}
.rmw-it-media img,.rmw-it-media video{width:100%;height:100%;object-fit:cover;display:block}
.rmw-it-ph{display:grid;justify-items:center;gap:6px;color:var(--n-500)}
.rmw-it-ph svg{width:30px;height:30px;fill:currentColor;opacity:.7}
.rmw-it-ph small{font-size:11.5px}
.rmw-it-macts{display:flex;flex-wrap:wrap;gap:6px}
.rmw-it-mbtn{display:inline-flex;align-items:center;gap:6px;height:32px;padding:0 11px;border:1px solid var(--n-200);border-radius:9px;background:var(--rx-field);color:var(--ink);font:600 12px var(--sans);cursor:pointer}
.rmw-it-mbtn svg{width:16px;height:16px;fill:currentColor;color:var(--atlas)}
.rmw-it-mbtn:hover{border-color:var(--n-300)}
.rmw-it-mbtn.ghost{border-color:transparent;background:transparent;color:var(--n-600)}
.rmw-it-mbtn.ghost:hover{color:#cb5238}
.rmw-it-mbtn[hidden]{display:none}
.rmw-it-mstatus{margin:-4px 0 0;min-height:0;font-size:11.5px;color:var(--n-500)}
.rmw-it-mstatus:empty{display:none}
.rmw-it-tgs{display:grid;gap:0;border-top:1px solid var(--n-200)}
.rmw-it-tgs .rmw-it-tg{padding:13px 0;border-bottom:1px solid var(--n-200)}
.rmw-it-tgs .rmw-it-tg:last-child{border-bottom:0;padding-bottom:0}
.rmw-it-builder{display:grid;gap:12px}
.rmw-it-builder[hidden]{display:none}
.rmw-it-tpl{display:grid;grid-template-columns:minmax(0,1fr) auto;gap:8px}
.rmw-it-tpl .rmw-rx-unit{height:38px}
.rmw-it-sbtn{height:38px;padding:0 14px;border:1px solid var(--n-200);border-radius:10px;background:var(--rx-field);color:var(--ink);font:600 12.5px var(--sans);cursor:pointer;white-space:nowrap}
.rmw-it-sbtn:hover{border-color:var(--atlas);color:var(--atlas)}
.rmw-it-steps{display:grid;gap:10px}
.rmw-it-formula-foot{display:flex;align-items:center;justify-content:space-between;gap:12px;flex-wrap:wrap}
.rmw-it-formula-foot .rmw-rx-add{margin-top:0}
.rmw-it-formula-foot .rmw-rx-add svg{fill:currentColor}
.rmw-st{border:1px solid var(--n-200);border-radius:12px;background:var(--rx-bg);overflow:hidden}
.rmw-st.is-open{border-color:color-mix(in srgb,var(--atlas) 30%,var(--n-200))}
.rmw-st-head{display:grid;grid-template-columns:minmax(0,1fr) auto;gap:4px 12px;align-items:center;padding:12px 12px 12px 14px}
.rmw-st-kicker{font:600 11px var(--sans);letter-spacing:.02em;color:var(--atlas)}
.rmw-st-acts{grid-row:1/3;grid-column:2;display:flex;align-items:center;gap:4px;align-self:start}
.rmw-st-sum{margin-inline-end:6px;font-size:11.5px;color:var(--n-500);white-space:nowrap}
.rmw-st-btn{width:32px;height:32px;display:grid;place-items:center;padding:0;border:0;border-radius:9px;background:transparent;color:var(--n-500);cursor:pointer}
.rmw-st-btn svg{width:18px;height:18px;fill:currentColor;transition:transform 200ms}
.rmw-st-btn:hover{background:color-mix(in srgb,var(--ink) 6%,transparent);color:var(--ink)}
.rmw-st-btn.danger:hover{background:color-mix(in srgb,#cb5238 10%,transparent);color:#cb5238}
.rmw-st-btn[aria-expanded="true"] svg{transform:rotate(180deg)}
.rmw-it input.rmw-st-title{grid-column:1;width:100%;height:30px;padding:0!important;border:0!important;border-radius:0!important;background:transparent!important;box-shadow:none!important;color:var(--ink);font:650 16px var(--sans)}
.rmw-it input.rmw-st-title:focus{outline:0;box-shadow:0 1px 0 var(--atlas)!important}
.rmw-st-err{grid-column:1/-1;margin:2px 0 0}
.rmw-st-rule{grid-column:1/-1;display:flex;flex-wrap:wrap;align-items:center;gap:6px;font-size:12.5px;color:var(--n-600)}
.rmw-it input.rmw-st-num{width:44px;height:30px;padding:0!important;border:1px solid var(--n-200)!important;border-radius:8px!important;background:var(--rx-field)!important;color:var(--ink);font:600 13px var(--sans);font-variant-numeric:tabular-nums;text-align:center;-moz-appearance:textfield}
.rmw-it input.rmw-st-num:focus{outline:0;border-color:var(--atlas)!important}
.rmw-it input.rmw-st-num::-webkit-inner-spin-button,.rmw-it .rmw-st-plus input::-webkit-inner-spin-button{-webkit-appearance:none;margin:0}
.rmw-st-body{border-top:1px solid var(--n-200);background:var(--rx-card)}
.rmw-st-body[hidden]{display:none}
.rmw-st-list{display:grid}
.rmw-st-choice{display:grid;grid-template-columns:24px minmax(0,1fr) auto 32px;gap:12px;align-items:center;padding:9px 12px 9px 14px;border-bottom:1px solid var(--n-200)}
.rmw-st-n{width:24px;height:24px;display:grid;place-items:center;border-radius:7px;background:color-mix(in srgb,var(--atlas) 10%,transparent);color:var(--atlas);font:600 11px var(--sans);font-variant-numeric:tabular-nums}
.rmw-st-name{display:grid;gap:1px;min-width:0}
.rmw-st-name b{overflow:hidden;font:600 13px var(--sans);text-overflow:ellipsis;white-space:nowrap;color:var(--ink)}
.rmw-st-name small{font-size:11px;color:var(--n-500);font-variant-numeric:tabular-nums}
.rmw-st-extra{display:flex;align-items:center;gap:8px;font-size:11.5px;color:var(--n-500)}
.rmw-st-plus{width:104px}
.rmw-it .rmw-st-plus .rmw-rx-in{height:34px;padding-inline:22px 38px!important;text-align:end;font-size:13px}
.rmw-st-plus em{position:absolute;inset-inline-start:10px;top:50%;transform:translateY(-50%);font:500 12px var(--sans);font-style:normal;color:var(--n-500);pointer-events:none}
.rmw-st-choice .rmw-rx-del{height:32px}
.rmw-st-choice .rmw-rx-del svg{fill:currentColor}
.rmw-st-empty{margin:0;padding:12px 14px;font-size:12px;color:var(--n-500)}
.rmw-it-steps>.rmw-st-empty{padding:0}
.rmw-st-note{display:grid;gap:6px;justify-items:start;padding:12px 14px}
.rmw-st-note p{margin:0;font-size:12px;line-height:1.45;color:var(--n-600)}
.rmw-st-add{position:relative;padding:8px 10px}
.rmw-st-pick{display:inline-flex;align-items:center;gap:7px;height:34px;padding:0 10px 0 7px;border:0;border-radius:9px;background:transparent;color:var(--atlas);font:600 12.5px var(--sans);cursor:pointer}
.rmw-st-pick svg{width:18px;height:18px;fill:currentColor}
.rmw-st-pick:hover,.rmw-st-pick[aria-expanded="true"]{background:color-mix(in srgb,var(--atlas) 8%,transparent)}
.rmw-it .rmw-formula-picker-add svg{width:16px;height:16px;fill:currentColor}
.rmw-it .rmw-formula-picker.is-floating,.rmw-formula-picker.is-floating{background:var(--paper)!important;backdrop-filter:none!important;-webkit-backdrop-filter:none!important}
html[data-theme="dark"] .rmw-formula-picker.is-floating{background:color-mix(in srgb,var(--ink) 7%,var(--paper))!important}
@media(max-width:900px){.rmw-it{grid-template-columns:1fr}
.rmw-it-side{position:static;order:-1;grid-template-columns:132px minmax(0,1fr);align-items:start}
.rmw-it-media{grid-row:1/3}
.rmw-it-tgs{grid-column:1/-1}}
@media(max-width:620px){.rmw-it-grid{grid-template-columns:1fr}
.rmw-it-side{order:1;grid-template-columns:1fr}
.rmw-it-media{grid-row:auto;aspect-ratio:16/9}
.rmw-it-media:has(.rmw-it-ph){aspect-ratio:auto;height:96px}
.rmw-st-choice{grid-template-columns:24px minmax(0,1fr) 32px;row-gap:8px}
.rmw-st-extra{grid-column:2;grid-row:2}
.rmw-st-choice .rmw-rx-del{grid-column:3;grid-row:1}
.rmw-it-tpl{grid-template-columns:1fr}}
`;document.head.appendChild(s);}
  function performanceStyle(){if($('#rmw-performance-css'))return;const s=document.createElement('style');s.id='rmw-performance-css';s.textContent=`
.rmw-perf-insights-sub{margin:-4px 0 12px;color:var(--n-500);font-size:12px}
.rmw-perf-insights ul{display:grid;gap:8px;margin:0;padding:0;list-style:none}
.rmw-perf-insights li{display:flex;align-items:flex-start;justify-content:space-between;gap:14px;padding:12px 14px;border:1px solid var(--n-200);border-radius:12px;background:var(--surface);font-size:13px;line-height:1.45}
.rmw-perf-insights li p{margin:0;min-width:0}
.rmw-perf-insights li .rmw-perf-link{flex:0 0 auto;white-space:nowrap;font-size:12px}
.rmw-perf-insights-none{margin:0;color:var(--n-500);font-size:12.5px}
.rmw-perf-table td small.rmw-perf-est{color:var(--n-600)}
@media(max-width:620px){.rmw-perf-insights li{flex-direction:column;gap:6px}}
.rmw-performance{gap:16px}
.rmw-perf-head{display:flex;align-items:flex-end;justify-content:space-between;gap:16px;flex-wrap:wrap;padding:2px 2px 0}
.rmw-perf-head h2{margin:0;font:650 26px/1.15 var(--sans);letter-spacing:-.025em;color:var(--ink)}
.rmw-perf-head p{margin:6px 0 0;font-size:13px;color:var(--n-500)}
.rmw-sum{display:grid;gap:14px;padding:18px 20px;border:1px solid var(--n-200);border-radius:16px;background:var(--surface)}
.rmw-sum-kpis{display:grid;grid-template-columns:repeat(4,minmax(0,1fr))}
.rmw-sum-kpis>div{display:flex;flex-direction:column;gap:5px;min-width:0;padding:0 18px;border-inline-start:1px solid var(--n-200)}
.rmw-sum-kpis>div:first-child{padding-inline-start:0;border:0}
.rmw-sum-kpis span{font:600 10px var(--mono);letter-spacing:.08em;text-transform:uppercase;color:var(--n-500)}
.rmw-sum-kpis b{font:650 24px/1.15 var(--sans);letter-spacing:-.025em;font-variant-numeric:tabular-nums;color:var(--ink)}
.rmw-sum-kpis small{font-size:11.5px;line-height:1.4;color:var(--n-500)}
.rmw-sum-bar{display:block;height:4px;margin:2px 0;border-radius:99px;background:var(--n-200);overflow:hidden}
.rmw-sum-bar>i{display:block;height:100%;border-radius:inherit;background:var(--atlas)}
.rmw-sum-recon{display:flex;flex-wrap:wrap;align-items:baseline;gap:6px 12px;padding-top:12px;border-top:1px solid var(--n-200);font-size:12.5px;color:var(--n-600)}
.rmw-sum-i{display:inline-flex;align-items:baseline;gap:5px}
.rmw-sum-recon b{font-weight:650;color:var(--ink);font-variant-numeric:tabular-nums}
.rmw-sum-recon small{color:var(--n-500)}
.rmw-sum-recon>i{font-style:normal;color:var(--n-400,var(--n-500))}
.rmw-sum .rmw-perf-notes{margin:0}
.rmw-mx{padding:20px}
.rmw-mx-head{display:flex;align-items:flex-start;justify-content:space-between;gap:18px;margin-bottom:16px}
.rmw-mx-head h3{margin:0;font:650 17px var(--sans);letter-spacing:-.01em;color:var(--ink)}
.rmw-mx-head p{max-width:64ch;margin:5px 0 0;font-size:12.5px;line-height:1.5;color:var(--n-500)}
.rmw-mx-key{display:flex;flex-direction:column;align-items:flex-end;gap:6px;flex:0 0 auto;font-size:11.5px;color:var(--n-500)}
.rmw-mx-key>span{display:flex;align-items:center;gap:6px}
.rmw-mx-key i{display:inline-block;border-radius:50%;background:var(--n-300)}
.rmw-mx-body{display:grid;grid-template-columns:minmax(0,1.6fr) minmax(300px,1fr);gap:18px;align-items:stretch}
.rmw-mx-chart{display:flex;flex-direction:column;gap:7px;min-width:0;margin:0}
.rmw-mx-axis{font:600 10px var(--mono);letter-spacing:.08em;text-transform:uppercase;color:var(--n-500)}
.rmw-mx-axis.x{padding-top:12px;text-align:end}
.rmw-mx-plot{--z-r:13px;position:relative;flex:1;min-height:360px;border:1px solid var(--n-200);border-radius:14px;background:var(--surface)}
.rmw-mx-zones{position:absolute;inset:0;overflow:hidden;border-radius:var(--z-r)}
.rmw-mx-zone{position:absolute;background:color-mix(in srgb,var(--q) 9%,transparent)}
.rmw-mx-zone>em{position:absolute;font:700 9.5px var(--mono);font-style:normal;letter-spacing:.1em;text-transform:uppercase;white-space:nowrap;color:color-mix(in srgb,var(--q) 78%,var(--ink))}
.rmw-mx-zone.puzzle>em{top:12px;left:14px}.rmw-mx-zone.star>em{top:12px;right:14px}.rmw-mx-zone.dog>em{bottom:12px;left:14px}.rmw-mx-zone.plow>em{bottom:12px;right:14px}
.rmw-mx-zone.star,.rmw-mx-q.star,.rmw-mx-dot.star{--q:#1d9c67}.rmw-mx-zone.puzzle,.rmw-mx-q.puzzle,.rmw-mx-dot.puzzle{--q:#357fad}.rmw-mx-zone.plow,.rmw-mx-q.plow,.rmw-mx-dot.plow{--q:#d49a25}.rmw-mx-zone.dog,.rmw-mx-q.dog,.rmw-mx-dot.dog{--q:#cb5238}
.rmw-mx-med,.rmw-mx-zero{position:absolute;z-index:1;border:0 dashed color-mix(in srgb,var(--ink) 24%,transparent)}
.rmw-mx-med.v{top:0;bottom:0;border-left-width:1px}.rmw-mx-med.h,.rmw-mx-zero{left:0;right:0;border-top-width:1px}.rmw-mx-zero{border-top-style:solid}
.rmw-mx-med>span,.rmw-mx-zero>span{position:absolute;padding:2px 8px;border:1px solid var(--n-200);border-radius:99px;background:var(--surface);font:600 10px/1.4 var(--mono);white-space:nowrap;color:var(--n-600)}
.rmw-mx-med.v>span{bottom:-11px;transform:translateX(-50%)}.rmw-mx-med.h>span{top:-11px;left:12px}.rmw-mx-zero>span{top:-11px;left:12px}
.rmw-mx-dot{position:absolute;width:var(--s);height:var(--s);padding:0;transform:translate(-50%,50%);border:2px solid var(--surface);border-radius:50%;background:var(--q);box-shadow:0 1px 4px rgba(0,0,0,.2);cursor:pointer;transition:transform 160ms ease,box-shadow 160ms ease}
.rmw-mx-dot:not([data-action]){cursor:default}
.rmw-mx-dot>b{position:absolute;inset:0;display:grid;place-items:center;font:700 10px var(--mono);color:#fff}
.rmw-mx-dot:hover,.rmw-mx-dot:focus-visible{z-index:60!important;transform:translate(-50%,50%) scale(1.14);outline:0;box-shadow:0 0 0 4px color-mix(in srgb,var(--q) 28%,transparent)}
.rmw-mx-lab{position:absolute;z-index:2;max-width:150px;overflow:hidden;padding:0 6px;border-radius:6px;background:color-mix(in srgb,var(--surface) 84%,transparent);font:600 11px/18px var(--sans);text-overflow:ellipsis;white-space:nowrap;color:var(--ink);pointer-events:none}
.rmw-mx-lab.r{transform:translate(calc(var(--r) + 5px),50%)}.rmw-mx-lab.l{transform:translate(calc(-100% - var(--r) - 5px),50%)}.rmw-mx-lab.t{transform:translate(-50%,calc(-1 * var(--r) - 4px))}.rmw-mx-lab.b{transform:translate(-50%,calc(100% + var(--r) + 4px))}
.rmw-mx-tip{display:none;position:absolute;bottom:calc(100% + 10px);left:50%;width:230px;padding:11px 12px;transform:translateX(-50%);border-radius:12px;background:#101612;color:#F7F5F0;text-align:start;font:12px/1.45 var(--sans);box-shadow:0 14px 36px rgba(0,0,0,.3);pointer-events:none}
.rmw-mx-dot.down>.rmw-mx-tip{top:calc(100% + 10px);bottom:auto}.rmw-mx-dot.end>.rmw-mx-tip{left:auto;right:-8px;transform:none}.rmw-mx-dot.start>.rmw-mx-tip{left:-8px;transform:none}
.rmw-mx-dot:hover>.rmw-mx-tip,.rmw-mx-dot:focus-visible>.rmw-mx-tip{display:grid;gap:8px}
.rmw-mx-tip>em{font:700 9px var(--mono);font-style:normal;letter-spacing:.1em;text-transform:uppercase;color:color-mix(in srgb,var(--q) 70%,#fff)}
.rmw-mx-tip>strong{font-size:12px}
.rmw-mx-tip-row{display:grid;gap:2px}.rmw-mx-tip-row b{font-size:13px}.rmw-mx-tip-row small{color:rgba(247,245,240,.66);font-size:11px;font-variant-numeric:tabular-nums}
.rmw-mx-quads{display:grid;grid-template-columns:1fr 1fr;grid-auto-rows:1fr;gap:10px;min-width:0}
.rmw-mx-q{display:flex;flex-direction:column;gap:7px;min-width:0;padding:12px 14px;border:1px solid var(--n-200);border-top:3px solid var(--q);border-radius:12px;background:var(--surface)}
.rmw-mx-q header{display:flex;align-items:center;gap:7px}
.rmw-mx-q header i{width:8px;height:8px;flex:0 0 auto;border-radius:50%;background:var(--q)}
.rmw-mx-q header b{font:650 13px var(--sans);color:var(--ink)}
.rmw-mx-q header span{min-width:22px;margin-inline-start:auto;padding:1px 7px;border-radius:99px;background:color-mix(in srgb,var(--q) 14%,transparent);font:700 11px/1.5 var(--mono);text-align:center;color:color-mix(in srgb,var(--q) 80%,var(--ink))}
.rmw-mx-q>p{margin:0;font-size:11.5px;line-height:1.4;color:var(--n-500)}
.rmw-mx-q ul{display:grid;gap:6px;margin:2px 0 0;padding:0;list-style:none}
.rmw-mx-q li{display:flex;flex-direction:column;min-width:0}
.rmw-mx-q li button{overflow:hidden;padding:0;border:0;background:none;font:600 12.5px/1.35 var(--sans);text-align:start;text-overflow:ellipsis;white-space:nowrap;color:var(--ink);cursor:pointer}
.rmw-mx-q li button:hover,.rmw-mx-q li button:focus-visible{color:var(--atlas);text-decoration:underline}
.rmw-mx-q li small,.rmw-mx-q .more{font-size:11px;font-variant-numeric:tabular-nums;color:var(--n-500)}
.rmw-mx-q footer{display:flex;flex-wrap:wrap;justify-content:space-between;gap:4px 10px;margin-top:auto;padding-top:8px;border-top:1px solid var(--n-200);font-size:11px;color:var(--n-500)}
.rmw-mx-q footer b{font-weight:650;color:var(--n-600)}
.rmw-mx-q .none{margin:auto 0;color:var(--n-500);font-size:12px}
.rmw-mx-few{padding:26px 18px;text-align:center;color:var(--n-500);font-size:13px}
.rmw-mx-few p{max-width:60ch;margin:0 auto;line-height:1.5}
@media(max-width:1100px){.rmw-mx-body{grid-template-columns:1fr}}
@media(max-width:900px){.rmw-sum-kpis{grid-template-columns:1fr 1fr;gap:16px 0}.rmw-sum-kpis>div:nth-child(3){padding-inline-start:0;border:0}}
@media(max-width:700px){.rmw-mx{padding:14px}.rmw-mx-head{flex-direction:column}.rmw-mx-key{align-items:flex-start}.rmw-mx-plot{min-height:270px}.rmw-mx-lab:not(.keep){display:none}.rmw-mx-zone>em{font-size:8.5px}.rmw-perf-head h2{font-size:22px}}
@media(max-width:480px){.rmw-mx-quads{grid-template-columns:1fr;grid-auto-rows:auto}.rmw-sum{padding:16px}.rmw-sum-kpis b{font-size:20px}}
`;document.head.appendChild(s);}
  function hoursStyle(){if($('#rmw-hours-css'))return;const s=document.createElement('style');s.id='rmw-hours-css';s.textContent=`
/* Analyse du menu : hors de .catalog-rail, la pastille active gardait le texte clair du dégradé sur la lentille claire. Même lecture que la rangée du menu. */
.rmw-analysis-panel .mi-pill-row[data-kw-lens] .mi-pill.on{color:var(--ink)!important;background:transparent!important;box-shadow:none!important}
.rmw-hours-page{display:grid;grid-template-columns:minmax(0,1fr);gap:18px}.rmw-hours-page>*{min-width:0}.rmw-hours-pills{margin-top:16px}.rmw-hours-kpis{display:grid;grid-template-columns:repeat(3,1fr);gap:10px;margin-top:14px}.rmw-hours-kpis>div{display:grid;gap:7px;padding:17px 18px;background:var(--surface);border:1px solid var(--n-200);border-radius:13px}.rmw-hours-kpis span{font:10px var(--mono);letter-spacing:.07em;text-transform:uppercase;color:var(--n-500)}.rmw-hours-kpis b{font-size:24px;line-height:1.1;letter-spacing:-.03em}.rmw-hours-kpis>div:last-child b{font-size:18px}.rmw-hours-kpis small{color:var(--n-500)}.rmw-hours-list-title{margin:22px 0 12px;color:var(--n-500);font-size:11px}.rmw-hours-bars{display:grid;gap:9px}.rmw-hours-row{display:grid;grid-template-columns:minmax(120px,190px) minmax(180px,1fr) 55px;align-items:center;gap:14px}.rmw-hours-name{overflow:hidden;text-overflow:ellipsis;white-space:nowrap;font-size:12px}.rmw-hours-track{height:12px;border-radius:4px;background:var(--n-100);overflow:hidden}.rmw-hours-track i{display:block;height:100%;min-width:3px;border-radius:4px;background:var(--atlas)}.rmw-hours-row>b{text-align:right;font:600 11px var(--mono)}.rmw-hours-insight{padding:22px 24px;border-radius:16px;background:#08100c;color:#fff;box-shadow:0 16px 38px rgba(4,9,6,.10)}.rmw-hours-insight>span{color:#73f0b2;font:600 9px var(--mono);letter-spacing:.12em}.rmw-hours-insight h3{margin:10px 0 7px;font-size:20px}.rmw-hours-insight p{max-width:780px;margin:0;color:rgba(255,255,255,.62);font-size:12px;line-height:1.6}.rmw-hours-notables{display:grid;gap:8px}.rmw-hours-notable{display:flex;gap:11px;align-items:flex-start;padding:12px 0;border-bottom:1px solid var(--n-200)}.rmw-hours-notable:last-child{border-bottom:0}.rmw-hours-notable>i{width:8px;height:8px;margin-top:5px;border-radius:50%;background:var(--atlas);flex:0 0 auto}.rmw-hours-notable b,.rmw-hours-notable span{display:block}.rmw-hours-notable b{font-size:12.5px}.rmw-hours-notable span{margin-top:4px;color:var(--n-500);font-size:11.5px}@media(max-width:800px){.rmw-hours-kpis{grid-template-columns:1fr}.rmw-hours-row{grid-template-columns:110px minmax(120px,1fr) 42px}.rmw-hours-insight{padding:19px}}
`;document.head.appendChild(s);}
  function catalogSheet(title, actions){
    const m=modal({title,width:480,body:`<div class="catalog-sheet">${actions.map(a=>`<button type="button" class="${a.danger?'danger':''}" data-catalog-action="${esc(a.id)}">${catalogIcon(a.icon||'menu')}<span${a.key?` data-i18n="catalog.${esc(a.key)}"`:''}>${esc(a.label)}</span></button>`).join('')}</div>`});
    m.el.querySelectorAll('[data-catalog-action]').forEach(button=>button.onclick=()=>{const action=actions.find(a=>a.id===button.dataset.catalogAction);m.close();action?.run();});
  }
  function openSectionActions(){
    const selected=filter==='all'?null:cat(filter);
    const actions=[{id:'new',icon:'category',label:ui('newSection').replace(/^\+\s*/,''),run:()=>openCategory(null)},
      {id:'reorder',key:'reorder',icon:'swap_horiz',label:catalogText('reorder','Réordonner les sections'),run:openSectionReorder},
      {id:'reorder-dishes',icon:'swap_vert',label:ui('reorderDishes'),run:()=>openSectionReorder(selected?String(selected.id):'')}];
    if(selected)actions.push({id:'rename',icon:'tune',label:ui('renameSection'),run:()=>openCategory(selected)},
      {id:'delete',icon:'delete',label:ui('deleteSection'),danger:true,run:()=>window.Kiwi.handlers['rmw-cat-delete'](null,selected.id)});
    catalogSheet(catalogText('sectionActions','Actions des sections'),actions);
  }
  /* With a section id (even ''), the same window reorders that section's
     dishes instead (Pasta Corner, 30 Oct 2026): d.items order is menu order. */
  function openSectionReorder(cid,focusId){
    if(typeof cid==='string'){
    cid=cid||(D().cats[0]||{}).id||'';
    const m=modal({title:ui('reorderDishes'),width:560,body:`<label class="rmw-dish-pick" style="display:flex;align-items:center;gap:10px;font-weight:600">${esc(ui('reorderPick'))}<select data-kiwi-native-select style="flex:1;min-height:44px;padding:0 12px;border:1px solid var(--n-200);border-radius:12px;background:var(--paper);color:var(--ink);font:inherit;font-weight:500">${D().cats.map(c=>`<option value="${esc(c.id)}"${c.id===cid?' selected':''}>${esc(t(c.name))}</option>`).join('')}</select></label><p class="rmw-dish-hint" style="margin:12px 0 14px;color:var(--n-500);font-size:13px;line-height:1.45">${esc(ui('reorderHint'))}</p><div class="catalog-reorder"></div>`,foot:`<button class="kb primary" data-catalog-done>${esc(ui('doneBtn'))}</button>`});
    const list=m.el.querySelector('.catalog-reorder'),pick=m.el.querySelector('.rmw-dish-pick select');
    const ids=()=>D().items.filter(x=>x.catId===cid).map(x=>String(x.id));
    const move=(id,position)=>{const order=ids().filter(x=>x!==id);order.splice(position,0,id);S().orderItems(order);draw();};
    const draw=()=>{
      const top=list.scrollTop,dishes=D().items.filter(x=>x.catId===cid);
      list.innerHTML=dishes.map((x,i)=>`<div class="catalog-reorder-row${String(x.id)===String(focusId)?' catalog-drop':''}" data-reorder-id="${esc(x.id)}"><button class="catalog-more catalog-drag" type="button" aria-label="${esc(ui('moveDish'))}: ${esc(t(x.name))}">${catalogIcon('menu')}</button><strong>${esc(t(x.name))}</strong><select data-kiwi-native-select aria-label="${esc(catalogText('position','Position'))}: ${esc(t(x.name))}">${dishes.map((_,j)=>`<option value="${j}"${i===j?' selected':''}>${j+1}</option>`).join('')}</select></div>`).join('');
      list.scrollTop=top;focusId='';
      list.querySelectorAll('[data-reorder-id]').forEach(row=>{
        row.querySelector('select').onchange=e=>move(row.dataset.reorderId,+e.target.value);
        const handle=row.querySelector('button');let destination=null;
        handle.onpointerdown=e=>{if(e.button!==0)return;e.preventDefault();destination=null;handle.setPointerCapture(e.pointerId);};
        handle.onpointermove=e=>{if(!handle.hasPointerCapture(e.pointerId))return;e.preventDefault();
          const rows=[...list.children];const mid=r=>r.getBoundingClientRect().top+r.offsetHeight/2;const nearest=rows.reduce((best,r)=>Math.abs(e.clientY-mid(r))<Math.abs(e.clientY-mid(best))?r:best,rows[0]);
          rows.forEach(r=>r.classList.toggle('catalog-drop',r===nearest));destination=rows.indexOf(nearest);
          const bounds=list.getBoundingClientRect();if(e.clientY>bounds.bottom-35)list.scrollTop+=10;else if(e.clientY<bounds.top+35)list.scrollTop-=10;
        };
        handle.onpointerup=e=>{if(handle.hasPointerCapture(e.pointerId))handle.releasePointerCapture(e.pointerId);if(destination!==null)move(row.dataset.reorderId,destination);};
        handle.onpointercancel=()=>{destination=null;list.querySelectorAll('.catalog-drop').forEach(r=>r.classList.remove('catalog-drop'));};
      });
    };
    pick.onchange=()=>{cid=pick.value;list.scrollTop=0;draw();};
    draw();m.el.querySelector('[data-catalog-done]').onclick=m.close;
      return;
    }
    const m=modal({title:catalogText('reorder','Réordonner les sections'),width:560,body:'<div class="catalog-reorder"></div>',foot:`<button class="kb primary" data-catalog-done>${esc(ui('doneBtn'))}</button>`});
    const list=m.el.querySelector('.catalog-reorder');
    const move=(id,position)=>{const at=D().cats.findIndex(c=>c.id===id),delta=position-at;for(let i=0;i<Math.abs(delta);i++)S().moveCategory(id,Math.sign(delta));draw();};
    const draw=()=>{
      const top=list.scrollTop;
      list.innerHTML=D().cats.map((c,i)=>`<div class="catalog-reorder-row" data-reorder-id="${esc(c.id)}"><button class="catalog-more catalog-drag" type="button" aria-label="${esc(catalogText('moveSection','Déplacer la section'))}: ${esc(t(c.name))}">${catalogIcon('menu')}</button><strong>${esc(t(c.name))}</strong><select data-kiwi-native-select aria-label="${esc(catalogText('position','Position'))}: ${esc(t(c.name))}">${D().cats.map((_,j)=>`<option value="${j}"${i===j?' selected':''}>${j+1}</option>`).join('')}</select></div>`).join('');
      list.scrollTop=top;
      list.querySelectorAll('[data-reorder-id]').forEach(row=>{
        row.querySelector('select').onchange=e=>move(row.dataset.reorderId,+e.target.value);
        const handle=row.querySelector('button');let destination=null;
        handle.onpointerdown=e=>{if(e.button!==0)return;e.preventDefault();destination=null;handle.setPointerCapture(e.pointerId);};
        handle.onpointermove=e=>{if(!handle.hasPointerCapture(e.pointerId))return;e.preventDefault();
          const rows=[...list.children];const nearest=rows.reduce((best,r)=>Math.abs(e.clientY-(r.getBoundingClientRect().top+r.offsetHeight/2))<Math.abs(e.clientY-(best.getBoundingClientRect().top+best.offsetHeight/2))?r:best,rows[0]);
          rows.forEach(r=>r.classList.toggle('catalog-drop',r===nearest));destination=rows.indexOf(nearest);
          const bounds=list.getBoundingClientRect();if(e.clientY>bounds.bottom-35)list.scrollTop+=10;else if(e.clientY<bounds.top+35)list.scrollTop-=10;
        };
        handle.onpointerup=e=>{if(handle.hasPointerCapture(e.pointerId))handle.releasePointerCapture(e.pointerId);if(destination!==null)move(row.dataset.reorderId,destination);};
        handle.onpointercancel=()=>{destination=null;list.querySelectorAll('.catalog-drop').forEach(r=>r.classList.remove('catalog-drop'));};
      });
    };
    draw();m.el.querySelector('[data-catalog-done]').onclick=m.close;
  }
  function openCardActions(x){
    catalogSheet(t(x.name),[
      {id:'edit',icon:'tune',label:ui('viewAndEdit'),run:()=>openItem(item(x.id))},
      {id:'move',icon:'swap_vert',label:ui('moveDish'),run:()=>openSectionReorder(String(x.catId||''),x.id)},
      ...(!x.archived?[{id:'availability',icon:'visibility',label:x.avail===false?ui('reactivate'):ui('unavailableBadge'),run:()=>S().updateItem(x.id,{avail:x.avail===false})}]:[]),
      {id:'archive',icon:'inventory_2',label:x.archived?ui('restore'):ui('archive'),run:()=>S().updateItem(x.id,{archived:!x.archived})},
      ...(x.formula?[{id:'reuse',icon:'folder_copy',label:ui('reuse'),run:()=>window.Kiwi.handlers['rmw-formula-duplicate'](null,x.id)}]:[]),
      {id:'delete',icon:'delete',label:ui('delete'),danger:true,run:()=>confirm(ui('deleteItemConfirm',{name:x.name}),()=>S().deleteItem(x.id))}
    ]);
  }
  function directCardAction(e){
    const control=e.target.closest?.('[data-rmw-command]');if(!control)return;
    const x=item(control.dataset.arg);if(!x)return;
    e.preventDefault();e.stopPropagation();
    if(control.dataset.rmwCommand==='edit')openItem(x);
    if(control.dataset.rmwCommand==='actions')openCardActions(x);
    if(control.dataset.rmwCommand==='avail'&&!x.archived)S().updateItem(x.id,{avail:x.avail===false});
  }
  let booted=false,storeBound=false,uiBound=false;
  function boot(){
    if(!window.Kiwi?.handlers){setTimeout(boot,50);return;}
    if(!booted){booted=true;style();nutritionStyle();performanceStyle();hoursStyle();bind();}
    /* Wire navigation before waiting for MenuStore. This closes the startup
     * window in which venues.js could still send the first click to its old UI. */
    wire();
    /* Existing composed menus are the saved templates: reuse makes an
     * independent copy with the same stages, choices, extras and options, then
     * opens that copy immediately so only its name/price need adapting. */
    window.Kiwi.handlers['rmw-formula-duplicate']=(_e,id)=>{const before=new Set(D().items.map(it=>it.id));S().duplicateItem(id);const copy=D().items.find(it=>!before.has(it.id));if(copy)openItem(copy);};
    /* Coût simple → brouillon : l'éditeur de recette s'ouvre pré-rempli ; rien
       n'est écrit avant son bouton Enregistrer. */
    const recipeFromSheet=(id,seed,from)=>{const x=item(id);if(!x||!seed||!window.KiwiRestaurantRecipes)return false;openRecipe(x,seed,from||{});return true;};
    window.KiwiRestaurantMenuWorkspace={show,render,isRestaurant,recipeFromSheet,analysis:{
      performance(){style();performanceStyle();hoursStyle();return `<div class="rmw-analysis-panel">${performancePanel()}</div>`;},
      hours(){style();performanceStyle();hoursStyle();return `<div class="rmw-analysis-panel">${hoursPanel()}</div>`;},
      sales(){style();performanceStyle();hoursStyle();salesStyle();return `<div class="rmw-analysis-panel">${salesPanel()}</div>`;},
      /* Le registre et le coût par plat que lit la Performance : la vue
         d'ensemble d'« Analyse du menu » les lit aussi, pour ne jamais
         afficher une autre marge que celle de l'onglet d'à côté. */
      ledger(w){return menuLedger(w);},
      /* Les quadrants et leurs deux seuils, tels que la matrice les trace. */
      /* Souvent pris ensemble, tel que la section l'affiche. */
      pairs(days=30){const q=pairsData(days);return {tickets:q.tickets,enough:q.enough,min:q.min,pairs:q.pairs.map(x=>({from:x.from.id,to:x.to.id,together:x.together,share:x.share,lift:x.lift}))};},
      quadrants(days=30){const p=performanceData(days);return {popularFrom:p.medQty,averageContribution:p.medProfit,items:p.measured.map(x=>({id:x.item?.id??x.id??null,name:x.item?.name??x.name??'',qty:x.qty,unitProfit:x.unitProfit,quadrant:x.quadrant}))};},
      insights(){const p=performanceData(30),est=costEstimates();return perfInsights(p,est).map(x=>({key:x.key,text:x.text,item:x.item?x.item.id:null}));},
      costOf(item){const hit=recipeCostResolver([{item}]).of({item});if(hit)return hit;try{return window.KiwiCost?.of?.({kind:'menu',id:item.id,name:item.name})||null;}catch(_){return null;}}
    }};
    if(!S()){setTimeout(boot,50);return;}
    if(!storeBound){storeBound=true;const refresh=()=>{if(document.body.classList.contains('page-menu')&&isRestaurant())render();};S().subscribe(refresh);S().subscribe(scheduleAutoTranslate);window.KiwiSales?.subscribe?.(refresh);window.KiwiRestaurantRecipes?.subscribe?.(refresh);window.KiwiHours?.subscribe?.(refresh);window.KiwiVenue?.subscribe?.(()=>{hoursPeriod=null;if(document.body.classList.contains('page-menu')&&isRestaurant())show();});try{window.addEventListener('kiwi:langchange',()=>{if(document.body.classList.contains('page-menu')&&isRestaurant())render();});}catch(_){}}
    if(document.body.classList.contains('page-menu')&&isRestaurant())show();
  }
  /* The legacy menu initializes at DOMContentLoaded. Waiting for window.load
   * left it visible until every low-priority asset had finished, which is why
   * a restaurant briefly saw the old screen (and sometimes had to revisit the
   * route). Run immediately after the legacy DOMContentLoaded listener, before
   * the first paint, then re-assert the handler at load because venues.js also
   * performs a final compatibility rewire there. */
  bind();
  document.addEventListener('click',directCardAction,true);
  document.addEventListener('keydown',e=>{if((e.key==='Enter'||e.key===' ')&&e.target.matches?.('[data-rmw-card-edit]'))directCardAction(e);},true);
  if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',boot,{once:true});else boot();
  window.addEventListener('load',boot,{once:true});
})();
