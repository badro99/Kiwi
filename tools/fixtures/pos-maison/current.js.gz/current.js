
  'use strict';

  /* ── real-store detection ── a REAL merchant has paired their boutique (or the
     shared KiwiEnv marks the session real). Demo people (staff roster + seeded
     clientes/ventes/avoirs) are neutralized whenever pvReal() is true so a real
     store never inherits the Maison Mansour cast. Local demo ⇒ pvReal() false. */
  function pvPaired() { try { return window.KiwiPlatform?.pairedVenue?.() || JSON.parse(localStorage.getItem('kiwiPairedVenue') || 'null'); } catch (_) { return null; } }

  /* Prix et coûts saisis par le commerçant. C'était `parseInt(v, 10)`, qui coupe
   * tout ce qui suit la virgule : une chemise à 129,90 était enregistrée à 129 —
   * 0,90 MAD offert à chaque vente, et une marge fausse pour toujours. Le champ
   * est un `type=number` sans `step`, donc il ACCEPTE les décimales : seule la
   * lecture les jetait. On accepte aussi la virgule, que tape un clavier
   * français, et on arrête aux centimes — l'unité réelle du dirham. */
  function bqMoney(v) {
    const n = parseFloat(String(v == null ? '' : v).replace(',', '.'));
    return Number.isFinite(n) && n > 0 ? Math.round(n * 100) / 100 : 0;
  }
  function pvReal()   { try { return !!(window.KiwiEnv && window.KiwiEnv.isReal && window.KiwiEnv.isReal()) || !!pvPaired(); } catch (_) { return !!pvPaired(); } }
  // Product sheet and promotion composer are siblings of mount(), not children.
  // Keep the selected catalogue/policy identity in their shared closure.
  let _bqKey = null;

  /* ── DEUX MAGASINS NE PARTAGENT PAS UN CATALOGUE ───────────────────────────
   * Une session réelle SANS appairage n'a ni venueId ni slug marchand. L'ancien
   * repli était le littéral 'boutique-live' — exactement celui de pos-boutique.js.
   * Deux verticales, et potentiellement deux commerces, écrivaient donc leur
   * stock et leurs prix dans la MÊME clé localStorage : le prêt-à-porter voyait
   * la vaisselle, et une correction de stock d'un côté effaçait celle de
   * l'autre. On se rabat maintenant sur l'identité du compte, et à défaut sur
   * une clé propre à cette verticale — jamais sur un nom partagé. */
  function realFallbackKey() {
    let who = '';
    try { who = String(localStorage.getItem('kiwiAccountKey') || '').trim().toLowerCase(); } catch (_) { who = ''; }
    if (!who) { try { who = String((window.KiwiVenues && window.KiwiVenues.currentSlug && window.KiwiVenues.currentSlug()) || '').trim().toLowerCase(); } catch (_) {} }
    const tag = who.replace(/[^a-z0-9]+/g, '-').replace(/^-+|-+$/g, '').slice(0, 48);
    return tag ? 'maison-' + tag : 'maison-live';
  }

  /* Reprise du catalogue laissé sous l'ancienne clé partagée. Une seule fois, et
     seulement si la nouvelle clé est encore vierge : on ne recouvre jamais un
     catalogue existant, et l'ancienne copie est laissée en place — si la caisse
     revenait à une version antérieure, elle la retrouverait intacte. */
  function adoptLegacySharedCatalogue(key) {
    if (!key || key === 'boutique-live' || !/^maison-/.test(key)) return;
    try {
      const target = 'kiwiBoutiqueCatalog:v1:' + key;
      if (localStorage.getItem(target)) return;
      const legacy = localStorage.getItem('kiwiBoutiqueCatalog:v1:boutique-live');
      if (!legacy) return;
      localStorage.setItem(target, legacy);
    } catch (_) {}
  }

  function toast(msg, ms, kind, desc) {
    if (typeof window.KiwiCaisseToast === 'function') { window.KiwiCaisseToast(msg, ms, kind, desc); return; }
    const stack = $('#toast-stack');
    if (!stack) return;
    const lower = String(msg || '').toLowerCase();
    kind = kind || (/refus|erreur|illisible|impossible|requis/.test(lower) ? 'danger' : /d'abord|attention|déjà|scannez/.test(lower) ? 'warn' : 'success');
    const el = document.createElement('div');
    el.className = `toast is-${kind}`;
    el.setAttribute('role', kind === 'danger' ? 'alert' : 'status');
    const copy = document.createElement('span'); copy.className = 'toast-copy';
    const title = document.createElement('span'); title.className = 'toast-title'; title.textContent = msg;
    copy.appendChild(title);
    if (desc) { const detail = document.createElement('span'); detail.className = 'toast-desc'; detail.textContent = desc; copy.appendChild(detail); }
    el.appendChild(copy);
    stack.appendChild(el);
    setTimeout(() => el.classList.add('fade'), ms || 2200);
    setTimeout(() => el.remove(), (ms || 2200) + 280);
  }

  /* ───────────────────────── catalogue (base partagée) ─────────────────────────
     Le catalogue est désormais la BASE PARTAGÉE (window.KiwiBoutiqueCatalog) —
     la même que le dashboard lit/écrit. compat() reconstruit la forme
     { RAYONS, P, BY_EAN } que ce module rend déjà : la grille de vente, la fiche
     variante et la douchette parlent tous l’inventaire en direct. La baisse de
     stock à la vente reste en mémoire (démo) ; la saisie de stock et la création
     de produits se font dans la vue Inventaire et persistent dans la base. */
  let RAYONS = [], P = {}, BY_EAN = {};
  function rebuildCatalog() {
    if (!window.KiwiBoutiqueCatalog) { RAYONS = []; P = {}; BY_EAN = {}; return; }
    const c = window.KiwiBoutiqueCatalog.compat();
    RAYONS = c.RAYONS; P = c.P; BY_EAN = c.BY_EAN;
  }
  rebuildCatalog();

  const sizesOf   = (p) => Object.keys(p.sizes);
  const stockOf   = (p) => sizesOf(p).reduce((s, k) => s + p.sizes[k], 0);
  const stockAdd  = (pid, size, d) => { P[pid].sizes[size] = Math.max(0, (P[pid].sizes[size] || 0) + d); };
  /* Persist a COMMITTED stock movement (real vente / retour / échange) to the SHARED
     catalogue — the same base the owner's dashboard reads. stockAdd() above only moves
     the in-memory projection (live display + oversell guard for the open ticket); that
     projection is rebuilt from the base on the next catalogue sync, so a real store's
     stock never actually moved on a sale. This writes the net change through so stock
     counts, low-stock / rupture alerts and stock valuation stay truthful across reloads
     and on the dashboard. The local pitch demo (pvReal() false) keeps the legacy
     in-memory-only behaviour, so Maison Mansour still resets to full stock each load.
     Resolves the exact variant (produit × couleur × taille); guarded so a miss can never
     break the sale. adjustStock() commit fires the subscribe → rebuildCatalog, which
     re-sets P from the base, so this never double-counts the in-memory hold. */
  /* La vente choisit une FAMILLE ("Bleu"), l'inventaire garde des variantes
     distinctes ("navy" et "blue" restent deux articles, deux stocks, deux codes
     — on ne fusionne jamais dans le dos du commerçant). Il faut donc décider
     laquelle bouge, dans cet ordre : l'identifiant exact s'il correspond, sinon
     la même famille EN AYANT du stock (une sortie ne doit pas creuser une
     variante déjà vide pendant qu'une autre est pleine), sinon la même famille,
     sinon la taille seule. Un retour (delta > 0) revient de préférence sur une
     variante existante de la même famille. */
  /* Le journal des mouvements (assets/maison-stock-movements.js) ne s'allume
     que s'il reconnaît le métier « maison » — par la fiche du magasin ou le
     métier d'onboarding, deux choses qu'une caisse appairée n'a pas en local.
     Sur la tablette du comptoir il restait donc éteint : chaque vente bougeait
     le stock sans écrire sa ligne, et la page « Mouvements de stock » du
     tableau de bord n'affichait aucune sortie. Ce module n'est chargé QUE pour
     une caisse maison : l'allumer ici est exact par construction. */
  function ensureStockJournal() {
    try { if (pvReal() && window.KiwiMaisonStock) window.KiwiMaisonStock.enable(); } catch (_) {}
  }
  function persistStock(pid, size, color, delta, ctx) {
    if (!delta || !pvReal()) return;
    ensureStockJournal();
    ctx = ctx || {};
    try {
      const cat = window.KiwiBoutiqueCatalog;
      if (!cat || !cat.listVariants || !cat.adjustStock) return;
      const sameSize = (cat.listVariants(pid) || []).filter((x) => String(x.size) === String(size));
      const fam = (x) => (cat.colorFamily ? cat.colorFamily(x) : x.colorId);
      const covers = (x) => (x.stock || 0) >= -delta;
      // Sur une SORTIE, « en avoir » passe avant « porter le même identifiant » :
      // sinon une vente de bleu se déduirait d'une variante bleue déjà vide
      // pendant que la variante marine, elle, est pleine — le magasin perdrait la
      // sortie de son stock. Sur un RETOUR, l'identifiant exact suffit.
      const matched = (delta < 0 && sameSize.find((x) => x.colorId === color && covers(x)))
             || (delta < 0 && sameSize.find((x) => fam(x) === color && covers(x)))
             || sameSize.find((x) => x.colorId === color)
             || sameSize.find((x) => fam(x) === color);
      /* Dernier recours : la couleur vendue n'existe pas du tout dans cette
         taille. Ne rien bouger fausserait le total du magasin — la pièce est
         bien sortie. Mais imputer en silence sur `sameSize[0]` écrivait « vente
         de marine » sur un article que personne n'a pris, et creusait au hasard
         une variante peut-être déjà vide pendant qu'une autre était pleine. On
         retient donc d'abord une variante qui a réellement du stock, et on DIT
         dans le motif que la couleur n'a pas été appariée : l'approximation
         reste lisible dans le journal au lieu d'être maquillée en certitude. */
      const v = matched || sameSize.find((x) => covers(x)) || sameSize[0];
      /* Le MOTIF suit le mouvement. Le stock est désormais un journal
         (assets/boutique-catalog.js) : « vente » et « retour » distinguent une
         sortie au comptoir d'une reprise, ce qui rend le journal lisible le jour
         où quelqu'un demande où sont passées douze pièces. */
      /* La RÉFÉRENCE du ticket suit le mouvement jusqu'au registre : c'est elle
         qui permet, six mois plus tard, de relier une sortie de stock à la vente
         qui l'a causée — et à l'employé qui l'a encaissée. */
      if (v) cat.adjustStock(v.id, delta, (ctx.why || (delta < 0 ? 'vente' : 'retour')) + (matched ? '' : ' · couleur non appariée'), {
        ref: ctx.ref || '', actor: ctx.actor || ((window.KiwiStaff && window.KiwiStaff.name) || ''),
      });
    } catch (_) {}
  }
  /* ══════════ UNE VENTE SORTIE DES LIVRES REND SON STOCK ═══════════════════
   * La console opérateur peut retirer une vente d'essai des livres (« god mode » ,
   * functions/api/admin/sales.js) : `void_ts` est daté, /api/feed cesse de servir
   * la ligne, et le tableau de bord recalcule tout à partir de là — recette,
   * panier, classement produits. Impeccable côté argent.
   *
   * Côté MARCHANDISE, rien ne bougeait. La vente d'essai avait décrémenté le
   * stock partagé au moment de l'encaissement (persistStock ci-dessus), et ce
   * mouvement-là restait : le tableau de bord affichait la bonne recette et un
   * stock faux, et l'article manquait à l'inventaire d'une vente qui, selon
   * Kiwi lui-même, n'avait jamais eu lieu. Sur une installation où l'on passe
   * cinq ou six ventes d'essai, c'est tout le comptage d'ouverture qui est
   * décalé.
   *
   * Ce n'est pas le serveur qui peut le réparer. La ligne qu'il détient ne porte
   * que { nom, quantité, total, rayon } — pas l'identifiant du produit, pas la
   * couleur, pas la taille (voir le panier construit dans onPaid). La caisse qui
   * a encaissé, elle, tient tout cela dans son propre journal. C'est donc elle
   * qui rend le stock, et elle seule : une AUTRE caisse du même magasin ne
   * trouvera pas la vente dans son journal et ne fera rien — ce qui est
   * exactement le comportement voulu, sans avoir à se coordonner.
   *
   * Trois règles :
   *  · EXACTEMENT UNE FOIS. La marque `voided` portée par la vente EST le
   *    registre : on ne rend le stock qu'en la posant. Le serveur renvoyant la
   *    liste complète des retraits à chaque passage, tout compteur séparé aurait
   *    fini par gonfler le stock à chaque sondage.
   *  · DANS LES DEUX SENS. « Remettre » fait disparaître la vente de la liste :
   *    la marque tombe et le stock ressort. Une vente d'essai remise en jeu par
   *    erreur ne laisse donc pas de marchandise fantôme.
   *  · LES LIGNES DÉJÀ RENDUES NE LE SONT PAS DEUX FOIS. Un article retourné au
   *    comptoir (restoreLines) a déjà regagné le stock ; le retrait des livres
   *    ne doit pas l'y remettre une seconde fois.
   *
   * Une vente plus ancienne que le journal (RETAIN_DAYS) n'est plus là : on ne
   * fait rien et on ne prétend rien. Rendre à l'aveugle le stock d'une vente de
   * trois semaines, alors que l'inventaire a été recompté depuis, ferait plus de
   * dégâts que le décalage qu'on prétend corriger. */
  function reconcileVoids(refs, authoritative) {
    if (IS_DEMO || !pvReal()) return 0;
    const KP = window.KiwiPosSale;
    const hit = (KP && KP.refMatcher) ? KP.refMatcher(refs) : null;
    let touched = 0;
    const move = (sale, sign) => {
      /* Une copie importée du serveur peut venir d'une AUTRE caisse. Seule la
         caisse qui a réellement décrémenté le stock répare un void God mode ;
         celle-ci marque la vente sortie mais ne rend pas la marchandise deux fois. */
      if (sale.remote) return;
      (sale.lines || []).forEach((ln) => {
        if (!ln) return;
        const remaining = lineAvailableQty(ln);
        if (!remaining) return;                  // déjà rendue au comptoir
        persistStock(ln.pid, ln.size, ln.color, sign * remaining, { ref: sale.num || sale.id, why: sign > 0 ? 'remb' : 'vente' });
      });
    };
    SALES.forEach((sale) => {
      if (!sale || !sale.id) return;
      const out = !!(hit && hit(sale.id));
      if (out === !!sale.voided || (!out && !authoritative)) return;   // remise : seulement sur la liste complète live-link (vide au montage, partielle au comptoir · A4)
      if (out) { move(sale, +1); sale.voided = true; }   // sortie : la marchandise revient
      else { move(sale, -1); sale.voided = false; }      // remise : elle repart
      touched++;
    });
    if (touched && root) {
      persistDay();
      rebuildCatalog();      /* le stock a bougé : la grille de vente le montre */
      pruneTicket();
      refreshOps();
      /* La ligne d'argent, explicitement : renderView() ne la touche pas, et
         c'est LE chiffre que l'opérateur vient de promettre au commerçant de
         faire disparaître. Le stock corrigé sous un total inchangé aurait juste
         déplacé le mensonge. */
      const today = $('#mz-today', root);
      if (today) today.textContent = headSubVente();
    } else if (touched) {
      persistDay();
    }
    return touched;
  }

  const sizeWord  = (p) => p.kind === 'pointure' ? 'Pointure' : p.kind === 'tu' ? 'Pièce unique' : 'Format';
  const firstFree = (p) => sizesOf(p).find((k) => p.sizes[k] > 0) || null;

  /* ───────────────────────── équipe & clientes (Tanger · Centre) ───────────── */
  /* A REAL boutique never inherits Vogue Home's staff — the roster is
     neutralized (« Vendeur N », blank role) while keeping the same shape/length.
     Local demo (pvReal() false) keeps the named cast, byte-identical. */
  const STAFF = pvReal() ? {
    gerante:   { name: 'Vendeur 1', role: '' },
    conseil:   { name: 'Vendeur 2', role: '' },
    caissiere: { name: 'Vendeur 3', role: '' },
  } : {
    gerante:   { name: 'Soraya Lahlou', role: 'Gérante Vogue Home' },
    conseil:   { name: 'Kenza Tazi',     role: 'Conseillère d’art de table' },
    caissiere: { name: 'Yasmine',        role: 'Caisse' },
  };

  /* The person who entered their code owns this session: their name goes on the
     ticket header and on every sale's `by`, so the day's takings are attributable
     to whoever actually rang them. Mutates the existing object rather than
     replacing it, because the render paths read STAFF.caissiere directly — and it
     re-runs on every unlock, so a handover follows the person, not the module's
     first load. Real stores only; the local demo keeps its named cast. */
  function syncTillStaff() {
    if (!pvReal()) return;
    const me = window.KiwiStaff;
    if (!me || !me.name) return;
    STAFF.caissiere.name = me.name;
    STAFF.caissiere.role = me.role || '';
  }

  /* A REAL boutique starts with an empty client book (its own clientes are read
     from KiwiClients / captured at the till). Only the local demo seeds this cast. */
  const CLIENTES = pvReal() ? [] : [
    { id: 'c1', name: 'Lalla Kenza Alami', phone: '0661 42 18 30', points: 1420, taille: 'TU', achats: 8, spent: 16800, vip: true,
      prefs: ['Service Fès Bleu', 'Emballage cadeau systématique'],
      history: [{ when: '24 mai', what: 'Service 18 pcs Fès Bleu', amt: 1450 }, { when: '12 avr.', what: 'Bougie Max 24 Totem', amt: 1850 }] },
    { id: 'c2', name: 'Mme Ghita Benjelloun', phone: '0664 77 02 19', points: 650, taille: 'TU', achats: 5, spent: 5400,
      prefs: ['Liste de mariage en cours', 'Verres Beldi émeraude'],
      history: [{ when: '10 juin', what: 'Verres soufflés Beldi (Lot 6)', amt: 140 }, { when: '18 mai', what: 'Carafe Beldi 1.5L', amt: 120 }] },
    { id: 'c3', name: 'Lalla Meryem Berrada', phone: '0667 31 55 08', points: 2300, taille: 'TU', achats: 12, spent: 28900, vip: true,
      prefs: ['Céramique Majorelle', 'Livraison fragile Marshan'],
      history: [{ when: '28 mai', what: 'Vase céramique émaillée', amt: 650 }, { when: '6 mai', what: 'Service Zellige Vert', amt: 1100 }] },
    { id: 'c4', name: 'Dr. Nabil El Omari', phone: '0650 09 64 12', points: 310, taille: 'TU', achats: 3, spent: 2600,
      prefs: ['Diffuseurs senteurs Tanger'],
      history: [{ when: '30 mai', what: 'Diffuseur Fleur d’Oranger Tanger', amt: 480 }] },
    { id: 'c5', name: 'Mme Sofia Tazi', phone: '0668 23 90 41', points: 450, taille: 'TU', achats: 2, spent: 1800,
      prefs: ['Cadeaux d’affaires & emballages prestige'],
      history: [{ when: '3 juin', what: 'Plateau laiton martelé', amt: 420 }] },
  ];
  const CL = Object.fromEntries(CLIENTES.map((c) => [c.id, c]));
  const initials = (name) => name.split(/\s+/).map((w) => w[0]).filter(Boolean).slice(0, 2).join('').toUpperCase();
  const firstName = (name) => name.replace(/^Lalla\s+|^Mme\s+/i, '').split(/\s+/)[0];
  const IS_DEMO = isDemoStore();  // frozen for this session — gates the seeded demo sales/avoirs/ticket

  /* ───────────────────────── ventes du jour (seed, mi-journée) ──────────── */
  const NOW = Date.now();
  const mkLine = (pid, size, color, qty, remise) => {
    const p = P[pid];
    const rem = remise || 0;
    return { pid, size, color, qty, remise: rem, unit: shelf(p.price * (100 - rem) / 100), returned: false, note: '' };
  };
  const SALES = IS_DEMO ? [
    { id: '1207', at: new Date(NOW - 24 * MIN),  clientId: 'c4', by: 'Rania', kind: 'vente', methods: 'espèces',
      lines: [mkLine('caftan_ete', 'S', 'ivoire', 1), mkLine('broche_perles', 'TU', 'argent', 1)] },
    { id: '1206', at: new Date(NOW - 57 * MIN),  clientId: 'c3', by: 'Aicha', kind: 'vente', methods: 'carte',
      lines: [mkLine('takchita_sultane', 'M', 'dore', 1, 10)] },
    { id: '1205', at: new Date(NOW - 96 * MIN),  clientId: null, by: 'Aicha', kind: 'vente', methods: 'espèces',
      lines: [mkLine('cabas_berbere', 'TU', 'terracotta', 1)] },
    { id: '1204', at: new Date(NOW - 135 * MIN), clientId: 'c2', by: 'Salma', kind: 'vente', methods: 'carte',
      lines: [mkLine('babouche_brodee', '38', 'rose', 1), mkLine('foulard_soie', 'TU', 'safran', 1)] },
    { id: '1203', at: new Date(NOW - 170 * MIN), clientId: null, by: 'Rania', kind: 'vente', methods: 'espèces',
      lines: [mkLine('babouche_homme', '42', 'camel', 1)] },
  ] : [];
  SALES.forEach((s) => { s.total = s.lines.reduce((t, l) => t + l.unit * l.qty, 0); });
  /* Jamais une vente sortie des livres : elle a disparu des écrans, mais un
     identifiant retenu dans state.ret / state.exchange peut encore la désigner
     une seconde après le retrait. */
  const findSale = (id) => SALES.find((s) => s.id === id && !s.voided);
  /* Résout la cliente d'une vente. IMPÉRATIF : passer par clById, pas par CL[…].
     Sur une VRAIE boutique, CLIENTES/CL sont vides (le carnet vit dans KiwiClients),
     donc CL[s.clientId] renvoyait toujours undefined et TOUTE vente s'affichait
     « Cliente de passage » à l'écran Échanges & avoirs — alors que checkout() avait
     bien horodaté le bon clientId. clById route vers KiwiClients quand c'est réel et
     garde le comportement démo intact. */
  const saleClient = (s) => (s && s.clientId ? clById(s.clientId) : null);

  /* avoirs actifs — store credit. AV-2031 vient du retour cherbil d'hier. */
  const AVOIRS = IS_DEMO ? [
    { code: 'AV-2031', amount: 350, balance: 350, holderId: 'c2', holderName: 'Mme Ghita Benjelloun',
      motif: 'Retour verres Beldi · lot 6', at: new Date(NOW - 26 * 3600 * 1000), until: new Date(NOW + 182 * 24 * 3600 * 1000), from: '1188' },
  ] : [];
  let avSeq = 2032;
  /* A voucher is spendable only while it has balance and is not expired. Keep
     the rule in one function so list, selection and final deduction agree. */
  const avoirExpired = (a) => !!(a && a.until && new Date(a.until).getTime() < Date.now());
  const activeAvoirs = () => AVOIRS.filter((a) => a.balance > 0 && a.status !== 'cancelled' && a.status !== 'consumed' && !avoirExpired(a));

  /* Les avoirs (bons d'achat) d'une VRAIE boutique doivent survivre à un
     rechargement de la caisse — sinon un bon émis sur un retour disparaît au
     prochain refresh et la cliente ne peut plus le consommer (perte sèche de
     crédit magasin). On les range comme le journal du jour (préfixe `kiwi:`,
     purgé au changement de compte via TENANT_PREFIXES), mais SANS filtre
     « aujourd'hui » : un bon vit jusqu'à sa consommation ou son expiration.
     avSeq repart au-delà du dernier code restauré pour ne pas réémettre un code
     déjà en circulation. La démo reste en mémoire, inchangée. */
  const AVOIR_KEY = 'kiwi:bqAvoirs';
  /* Le cache des avoirs est RANGÉ PAR COMMERCE (`kiwi:bqAvoirs@<slug>`). Une
     seule clé pour tous valait tant qu'un appareil n'avait qu'un commerçant,
     mais une tablette qui change de boutique SANS ré-appairage complet (compte
     multi-établissements, vue opérateur) montrait les bons de la précédente, et
     la caisse proposait de les consommer. On range, on n'efface pas : chaque
     commerce retrouve les siens, personne ne lit ceux d'un autre. L'ancienne
     clé, sans propriétaire connu, n'est plus lue (le registre serveur refait le
     cache au chargement). */
  function avoirKey() { return AVOIR_KEY + '@' + (merchantSlug() || 'local'); }
  function persistAvoirs() {
    if (IS_DEMO) return;
    try {
      const keep = AVOIRS.filter((a) => a && a.balance > 0 && a.status !== 'cancelled'
        && a.status !== 'consumed' && (!a.until || new Date(a.until) > new Date()));
      localStorage.setItem(avoirKey(), JSON.stringify(keep));
    } catch (_) {}
  }
  (function restoreAvoirs() {
    if (IS_DEMO) return;
    let saved = null;
    try { saved = JSON.parse(localStorage.getItem(avoirKey()) || '[]'); } catch (_) { return; }
    if (!Array.isArray(saved) || !saved.length) return;
    let maxSeq = avSeq - 1;
    saved.forEach((a) => {
      if (!a || !a.code) return;
      a.at = a.at ? new Date(a.at) : new Date();
      a.until = a.until ? new Date(a.until) : null;
      a.amount = +a.amount || 0;
      a.balance = +a.balance || 0;
      AVOIRS.push(a);
      const n = parseInt(String(a.code).replace(/^\D+/, ''), 10);
      if (Number.isFinite(n) && n > maxSeq) maxSeq = n;
    });
    if (maxSeq >= avSeq) avSeq = maxSeq + 1;   // le prochain bon ne réutilise pas un code déjà restauré
  })();

  function creditFromServer(row) {
    return {
      id: row.id, code: row.code, amount: Number(row.amountCents || 0) / 100,
      balance: Number(row.balanceCents || 0) / 100, holderId: row.customerId || null,
      holderName: row.customerName || 'Porteur du bon', motif: row.reason || 'Retour',
      at: new Date(Number(row.createdAt || Date.now())), until: new Date(Number(row.expiresAt || 0)),
      from: row.originalRef || row.originalSaleId || null, status: row.status || 'active',
      events: Array.isArray(row.events) ? row.events : [],
    };
  }

  async function creditRequest(body, query) {
    const merchant = merchantSlug();
    if (!merchant) throw new Error('merchant-unavailable');
    const url = '/api/store-credits?merchant=' + encodeURIComponent(merchant) + (query || '');
    const response = await fetch(url, body ? {
      method: 'POST', headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ ...body, merchant }),
    } : { headers: { Accept: 'application/json' } });
    let data = null;
    try { data = await response.json(); } catch (_) {}
    if (!response.ok || !data || data.error) {
      const error = new Error((data && data.error) || `http-${response.status}`);
      error.code = (data && data.error) || `http-${response.status}`;
      throw error;
    }
    return data;
  }

  async function refreshRemoteAvoirs() {
    if (IS_DEMO || typeof fetch !== 'function') return AVOIRS;
    try {
      const data = await creditRequest(null, '');
      AVOIRS.splice(0, AVOIRS.length, ...(data.credits || []).map(creditFromServer));
      persistAvoirs();
      renderBadges();
    } catch (_) { /* cached credits remain visible; redemption still fails closed server-side */ }
    return AVOIRS;
  }

  /* Émettre un avoir CRÉE UNE DETTE : c'est un remboursement dont la somme reste
     chez nous. Il demande donc le même accord qu'un remboursement. Le responsable
     frappe son code, le serveur le vérifie (/api/pin/verify) et rend une capacité
     liée à CETTE émission (ticket, montant, identifiant, moyen « avoir ») ;
     /api/store-credits la relit et refuse sans elle. Le code, lui, ne voyage pas. */
  function avoirApproval(amount, requestId, originalSaleId) {
    return new Promise((resolve, reject) => {
      const refuse = (code) => { const error = new Error(code); error.code = code; reject(error); };
      if (typeof window.requireManager !== 'function') { refuse('manager-required'); return; }
      try { if (window.KiwiAuthAct) window.KiwiAuthAct({ kind: 'refund', key: 'act.refund', args: { amount: fmtMAD(amount) } }); } catch (_) {}
      window.requireManager(`Avoir ${fmtMAD(amount)} · ticket ${originalSaleId}`,
        (manager) => resolve((manager && manager.approval) || ''),
        { kind: 'refund', refundId: requestId, originalSaleId, amountCents: Math.round(amount * 100), refundMethod: 'avoir', windowOverride: outsideWindow((findSale(originalSaleId) || {}).at, businessDateKey) },
        { onCancel: () => refuse('manager-cancelled') });
    });
  }

  function creditIntent(prefix) {
    try { if (crypto && crypto.randomUUID) return `${prefix}:${crypto.randomUUID()}`; } catch (_) {}
    return `${prefix}:${Date.now().toString(36)}:${Math.random().toString(36).slice(2, 12)}`;
  }

  function creditErrorDetail(error) {
    const code = error && error.code;
    if (code === 'sale-credit-exceeds-available') {
      return 'Ce ticket n’est pas encore synchronisé, ou il a déjà été remboursé jusqu’à son montant disponible.';
    }
    if (code === 'manager-cancelled') return 'Autorisation du responsable annulée. Rien n’a été remis en stock.';
    if (code === 'manager-required') return 'L’accord d’un responsable est nécessaire pour émettre un avoir. Rien n’a été remis en stock.';
    return 'Connexion au registre des avoirs impossible. Rien n’a été remis en stock.';
  }

  function stableCreditIssueId(sale, quantities, amountCents) {
    const original = String((sale && (sale.serverId || sale.syncId || sale.id)) || 'sale')
      .replace(/[^A-Za-z0-9:._-]/g, '').slice(0, 48);
    const revision = Array.from(quantities.entries()).sort((a, b) => Number(a[0]) - Number(b[0])).map(([idx, qty]) => {
      const line = sale && sale.lines && sale.lines[idx];
      return `${idx}-${lineReturnedQty(line) + Number(qty || 0)}`;
    }).join('_');
    return `credit-issue:${original}:${revision}:${Math.round(Number(amountCents) || 0)}`.slice(0, 96);
  }

  function stableRefundId(sale, quantities, amountCents) {
    const original = String((sale && (sale.serverId || sale.syncId || sale.id)) || 'sale')
      .replace(/[^A-Za-z0-9:._-]/g, '').slice(0, 42);
    const revision = Array.from(quantities.entries()).sort((a, b) => Number(a[0]) - Number(b[0])).map(([idx, qty]) => {
      const line = sale && sale.lines && sale.lines[idx];
      return `${idx}-${lineReturnedQty(line) + Number(qty || 0)}`;
    }).join('_');
    return `refund:${original}:${revision}:${Math.round(Number(amountCents) || 0)}`.slice(0, 64);
  }

  /* Une vente que la file de Live Link refuse est gardée sur la vente et
     renvoyée plus tard, une seule fois (assets/retail-sale-hold.js). */
  let bqHoldKit = null;
  const bqHold = () => bqHoldKit || (bqHoldKit = window.KiwiRetailSaleHold
    ? window.KiwiRetailSaleHold.create({ sales: () => SALES, persist: () => persistDay(), isDemo: IS_DEMO, slug: () => merchantSlug(),
      onLost: () => toast('Vente NON sauvegardée : stockage de la tablette plein et serveur injoignable. Ne rechargez pas la page, notez le ticket.', 15000, 'warn') })
    : null);
  function bqReplayHeld() { const h = bqHold(); return h ? h.replay() : 0; }
  function bqPost(sale, payload) {
    const h = bqHold();
    if (h) return h.post(sale, payload);
    try { return window.KiwiLive.postSale(payload); } catch (_) { return null; }
  }

  /* Rebuild the immutable cloud receipt from the frozen local sale. This is
     also the migration path for tickets sold before gross receipt values were
     stored separately from owner revenue. */
  function originalSalePayload(sale) {
    if (!sale) return null;
    const parts = Array.isArray(sale.parts) ? sale.parts : [];
    const received = parts.filter((part) => part && part.m !== 'avoir' && part.m !== 'livraison' && (+part.amount || 0) > 0);
    const methods = received.map((part) => part.m);
    const method = sale.tenderVersion === 2 ? bqPaymentMethod(parts)
      : (methods.includes('carte') ? 'card' : (methods.includes('espèces') ? 'cash' : 'wallet'));
    const creditIn = parts.reduce((sum, part) => sum + (part && part.m === 'avoir' ? (+part.amount || 0) : 0), 0);
    const delivery = parts.some((part) => part && part.m === 'livraison');
    const consigned = Math.max(0, Number(sale.consigned) || (sale.lines || []).reduce((sum, line) => sum + (line && line.consigned ? (+line.unit || 0) * (+line.qty || 0) : 0), 0));
    /* Un ticket à 0 (tout offert) reste à 0 : seul un total absent retombe sur les lignes. */
    const total = Math.max(0, sale.total != null && sale.total !== '' && Number.isFinite(+sale.total) ? +sale.total : (sale.lines || []).reduce((sum, line) => sum + (+line.unit || 0) * (+line.qty || 0), 0));
    const cashIn = sale.remote && sale.receivedAmount != null
      ? Math.max(0, Number(sale.receivedAmount) || 0)
      : Math.max(0, received.reduce((sum, part) => sum + (+part.amount || 0), 0) - consigned);
    const lineTotals = bqLineTotals((sale.lines || []).map((line) => (+line.unit || 0) * Math.max(1, Number(line.qty) || 1)), Number(sale.balanceTotal) || total);
    const lines = bqFoldBasket((sale.lines || []).map((line, i) => ({
      itemId: line.pid || '', variantId: line.variantId || [line.pid || '', line.size || '', line.color || ''].join(':'),
      name: line.name || (P[line.pid] && P[line.pid].name) || 'Article retiré du catalogue',
      qty: Math.max(1, Number(line.qty) || 1), total: lineTotals[i],
      cat: line.category || rayonOf(line.pid) || '', unit: 'piece', kind: 'product',
    })));
    const payload = {
      id: sale.serverId || sale.syncId || sale.id,
      merchant: merchantSlug(), amount: cashIn, amountCents: Math.round(cashIn * 100),
      ticketAmountCents: Math.round(total * 100), consignedAmountCents: Math.round(consigned * 100),
      method, channel: delivery ? 'delivery' : 'counter', label: (lines[0] && lines[0].name) || 'Vente',
      ref: sale.id, ts: +new Date(sale.at || Date.now()), lines,
    };
    if (sale.tenderVersion === 2) payload.paymentParts = bqPaymentParts(parts);
    if (cashIn <= 0 && creditIn > 0 && lines.length) {
      payload.settlementKind = 'store-credit'; payload.creditAmountCents = Math.round(creditIn * 100);
    } else if (cashIn <= 0 && consigned >= total && total > 0 && lines.length) {
      payload.settlementKind = 'consignment';
    } else if (cashIn <= 0 && delivery && lines.length) {
      payload.settlementKind = 'receivable';
    }
    return payload;
  }

  async function ensureOriginalSale(sale) {
    if (IS_DEMO) return sale && (sale.serverId || sale.syncId || sale.id);
    const payload = originalSalePayload(sale);
    if (!payload || !payload.id || !payload.merchant || !payload.lines.length) {
      const error = new Error('sale-unavailable'); error.code = 'sale-unavailable'; throw error;
    }
    const response = await fetch('/api/sale', {
      method: 'POST', credentials: 'same-origin', headers: { 'Content-Type': 'application/json', Accept: 'application/json' },
      body: JSON.stringify(payload),
    });
    let data = null; try { data = await response.json(); } catch (_) {}
    if (!response.ok || !data || data.error) {
      const error = new Error((data && data.error) || `http-${response.status}`);
      error.code = (data && data.error) || `http-${response.status}`;
      throw error;
    }
    sale.serverId = String(data.id || payload.id);
    persistDay();
    return sale.serverId;
  }

  refreshRemoteAvoirs();

  /* ───────────────────────── state ───────────────────────── */
  /* Le préfixe ne sert plus qu'à reconnaître les anciens journaux locaux lors
     de leur migration. Les nouveaux tickets réels n'affichent que des chiffres. */
  function ticketPrefix() {
    if (IS_DEMO) return 'MM';
    const pv = pvPaired();
    const ini = String((pv && pv.name) || '')
      .split(/\s+/).filter(Boolean).slice(0, 2)
      .map((w) => w[0]).join('')
      .normalize('NFD').replace(/[^A-Za-z]/g, '')
      .toUpperCase();
    return ini || 'KW';
  }
  const TK = ticketPrefix();
  /* 1000 : quatre chiffres, qui se disent d'un trait au téléphone. Pour une
     vraie boutique ce n'est qu'un plancher de migration : le serveur réserve les
     plages qui font autorité et saleSeq ne peut que le pousser vers le haut. */
  let saleSeq = IS_DEMO ? 1208 : 1000;
  let saleSeqPeriod = new Date().getFullYear();

  /* ── le journal du jour survit à un rechargement (boutiques réelles) ───────
     SALES ne vivait qu'en mémoire : recharger la caisse remettait son en-tête à
     « 0 vente · 0 MAD aujourd'hui » alors que le dashboard, qui lit le serveur,
     affichait toujours la recette du jour. Une caissière et la gérante ne doivent
     jamais lire deux chiffres différents pour la même journée.
     Rangé sous le préfixe `kiwi:` pour qu'un changement de compte le purge (voir
     TENANT_PREFIXES dans identity.js), et filtré sur aujourd'hui au chargement :
     le compteur bascule donc tout seul à minuit. saleSeq est repris au-delà du
     dernier numéro restauré, sinon le ticket suivant réutiliserait un numéro déjà
     encaissé. La démo garde ses ventes en mémoire, inchangée. */
  const DAY_KEY = 'kiwi:bqDay';
  /* « Aujourd'hui » = la journée commerciale (bascule à 5 h), la même que le
     tableau de bord et le rapport journalier. Minuit coupait en deux un service
     de soirée : à 0 h 30 la caisse affichait une vente, le rapport cinq. */
  function businessDayKey(ts) {
    const R = window.KiwiDayReport;
    try { if (R && R.businessDay) return R.businessDay(ts); } catch (_) {}
    const x = new Date(ts - 5 * 3600000);
    return x.getFullYear() + '-' + x.getMonth() + '-' + x.getDate();
  }
  function isToday(d) {
    const t = +new Date(d);
    return !isNaN(t) && businessDayKey(t) === businessDayKey(tillNow());
  }
  /* La même journée, écrite 'YYYY-MM-DD' pour un <input type="date"> : la page
     des retours la compare aux ventes. Elle découpait à minuit, si bien qu'à
     0 h 30 une vente de 23 h quittait « Aujourd'hui » pour « Hier » alors que
     le reste de la caisse la comptait encore dans la journée. */
  function businessDateKey(ts) {
    const t = +new Date(ts);
    const R = window.KiwiDayReport;
    try { if (R && R.businessDay) { const k = R.businessDay(t); if (/^\d{4}-\d{2}-\d{2}$/.test(k)) return k; } } catch (_) {}
    const x = new Date(t - 5 * 3600000);
    return x.getFullYear() + '-' + pad2(x.getMonth() + 1) + '-' + pad2(x.getDate());
  }
  function shiftDateKey(key, days) {
    const p = String(key).split('-').map(Number);
    const x = new Date(Date.UTC(p[0], p[1] - 1, p[2] + days));
    return x.getUTCFullYear() + '-' + pad2(x.getUTCMonth() + 1) + '-' + pad2(x.getUTCDate());
  }

  /* ── « Retour sous 7 jours » — encore faut-il retrouver la vente ────────────
   * L'échange affiche « retour sous 7 jours », mais le journal ne gardait que la
   * journée en cours : une cliente qui revenait le jeudi avec un article acheté
   * le mardi était introuvable, et l'employé n'avait aucun moyen de vérifier le
   * prix payé. La promesse faite au comptoir ne tenait qu'un jour.
   *
   * Le journal garde donc RETAIN_DAYS jours. Deux limites, pour que cet
   * élargissement ne déborde nulle part :
   *
   *  · L'ARGENT RESTE À LA JOURNÉE. caToday() et l'en-tête filtrent
   *    explicitement sur aujourd'hui (voir salesToday) : ils sommaient tout
   *    SALES en se fiant au fait qu'il ne contenait qu'un jour, et garder une
   *    semaine y aurait affiché une recette multipliée par sept sous le mot
   *    « aujourd'hui ». C'est le vrai piège de ce changement.
   *  · LE NUMÉRO DE TICKET NE RECULE JAMAIS. saleSeq repart au-dessus du plus
   *    grand numéro RESTAURÉ, toutes journées confondues — sinon un ticket
   *    d'aujourd'hui réutiliserait le numéro d'hier, et deux ventes
   *    différentes se présenteraient sous la même référence dans les retours.
   *
   * Le rapport journalier n'est pas concerné : build() reçoit « toutes les ventes
   * connues (elles seront filtrées sur la journée) » — voir assets/day-report.js.
   * Le plafond de purge borne aussi la taille du journal ; une boutique très
   * active tient largement dans le quota localStorage sur sept jours. */
  const RETAIN_DAYS = 7;
  function withinRetention(d) {
    const x = new Date(d);
    if (isNaN(x)) return false;
    const start = new Date();
    start.setHours(0, 0, 0, 0);
    start.setDate(start.getDate() - (RETAIN_DAYS - 1));       // aujourd'hui inclus
    return x >= start;
  }
  /* Les ventes du JOUR — la seule base admise pour un chiffre d'affaires. Les
     ventes sorties des livres n'en sont plus (voir reconcileVoids). */
  const salesToday = () => SALES.filter((s) => s && !s.voided && isToday(s.at));

  /* Quand une vente a-t-elle eu lieu ? Le journal couvrant maintenant la semaine,
     un libellé « auj. » écrit en dur mentirait sur une vente de mardi. Sur sept
     jours le nom du jour suffit à lever toute ambiguïté. */
  function whenLabel(d) {
    const x = new Date(d);
    if (isToday(x)) return `auj. ${fmtHM(x)}`;
    const y = new Date(); y.setDate(y.getDate() - 1);
    if (x.getFullYear() === y.getFullYear() && x.getMonth() === y.getMonth() && x.getDate() === y.getDate()) {
      return `hier ${fmtHM(x)}`;
    }
    return `${DAYS[x.getDay()]} ${fmtHM(x)}`;
  }

  /* ── À QUI EST CE JOURNAL ─────────────────────────────────────────────────
     Il ne le disait pas. Une caisse ré-appairée d'une enseigne à une autre
     relisait donc les ventes de la PREMIÈRE et les servait sous le nom de la
     SECONDE : « Échanges & avoirs » listait les ventes d'un autre commerce,
     « Réimprimer » proposait leurs tickets, et l'en-tête en comptait une dans
     la recette du jour. Constaté le 30/07/2026 sur une caisse en production —
     le journal local disait CM-15-44 pendant que le comptoir tapait des tickets
     SS-16-44 et que le tableau de bord, lui, comptait juste.

     Deux gardes, parce qu'elles ne couvrent pas la même population :

      · LE TAMPON, pour tout ce qui s'écrit désormais. Le blob porte son
        commerçant ; à la relecture, un autre nom et on n'adopte rien.
      · LE PRÉFIXE DE TICKET, pour les blobs déjà sur les appareils, qui n'ont
        aucun tampon. Une référence porte l'initiale de l'enseigne (voir
        ticketPrefix) : « CM- » relu sous une enseigne qui tape « SS- » n'est
        pas d'ici. C'est la seule preuve que porte l'ancien format, et elle
        suffit à réparer les caisses déjà contaminées sans attendre un
        ré-appairage.

     Une enseigne qui se RENOMME perd ainsi sa semaine de journal — sept jours
     de réimpression et de retours. C'est le prix, et il est plus petit que
     l'inverse : montrer à une commerçante les ventes de quelqu'un d'autre. */
  function merchantSlug() {
    try {
      const pv = pvPaired();
      return String((pv && pv.merchant) || localStorage.getItem('kiwiLiveMerchant') || '');
    } catch (_) { return ''; }
  }
  function persistDay() {
    if (IS_DEMO) return true;
    try {
      localStorage.setItem(DAY_KEY, JSON.stringify({
        v: 1, m: merchantSlug(), s: SALES.filter((s) => s && withinRetention(s.at)),
      }));
      return true;
    } catch (_) { return false; }
  }
  (function restoreDay() {
    if (IS_DEMO) return;
    let blob = null;
    try { blob = JSON.parse(localStorage.getItem(DAY_KEY) || 'null'); } catch (_) { return; }
    if (!blob) return;

    let saved;
    if (Array.isArray(blob)) {
      /* Ancien format, sans tampon : on juge sur le préfixe des références. Un
         journal dont AUCUNE référence ne commence par le préfixe d'ici vient
         d'ailleurs. On ne juge que sur les références lisibles — un journal sans
         aucune référence exploitable est adopté, faute de preuve du contraire. */
      const refs = blob.map((s) => String((s && s.id) || '')).filter((r) => /^[A-Z]{2,}-/.test(r));
      const mine = refs.filter((r) => r.indexOf(TK + '-') === 0);
      if (refs.length && !mine.length) {
        try { localStorage.removeItem(DAY_KEY); } catch (_) {}
        return;
      }
      saved = blob;
    } else if (blob && Array.isArray(blob.s)) {
      const now = merchantSlug();
      /* Tampon présent et différent : ce journal est celui d'un autre commerce.
         On l'efface plutôt que de le laisser dormir — il ressortirait au
         prochain ré-appairage vers son propriétaire d'origine, avec une semaine
         de retard et des stocks qui ne correspondent plus. */
      if (blob.m && now && blob.m !== now) {
        try { localStorage.removeItem(DAY_KEY); } catch (_) {}
        return;
      }
      saved = blob.s;
    } else return;

    if (!Array.isArray(saved) || !saved.length) return;
    let maxSeq = 0;
    saved.forEach((s) => {
      if (!s || !s.at || !withinRetention(s.at)) return;      // au-delà de la semaine, on oublie
      s.at = new Date(s.at);
      s.lines = Array.isArray(s.lines) ? s.lines : [];
      s.total = +s.total || s.lines.reduce((t, l) => t + (+l.unit || 0) * (+l.qty || 0), 0);
      // Le plus grand numéro TOUTES JOURNÉES CONFONDUES : un numéro déjà encaissé
      // ne doit jamais resservir, même s'il vient d'hier.
      const n = parseInt(String(s.id || '').replace(/^\D+/, ''), 10);
      if (new Date(s.at).getFullYear() === new Date().getFullYear() && n > maxSeq) maxSeq = n;
      SALES.push(s);
    });
    SALES.sort((a, b) => b.at - a.at);                       // le plus récent d'abord, comme unshift
    if (maxSeq >= saleSeq) saleSeq = maxSeq + 1;
    /* Adopté : on le tamponne TOUT DE SUITE. Sinon un journal d'ancien format
       reste jugé sur son préfixe de ticket jusqu'à la prochaine vente — c'est
       la preuve la plus faible dont on dispose, et une enseigne qui se renomme
       la ferait échouer. Une écriture au démarrage, et la garde repose ensuite
       sur le nom du commerçant, qui lui ne se devine pas. */
    if (Array.isArray(blob)) persistDay();
  })();

  /* ── les tickets du magasin, pas seulement ceux de CET écran ─────────────
   * Échanges & avoirs lisait uniquement `kiwi:bqDay`, donc le journal local de
   * cette tablette. Une vente bien présente dans le dashboard (ou encaissée sur
   * la deuxième caisse) restait introuvable au retour client. Le serveur est le
   * registre commun : on relit la journée et on complète SALES. La copie locale
   * gagne toujours, car elle porte la variante exacte et l'état des retours.
   *
   * Les anciennes lignes serveur portent le nom imprimé (« Jean noir M »), pas
   * encore l'id de variante. On les rattache au produit par le plus long nom de
   * catalogue, puis à sa taille. Ce repli rend les ventes déjà faites utilisables
   * immédiatement ; aucune donnée n'est inventée si aucun produit ne correspond. */
  const srvMethod = (m) => ({ cash: 'espèces', card: 'carte', delivery: 'livraison' }[m] || m || 'paiement');
  function remoteLine(line) {
    if (!line) return null;
    const raw = String(line.name || '').trim();
    /* /api/sale garde l'article et la variante exacte (itemId et
       « pid:taille:couleur »). On ne les lisait pas : la ligne était rattachée
       par son nom imprimé, puis au premier modèle de la taille, si bien qu'une
       chemise bleue rendue sur l'autre caisse revenait en stock en blanc. */
    const itemKey = String(line.itemId || line.pid || '');
    let item = itemKey && P[itemKey] ? P[itemKey] : null;
    const vKey = String(line.variantId || '');
    const vRest = item && vKey.indexOf(itemKey + ':') === 0 ? vKey.slice(itemKey.length + 1) : '';
    const vCut = vRest.indexOf(':');
    const vSize = vCut >= 0 ? vRest.slice(0, vCut) : '';
    const vColor = vCut >= 0 ? vRest.slice(vCut + 1) : '';
    if (!item && raw) {
      const low = raw.toLocaleLowerCase('fr');
      const uniq = [];
      Object.keys(P).forEach((k) => { const p = P[k]; if (p && !uniq.includes(p)) uniq.push(p); });
      item = uniq.filter((p) => {
        const n = String(p.name || '').toLocaleLowerCase('fr');
        return low === n || low.indexOf(n + ' ') === 0;
      }).sort((a, b) => String(b.name || '').length - String(a.name || '').length)[0] || null;
    }
    if (!item) {
      const qty = Math.max(1, Number(line.qty) || 1);
      return {
        pid: String(line.itemId || ''), variantId: String(line.variantId || ''), size: String(line.size || 'TU'),
        color: String(line.color || ''), qty, remise: 0,
        unit: Number(line.unit) || ((Number(line.total) || 0) / qty), returned: false, note: '',
        name: raw || 'Article retiré du catalogue', category: String(line.cat || ''), catalogueMissing: true,
      };
    }
    const suffix = raw.slice(String(item.name || '').length).trim();
    const sizes = sizesOf(item);
    const size = String(line.size || vSize || (sizes.includes(suffix) ? suffix : '') || sizes[0] || 'TU');
    const vs = item._variants || [];
    const variant = (vColor && vs.find((v) => String(v.size) === size && String(v.colorId) === vColor))
      || vs.find((v) => String(v.size) === size) || vs[0];
    const qty = Math.max(1, Number(line.qty) || 1);
    return {
      pid: item.id, size, color: String(line.color || vColor || (variant && variant.colorId) || ''), qty,
      remise: 0, unit: Number(line.unit) || ((Number(line.total) || 0) / qty),
      returned: false, note: '', name: item.name,
    };
  }
  function syncReturnSales() {
    if (IS_DEMO || typeof fetch !== 'function') return Promise.resolve(0);
    const merchant = merchantSlug();
    if (!merchant) return Promise.resolve(0);
    const start = new Date(); start.setHours(0, 0, 0, 0);
    start.setDate(start.getDate() - (RETAIN_DAYS - 1));
    return (window.KiwiPosSale?.feedDay || ((u, o) => fetch(u, o).then((r) => r.ok ? r.json() : null)))('/api/feed?merchant=' + encodeURIComponent(merchant) + '&from=' + start.getTime(), {
      credentials: 'same-origin', headers: { Accept: 'application/json' },
    }).then((data) => {
      let added = 0;
      ((data && data.sales) || []).forEach((row) => {
        const ref = String(row.ref || '');
        if (!ref || SALES.some((s) => s && s.id === ref)) return;
        const lines = (Array.isArray(row.lines) ? row.lines : []).map(remoteLine).filter(Boolean);
        if (!lines.length) return; // sans article identifiable, aucun échange honnête à proposer
        SALES.push({
          id: ref, serverId: String(row.id || ''), at: new Date(Number(row.ts) || Date.now()),
          clientId: null, by: 'Caisse', kind: 'vente', methods: srvMethod(row.method), lines,
          total: lines.reduce((sum, l) => sum + l.unit * l.qty, 0),
          receivedAmount: Number(row.amountCents != null ? row.amountCents / 100 : row.amount) || 0,
          remote: true,
        });
        added++;
      });
      if (added) {
        SALES.sort((a, b) => new Date(b.at) - new Date(a.at));
        persistDay();
        if (root && state.view === 'echanges') { renderEchanges(); renderBadges(); icons(); }
      }
      return added;
    }).catch(() => 0);
  }
  const state = {
    view: 'vente',
    rayon: 'tous',
    filterAxis: 'rayons',        /* 'rayons' | 'marques' | 'motifs' | 'fragile' */
    selectedMarque: 'tous',
    selectedMotif: 'tous',
    ticket: null,                /* { num, lines:[], client:id|'passage'|null, remiseAuth, giftWrap, delivery } */
    exchange: null,              /* { saleId, idx, qty:1 } pendant le choix du remplacement */
    ret: null,                   /* { saleId, picks:Set, quantities:Map, motif } */
    retQuery: '',
    retDate: businessDateKey(tillNow()),
    clQuery: '',
    registriesQuery: '',
    activeRegistry: null,
    movementDays: 0,
    movementType: '',
    movementCategory: '',
    movementQuery: '',
    movementSyncing: false,
    casseQuery: '',
    scanLog: [],                 /* journal des articles VÉRIFIÉS (onglet Scan) */
    lookup: null,                /* { pid, size, color, ean, at } — dernière vérif affichée */
    scanIdx: 0,
    scanBusy: false,
    offline: (typeof navigator !== 'undefined' && navigator.onLine === false),
    simulatedOffline: false,
    queued: 0,
    syncBlocked: false,
    syncStorageError: false,
    ticketStorageError: false,
  };

  /* Journal partagé des retours. Avant ceci, le stock et l'avoir changeaient
     bien à la caisse, mais le dashboard ne recevait aucun retour et continuait
     d'afficher ses exemples. */
  const RETURN_LOG_KEY = 'kiwi:bqReturns';
  let RETURN_LOG = [];
  let returnCloudHandle = null;
  (function restoreReturnLog() {
    if (IS_DEMO) return;
    try {
      const d = JSON.parse(localStorage.getItem(RETURN_LOG_KEY) || 'null');
      if (d && (!d.m || !merchantSlug() || d.m === merchantSlug()) && Array.isArray(d.list)) RETURN_LOG = d.list;
    } catch (_) {}
  })();
  function persistReturnLog() {
    if (IS_DEMO) return;
    try { localStorage.setItem(RETURN_LOG_KEY, JSON.stringify({ m: merchantSlug(), list: RETURN_LOG })); } catch (_) {}
  }
  function ensureReturnCloud() {
    if (IS_DEMO || returnCloudHandle || !window.KiwiCloudDoc) return returnCloudHandle;
    returnCloudHandle = window.KiwiCloudDoc.attach({
      feature: 'returns', slug: merchantSlug,
      read: () => ({ list: RETURN_LOG }),
      write: (doc) => {
        RETURN_LOG = Array.isArray(doc && doc.list) ? doc.list : [];
        persistReturnLog();
      },
      isEmpty: (doc) => !doc || !Array.isArray(doc.list) || !doc.list.length,
    });
    returnCloudHandle.bind();
    return returnCloudHandle;
  }
  function recordReturn(sale, idxs, amount, reason, kind, reference, quantities) {
    if (IS_DEMO || !sale) return;
    const items = idxs.map((i) => {
      const ln = sale.lines[i];
      if (!ln) return null;
      const qty = quantities && quantities.has(i) ? Number(quantities.get(i)) || 1 : 1;
      return {
        name: (P[ln.pid] && P[ln.pid].name) || ln.name || 'Article', size: ln.size || '',
        qty, amount: Math.sign((Number(ln.unit) || 0) * qty) * Math.round(Number(Math.abs((Number(ln.unit) || 0) * qty).toExponential().replace(/e(.+)$/, (_, e) => 'e' + (+e + 2)))) / 100,
      };
    }).filter(Boolean);
    const now = tillNow();
    const client = saleClient(sale);
    RETURN_LOG.unshift({
      id: `RET-${sale.id}-${now}`, ts: now, saleRef: sale.id, kind: kind || 'avoir',
      reason: reason || '', amount: Math.sign(Number(amount) || 0) * Math.round(Number(Math.abs(Number(amount) || 0).toExponential().replace(/e(.+)$/, (_, e) => 'e' + (+e + 2)))) / 100, reference: reference || '',
      actor: (STAFF.caissiere && STAFF.caissiere.name) || 'Caisse',
      client: (client && client.name) || 'Cliente de passage', items,
    });
    RETURN_LOG = RETURN_LOG.slice(0, 500); persistReturnLog();
    try { document.dispatchEvent(new CustomEvent('kiwi:returns-changed')); } catch (_) {}   // le registre des retours du tableau de bord se relit sans attendre
    const cloud = ensureReturnCloud();
    if (cloud) cloud.push();
  }
  /* ── LE NUMÉRO DE TICKET : DES CHIFFRES, ET RIEN D'AUTRE ──────────────────
   * Une référence lisible (1000, 1001…) et un identifiant technique sont deux
   * choses différentes. `syncId` est un UUID : deux ventes ne deviennent jamais
   * le même INSERT OR IGNORE, même si un ancien client nous remet un jour une
   * référence erronée. `num` vient d'une plage atomiquement réservée au serveur :
   * deux comptoirs reçoivent des plages disjointes, puis peuvent les consommer
   * hors ligne. Une plage perdue crée un trou ; elle ne revient jamais en vente. */
  const TICKET_LEASE_KEY = 'kiwi:bqTicketLease';
  /* 500 numbers = several busy offline days for a boutique, while staying well
     below the five-digit annual ceiling. The range is persisted immediately. */
  const TICKET_LEASE_SIZE = 500;
  /* Sous ce seuil de numéros restants on réserve la plage suivante. 120 laisse
     une journée chargée d'avance avant même de toucher la réserve. */
  const TICKET_LEASE_LOW = 120;
  let ticketLease = null;
  let ticketLeaseRequest = null;
  let ticketTopUpRequest = null;

  function ticketPeriod() { return new Date().getFullYear(); }
  function syncTicketPeriod() {
    if (!IS_DEMO && saleSeqPeriod !== ticketPeriod()) {
      saleSeq = 1000;
      saleSeqPeriod = ticketPeriod();
      ticketLease = null;
    }
  }

  function newSaleId() {
    try {
      if (crypto && crypto.randomUUID) return 'sale-' + crypto.randomUUID();
      if (crypto && crypto.getRandomValues) {
        const b = new Uint32Array(2); crypto.getRandomValues(b);
        return 'sale-' + Date.now().toString(36) + '-' + b[0].toString(36) + b[1].toString(36);
      }
    } catch (_) {}
    return 'sale-' + Date.now().toString(36) + '-' + Math.random().toString(36).slice(2, 12);
  }

  /* Une plage réservée est une provision, pas un jeton à usage unique : tant que
     la caisse est en ligne, on garde toujours une plage d'avance en réserve.
     Sans cela, la première panne de réseau qui tombe sur une plage épuisée
     bloque la vente — alors que le hors-ligne est précisément ce que la plage
     est censée couvrir. */
  function cleanLeaseQueue(q) {
    if (!Array.isArray(q)) return [];
    return q.map((r) => (r && Number.isInteger(+r.start) && Number.isInteger(+r.end) && +r.start >= 1000 && +r.end >= +r.start && +r.end <= 99999
      ? { start: +r.start, end: +r.end } : null)).filter(Boolean).slice(0, 4);
  }

  function leaseRemaining(lease) {
    if (!lease) return 0;
    let n = Math.max(0, lease.end - Math.max(+lease.next || 0, saleSeq, 1000) + 1);
    (lease.queue || []).forEach((r) => { n += r.end - r.start + 1; });
    return n;
  }

  function readTicketLease() {
    const m = merchantSlug();
    const period = ticketPeriod();
    if (ticketLease && ticketLease.m === m && ticketLease.period === period) return ticketLease;
    ticketLease = null;
    try {
      const x = JSON.parse(localStorage.getItem(TICKET_LEASE_KEY) || 'null');
      if (x && x.m === m && +x.period === period && Number.isInteger(+x.next) && Number.isInteger(+x.end) && +x.next <= +x.end) {
        ticketLease = { m, period, next: +x.next, end: +x.end, queue: cleanLeaseQueue(x.queue) };
      }
    } catch (_) {}
    return ticketLease;
  }

  function saveTicketLease() {
    try {
      if (ticketLease) localStorage.setItem(TICKET_LEASE_KEY, JSON.stringify(ticketLease));
      state.ticketStorageError = false;
      return true;
    } catch (_) {
      state.ticketStorageError = true;
      return false;
    }
  }

  function takeTicketNumber() {
    if (IS_DEMO) return String(saleSeq);
    syncTicketPeriod();
    const lease = readTicketLease();
    if (!lease) return '';
    let n = Math.max(+lease.next || 0, saleSeq, 1000);
    const previousNext = lease.next;
    const previousEnd = lease.end;
    const previousQueue = (lease.queue || []).slice();
    const previousSeq = saleSeq;
    /* Plage épuisée : on bascule sur la suivante déjà réservée. C'est ce qui
       permet de vendre hors ligne au-delà des 500 premiers numéros. */
    while (n > lease.end && (lease.queue || []).length) {
      const nextRange = lease.queue.shift();
      lease.end = nextRange.end;
      n = Math.max(nextRange.start, saleSeq, 1000);
    }
    if (n > lease.end || n > 99999) {
      lease.end = previousEnd;
      lease.queue = previousQueue;
      return '';
    }
    lease.next = n + 1;
    saleSeq = n + 1;
    /* The number is not claimed until its successor is durable. Otherwise a
       full/private localStorage can reload the old `next` and print the same
       visible receipt number twice. Losing the whole server-reserved range is
       acceptable; reusing one of its numbers is not. */
    if (!saveTicketLease()) {
      lease.next = previousNext;
      lease.end = previousEnd;
      lease.queue = previousQueue;
      saleSeq = previousSeq;
      return '';
    }
    topUpTicketLease();
    return String(n);
  }

  /* Réserve la plage SUIVANTE pendant qu'on est encore en ligne. Appelée après
     chaque numéro pris et à l'ouverture de la caisse : quand le réseau tombe,
     la réserve est déjà sur la tablette. */
  function topUpTicketLease() {
    if (IS_DEMO) return;
    try { if (navigator && navigator.onLine === false) return; } catch (_) {}
    const lease = readTicketLease();
    if (!lease) {
      /* Aucune plage : on en réserve une tout de suite, sans attendre la
         première cliente — sinon la panne de réseau arrive avant la plage. */
      if (!ticketLeaseRequest) { try { ensureTicketLease().catch(() => {}); } catch (_) {} }
      return;
    }
    if (leaseRemaining(lease) > TICKET_LEASE_LOW) return;
    if ((lease.queue || []).length >= 2) return;
    if (ticketLeaseRequest || ticketTopUpRequest) return;
    ticketTopUpRequest = requestTicketRange().then((range) => {
      const live = readTicketLease();
      if (!live || !range) return;
      live.queue = cleanLeaseQueue((live.queue || []).concat([range]));
      saveTicketLease();
    }).catch(() => {}).finally(() => { ticketTopUpRequest = null; });
  }

  function requestTicketRange() {
    const m = merchantSlug();
    if (!m || typeof fetch !== 'function') return Promise.reject(new Error('merchant-unavailable'));
    return fetch('/api/ticket-sequence', {
      method: 'POST',
      credentials: 'same-origin',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ merchant: m, size: TICKET_LEASE_SIZE, floor: saleSeq, period: ticketPeriod() }),
    }).then((r) => {
      if (!r.ok) throw new Error('ticket-sequence-' + r.status);
      return r.json();
    }).then((j) => {
      const start = +j.start, end = +j.end;
      if (!Number.isInteger(start) || !Number.isInteger(end) || start < 1000 || end < start || end > 99999 || +j.period !== ticketPeriod()) {
        throw new Error('ticket-sequence-invalid');
      }
      return { start, end };
    });
  }

  function ensureTicketLease() {
    if (IS_DEMO) return Promise.resolve(ticketLease);
    syncTicketPeriod();
    const existing = readTicketLease();
    if (existing && Math.max(existing.next, saleSeq) <= existing.end) return Promise.resolve(existing);
    if (ticketLeaseRequest) return ticketLeaseRequest;
    const m = merchantSlug();
    ticketLeaseRequest = requestTicketRange().then(({ start, end }) => {
      const carried = existing && existing.m === m ? cleanLeaseQueue(existing.queue) : [];
      ticketLease = { m, period: ticketPeriod(), next: start, end, queue: carried };
      if (!saveTicketLease()) {
        ticketLease = null;
        throw new Error('ticket-lease-storage');
      }
      return ticketLease;
    }).finally(() => { ticketLeaseRequest = null; });
    return ticketLeaseRequest;
  }

  function withTicketLock(work) {
    /* Two tabs on the SAME till share localStorage. Without a cross-tab lock they
       can both read `next: 1042` before either writes 1043. Web Locks serializes
       that tiny critical section; the fallback still serializes calls in one
       tab, and storage events invalidate the cache in other legacy browsers. */
    try {
      if (navigator && navigator.locks && navigator.locks.request) {
        return navigator.locks.request('kiwi-ticket:' + merchantSlug(), work);
      }
    } catch (_) {}
    return Promise.resolve().then(work);
  }

  function claimTicketNumber() {
    return withTicketLock(() => {
      /* Another tab may have advanced the persisted lease while this tab kept
         its in-memory copy. Always re-read after acquiring the lock. */
      ticketLease = null;
      const ready = takeTicketNumber();
      if (ready) return ready;
      return ensureTicketLease().then(() => {
        ticketLease = null;
        const n = takeTicketNumber();
        if (!n) throw new Error('ticket-sequence-empty');
        return n;
      }).catch((e) => {
        /* LE PANIER N'EST JAMAIS OTAGE DU RÉSEAU.
           Le serveur n'a pas pu réserver de plage : plutôt que d'interdire la
           vente — ce que la bannière hors-ligne promet justement le contraire —
           on émet une référence provisoire dans une bande qui ne peut PAS
           entrer en collision avec une plage serveur (elle n'est pas
           numérique). L'identité technique de la vente reste `syncId`, un UUID,
           donc la synchronisation n'est pas affectée. La vente part au journal
           avec sa marque « hors-ligne » et reste lisible par le comptoir. */
        const fallback = takeOfflineRef();
        if (fallback) return fallback;
        throw e;
      });
    });
  }

  const OFFLINE_REF_KEY = 'kiwi:bqTicketOffline';

  function offlineDeviceTag() {
    /* Deux comptoirs hors ligne ne doivent pas frapper la même référence. */
    try {
      let tag = localStorage.getItem(OFFLINE_REF_KEY + ':tag');
      if (!tag || !/^[A-Z0-9]{3}$/.test(tag)) {
        const pool = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
        tag = '';
        for (let i = 0; i < 3; i++) tag += pool[Math.floor(Math.random() * pool.length)];
        localStorage.setItem(OFFLINE_REF_KEY + ':tag', tag);
      }
      return tag;
    } catch (_) { return 'HL0'; }
  }

  function takeOfflineRef() {
    if (IS_DEMO) return '';
    const m = merchantSlug();
    const period = ticketPeriod();
    try {
      let n = 1;
      const raw = JSON.parse(localStorage.getItem(OFFLINE_REF_KEY) || 'null');
      if (raw && raw.m === m && +raw.period === period && Number.isInteger(+raw.n)) n = +raw.n + 1;
      localStorage.setItem(OFFLINE_REF_KEY, JSON.stringify({ m, period, n }));
      return 'HL-' + offlineDeviceTag() + '-' + n;
    } catch (_) {
      state.ticketStorageError = true;
      return '';
    }
  }

  function isOfflineRef(ref) { return /^HL-/.test(String(ref || '')); }

  function assignTicketNumber(ticket) {
    if (!ticket || ticket.num) return Promise.resolve(ticket && ticket.num);
    ticket.numbering = true;
    ticket.numError = false;
    return claimTicketNumber().then((n) => {
      /* The ticket object, not merely state.ticket, is captured. A reset while
         the request is in flight cannot put the old response on the new cart. */
      ticket.num = n;
      ticket.period = ticketPeriod();
      ticket.numbering = false;
      ticket.numError = false;
      if (state.ticket === ticket && root) { renderTicket(); icons(); }
      return n;
    }).catch((e) => {
      ticket.numbering = false;
      /* L'ÉCHEC DOIT SE VOIR TOUT DE SUITE, PAS AU MOMENT DE PAYER.
         Sans marque d'erreur, un ticket sans numéro reste bloqué sur
         « attribution… » : la vendeuse scanne tout le panier, la cliente sort sa
         carte, et c'est seulement là qu'on découvre que la caisse n'a jamais pu
         réserver de série. On distingue donc « en cours » de « échoué », pour
         que la tête du ticket le dise et propose de réessayer. */
      ticket.numError = true;
      if (state.ticket === ticket && root) { renderTicket(); icons(); }
      throw e;
    });
  }

  function nextStandaloneTicketNumber() {
    if (IS_DEMO) return Promise.resolve(String(saleSeq++));
    return claimTicketNumber();
  }

  function freshTicket() {
    const ticket = {
      num: IS_DEMO ? String(saleSeq) : '',
      period: ticketPeriod(),
      syncId: newSaleId(),
      lines: [], client: null, remiseAuth: false, numbering: false, numError: false,
      giftWrap: false, delivery: null,
    };
    state.ticket = ticket;
    if (!IS_DEMO) assignTicketNumber(ticket).catch(() => {
      if (state.ticket !== ticket) return;
      toast('Numéro de ticket indisponible', state.ticketStorageError
        ? 'Le stockage sécurisé de cette tablette est indisponible. Contactez le support.'
        : 'Reconnectez cette caisse pour réserver sa prochaine série.');
    });
  }
  function ticketClient() {
    const t = state.ticket;
    return t.client && t.client !== 'passage' ? clById(t.client) : null;
  }
  /* ── PROMOTIONS ───────────────────────────────────────────────────────────
   * La règle vit dans assets/promos.js ; ici on ne fait que la LIRE, par une
   * seule porte, pour que la grille, la fiche variante, le ticket et le reçu
   * annoncent tous le même prix. Deux lectures indépendantes du même catalogue
   * finissent toujours par diverger d'un arrondi, et c'est l'étiquette en rayon
   * qui contredit alors le ticket, devant la cliente.
   *
   * `stock` compte parce qu'une promotion peut viser « ce qui descend à N
   * pièces » : la projection vivante (celle que le ticket en cours entame) est
   * la bonne référence pour ce que le rayon affiche à cet instant. */
  function promoFor(pid) {
    const p = P[pid];
    if (!p || !window.KiwiPromos) return null;
    try {
      const pr = window.KiwiPromos.priceFor(p, { stock: promoStockOf(p) });
      return pr ? { ...pr, price: shelf(pr.price), was: shelf(pr.was) } : null;
    } catch (_) { return null; }
  }

  /* Promotions are authored against the catalogue unit. A service sold as one
     loose piece has a different unit price, so convert the promotion using its
     own kind instead of comparing a full-service price with a piece price.
     One door for the piece price: the sheet, the ticket and the exchange all
     read it here. `+null` is 0, so a catalogue piece price left empty (null)
     used to read as a free piece on the sheet while the ticket charged the
     set price divided by its pieces. */
  function pieceUnitPrice(p) {
    if (!p) return 0;
    return +p.piecePriceMAD > 0
      ? shelf(p.piecePriceMAD)
      : shelf((+p.price || 0) / Math.max(1, +p.servicePieces || 12));
  }
  function promoForLine(ln) {
    const live = promoFor(ln && ln.pid);
    if (!live || !ln || !ln.isPiece) return live;
    const p = P[ln.pid];
    const base = (ln.customPrice != null && Number.isFinite(+ln.customPrice)) ? shelf(ln.customPrice) : pieceUnitPrice(p);
    const per = Math.max(1, +(ln.servicePieces || (p && p.servicePieces)) || 12);
    const rule = live.promo || {};
    let price;
    if (rule.kind === 'percent') price = base * (100 - (+rule.value || 0)) / 100;
    else if (rule.kind === 'amount') price = base - (+rule.value || 0) / per;
    else if (rule.kind === 'fixed') price = live.price / per;
    else price = base * (live.price / Math.max(1, live.was));
    price = Math.min(base, shelf(price));
    return { ...live, was: base, price, off: base - price };
  }
  function promoStockOf(p) {
    if (!p) return 0;
    return stockOf(p) + sizesOf(p).reduce((sum, size) => sum + looseOf(p.id, size), 0);
  }
  /* ── LE PRIX D'UNE LIGNE : LE MEILLEUR DES DEUX ───────────────────────────
   * Le prix promo est estampillé sur la ligne quand elle entre sur le ticket
   * (voir addToTicket), et la règle est relue à chaque rendu. On retient le PLUS
   * BAS des deux. Les deux moitiés comptent, et pour des raisons opposées :
   *
   *   · la promotion se TERMINE pendant qu'une cliente attend au comptoir —
   *     l'estampille tient, on encaisse le prix annoncé au moment du scan. Une
   *     caisse qui remonte ses prix entre le rayon et le paiement, c'est une
   *     dispute au comptoir, et le magasin a tort.
   *   · la promotion COMMENCE pendant le ticket — la règle du jour prend le
   *     dessus. Sans ça, deux lignes du même article cohabitaient à 2 400 et
   *     2 160 sur le même ticket, et personne n'aurait su expliquer laquelle
   *     était la bonne.
   *
   * Une seule phrase à tenir devant la cliente : « on ne vous facture jamais
   * plus que le prix affiché au moment où l'article a été scanné, ni plus que
   * celui affiché maintenant. » C'est aussi ce qui rend un retour juste trois
   * jours plus tard : la ligne de vente porte le prix réellement payé. */
  function lineDeal(ln) {
    const stamp = (ln && ln.promo && Number.isFinite(+ln.promo.price)) ? { ...ln.promo, price: shelf(ln.promo.price) } : null;
    const live = promoForLine(ln);
    const p = P[ln.pid];
    const full = shelf((ln.customPrice != null && Number.isFinite(+ln.customPrice))
      ? +ln.customPrice
      : (p ? p.price : (ln.unit || 0)));
    let best = { price: full, promo: null };
    if (stamp && stamp.price < best.price) best = { price: stamp.price, promo: stamp };
    if (live && live.price < best.price) best = { price: live.price, promo: { price: live.price, badge: live.badge, name: live.promo.name, id: live.promo.id } };
    return best;
  }
  const linePromo = (ln) => lineDeal(ln).promo;
  const lineBase  = (ln) => lineDeal(ln).price;
  const lineUnit  = (ln) => shelf(lineBase(ln) * (100 - ln.remise) / 100);
  const lineTotal = (ln) => Math.round(lineUnit(ln) * 100) * ln.qty / 100;
  /* Remise fidélité au niveau du TICKET (distincte de la remise gérante par ligne).
     Attachée au client via clientId : si on détache/change la cliente, elle cesse
     de s'appliquer d'elle-même, sans avoir à la retirer partout à la main. */
  function rewardDiscount(t, base) {
    return loyaltyRewardDiscount(t.reward, t.client, base, t.lines.map(lineUnit));
  }
  /* Trois baisses, trois lignes séparées, jamais une seule « remise » fourre-tout :
     la promotion est une décision du magasin, la remise un geste de la gérante,
     la récompense un dû de la cliente. Les confondre au total, c'est rendre le
     rapport de clôture incapable de dire ce que les promotions ont coûté. */
  /* ═══════════════════════ DÉPÔT-VENTE (catégorie B) ═══════════════════════
   * Une partie du rayon appartient à des TIERS : le commerce la vend pour eux.
   * La vente est enregistrée normalement — ticket, journal des ventes, stock,
   * traçabilité — mais l'argent n'est pas une recette : il est DÛ au déposant.
   * On ne retire donc rien du journal, on ATTRIBUE.
   *
   * Deux vérités cohabitent, et il faut les deux :
   *   · le TIROIR encaisse le montant plein — la cliente paie ici, et la
   *     clôture doit tomber juste ;
   *   · sa RECETTE exclut ces lignes — ce n'est pas son chiffre d'affaires.
   * C'est exactement la discipline des avoirs plus bas : ce qui rentre en
   * caisse et ce qui compte comme vente ne sont pas le même nombre.
   *
   * Ce que la caisse ne fait PAS, volontairement : tenir le compte de ce qui
   * est dû à chaque déposant. Le reversement se règle ailleurs, hors caisse ;
   * un solde tenu ici serait un second livre à maintenir, jamais consulté et
   * faux dès le premier virement fait à côté. La caisse marque l'article,
   * enregistre la vente en entier, et sort le montant de la recette. */
  /* ── L'INTERRUPTEUR ──────────────────────────────────────────────────────
   * Le dépôt-vente est une option posée par l'opérateur Kiwi, commerce par
   * commerce (kiwi-admin.html › Modules → « Dépôt-vente »), et ÉTEINTE partout
   * ailleurs. La comparaison est stricte (`=== true`) pour la même raison
   * qu'Order Pro : une clé absente, un backend injoignable, une réponse vide —
   * tout cela doit répondre NON. Éteinte, la notion n'existe pas : pas de
   * repère B, pas de choix A/B, et un article resté marqué compte comme
   * n'importe quel autre. Les ventes DÉJÀ encaissées gardent, elles, les
   * montants figés sur leur ticket : allumer ou éteindre l'option ne réécrit
   * jamais le passé. */
  function depotOn() {
    try {
      return !!(window.KiwiConfig && window.KiwiConfig.features
        && window.KiwiConfig.features.depotvente === true);
    } catch (_) { return false; }
  }
  const isConsigned = (ln) => { const p = P[ln.pid]; return depotOn() && !!p && p.ownership === 'consignment'; };
  const isConsignedProduct = (p) => depotOn() && !!p && p.ownership === 'consignment';
  const consignedOf = (lines) => (lines || []).reduce((s, ln) => s + (isConsigned(ln) ? Math.round(lineTotal(ln) * 100) : 0), 0) / 100;
  function ticketTotals(t) {
    /* Tout en centimes entiers, puis redivisé : 249,90 + 0,10 fait 250, pas 249,99999. */
    const c = (v) => Math.round(v * 100);
    const sub = t.lines.reduce((s, ln) => {
      const p = P[ln.pid];
      const orig = shelf((ln.customPrice != null) ? ln.customPrice : (p ? p.price : 0));
      return s + c(orig) * ln.qty;
    }, 0) / 100;
    const afterPromo = t.lines.reduce((s, ln) => s + c(lineBase(ln)) * ln.qty, 0) / 100;
    const afterLines = t.lines.reduce((s, ln) => s + c(lineTotal(ln)), 0) / 100;
    const reward = c(rewardDiscount(t, afterLines)) / 100;
    const total = Math.max(0, c(afterLines) - c(reward)) / 100;
    /* `consigned` ≤ `total` : la remise fidélité s'applique au ticket entier,
       donc on borne pour qu'un ticket très remisé ne doive jamais au déposant
       plus que ce que la cliente a réellement payé. */
    const consigned = Math.min(total, consignedOf(t.lines));
    const d = (x, y) => (c(x) - c(y)) / 100;
    return { sub, promo: d(sub, afterPromo), remise: d(afterPromo, afterLines), reward, total, consigned, own: d(total, consigned) };
  }
  /* Le nom à écrire sur le reçu. Une seule promotion en jeu → son nom ; deux ou
     plus → le mot générique, parce qu'en nommer une seule laisserait croire que
     l'autre n'a pas été appliquée. */
  function promoLabelForTicket(t) {
    const names = [];
    t.lines.forEach((ln) => {
      const pr = linePromo(ln);
      if (pr && pr.name && names.indexOf(pr.name) < 0) names.push(pr.name);
    });
    return names.length === 1 ? names[0] : '';
  }
  const ticketCount = (t) => t.lines.reduce((s, ln) => s + ln.qty, 0);
  /* Sur salesToday(), jamais sur SALES : le journal garde une semaine pour les
     retours (voir RETAIN_DAYS), et sommer tout afficherait la recette de sept
     jours sous le mot « aujourd'hui ». */
  /* La recette du jour EXCLUT le dépôt-vente : ces montants sont dans le
     tiroir mais ils appartiennent aux déposants. Les ventes d'avant cette
     fonctionnalité n'ont pas de champ `own` — elles retombent sur `total`,
     ce qui est correct : à l'époque tout le rayon lui appartenait.
     Et l'argent QUI RENTRE, comme le serveur et le tableau de bord
     (originalSalePayload().amount) : la part réglée en avoir consomme une
     dette née d'une vente déjà comptée, et une livraison est une créance que
     le serveur enregistre à 0 (« Livraisons · à recevoir » au Z). Les compter
     ici gonflait l'en-tête « X MAD aujourd'hui ». Une vente relue du serveur
     porte déjà ce qu'il a encaissé. */
  const notCashedOf = (x) => (Array.isArray(x.parts) ? x.parts : [])
    .reduce((s, p) => s + (p && (p.m === 'avoir' || p.m === 'livraison') ? (+p.amount || 0) : 0), 0);
  const cashedOf = (x) => (x.remote && x.receivedAmount != null)
    ? Math.max(0, Number(x.receivedAmount) || 0)
    : Math.max(0, (x.own != null ? +x.own : (+x.total || 0)) - notCashedOf(x));
  const caToday = () => salesToday().reduce((s, x) => s + cashedOf(x), 0);
  function queueIfOffline(label) {
    if (!state.offline) return false;
    try {
      const q = window.KiwiLive && window.KiwiLive.queueStatus && window.KiwiLive.queueStatus();
      if (q) {
        state.queued = +q.pending || 0;
        state.syncStorageError = !!q.storageError;
        state.syncBlocked = state.syncStorageError || (+q.blocked || 0) > 0;
      }
    } catch (_) {}
    renderNet();
    toast(`${label}, enregistré sur cette caisse${state.queued ? ` (${state.queued} vente${state.queued > 1 ? 's' : ''} à synchroniser)` : ''}`);
    return true;
  }

  /* ═══════════════════════ MOUNT ═══════════════════════ */
  let root = null;

  /* Plein écran (mode kiosque) — la caisse resto l'a via le bandeau partagé du
     shell ; la boutique dessine son PROPRE rail, ce bandeau n'y apparaît pas,
     d'où l'absence du bouton signalée en boutique. On repose donc le même geste
     dans le rail boutique. Deux icônes (agrandir / réduire) dont on bascule
     `hidden` — aucun re-rendu lucide nécessaire. L'écouteur `fullscreenchange`
     n'est attaché qu'UNE fois (le rail est reconstruit à chaque montage). */
  function fsIsOn() { return !!(document.fullscreenElement || document.webkitFullscreenElement); }
  function fsToggle() {
    try {
      const r = fsIsOn()
        ? (document.exitFullscreen || document.webkitExitFullscreen || function () {}).call(document)
        : (function () { const el = document.documentElement; return (el.requestFullscreen || el.webkitRequestFullscreen || function () {}).call(el); })();
      if (r && r.catch) r.catch(function () {});   // certains contextes (iframe sandbox) rejettent — on ignore
    } catch (_) {}
  }
  function paintFs() {
    const b = root && $('#mz-fs', root); if (!b) return;
    const on = fsIsOn();
    const en = b.querySelector('[data-fs="enter"]'), ex = b.querySelector('[data-fs="exit"]');
    // `hidden` ne suffit pas ici : un reset `svg { display:block }` bat la règle
    // UA `[hidden]{display:none}` — on force donc le display en inline (spécificité max).
    if (en) en.style.display = on ? 'none' : '';
    if (ex) ex.style.display = on ? '' : 'none';
    const lb = b.querySelector('span'); if (lb) lb.textContent = on ? 'Quitter le plein écran' : 'Plein écran';
    b.setAttribute('aria-pressed', on ? 'true' : 'false');
    b.title = on ? 'Quitter le plein écran' : 'Plein écran';
  }
  function setupFullscreenBtn() {
    const b = $('#mz-fs', root); if (!b) return;
    b.addEventListener('click', fsToggle);
    paintFs();
    if (!setupFullscreenBtn._subbed) {
      setupFullscreenBtn._subbed = true;
      document.addEventListener('fullscreenchange', paintFs);
      document.addEventListener('webkitfullscreenchange', paintFs);
    }
  }

  function mount(rootEl) {
    root = rootEl;
    ensureStockJournal();
    syncTillStaff();
    /* On constitue la réserve de numéros DÈS l'ouverture, pendant que le réseau
       est là : c'est ce qui rend la vente hors ligne possible plus tard. */
    try { topUpTicketLease(); } catch (_) {}
    try {
      if (!IS_DEMO && window.addEventListener) window.addEventListener('online', () => { try { topUpTicketLease(); } catch (_) {} });
    } catch (_) {}
    /* A PAIRED caisse shows the real store's name/city (from onboarding); the
       unpaired demo (PIN 0002) keeps the Maison Mansour identity. */
    const _pv = (function () { try { return window.KiwiPlatform?.pairedVenue?.() || JSON.parse(localStorage.getItem('kiwiPairedVenue') || 'null'); } catch (_) { return null; } })();
    const _esc = (s) => String(s == null ? '' : s).replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
    const _vName = (_pv && _pv.name) ? _esc(_pv.name) : 'Vogue Home';
    const _vSub = (_pv && _pv.location) ? _esc(_pv.location) : (_pv ? '' : 'Tanger · Centre');
    root.innerHTML = `
      <aside class="mz-rail">
        <div class="mz-brand"><img class="kiwi-pos-logo" src="assets/kiwi-newlogo-inverse.svg" alt="Kiwi"></div>
        <div class="mz-venue">
          <div class="mz-venue-name">${_vName}</div>
          <div class="mz-venue-sub">${_vSub}${_vSub ? '<br>' : ''}Le même Kiwi, <b>un seul compte</b>.</div>
        </div>
        <nav class="mz-nav" id="mz-nav">
          <button class="mz-nav-it on" data-mz-view="vente"><i data-lucide="shopping-bag"></i><span>Vente</span><b class="mz-nav-badge" id="mz-badge-vente"></b></button>
          <button class="mz-nav-it" data-mz-view="mouvements"><i data-lucide="history"></i><span>Mouvements de stock</span></button>
          <button class="mz-nav-it" data-mz-view="casse"><i data-lucide="shield-alert"></i><span>Déclarer Casse</span></button>
          <button class="mz-nav-it" data-mz-view="scan"><i data-lucide="scan-line"></i><span>Scan</span><b class="mz-nav-badge" id="mz-badge-scan"></b></button>
          <button class="mz-nav-it" data-mz-view="inventaire"><i data-lucide="package"></i><span>Inventaire</span><b class="mz-nav-badge" id="mz-badge-inv"></b></button>
          <button class="mz-nav-it" data-mz-view="fournisseurs"><i data-lucide="truck"></i><span>Fournisseurs</span></button>
          <button class="mz-nav-it" data-mz-view="echanges"><i data-lucide="arrow-left-right"></i><span>Échanges &amp; avoirs</span><b class="mz-nav-badge" id="mz-badge-ret"></b></button>
          <button class="mz-nav-it" data-mz-view="vendus"><i data-lucide="chart-no-axes-column-increasing"></i><span>Vendus</span></button>
          <button class="mz-nav-it" data-mz-view="clientes"><i data-lucide="users"></i><span>Clients</span><b class="mz-nav-badge" id="mz-badge-cl"></b></button>
          <button class="mz-nav-it" data-mz-view="acomptes"><i data-icon="payments"></i><span>Acomptes</span></button><button class="mz-nav-it" data-mz-view="livraisons"><i data-icon="local_shipping"></i><span>Livraisons</span></button>
        </nav>
        <div class="mz-rail-foot">
          <button class="mz-lock" data-action="printer-connect" title="Configurer les imprimantes"><i data-lucide="printer"></i><span>Imprimantes</span></button>
          <button class="mz-net" id="mz-net" title="${IS_DEMO ? 'Simuler une coupure réseau' : 'État de la synchronisation'}">
            <i class="mz-net-dot"></i><span class="mz-net-label">En ligne</span>
          </button>
          <button class="mz-lock" id="mz-fs" title="Plein écran" aria-label="Basculer le plein écran" aria-pressed="false"><svg data-fs="enter" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M8 3H5a2 2 0 0 0-2 2v3"/><path d="M21 8V5a2 2 0 0 0-2-2h-3"/><path d="M3 16v3a2 2 0 0 0 2 2h3"/><path d="M16 21h3a2 2 0 0 0 2-2v-3"/></svg><svg data-fs="exit" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" style="display:none"><path d="M8 3v3a2 2 0 0 1-2 2H3"/><path d="M21 8h-3a2 2 0 0 1-2-2V3"/><path d="M3 16h3a2 2 0 0 1 2 2v3"/><path d="M16 21v-3a2 2 0 0 1 2-2h3"/></svg><span>Plein écran</span></button>
          ${IS_DEMO ? '' : '<button class="mz-lock" id="mz-close-day"><i data-lucide="power"></i><span>Fin de service</span></button>'}
          <button class="mz-lock" id="mz-lock"><i data-lucide="lock"></i><span>Verrouiller</span></button>
        </div>
      </aside>
      <main class="mz-main">
        <div class="mz-offline-note" id="mz-offline-note" hidden>
          Hors-ligne, les ventes sont enregistrées sur la tablette et synchronisées au retour du réseau.
          <b id="mz-queue-count"></b>
        </div>
        <section class="mz-view is-on" data-mz-panel="vente">
          <div class="mz-sell">
            <header class="mz-head">
              <div><h1>Vente</h1><div class="mz-head-sub" id="mz-today"></div></div>
              <div class="mz-head-hint">Scannez un code-barres, ou touchez un article</div>
            </header>
            <div id="mz-exch-slot"></div>
            <div class="mz-sell-scan">
              <i data-lucide="scan-line"></i>
              <input id="mz-sell-ean" placeholder="Scannez un code-barres pour l'ajouter au ticket…" autocomplete="off" />
              <span class="mz-sell-scan-tag">Entrée</span>
              ${pvReal() && camSupported()
                ? `<button class="mz-sell-cam" id="mz-sell-cam" title="Scanner avec la caméra" aria-label="Scanner avec la caméra"><i data-lucide="camera"></i></button>`
                : ''}
            </div>
            <div class="mz-cats" id="mz-cats"></div>
            <div class="mz-grid-scroll" id="mz-gridwrap"></div>
          </div>
          <aside class="mz-ticket" id="mz-ticket"></aside>
        </section>
        <section class="mz-view" data-mz-panel="mouvements"></section>
        <section class="mz-view" data-mz-panel="casse"></section>
        <section class="mz-view" data-mz-panel="scan"></section>
        <section class="mz-view" data-mz-panel="inventaire"></section>
        <section class="mz-view" data-mz-panel="fournisseurs"></section>
        <section class="mz-view" data-mz-panel="echanges"></section>
        <section class="mz-view" data-mz-panel="vendus"></section>
        <section class="mz-view" data-mz-panel="clientes"></section>
        <section class="mz-view" data-mz-panel="acomptes"></section><section class="mz-view" data-mz-panel="livraisons"></section>
      </main>
      <div class="modal-veil" id="mz-sheet-veil"><div class="modal mz-sheet mz-rel" id="mz-sheetm"></div></div>
      <div class="modal-veil" id="mz-approve-veil"><div class="modal mz-approve mz-rel" id="mz-approvem"></div></div>
      <div class="modal-veil" id="mz-client-veil"><div class="modal mz-client mz-rel" id="mz-clientm"></div></div>
      <div class="modal-veil" id="mz-fiche-veil"><div class="modal mz-fiche mz-rel" id="mz-fichem"></div></div>
      <div class="modal-veil" id="mz-exch-veil"><div class="modal mz-exch mz-rel" id="mz-exchm"></div></div>
      <div class="modal-veil" id="mz-pay-veil"><div class="modal mz-pay mz-rel" id="mz-paym"></div></div>
      <div class="modal-veil" id="mz-inv-veil"><div class="modal mz-invm mz-rel" id="mz-invmm"></div></div>
      <div class="modal-veil" id="mz-avoir-veil"><div class="modal mz-avoirm mz-rel" id="mz-avoirmm"></div></div>
      <div class="modal-veil" id="mz-delivery-veil"><div class="modal mz-delivery-modal mz-rel" id="mz-deliverym"></div></div>`;

    $('#mz-nav', root).addEventListener('click', (e) => {
      const b = e.target.closest('[data-mz-view]');
      if (b) switchView(b.dataset.mzView);
    });
    $('#mz-lock', root).addEventListener('click', () => {
      /* La feuille de clôture vit au niveau du body (au-dessus du root) : la
         laisser ouverte pendant le verrouillage la poserait sur l'écran PIN. */
      if (bqCloVeil) bqCloVeil.classList.remove('is-open');
      window.KiwiPosDispatch.lock();
    });
    const closeDay = $('#mz-close-day', root);
    if (closeDay) closeDay.addEventListener('click', bqOpenCloture);
    if (window.KiwiShiftNudge) window.KiwiShiftNudge.check({ host: root, scope: 'maison@' + merchantSlug(),
      openedAt: () => bqShift && bqShift.openedAt, open: bqOpenCloture, isBusy: () => state.checkoutBusy });
    $('#mz-net', root).addEventListener('click', toggleOffline);
    if (!mount._netBound) {
      mount._netBound = true;
      const refresh = () => syncNetworkState();
      window.addEventListener('online', () => { refresh(); try { bqReplayHeld(); } catch (_) {} });
      window.addEventListener('offline', refresh);
      window.addEventListener('kiwi:sale-queue', (e) => syncNetworkState(e && e.detail));
      window.addEventListener('storage', (e) => {
        if (!e || e.key === 'kiwiSaleQueue') syncNetworkState();
        if (e && e.key === TICKET_LEASE_KEY) ticketLease = null;
      });
    }
    syncNetworkState();
    setupFullscreenBtn();
    $$('.modal-veil', root).forEach((v) => {
      v.addEventListener('click', (e) => { if (e.target === v) closeVeil(v); });
    });

    /* Vente — scan-to-sell bar : a code scanned or typed here drops the article
       straight onto the ticket, supermarket-style. Commit on Enter only (the USB
       douchette ends every scan with Enter) so a scan is never counted twice. */
    const sellEan = $('#mz-sell-ean', root);
    if (sellEan) sellEan.addEventListener('keydown', (e) => {
      if (e.key !== 'Enter') return;
      const v = sellEan.value.trim();
      sellEan.value = '';
      if (v) commitEan(v);
    });
    wireSellSearch($('.mz-sell-scan', root), sellEan);   // peau 2027 : la liste qui répond au 1er chiffre
    /* Même barre, sans douchette : la caméra dépose l'article sur le ticket. */
    const sellCam = $('#mz-sell-cam', root);
    if (sellCam) sellCam.onclick = () => openCamScan(commitEan);

    /* live catalogue → the sale grid, the sheet and the douchette track the DB.
       A PAIRED caisse (assets/caisse-pairing.js sets __kiwiPairedBoutiqueVenue)
       uses the real store's own catalogue — the same per-venue key the dashboard
       writes — so a real boutique shows its real stock. Unpaired demo (PIN 0002)
       stays Maison Mansour. When either side edits the inventory, rebuild. */
    if (window.KiwiBoutiqueCatalog) {
      /* A real/paired store keys its OWN catalogue (venueId, else the merchant slug —
         the identity spine) and NEVER falls back to the Maison Mansour demo, even when
         the pairing record carries no venueId (a non-custom merchant). Only the unpaired
         local demo (PIN 0002) stays on Maison Mansour. */
      var _bqPv = pvPaired();
      _bqKey = (pvReal() && _bqPv && _bqPv.merchant)          /* real → merchant slug — SAME key the dashboard uses (pages-pro.js _bqxVenue) */
        || window.__kiwiPairedBoutiqueVenue
        || (_bqPv && (_bqPv.venueId || _bqPv.merchant))
        || (pvReal() ? realFallbackKey() : 'vogueHome');
      adoptLegacySharedCatalogue(_bqKey);
      window.KiwiBoutiqueCatalog.use(_bqKey);
      /* Les promotions suivent EXACTEMENT la même clé que le catalogue : ce sont
         les prix de ce magasin-là. Une promotion rangée sous une autre clé que
         les articles qu'elle vise remiserait le catalogue du voisin — et,
         au retour d'une démo, brader la vraie boutique. */
      if (window.KiwiPromos) {
        window.KiwiPromos.use(_bqKey);
        /* Remontée serveur : le patron pose la promotion depuis le bureau, le
           comptoir doit la voir sans qu'on aille toucher la tablette. Le slug
           est celui du commerce, pas la clé locale (voir localKey dans
           promos.js) — deux surfaces du même magasin rangent leur copie sous
           des noms différents mais parlent au même document. */
        try {
          if (pvReal() && window.KiwiCloudDoc) {
            window.KiwiPromos.cloud(() => window.KiwiCloudDoc.slugFor(_bqKey));
          }
        } catch (_) {}
        if (!mount._promoSubbed) {
          mount._promoSubbed = true;
          window.KiwiPromos.subscribe(() => {
            /* Une promotion qui change repeint les PRIX : la grille, le rayon
               courant, le badge du rail. Le ticket en cours, lui, garde ses prix
               figés — voir linePromo. */
            if (!root || intake.open) return;
            /* renderCats() aussi : le filtre « En promo » n'existe que s'il a
               quelque chose à montrer, donc il apparaît et disparaît AVEC les
               promotions. Le laisser hors du repeint, c'était un onglet qui ne
               s'affichait qu'au prochain changement de rayon. */
            try { renderCats(); renderView(state.view); renderBadges(); icons(); } catch (_) {}
          });
        }
      }
    }
    rebuildCatalog();
    injectInvCss();
    if (window.KiwiBoutiqueCatalog && !mount._subbed) {
      mount._subbed = true;
      window.KiwiBoutiqueCatalog.subscribe(() => {
        /* Pendant une reprise de stock, la projection de vente (RAYONS / P /
         * BY_EAN) n'est lue par personne : la grille est cachée, et les écrans de
         * saisie interrogent la base directement. La reconstruire à chaque
         * enregistrement — plusieurs fois par article scanné — ne servait qu'à
         * ralentir l'import. On la rebâtit une seule fois, à la fermeture
         * (voir intakeClose), donc la caisse retrouve un catalogue à jour avant
         * la première vente. */
        if (intake.open) return;
        rebuildCatalog();
        if (root) { pruneTicket(); refreshAfterCatalog(); }
      });
    }
    /* Même avertissement que la caisse boutique (assets/pos-boutique.js) : le
       stock n'a pas pris sur cette tablette, la vente continue, la baisse part
       au serveur. Un seul écouteur pour la page, quelle que soit la caisse. */
    if (window.KiwiBoutiqueCatalog && !window.__kiwiCatalogSaveWarn) {
      window.__kiwiCatalogSaveWarn = true;
      let lastWarn = 0;
      window.addEventListener('kiwi:local-save', (e) => {
        const d = (e && e.detail) || {};
        if (d.store !== 'catalog') return;
        if (d.durable) {
          if (lastWarn) { lastWarn = 0; toast('Stock de nouveau enregistré sur cette caisse', 3200, 'success'); }
          return;
        }
        const now = Date.now();
        if (lastWarn && now - lastWarn < 30000) return;
        lastWarn = now;
        toast('Stock non enregistré sur cette caisse', 9000, 'warn',
          'La vente continue et le stock part au serveur dès que le réseau le permet. Libérez du stockage avant de recharger la page.');
      });
      window.addEventListener('kiwi:catalog-conflict', (e) => { if (e.detail && e.detail.store === 'catalog') { e.preventDefault(); toast(e.detail.message, 9000, e.detail.kind); e.detail.sync(); } });
    }
    installWedgeScanner();

    /* Les ventes sorties des livres par la console opérateur. On écoute la
       liste, et on la redemande au montage : la caisse peut avoir été rouverte
       longtemps après le retrait, auquel cas l'annonce est passée sans nous mais
       l'état, lui, est toujours là (assets/live-link.js · voidedRefs). */
    if (!mount._voidsBound) {
      mount._voidsBound = true;
      document.addEventListener('kiwi-sales-voided', (e) => {
        try { reconcileVoids((e && e.detail && e.detail.refs) || [], !!(e && e.detail && e.detail.source === 'live-link')); } catch (_) {}
      });
    }
    try {
      if (window.KiwiLive && window.KiwiLive.voidedRefs) reconcileVoids(window.KiwiLive.voidedRefs());
    } catch (_) {}

    /* Pitch demo only: a mid-day sale already in progress. A REAL store starts with
       a truly empty ticket and NO client (attached on demand via « Chercher »). */
    freshTicket();
    if (IS_DEMO) seedDemoTicket();

    renderAll();
    syncReturnSales();
    ensureReturnCloud();
    /* Une vente retenue (voir bqHoldPost) repart dès que le commerce est
       résolu, puis à chaque minute tant qu'il en reste. */
    if (!IS_DEMO && !mount._heldTimer) {
      setTimeout(() => { try { bqReplayHeld(); } catch (_) {} }, 4000);
      mount._heldTimer = setInterval(() => {
        try { if (SALES.some((s) => s && s.pendingPost)) bqReplayHeld(); } catch (_) {}
      }, 60000);
    }

    /* Une vraie boutique ouvre son poste comme la caisse restaurant : fond
       d'ouverture d'abord, la vente ensuite. La démo entre directement. */
    mzKitRail(root, $, icons, mzKitReady(), (STAFF.caissiere && STAFF.caissiere.name) || '');   // peau 2027 : le rail de la boutique
    bqMaybeOpenScreen();
  }

  /* Pick the first two in-stock articles from the live catalogue for the
     mid-day demo ticket (ids are the DB's, not the old hard-coded literals). */
  function seedDemoTicket() {
    const picks = [];
    for (const r of RAYONS) {
      for (const it of r.items) {
        const size = firstFree(it);
        if (size) { picks.push({ pid: it.id, size, color: it.colors[0], qty: 1, remise: 0 }); }
        if (picks.length >= 2) break;
      }
      if (picks.length >= 2) break;
    }
    state.ticket.lines = picks;
    picks.forEach((ln) => holdStock(ln.pid, ln.size, ln.qty, ln.isPiece));
  }
  /* Drop ticket lines whose product vanished from the catalogue. */
  function pruneTicket() { if (state.ticket) state.ticket.lines = state.ticket.lines.filter((ln) => P[ln.pid]); }
  function refreshAfterCatalog() {
    if (!root) return;
    /* Pendant une reprise de stock, la liste d'inventaire est CACHÉE derrière le
     * formulaire : la redessiner à chaque enregistrement ne montre rien à
     * personne et coûte cher. invRow() et stats() relisent tous les variants pour
     * chaque produit — du O(produits × variants) — donc sur un import de plusieurs
     * milliers d'articles la caisse ralentissait scan après scan, exactement là où
     * elle doit rester vive. On redessine une fois, à la fermeture. */
    if (intake.open) return;
    try { renderCats(); renderView(state.view); renderBadges(); icons(); } catch (e) {}
  }

  function onShow() {
    if (!root) return;
    syncTillStaff();                      // a new shift may have unlocked the till
    bqMaybeOpenScreen();                  // re-unlock without a poste open → fond d'ouverture
    const today = $('#mz-today', root);
    if (today) today.textContent = headSubVente();
    renderBadges();
    renderView(state.view);
    icons();
  }

  function openVeil(id) { const v = $(id, root); v.classList.add('is-open'); return v; }
  function closeVeil(v) { (typeof v === 'string' ? $(v, root) : v).classList.remove('is-open'); }

  /* ═══════════════════════ NAV / SHELL ═══════════════════════ */
  function switchView(view) {
    state.view = view;
    $$('.mz-nav-it', root).forEach((b) => b.classList.toggle('on', b.dataset.mzView === view));
    $$('.mz-view', root).forEach((p) => p.classList.toggle('is-on', p.dataset.mzPanel === view));
    renderView(view);
    icons();
    mzKitRailPaint();   // la lentille du rail du kit suit la destination
    /* Le registre local s'affiche tout de suite, puis se rapproche du serveur.
       Une synchronisation lente ne doit jamais bloquer l'ouverture du rayon. */
    if (view === 'mouvements' && !state.movementSyncing && window.KiwiInventory?.sync) {
      state.movementSyncing = true;
      Promise.resolve(window.KiwiInventory.sync()).catch(() => null).then(() => {
        state.movementSyncing = false;
        if (state.view === 'mouvements') { renderMovements(); icons(); }
      });
    }
  }
  function renderView(view) {
    if (view === 'vente') { renderCats(); renderTicket(); renderGrid(); renderExchNote(); }
    if (view === 'mouvements') renderMovements();
    if (view === 'casse') renderCasse();
    if (view === 'scan') renderScan();
    if (view === 'inventaire') renderInventaire();
    if (view === 'fournisseurs') renderSuppliers();
    if (view === 'echanges') renderEchanges();
    if (view === 'vendus') {
      const panel = $('[data-mz-panel="vendus"]', root);
      if (window.KiwiSoldInsights) window.KiwiSoldInsights.renderTill(panel);
      else panel.innerHTML = '<div class="mz-empty" style="margin:40px;">Analyse des ventes indisponible.</div>';
    }
    if (view === 'clientes') renderClientes();
    if (view === 'acomptes') renderAcomptes(); if (view === 'livraisons') mzLivraisons($('[data-mz-panel="livraisons"]', root), { esc, icons, toast, fmtMAD, persistStock: (pid, size, color, delta, ref, why) => persistStock(pid, size, color, delta, { ref, why }), slug: merchantSlug, demo: IS_DEMO });
  }
  function renderBadges() {
    const items = state.ticket ? ticketCount(state.ticket) : 0;
    const avs = activeAvoirs().length;
    const set = (id, n) => {
      const el = $(id, root);
      if (!el) return;
      el.textContent = n || '';
      el.style.display = n ? '' : 'none';
    };
    set('#mz-badge-vente', items);
    set('#mz-badge-scan', state.scanLog.length);
    set('#mz-badge-ret', avs);
    set('#mz-badge-cl', (window.KiwiClients && KiwiClients.count && KiwiClients.count()) || CLIENTES.length);
    const invBadge = $('#mz-badge-inv', root);
    if (invBadge) { const st = window.KiwiBoutiqueCatalog ? window.KiwiBoutiqueCatalog.stats() : null; const n = st ? st.ruptures + st.low : 0; invBadge.textContent = n || ''; invBadge.style.display = n ? '' : 'none'; }
    mzKitRailPaint();   // le rail du kit lit ses compteurs sur ces pastilles
  }
  function headSubVente() {
    // Le compte de ventes suit la même règle que la recette : la journée, pas la
    // semaine conservée pour les retours.
    const n = salesToday().length;
    return `${fmtDT(new Date())} · ${n} vente${n > 1 ? 's' : ''} · ${fmtMAD(caToday())} aujourd'hui`;
  }
  function renderAll() {
    $('#mz-today', root).textContent = headSubVente();
    renderCats();
    renderGrid();
    renderTicket();
    renderExchNote();
    renderBadges();
    renderNet();
    icons();
  }
  /* merchant-config.js est en `defer` et interroge /api/config : la réponse
     arrive APRÈS le premier rendu. Si l'option s'allume à ce moment-là, la
     caisse redessine — sinon les repères B n'apparaîtraient qu'au prochain
     changement d'écran. */
  let _depotWas = depotOn();
  document.addEventListener('kiwi-config', () => {
    const now = depotOn();
    if (now === _depotWas) return;
    _depotWas = now;
    try { renderAll(); } catch (_) {}
  });

  function refreshOps() {
    renderBadges();
    renderView(state.view);
    icons();
  }

  async function issueAvoir(amount, cliente, motif, fromSaleId, context) {
    if (!IS_DEMO) {
      if (context && context.originalSale) fromSaleId = await ensureOriginalSale(context.originalSale);
      const requestId = (context && context.requestId) || creditIntent('credit-issue');
      const approval = await avoirApproval(amount, requestId, fromSaleId);
      const data = await creditRequest({
        action: 'issue', id: requestId, originalSaleId: fromSaleId, approval,
        originalRef: context && context.originalRef, amountCents: Math.round(amount * 100),
        customerId: cliente && cliente.id, customerName: cliente && cliente.name,
        reason: motif, expiresAt: Date.now() + 182 * 24 * 3600 * 1000,
        resellable: !context || context.resellable !== false,
        lines: context && context.lines,
      });
      const av = creditFromServer(data.credit);
      const old = AVOIRS.findIndex((item) => item.code === av.code);
      if (old >= 0) AVOIRS.splice(old, 1, av); else AVOIRS.unshift(av);
      persistAvoirs(); renderBadges();
      toast(`${av.code} émis, ${fmtMAD(amount)}`);
      return av;
    }
    const av = {
      code: `AV-${avSeq++}`,
      amount, balance: amount,
      holderId: cliente ? cliente.id : null,
      holderName: cliente ? cliente.name : 'Porteur du bon',
      motif, at: new Date(),
      until: new Date(Date.now() + 182 * 24 * 3600 * 1000),
      from: fromSaleId || null,
    };
    AVOIRS.unshift(av);
    persistAvoirs();                          // un bon émis doit survivre au rechargement de la caisse
    queueIfOffline(`Avoir ${av.code}`);
    toast(`${av.code} émis, ${fmtMAD(amount)}, pièces remises en stock`);
    renderBadges();
    return av;
  }

  function checkout() {
    const t = state.ticket;
    if (!t.lines.length) return;
    if (state.syncStorageError || state.ticketStorageError) {
      toast('Vente suspendue', 'La tablette ne peut plus sécuriser la file hors-ligne. Contactez le support avant de continuer.');
      return;
    }
    if (!IS_DEMO && t.period !== ticketPeriod()) {
      t.num = '';
      t.period = ticketPeriod();
    }
    if (!t.num) {
      assignTicketNumber(t).then(() => { if (state.ticket === t) checkout(); })
        .catch(() => toast('Numéro de ticket indisponible', state.ticketStorageError
          ? 'Le stockage sécurisé de cette tablette est indisponible. Contactez le support.'
          : 'Reconnectez cette caisse pour réserver sa prochaine série.'));
      return;
    }
    const tot = ticketTotals(t);
    const total = tot.total;
    const c = ticketClient();
    const RS = window.KiwiRepeatSale, repeatSig = RS ? RS.signature(t.lines.map(ln => Object.assign({}, ln, { unit: lineUnit(ln) })), total) : '';
    const beginPay = () => openPay({
      amount: total,
      customerId: c ? c.id : null,
      beforePaid: () => window.KiwiLoyaltyReserve.create({ isDemo: IS_DEMO, ticket: t, client: c, render: renderTicket, close: () => { state.checkoutBusy = false; closeVeil('#mz-pay-veil'); } }).confirm(),
      title: 'Encaissement',
      subtitle: `${t.num} · ${c ? esc(c.name) : 'Cliente de passage'}`,
      ref: t.num,
      lines: t.lines.map((ln) => ({
        qty: ln.qty,
        name: (P[ln.pid] ? P[ln.pid].name : 'Article') + (ln.size && ln.size !== 'TU' ? ' ' + ln.size : '') + (ln.isPiece ? ' (À la pièce)' : ''),
        amount: lineUnit(ln) * ln.qty,
        ref: ln.pid,
        barcode: (P[ln.pid] && P[ln.pid].barcode) || '',
        marque: ln.marque || (P[ln.pid] && P[ln.pid].marque) || '',
        motif: ln.motif || (P[ln.pid] && P[ln.pid].motif) || '',
        format: ln.format || (P[ln.pid] && P[ln.pid].format) || 'piece',
      })),
      subtotal: t.lines.reduce((s, ln) => {
        const p = P[ln.pid];
        const orig = shelf((ln.customPrice != null) ? ln.customPrice : (p ? p.price : 0));
        return s + orig * ln.qty;
      }, 0),
      promo: tot.promo ? { amount: tot.promo, label: promoLabelForTicket(t) } : null,
      discount: tot.remise + tot.reward,
      customer: c ? { name: c.name, phone: c.phone, points: c.points, loyalty: (t.reward && t.reward.clientId === t.client) ? t.reward.label : '' } : null,
      waName: c ? firstName(c.name) : null, waPhone: c ? c.phone : null,
      onPaid: (parts, paymentContext) => {
        const isAcompte = !!(paymentContext && paymentContext.partial);
        const receivedNow = isAcompte ? paymentContext.paidNow : total;
        if (isAcompte && (!c || !c.id || !window.KiwiRetailBalances || tot.consigned > 0)) {
          toast('Acompte : cliente requise, hors articles en dépôt-vente'); return { error: 'acompte-not-eligible' };
        }
        const rewardUsed = !!(t.reward && c && c.id && t.reward.clientId === c.id);
        const sale = {
          id: t.num, syncId: t.syncId || newSaleId(), tenderVersion: 2, at: new Date(), clientId: c ? c.id : null, by: STAFF.caissiere.name, kind: isAcompte ? 'acompte' : 'vente',
          /* Référence provisoire émise hors ligne : le journal doit le dire, la
             vente elle-même est complète et synchronisable. */
          offlineRef: isOfflineRef(t.num) || undefined,
          methods: parts.map((x) => x.m).join(' + '),
          parts: parts.map((x) => ({ m: x.m, amount: Math.round((+x.amount || 0) * 100) / 100 })),
          discount: bqMoney(tot.remise + tot.reward),
          remiseAuth: (t.remiseAuth && typeof t.remiseAuth === 'object')
            ? { by: t.remiseAuth.by || '', role: t.remiseAuth.role || '', at: t.remiseAuth.at, pct: t.remiseAuth.pct, amount: bqMoney(tot.remise) }
            : null,
          promoOff: bqMoney(tot.promo),
          giftWrap: !!t.giftWrap,
          delivery: t.delivery ? Object.assign({}, t.delivery) : null,
          lines: t.lines.map((ln) => ({
            pid: ln.pid, size: ln.size, color: ln.color, qty: ln.qty, remise: ln.remise, promo: linePromo(ln),
            unit: lineUnit(ln), returned: false, note: '', format: ln.format, isPiece: ln.isPiece,
            marque: ln.marque, motif: ln.motif, fragile: ln.fragile, registryId: ln.registryId,
            name: (P[ln.pid] && P[ln.pid].name) || ln.name || 'Article',
            category: rayonOf(ln.pid) || '',
            variantId: [ln.pid, ln.size || '', ln.color || ''].join(':'),
            /* Figé à l'encaissement : si l'article cesse d'être en dépôt-vente
               demain, le journal d'hier doit rester vrai. */
            consigned: isConsigned(ln)
          })),
          reward: rewardUsed ? t.reward.label : null,
          total: receivedNow,
          balanceTotal: isAcompte ? total : null,
          balanceDue: isAcompte ? Math.round((total - receivedNow) * 100) / 100 : 0,
          /* `total` = ce que la cliente a payé (et ce que le tiroir contient).
             `consigned` = la part qui appartient aux déposants. `own` = la
             recette réelle du commerce. Les trois sont écrites : rien n'est
             retiré du journal, tout est attribué. */
          consigned: bqMoney(tot.consigned),
          own: isAcompte ? receivedNow : bqMoney(tot.own),
        };
        const balanceId = isAcompte ? 'rb-' + sale.syncId : '';
        if (isAcompte) {
          const savedBalance = window.KiwiRetailBalances.record(merchantSlug(), {
            id: balanceId, customerId: c.id, ticketRef: sale.id,
            totalCents: Math.round(total * 100), receipt: {
              id: sale.syncId, amountCents: Math.round(receivedNow * 100),
              method: bqPaymentMethod(parts), ts: +sale.at,
            },
          });
          if (!savedBalance) { toast('Acompte non conservé : stockage local indisponible'); return { error: 'balance-storage-failed' }; }
          bqOutstandingCents = window.KiwiRetailBalances.read(merchantSlug())
            .reduce((sum, row) => sum + window.KiwiRetailBalances.due(row), 0);
        }
        SALES.unshift(sale);
        persistDay();
        bqSaveProvisional(isAcompte);
        if (IS_DEMO) saleSeq++;
        sale.lines.forEach((ln) => persistStock(ln.pid, ln.size, ln.color, -(ln.units != null ? ln.units : ln.qty), { ref: sale.num || sale.id, why: 'vente' }));
        if (typeof updateRegistryContribution === 'function') updateRegistryContribution(sale);
        try {
          if (window.KiwiLive && window.KiwiLive.isOn()) {
            const received = (parts || []).filter((x) => x && x.m !== 'avoir' && x.m !== 'livraison' && (+x.amount || 0) > 0);
            const receivedMethods = received.map((x) => x.m);
            const method = bqPaymentMethod(parts);
            const first = t.lines[0];
            const pieces = t.lines.reduce((n, ln) => n + ln.qty, 0);
            const name = (first && P[first.pid]) ? P[first.pid].name : 'Vente';
            const label = t.lines.length > 1 ? (name + ' +' + (pieces - first.qty) + ' art.') : name;
            /* On remonte l'argent QUI RENTRE, pas la valeur du ticket. Un avoir
               n'est pas un encaissement : c'est la consommation d'une dette née
               d'une vente déjà comptée. Remonter le total, c'est compter deux
               fois — un caftan à 1 200 rendu puis réglé avec l'avoir affichait
               2 400 MAD de recette pour 1 200 MAD réellement pris. Réglé
               entièrement en avoir, il ne reste rien à remonter et postSale
               (montant ≤ 0) passe son tour, ce qui est le bon comptage.
               sale.total garde la valeur du ticket : c'est la vente, pas la caisse. */
            let cashIn = received.reduce((s, x) => s + (+x.amount || 0), 0);
            /* Même raisonnement que l'avoir juste au-dessus, pour une autre
               raison : l'argent du dépôt-vente entre bien dans le tiroir, mais
               il n'est pas à elle. Le remonter gonflerait son chiffre d'affaires
               d'une somme qu'elle doit reverser. La vente reste enregistrée —
               c'est l'ATTRIBUTION qui change, pas l'existence de la vente. */
            cashIn = Math.max(0, bqMoney(cashIn - bqMoney(tot.consigned)));
            /* LE PANIER, qui ne partait pas. On ne remontait que {montant,
               moyen, libellé}, et le libellé est un RÉSUMÉ de ticket
               (« Caftan +3 art. ») : le tableau de bord ne pouvait donc pas dire
               à la patronne combien de jeans noirs elle avait vendus, alors que
               la caisse le savait ligne par ligne. Le rayon voyage avec chaque
               ligne — c'est lui qui fait tenir le « Catégorie : Jeans » du
               rapport de fin de journée même si le rayon est renommé plus tard.
               Bornes identiques à celles de /api/sale : 40 lignes, 60 signes. */
            const lineTotals = bqLineTotals(t.lines.map((ln) => lineUnit(ln) * ln.qty), tot.total);
            const basket = bqFoldBasket(t.lines.map((ln, i) => ({
              itemId: ln.pid,
              variantId: [ln.pid, ln.size || '', ln.color || ''].join(':'),
              name: (P[ln.pid] ? P[ln.pid].name : 'Article') + (ln.size ? ' ' + ln.size : ''),
              qty: ln.qty,
              total: lineTotals[i],
              cat: rayonOf(ln.pid) || '',
              unit: 'piece',
              kind: 'product',
            })));
            /* Réglée entièrement en avoir : aucun argent n'entre, mais la
               marchandise sort. On le DIT, avec le montant d'avoir consommé,
               pour que le panier arrive quand même au serveur — sinon la vente
               n'existe nulle part ailleurs que sur cette tablette. */
            const creditIn = (parts || []).reduce((sum, x) => sum + (x && x.m === 'avoir' ? (+x.amount || 0) : 0), 0);
            const payload = {
              id: sale.syncId,
              amount: cashIn,
              amountCents: Math.round(cashIn * 100),
              ticketAmountCents: Math.round(receivedNow * 100),
              consignedAmountCents: Math.round(tot.consigned * 100),
              method: method,
              paymentParts: bqPaymentParts(parts),
              discountPercents: [...new Set(t.lines.map(ln => Number(ln.remise)).filter(n => n > 0))],
              channel: (parts || []).some((x) => x && x.m === 'livraison') ? 'delivery' : 'counter', deliveryCard: ((parts || []).find((x) => x && x.m === 'livraison' && x.card) || {}).card,
              label: isAcompte ? 'Acompte · ' + label : label,
              ref: sale.id,
              time: sale.at,
              lines: basket,
            };
            if (isAcompte) payload.retailBalance = {
              id: balanceId, customerId: c.id, ticketRef: sale.id,
              totalCents: Math.round(total * 100), stage: 'open',
            };
            if (cashIn <= 0 && creditIn > 0 && basket.length) {
              payload.settlementKind = 'store-credit';
              payload.creditAmountCents = Math.round(creditIn * 100);
            } else if (cashIn <= 0 && tot.consigned >= total && basket.length) {
              payload.settlementKind = 'consignment';
            } else if (cashIn <= 0 && (parts || []).some((x) => x && x.m === 'livraison') && basket.length) {
              payload.settlementKind = 'receivable';
            }
            bqPost(sale, payload);
          }
        } catch (_) {}
        let ptsLine = '';
        if (c) {
          // Persist the purchase to the SHARED client book (spend + points + visit)
          // so the owner's dashboard client directory + loyalty reflect it — a real
          // store's sale must attach to the real client, not a throwaway in-memory
          // object. Real store only; the local demo keeps its in-memory client. F5.
          /* Le toast dit les points réellement crédités, comme la boutique : il
             annonçait un point pour 10 MAD, codé en dur, quel que soit le programme. */
          let pts = 0;
          const ptsBefore = Number(c.points) || 0;
          if (useKiwiCl() && window.KiwiClients && window.KiwiClients.recordPurchase && c.id) {
            try { const res = window.KiwiClients.recordPurchase(c.id, {
              amount: receivedNow, method: sale.methods, saleRef: sale.id, saleId: sale.syncId, eventRef: sale.syncId, createdAt: +sale.at,
              items: sale.lines.map((ln) => ({ name: (P[ln.pid] && P[ln.pid].name) || ln.name || 'Article', qty: ln.qty, total: ln.unit * ln.qty, id: ln.pid || '' })),
            }); if (res && res.client && !res.replayed) pts = Math.max(0, (Number(res.client.points) || 0) - ptsBefore); } catch (_) {}
            // La récompense est portée : on retire le seuil (KiwiClients.redeem),
            // après recordPurchase pour que l'achat compte d'abord. Sans réservation,
            // LA VENTE nomme la remise · assets/loyalty-reward.js
            if (rewardUsed && window.KiwiClients.redeem) {
              try { window.KiwiClients.redeem(c.id, null, (t.reward && t.reward.reservation) || { ref: window.KiwiClients.redemptionRef(c.id, sale.syncId || sale.id) }); } catch (_) {}
            }
          }
          if (!useKiwiCl()) {
            const cfg = window.KiwiClients && window.KiwiClients.config ? window.KiwiClients.config() : null;
            pts = cfg && cfg.model === 'amount' ? Math.floor(receivedNow * ((cfg.amount && cfg.amount.perMad) || 1) + 1e-6) : 0;
          }
          c.points = ptsBefore + pts;
          c.achats += 1;
          ptsLine = (pts ? ` · +${pts} pts pour ${firstName(c.name)}` : '') + (rewardUsed ? ` · récompense ${t.reward.label}` : '');
        }
        if (RS) RS.remember('maison', repeatSig, sale.id);
        queueIfOffline(`Vente ${sale.id}`);
        freshTicket();
        $('#mz-today', root).textContent = headSubVente();
        renderTicket(); renderGrid(); renderBadges(); icons();
        const delivery = parts.some((x) => x.m === 'livraison');
        return { ref: sale.id, sale, delivery, line: delivery
          ? `Vente ${sale.id} en livraison, ${fmtMAD(total)} à recevoir${ptsLine}`
          : `Vente ${sale.id} encaissée, ${fmtMAD(total)}${ptsLine}` };
      },
    });
    if (!(RS && RS.confirmRepeat({ scope: 'maison', sig: repeatSig, el: $('#mz-paym', root), open: () => openVeil('#mz-pay-veil'), close: () => closeVeil('#mz-pay-veil'), busy: () => {}, go: () => state.ticket === t && beginPay(), classes: { x: 'mz-modal-x', foot: 'mz-sheet-foot', no: 'mz-btn secondary', yes: 'cash-confirm' } }))) beginPay();
  }
  function payExistingBalance(row) {
    const R = window.KiwiRetailBalances;
    if (!R || row.pendingCents > 0) { toast('Synchronisation de l’acompte en attente'); return; }
    const remaining = R.due(row) / 100;
    if (!(remaining > 0)) { toast('Cette note est déjà réglée'); renderAcomptes(); return; }
    const client = clById(row.customerId);
    openPay({
      amount: remaining, balanceExisting: true, balanceTotal: row.totalCents / 100,
      balancePaid: row.paidCents / 100, customerId: row.customerId,
      title: 'Régler un acompte', subtitle: `${row.ticketRef} · ${client ? esc(client.name) : 'Cliente'}`,
      ref: row.ticketRef, lines: [], customer: client ? { name: client.name, phone: client.phone } : null,
      waName: client ? firstName(client.name) : '', waPhone: client ? client.phone : '',
      onPaid: (parts, context) => {
        const amount = context.paidNow;
        const at = new Date();
        const syncId = newSaleId();
        const method = bqPaymentMethod(parts);
        const sale = {
          id: row.ticketRef + '-P' + at.getTime(), syncId, tenderVersion: 2, at,
          clientId: row.customerId, by: STAFF.caissiere.name, kind: 'acompte-reglement',
          methods: parts[0].m, parts: [{ m: parts[0].m, amount }], lines: [], total: amount,
          balanceTotal: row.totalCents / 100,
          balanceDue: Math.max(0, (R.due(row) / 100) - amount),
        };
        const saved = R.record(merchantSlug(), {
          id: row.id, customerId: row.customerId, ticketRef: row.ticketRef,
          totalCents: row.totalCents, basePaidCents: row.paidCents,
          receipt: { id: syncId, amountCents: Math.round(amount * 100), method, ts: +at },
        });
        if (!saved) { toast('Règlement non conservé : stockage local indisponible'); return { error: 'balance-storage-failed' }; }
        bqOutstandingCents = R.read(merchantSlug()).reduce((sum, item) => sum + R.due(item), 0);
        SALES.unshift(sale); persistDay(); bqSaveProvisional(true);
        try { if (window.KiwiLive && window.KiwiLive.isOn()) bqPost(sale, {
          id: syncId, amount, amountCents: Math.round(amount * 100), method,
          paymentParts: bqPaymentParts(parts), ticketAmountCents: Math.round(amount * 100),
          label: 'Règlement acompte', ref: row.ticketRef, time: at, channel: 'counter',
          retailBalance: { id: row.id, customerId: row.customerId, ticketRef: row.ticketRef,
            totalCents: row.totalCents, stage: 'payment' },
        }); } catch (_) { /* the local journal remains readable */ }
        renderAcomptes(); renderAll();
        return { sale, line: `Reçu ${fmtMAD(amount)} · reste ${fmtMAD(sale.balanceDue)}` };
      },
    });
  }

  /* ═══════════════════════ FIN DE SERVICE ═══════════════════════
     Le cycle de poste de la caisse restaurant, porté à la boutique : fond
     d'ouverture au déverrouillage, clôture avec tiroir-caisse et comptage,
     rapport Z imprimé et classé (KiwiDayReport) — le MÊME document que le
     tableau de bord rouvre le lendemain, rangé sous le même slug. Réservé aux
     VRAIES boutiques : la démo (PIN 0002) garde son entrée directe — elle n'a
     ni tiroir ni comptabilité, et KiwiDayReport refuse de toute façon
     d'archiver une démo. L'écran d'ouverture et la feuille de clôture
     réutilisent les styles .clockin-* / .clo-* de kiwi-caisse.html : même
     geste, même dessin, zéro CSS dupliqué. */

  const BQ_SHIFT_KEY = 'kiwi:bqShift';
  let bqShift = null;               /* { openedAt: ms, openedBy, float } */
  (function bqShiftRestore() {
    if (IS_DEMO) return;
    try {
      const s = JSON.parse(localStorage.getItem(BQ_SHIFT_KEY) || 'null');
      /* Maison annonce ses postes depuis l'ouverture : un poste plus ancien
         que le drapeau openSent l'a déjà été. */
      if (s && +s.openedAt > 0) bqShift = { openedAt: +s.openedAt, openedBy: String(s.openedBy || ''), float: +s.float || 0,
        sid: String(s.sid || ''), openSent: s.openSent !== false };
    } catch (_) {}
  })();
  /* ── LE RÉCONCILIATEUR DOIT VOIR CE COMPTOIR ───────────────────────────────
   * La caisse maison tenait son poste entièrement pour elle : aucun événement
   * de session n'était émis, donc `cash_session_events` restait vide pour ce
   * commerce et le rapprochement de caisse regardait un terminal qui, pour lui,
   * n'avait jamais ouvert ni fermé. On émet donc les deux bornes du poste —
   * ouverture (fond) et clôture (attendu / compté / écart) — par le MÊME canal
   * durable que les autres verticales (KiwiCashSessions, boîte d'envoi hors
   * ligne comprise). Aucun chiffre n'est recalculé ici : ils viennent du
   * rapport Z, le document qui fait foi. */
  /* L'identifiant est posé à l'ouverture et ne bouge plus : l'ouverture et la
     clôture d'un même poste doivent toujours se retrouver au registre. */
  function bqSessionId() {
    return bqShift && bqShift.sid ? bqShift.sid : 'bq-' + (bqShift && bqShift.openedAt ? bqShift.openedAt : 0);
  }
  /* L'ouverture, annoncée une fois. Sans elle le serveur refuse la clôture
     (session-not-open) et la caisse finit par la mettre de côté. */
  function bqAnnounceOpen() {
    if (!bqShift || bqShift.openSent) return false;
    if (!bqCashEvent('open', { countedCents: bqCents(bqShift.float) })) return false;
    bqShift.openSent = true;
    bqShiftPersist();
    return true;
  }
  function bqActorId() {
    const s = (STAFF && STAFF.caissiere) || {};
    /* Jamais un code : un code de caisse est un secret, pas une identité. */
    return String(s.id || s.name || 'caisse');
  }
  function bqCashEvent(eventType, extra) {
    if (IS_DEMO) return false;
    const CS = window.KiwiCashSessions;
    if (!CS || typeof CS.emit !== 'function' || !bqShift || !bqShift.openedAt) return false;
    try {
      return CS.emit(Object.assign({
        sessionId: bqSessionId(),
        eventType,
        actorId: bqActorId(),
        openedAt: bqShift.openedAt,
        occurredAt: Date.now(),
      }, extra || {}));
    } catch (_) { return false; }
  }
  const bqCents = (v) => Math.round((+v || 0) * 100);

  function bqShiftPersist() {
    try {
      if (bqShift) localStorage.setItem(BQ_SHIFT_KEY, JSON.stringify(bqShift));
      else localStorage.removeItem(BQ_SHIFT_KEY);
    } catch (_) {}
  }

  /* Ce que chaque vente a réellement mis dans le tiroir. Les parts de règlement
     sont figées sur la vente à l'encaissement (sale.parts) ; une vente d'avant
     cette version n'en porte pas, et on retombe sur `methods` — exact pour un
     règlement simple, et pour un mixte le total est posé sur le premier moyen
     monétaire (approximation limitée au jour de la transition). Un avoir n'est
     jamais de l'argent qui rentre : il consomme une dette déjà comptée. */
  function bqMoneyParts(s) {
    if (Array.isArray(s.parts) && s.parts.length) {
      return s.parts.filter((p) => p && p.m !== 'avoir' && +p.amount > 0)
        .map((p) => ({ m: p.m, amount: +p.amount }));
    }
    const names = String(s.methods || '').split(' + ').filter((m) => m && m !== 'avoir');
    /* Vente importée : seul ce que le serveur a reçu est de l'argent. Un ticket
       réglé par avoir arrivait en « credit » à 0 et comptait sa valeur entière. */
    const amount = s.remote && Number.isFinite(+s.receivedAmount) ? Math.min(+s.total || 0, +s.receivedAmount) : +s.total;
    return names.length && amount > 0 && !(s.remote && names[0] === 'livraison') ? [{ m: names[0], amount }] : [];
  }
  const BQ_SRV_METHOD = { 'espèces': 'cash', 'carte': 'card', 'virement': 'transfer', 'chèque': 'cheque', 'avoir': 'credit', 'livraison': 'delivery' };
  function bqPaymentParts(parts) {
    const by = new Map();   // le serveur refuse plus de huit lignes (_retail-tenders.js) : les parts d'un même mode s'additionnent
    (parts || []).filter((part) => part && +part.amount > 0).forEach((part) => { const m = BQ_SRV_METHOD[part.m] || 'wallet'; by.set(m, (by.get(m) || 0) + Math.round((+part.amount || 0) * 100)); });
    return Array.from(by, ([method, amountCents]) => ({ method, amountCents })).filter((part) => part.amountCents > 0);
  }
  function bqPaymentMethod(parts) {
    const methods = bqPaymentParts(parts);
    if (methods.length === 1) return methods[0].method;
    if (methods.some((part) => part.method !== 'credit' && part.method !== 'delivery')) return 'split';
    return methods.some((part) => part.method === 'delivery') ? 'delivery' : 'credit';
  }

  function bqDayTotals(only) {
    const t = { moneyIn: 0, cash: 0, card: 0, transfer: 0, cheque: 0, delivery: 0, other: 0, txns: 0, paidTxns: 0, items: 0, discounts: 0, discountsN: 0, promoOff: 0, avoirUsed: 0, avoirUsedN: 0, avoirIssued: 0, avoirIssuedN: 0, acompteReceived: 0, outstanding: 0 };
    zSalesFor(salesToday(), only).forEach((s) => {
      let took = 0; const away = only === 'store' && zIsDelivery(s);   /* livraison vue du Z magasin : l'argent du comptoir seul */
      /* L'avoir consommé, compté À PART du reste. bqMoneyParts l'écarte — à
         raison, ce n'est pas de l'argent qui rentre — mais l'écarter du total
         ne dispense pas de le dire : la marchandise, elle, est bien sortie du
         magasin. Sans cette ligne, un Z pouvait laisser partir 1 200 MAD de
         stock contre un avoir sans qu'aucun chiffre de la clôture ne bouge. */
      let onAvoir = 0;
      if (Array.isArray(s.parts)) s.parts.forEach((p) => { if (p && p.m === 'avoir') onAvoir += +p.amount || 0; });
      if (onAvoir > 0 && !away) { t.avoirUsed += onAvoir; t.avoirUsedN++; }
      zSplitParts(s, bqMoneyParts(s), only).forEach((p) => {
        if (p.m !== 'livraison') took += p.amount;
        if (p.m === 'espèces') t.cash += p.amount;
        else if (p.m === 'carte') t.card += p.amount;
        else if (p.m === 'virement') t.transfer += p.amount;
        else if (p.m === 'chèque') t.cheque += p.amount;
        else if (p.m === 'livraison') t.delivery += p.amount;
        else t.other += p.amount;
      });
      if (took > 0) { t.moneyIn += took; t.paidTxns++; }
      if (s.kind === 'acompte' || s.kind === 'acompte-reglement') t.acompteReceived += took; if (away) return;   /* le ticket, ses articles et sa remise partent sur le Z livraisons */
      /* DEUX compteurs, parce qu'il y a deux questions. `paidTxns` ne retient
         que les tickets qui ont fait entrer de l'argent — c'est le diviseur du
         ticket moyen. `txns` compte TOUS les tickets du jour, y compris celui
         réglé entièrement par avoir ou parti en livraison : sans lui, la
         clôture affichait « Transactions 6 · Articles vendus 6 » alors que les
         articles, eux, étaient comptés sur sept tickets. Deux lignes voisines
         qui ne parlaient pas de la même journée. */
      t.txns++;
      (s.lines || []).forEach((ln) => { t.items += lineAvailableQty(ln); });
      const d = +s.discount || 0;
      if (d > 0) { t.discounts += d; t.discountsN++; }
      /* Compté À PART des réductions. Une gérante qui voit « 4 200 MAD de
         réductions accordées » sans savoir que 3 900 viennent de la promotion
         qu'elle a elle-même lancée croit que son équipe brade le magasin. */
      t.promoOff += +s.promoOff || 0;
    });
    /* Les deux sens de l'avoir sur la même journée : ce qui a été ÉMIS (une
       dette que le magasin vient de contracter) et ce qui a été CONSOMMÉ (une
       dette qu'il vient d'éteindre en marchandise). Les additionner serait un
       contresens ; les taire l'était aussi. */
    if (only !== 'delivery') AVOIRS.forEach((a) => {
      if (!a || !a.at || !isToday(a.at)) return;
      const v = +a.amount || 0;
      if (v > 0) { t.avoirIssued += v; t.avoirIssuedN++; }
    });
    t.outstanding = only === 'delivery' ? 0 : bqOutstandingCents / 100;
    ['moneyIn', 'cash', 'card', 'transfer', 'cheque', 'delivery', 'other', 'discounts', 'promoOff', 'avoirUsed', 'avoirIssued', 'acompteReceived'].forEach((k) => { t[k] = Math.round(t[k] * 100) / 100; });
    return t;
  }

  /* Le journal du jour, traduit vers la forme que KiwiDayReport.build attend.
     Une entrée PAR PART monétaire — la même écriture que la caisse restaurant,
     où chaque part d'un règlement partagé passe par recordSale : c'est ce qui
     rend le tiroir exact quand un ticket est réglé moitié carte moitié espèces.
     Le panier ne voyage qu'avec la première part, sinon le classement par
     rayon compterait chaque article deux fois. */
  function bqReportSales(only) {
    const out = [];
    zSalesFor(salesToday(), only).forEach((s) => {
      const at = (s.at instanceof Date ? s.at : new Date(s.at)).getTime(), away = only === 'store' && zIsDelivery(s);
      const lines = (away ? [] : s.lines || []).filter((ln) => lineAvailableQty(ln) > 0).map((ln) => ({
        name: ((P[ln.pid] && P[ln.pid].name) || 'Article') + (ln.size ? ' ' + ln.size : ''),
        qty: lineAvailableQty(ln),
        total: Math.round((+ln.unit || 0) * lineAvailableQty(ln) * 100) / 100,
        cat: rayonOf(ln.pid) || '',
      }));
      const taken = zSplitParts(s, bqMoneyParts(s), only);
      if (s.syncId && taken.length) {
        out.push({ id: s.syncId, ts: at,
          amount: taken.reduce((sum, part) => sum + part.amount, 0),
          method: bqPaymentMethod(zSentParts(s, only)),
          parts: bqPaymentParts(taken),
          label: s.kind === 'echange' ? 'Différence échange' : s.kind === 'acompte' ? 'Acompte' : s.kind === 'acompte-reglement' ? 'Règlement acompte' : 'Vente',
          ref: s.id, cashier: s.by || '', lines: lines.length ? lines : null });
        return;
      }
      let first = true;
      taken.forEach((p, i) => {
        out.push({
          id: s.id + (i ? '#' + i : ''),
          ts: at,
          amount: p.amount,
          method: BQ_SRV_METHOD[p.m] || 'wallet',
          label: s.kind === 'echange' ? 'Différence échange' : s.kind === 'acompte' ? 'Acompte' : s.kind === 'acompte-reglement' ? 'Règlement acompte' : 'Vente',
          ref: s.id,
          cashier: s.by || '',
          lines: first && lines.length ? lines : null,
        });
        first = false;
      });
    });
    return out;
  }

  function bqReportSession(counted, only) {
    const t = bqDayTotals(only);
    return {
      openedAt: bqShift ? bqShift.openedAt : 0,
      openedBy: bqShift ? bqShift.openedBy : '',
      closedBy: (STAFF.caissiere && STAFF.caissiere.name) || '',
      openingFloat: only !== 'delivery' && bqShift ? bqShift.float : 0,
      cashMovements: [], handovers: [],
      discounts: t.discounts, discountsCount: t.discountsN, cancels: 0,
      /* L'avoir voyage jusqu'au rapport, sinon il ne sort que sur l'écran de
         clôture et disparaît du Z imprimé — le seul document qui reste. */
      avoirs: { issued: t.avoirIssued, issuedCount: t.avoirIssuedN, used: t.avoirUsed, usedCount: t.avoirUsedN },
      acomptes: { received: t.acompteReceived, outstanding: t.outstanding },
      countedCash: only === 'delivery' ? null : counted,
    };
  }
  /* La journée commerciale EN COURS, comme closeRegister() côté restaurant.
     Une boutique de souk ouverte jusqu'après minuit reste sur UNE journée grâce
     à la coupure de 05:00 (businessDay), pas grâce à la date d'ouverture. Un
     poste resté ouvert depuis la veille classait les ventes du jour (salesToday)
     sous la date d'ouverture, où le calcul n'en gardait aucune : la veille était
     réécrite à 0 et le jour qui vendait n'avait pas de rapport. */
  function bqBuildReport(counted, closedAt, only) {
    const DR = window.KiwiDayReport;
    if (!DR) return null;
    const sess = bqReportSession(counted, only);
    if (closedAt) sess.closedAt = closedAt;
    const pv = pvPaired() || {};
    return DR.build({
      day: DR.businessDay(tillNow()),
      sales: bqReportSales(only),
      session: sess,
      store: { slug: DR.storeSlug(), name: pv.name || '', location: pv.location || '', type: pv.type || 'boutique' },
      source: 'caisse',
    });
  }
  /* L'instantané provisoire (closed:false) tient le tableau de bord à jour
     pendant le service, sans compter comme une clôture — même contrat que
     saveProvisional() côté restaurant. */
  let bqLastProv = 0;
  /* Le rapprochement des ventes avec le serveur (z-reconciliation.js), que la
     caisse restaurant fait depuis longtemps et que la boutique ne faisait pas :
     les boutiques Santos Store et Maison 121 ont encaissé 224 ventes en deux
     semaines sans qu'aucune ne soit jamais comparée au registre ; la caisse
     maison partage ce code et ce manque. Chaque vente envoyée est décrite comme le
     serveur la range : l'identifiant que postSale() lui donne, l'argent
     réellement reçu (ni l'avoir, ni la livraison encore à encaisser) et le
     moyen de paiement. Une vente réglée sans argent (avoir, livraison en
     compte) n'apporte rien à comparer et reste dehors ; une vente annulée
     part comme marque, pour retirer son identifiant d'un envoi précédent. */
  /* /api/sale garde 40 lignes. Les tickets plus longs perdaient le reste en
     silence : la recette restait entière, mais les lignes ne faisaient plus le
     ticket et les articles du bout n'existaient nulle part. Au-delà de 39, le
     reste part en une seule ligne « N autres articles », au centime près. Elle
     ne porte aucun identifiant d'article : rien n'est rendu au mauvais stock. */
  function bqFoldBasket(lines) {
    if (!Array.isArray(lines) || lines.length <= 40) return lines;
    const rest = lines.slice(39);
    return lines.slice(0, 39).concat([{
      name: rest.length + ' autres articles',
      qty: rest.reduce((n, l) => n + Math.max(0, Number(l && l.qty) || 0), 0),
      total: Math.round(rest.reduce((s, l) => s + Math.round((Number(l && l.total) || 0) * 100), 0)) / 100,
      cat: '', unit: 'piece', kind: 'product',
    }]);
  }
  /* LE PANIER AU CENTIME, ET À LA VALEUR DU TICKET. Deux écarts entre ce que
     la caisse encaissait et ce que ses lignes disaient au serveur. Un : chaque
     ligne était arrondie au dirham (Math.round), donc un caftan à 249,90 partait
     à 250, et le classement des articles comme le rapport par rayon portaient
     des centimes qui n'avaient jamais existé. Deux : la récompense fidélité
     baisse le TICKET, pas une ligne, et les lignes partaient à leur prix d'avant
     la récompense ; vu en production, un ticket encaissé 171,00 portait 190,00
     de lignes, et chaque article semblait avoir rapporté 10 % de plus.
     Ici, chaque ligne part au centime ; quand le ticket vaut moins que ses
     lignes, la baisse se répartit au prorata, le reste en centimes sur les plus
     grosses lignes, si bien que la somme des lignes est exactement le ticket.
     Un ticket inconnu (0, absent) ne touche à rien : mieux vaut des lignes
     pleines que des lignes à zéro. */
  function bqLineTotals(amounts, ticket) {
    const c = (amounts || []).map((x) => Math.max(0, Math.round((+x || 0) * 100)));
    const sum = c.reduce((a, b) => a + b, 0);
    /* Ticket inconnu → lignes telles quelles. Ticket explicitement à 0 (une
       récompense fidélité qui offre tout) → lignes à 0 : elles partaient au
       serveur à leur prix plein sur une vente à 0. */
    if (ticket == null || ticket === '' || !Number.isFinite(+ticket)) return c.map((x) => x / 100);
    const want = Math.max(0, Math.round(+ticket * 100));
    if (want >= sum) return c.map((x) => x / 100);
    if (want === 0) return c.map(() => 0);
    const out = c.map((x) => Math.floor(x * want / sum));
    let rest = want - out.reduce((a, b) => a + b, 0);
    const order = c.map((_, i) => i).sort((a, b) => c[b] - c[a] || a - b);
    for (let k = 0; rest > 0; k = (k + 1) % order.length) { out[order[k]]++; rest--; }
    return out.map((x) => x / 100);
  }
  function bqZJournal(slug) {
    const Live = window.KiwiLive;
    if (!Live || !Live.saleIdFor) return null;
    const out = [];
    SALES.forEach((s) => {
      if (!s || !s.syncId || !isToday(s.at)) return;
      const id = s.serverId ? String(s.serverId) : Live.saleIdFor({ id: s.syncId }, slug);
      if (s.voided) { out.push({ id, origin: true, voided: true }); return; }
      const parts = Array.isArray(s.parts) ? s.parts : [];
      /* La part du dépôt-vente (Maison) n'est pas la recette du commerce :
         postSale() la retire, la comparaison aussi. */
      const received = parts.reduce((sum, p) => sum
        + (p && p.m !== 'avoir' && p.m !== 'livraison' && (+p.amount || 0) > 0 ? +p.amount : 0), 0);
      const cents = Math.round(Math.max(0, received - (+s.consigned || 0)) * 100);
      if (!(cents > 0)) return;
      out.push({ id, origin: true, time: new Date(s.at), amount: cents / 100, method: bqPaymentMethod(parts), kind: 'vente' });
    });
    return out;
  }
  /* Un échec ne bloque jamais la caisse : la vente est déjà au journal et dans
     la file de Live Link. Le rapprochement ne fait que dire si elle est arrivée. */
  function bqZQueue(closed) {
    try {
      const Z = window.KiwiZReconciliation, DR = window.KiwiDayReport;
      if (IS_DEMO || !Z || !DR || !DR.isReal || !DR.isReal()) return Promise.resolve({ ok: false, reason: 'not-real' });
      const slug = DR.storeSlug();
      const journal = bqZJournal(slug);
      if (!slug || !journal) return Promise.resolve({ ok: false, reason: 'unavailable' });
      const day = DR.businessDay(tillNow());
      /* Mêmes bornes que celles du module : une vente comptée ici et écartée
         là ressortirait en « vente sans envoi », une fausse alerte. */
      const bounds = DR.dayBounds(day, slug);
      const sent = journal.filter((e) => !e.voided && +e.time >= bounds.from && +e.time < bounds.to);
      const CS = window.KiwiCashSessions;
      const report = {
        store: { slug }, day, cutoff: DR.cutoff(slug),
        terminalId: (CS && CS.terminalId && CS.terminalId()) || 'boutique',
        txns: sent.length, net: sent.reduce((sum, e) => sum + Math.round(e.amount * 100), 0) / 100,
      };
      return Promise.resolve(closed ? Z.queueClose(report, journal) : Z.queueSnapshot(report, journal))
        .catch(() => ({ ok: false, reason: 'queue-failed' }));
    } catch (_) { return Promise.resolve({ ok: false, reason: 'queue-failed' }); }
  }
  function bqSaveProvisional(force) {
    if (IS_DEMO || !window.KiwiDayReport || !bqShift) return;
    bqAnnounceOpen();
    bqZQueue(false);
    if (!force && Date.now() - bqLastProv < 90000) return;
    bqLastProv = Date.now();
    try {
      const r = bqBuildReport(null, 0);
      if (!r) return;
      r.closed = false;
      window.KiwiDayReport.save(r, { reopen: false, note: 'en cours', by: bqShift.openedBy });
    } catch (_) {}
  }

  function bqPrintReport(report, copyLabel, only) {
    if (!window.KiwiPrinter || !window.KiwiPrinter.printDayReport) {
      toast('Imprimante indisponible'); return Promise.resolve({ ok: false });
    }
    const DR = window.KiwiDayReport;
    const V = DR ? DR.vocab() : { items: 'articles', item: 'article', cat: 'rayon' };
    const hm = (ms) => { if (!ms) return ''; const d = new Date(ms); return pad2(d.getHours()) + ':' + pad2(d.getMinutes()); };
    const p = String(report.day || '').split('-');
    const pv = pvPaired() || {};
    return window.KiwiPrinter.printDayReport({
      report: report,
      shop: pv.name || 'Kiwi',
      address: pv.location || '',
      dateLabel: p.length === 3 ? `${p[2]}/${p[1]}/${p[0]}` : report.day,
      copy: copyLabel || '',
      openedLabel: hm(report.openedAt),
      closedLabel: hm(report.closedAt || tillNow()),
      detailTitle: 'DÉTAIL PAR ' + String(V.cat || 'rayon').toUpperCase(),
      drawerTitle: 'TIROIR-CAISSE',
      unitWord: V.items || 'articles',
      unitWordOne: V.item || '',
      notCounted: 'non compté',
      handoverWord: 'Passation',
      reopenWord: 'Clôture n°',
      methodLabels: { cash: 'Espèces', card: 'Carte', transfer: 'Virement / Versement', cheque: 'Chèque', wallet: 'Wallet', tap: 'Kiwi Tap', qr: 'QR', delivery: 'Livraison · à recevoir' },
      fmt: (n) => fmtMAD(n).replace(/\s*MAD\s*$/, ''), ...zTicketOpts(only),   /* titre, net et tiroir du ticket : magasin ou livraisons */
    }).then((res) => {
      if (res && res.ok) toast(res.via === 'pdf' ? 'Rapport prêt · imprimer ou partager le PDF' : res.via === 'browser' ? 'Rapport ouvert dans l\'impression système' : 'Rapport imprimé');
      else toast('Impression impossible · le rapport reste dans le tableau de bord');
      return res || { ok: false };
    }, () => { toast('Impression impossible · le rapport reste dans le tableau de bord'); return { ok: false }; });
  }

  /* ── l'écran d'ouverture (fond de caisse) ──
     Même dessin que le clock-in restaurant, mêmes classes ; seul le conteneur
     porte .mz-clockin, que pos-boutique.css ré-affiche par-dessus le masquage
     body.is-pos. Le fond retenu est mémorisé PAR ÉTABLISSEMENT, sous la même
     clé que la caisse restaurant : un appareil qui sert deux commerces retient
     deux montants. */
  function bqFloatMemKey() {
    try { const p = pvPaired(); if (p && p.merchant) return 'kiwi:openingFloat:v1:' + p.merchant; } catch (_) {}
    return 'kiwi:openingFloat:v1:boutique';
  }
  let bqFloat = 0;
  function bqMaybeOpenScreen() {
    if (IS_DEMO || bqShift) return;
    bqShowOpenScreen();
  }
  function bqShowOpenScreen() {
    /* God Mode regarde la caisse sans ouvrir de poste : session opérateur prouvée par /api/me pour CE magasin (caisse-pairing.js). */
    try { const o = sessionStorage.getItem('kiwi:tillOperator:v1'); const pv = pvPaired(); if (o && pv && pv.merchant === o) return; } catch (_) {}
    if (document.getElementById('mz-clockin')) return;
    const pv = pvPaired() || {};
    const who = ((STAFF.caissiere && STAFF.caissiere.name) || '').trim().split(/\s+/)[0] || 'Caissier';
    const role = (STAFF.caissiere && STAFF.caissiere.role) || 'Caissier';
    const DDAYS = ['Dimanche', 'Lundi', 'Mardi', 'Mercredi', 'Jeudi', 'Vendredi', 'Samedi'];
    const DMONTHS = ['janvier','février','mars','avril','mai','juin','juillet','août','septembre','octobre','novembre','décembre'];
    const el = document.createElement('div');
    el.className = 'clockin-screen mz-clockin';
    el.id = 'mz-clockin';
    el.setAttribute('aria-hidden', 'true');
    el.innerHTML = `
      <div class="clockin-top">
        <div class="clockin-brand" aria-label="Kiwi"><img src="assets/kiwi-newlogo-inverse.svg" alt="" draggable="false"></div>
        <div class="clockin-tagline">version commerçant</div>
      </div>
      <div class="clockin-mid">
        <div class="clockin-greet">Bonjour <em>${esc(who)}</em></div>
        <div class="clockin-role">${esc(role)} · ${esc(pv.name || 'Boutique')}</div>
        <div class="clockin-clock" id="bqci-time">--:--</div>
        <div class="clockin-date" id="bqci-date"></div>
        <div class="clockin-float">
          <span class="clockin-float-label">Fond d'ouverture</span>
          <div class="clockin-float-chips" id="bqci-chips">
            <button class="ci-float-chip" data-float="300">300 MAD</button>
            <button class="ci-float-chip" data-float="500">500 MAD</button>
            <button class="ci-float-chip" data-float="1000">1 000 MAD</button>
            <button class="ci-float-chip" data-float="custom" aria-expanded="false" aria-controls="bqci-custom">Autre</button>
          </div>
          <div class="clockin-float-custom" id="bqci-custom" hidden>
            <input id="bqci-input" class="ci-float-input" type="number"
                   inputmode="decimal" min="0" step="any" placeholder="0"
                   aria-label="Fond d'ouverture, montant libre en dirhams">
            <span class="ci-float-cur" aria-hidden="true">MAD</span>
          </div>
          <!-- Rien n'est présélectionné : le fond est ce que le caissier a COMPTÉ.
               Le dernier fond n'est qu'un raccourci à toucher. -->
          <button type="button" class="ci-float-last" id="bqci-last" hidden></button>
          <div class="ci-float-err" id="bqci-hint" role="status">Comptez le tiroir et indiquez le fond d'ouverture avant d'ouvrir la caisse.</div>
        </div>
      </div>
      <div class="clockin-bottom">
        <button class="clockin-btn" id="bqci-btn" disabled aria-describedby="bqci-hint">
          <i data-lucide="unlock" class="clockin-btn-ic"></i>
          <span class="clockin-btn-label">Ouvrir la caisse</span>
          <span class="clockin-btn-check" aria-hidden="true"><i data-lucide="check"></i></span>
        </button>
        <div class="clockin-foot">${esc(pv.location || '')}</div>
      </div>`;
    document.body.appendChild(el);

    const chips  = el.querySelector('#bqci-chips');
    const custom = el.querySelector('#bqci-custom');
    const input  = el.querySelector('#bqci-input');
    const mark = (chip) => el.querySelectorAll('.ci-float-chip').forEach((c) => c.classList.toggle('is-active', c === chip));
    const showCustom = (on, focus) => {
      custom.hidden = !on;
      const b = chips.querySelector('[data-float="custom"]');
      if (b) b.setAttribute('aria-expanded', on ? 'true' : 'false');
      if (on && focus) { input.focus(); input.select(); }
    };
    const remember = () => { try { localStorage.setItem(bqFloatMemKey(), String(bqFloat)); } catch (_) {} };
    /* Le bouton ne s'enfonce qu'une fois le fond indiqué : jamais de 500
       présélectionné qu'un seul toucher enregistrerait tel quel. */
    let chosen = false;
    const btnOpen = el.querySelector('#bqci-btn');
    const hint = el.querySelector('#bqci-hint');
    const last = el.querySelector('#bqci-last');
    const gate = () => { const kit = mzKitReady(); el.classList.toggle('mz-float-kit', kit); if (btnOpen) btnOpen.disabled = !chosen && !kit; if (hint) hint.hidden = chosen || kit; };

    /* Restitution du dernier fond utilisé par CE magasin. */
    let saved = NaN;
    try { saved = parseFloat(localStorage.getItem(bqFloatMemKey())); } catch (_) {}
    bqFloat = 0;
    if (Number.isFinite(saved) && saved >= 0 && last) {
      last.textContent = 'Dernier fond : ' + saved + ' MAD';
      last.dataset.value = String(saved);
      last.hidden = false;
      last.addEventListener('click', () => {
        const v = parseFloat(last.dataset.value);
        if (!Number.isFinite(v) || v < 0) return;
        bqFloat = v; chosen = true; gate();
        const preset = chips.querySelector(`[data-float="${v}"]`);
        if (preset) { mark(preset); showCustom(false); return; }
        mark(chips.querySelector('[data-float="custom"]')); input.value = String(v); showCustom(true, false);
      });
    }
    gate();

    chips.addEventListener('click', (e) => {
      const chip = e.target.closest('[data-float]');
      if (!chip) return;
      mark(chip);
      if (chip.dataset.float === 'custom') {
        showCustom(true, true);
        const v = parseFloat(input.value);
        bqFloat = Number.isFinite(v) && v > 0 ? v : 0;
        chosen = input.value !== ''; gate();
        return;
      }
      showCustom(false);
      bqFloat = parseInt(chip.dataset.float, 10) || 0;
      chosen = true; gate();
      remember();
    });
    input.addEventListener('input', () => {
      if (input.value && parseFloat(input.value) < 0) input.value = input.value.replace('-', '');
      const v = parseFloat(input.value);
      bqFloat = Number.isFinite(v) && v > 0 ? v : 0;
      chosen = input.value !== ''; gate();
      if (chosen) remember();
    });
    input.addEventListener('keydown', (e) => { if (e.key === 'Enter') { e.preventDefault(); input.blur(); } });

    const tick = () => {
      const n = new Date();
      const tEl = el.querySelector('#bqci-time'), dEl = el.querySelector('#bqci-date');
      if (tEl) tEl.textContent = pad2(n.getHours()) + ':' + pad2(n.getMinutes());
      if (dEl) dEl.textContent = DDAYS[n.getDay()] + ' ' + n.getDate() + ' ' + DMONTHS[n.getMonth()];
    };
    tick();
    const timer = setInterval(tick, 10000);

    el.querySelector('#bqci-btn').addEventListener('click', () => {
      /* Sous la peau, le tiroir se compte dans la feuille du kit ; le montant compté suit le chemin livré. */
      if (!chosen && mzKitFloat(el, bqFloatMemKey(), (v) => { bqFloat = v; chosen = true; remember(); gate(); el.querySelector('#bqci-btn').click(); })) return;
      if (!chosen) { gate(); return; }
      el.querySelector('#bqci-btn').classList.add('is-confirmed');
      icons();
      const openedAt = Date.now();
      bqShift = { openedAt, openedBy: (STAFF.caissiere && STAFF.caissiere.name) || '', float: bqFloat, sid: 'bq-' + openedAt, openSent: false };
      bqShiftPersist();
      /* Le fond d'ouverture est le premier chiffre du rapprochement. */
      bqAnnounceOpen();
      bqSaveProvisional(true);
      setTimeout(() => el.classList.add('is-leaving'), 420);
      setTimeout(() => { clearInterval(timer); el.remove(); }, 940);
    });

    requestAnimationFrame(() => { el.classList.add('is-visible'); el.setAttribute('aria-hidden', 'false'); icons(); });
  }

  /* ── la clôture ── */
  let bqCloVeil = null, bqCloExpected = 0, bqClosedReport = null, bqClosedPair = null;
  function bqFmtDur(min) {
    if (min < 60) return `${min} mn`;
    return `${Math.floor(min / 60)}h${pad2(min % 60)}`;
  }
  function bqUpdateEcart() {
    const v = bqCloVeil; if (!v) return;
    const line = v.querySelector('#bqclo-ecart-line'), out = v.querySelector('#bqclo-ecart'), inp = v.querySelector('#bqclo-count');
    if (!line || !out) return;
    line.classList.remove('is-ok', 'is-off');
    const raw = inp ? inp.value : '';
    if (raw === '' || raw == null) { out.textContent = '·'; return; }
    const ecart = (parseFloat(raw) || 0) - bqCloExpected;
    out.textContent = (ecart > 0 ? '+ ' : (ecart < 0 ? '− ' : '')) + fmtMAD(Math.abs(ecart));
    line.classList.add(Math.abs(ecart) <= 5 ? 'is-ok' : 'is-off');
  }
  let bqOutstandingCents = 0;
  async function bqOpenCloture() {
    if (window.KiwiRetailBalances) {
      const open = await window.KiwiRetailBalances.list(merchantSlug());
      bqOutstandingCents = open.reduce((sum, row) => sum + window.KiwiRetailBalances.due(row), 0);
    }
    if (!bqCloVeil) {
      bqCloVeil = document.createElement('div');
      bqCloVeil.className = 'cloture-veil';
      bqCloVeil.id = 'mz-cloture';
      bqCloVeil.setAttribute('role', 'dialog');
      bqCloVeil.setAttribute('aria-modal', 'true');
      document.body.appendChild(bqCloVeil);
    }
    const v = bqCloVeil;
    const now = new Date();
    const openedAt = bqShift ? new Date(bqShift.openedAt) : now;
    const durMin = Math.max(0, Math.floor((now - openedAt) / 60000));
    const t = bqDayTotals('store'), td = bqDayTotals('delivery');   /* l'écran comme le papier : la caisse hors livraisons, puis les livraisons */
    const pv = pvPaired() || {};
    const DR = window.KiwiDayReport;
    const V = DR ? DR.vocab() : { items: 'articles', cats: 'rayons', cat: 'rayon' };

    const rows = [
      ['Service ouvert à', fmtHM(openedAt), false, ''],
      ['Durée du service', bqFmtDur(durMin), false, ''],
      zStoreHead(), ['Transactions', String(t.txns), false, ''],
      ['Articles vendus', String(t.items), false, ''],
      ['Total encaissé', fmtMAD(t.moneyIn), true, 'total'],
      ['dont Carte', fmtMAD(t.card), true, 'sub'],
      ['dont Espèces', fmtMAD(t.cash), true, 'sub'],
    ];
    if (t.other > 0) rows.push(['dont Autres', fmtMAD(t.other), true, 'sub']);
    if (t.transfer > 0) rows.push(['dont Virement / Versement', fmtMAD(t.transfer), true, 'sub']);
    if (t.cheque > 0) rows.push(['dont Chèque', fmtMAD(t.cheque), true, 'sub']);
    if (t.acompteReceived > 0) rows.push(['Acomptes reçus', fmtMAD(t.acompteReceived), true, '']);
    if (t.outstanding > 0) rows.push(['Soldes restant à régler', fmtMAD(t.outstanding), true, '']);
    /* HORS du bloc « dont » : une livraison n'est pas encaissée, elle est à
       recevoir. Nichée en sous-ligne du total, elle se lisait comme une de ses
       composantes — alors qu'aucun dirham correspondant n'est dans le tiroir. */
    /* Les livraisons ont leur propre bloc, sous les chiffres de la caisse (zDeliveryRows). */
    if (t.paidTxns > 0) rows.push(['Ticket moyen', fmtMAD(t.moneyIn / t.paidTxns), true, '']);
    if (t.promoOff > 0) rows.push(['Promotions du magasin', fmtMAD(t.promoOff), true, '']);
    rows.push(['Réductions accordées', fmtMAD(t.discounts), true, '']);
    if (t.avoirIssued > 0) rows.push(['Avoirs émis', fmtMAD(t.avoirIssued), true, '']);
    /* Réglé en avoir : la contrepartie du « Total encaissé ». Ces tickets ont
       vidé des rayons sans faire sonner le tiroir — les compter nulle part
       revenait à imprimer un Z où la marchandise partie ne figure pas. */
    if (t.avoirUsed > 0) rows.push([`Réglé en avoir (${t.avoirUsedN})`, fmtMAD(t.avoirUsed), true, '']); rows.push(...zDeliveryRows(td, fmtMAD));

    /* Tiroir : fond + espèces. La boutique n'a ni pourboires ni mouvements de
       caisse — les lignes qui n'existent pas ne s'affichent pas. */
    bqCloExpected = (bqShift ? bqShift.float : 0) + t.cash;
    const dLines = [
      ["Fond d'ouverture", fmtMAD(bqShift ? bqShift.float : 0), ''],
      ['Espèces encaissées', '+ ' + fmtMAD(t.cash), ''],
      ['Attendu en caisse', fmtMAD(bqCloExpected), 'is-total'],
    ];

    const nCats = (() => {
      const seen = {};
      /* Une ligne intégralement reprise n'a rien vendu : compter son rayon
         faisait dire « 3 rayons » à une clôture où deux seulement ont laissé de
         la marchandise chez le client — la phrase contredisait le nombre de
         pièces affiché juste à côté, qui, lui, est net des retours. */
      salesToday().forEach((s) => (s.lines || []).forEach((ln) => {
        if (lineAvailableQty(ln) <= 0) return;
        const r = rayonOf(ln.pid); if (r) seen[r] = 1;
      }));
      return Object.keys(seen).length;
    })();
    const hlText = t.txns
      ? `<em>${t.items}</em> ${V.items} vendus sur ${t.txns} ticket${t.txns > 1 ? 's' : ''}${nCats ? `, ${nCats} ${nCats > 1 ? V.cats : V.cat}` : ''}.`
      : 'Aucune vente sur ce service.';

    v.innerHTML = `
      <div class="cloture-card">
        <div class="clo-eyebrow">Fin de service</div>
        <div class="clo-title">Clôture de caisse</div>
        <div class="clo-meta">${esc(pv.name || 'Boutique')} · ${esc((STAFF.caissiere && STAFF.caissiere.name) || '')} · ${fmtDay(now)}</div>
        <div class="clo-rows">${rows.map((r, i) => {
          const cls = 'clo-row' + (r[3] === 'total' ? ' is-total' : (r[3] === 'sub' ? ' is-sub' : (r[3] === 'head' ? ' is-head' : '')));
          const vCls = 'clo-row-value' + (r[2] ? ' mono' : '');
          return `<div class="${cls}" style="animation-delay:${i * 70}ms"><span class="clo-row-label">${r[0]}</span><span class="${vCls}">${r[1]}</span></div>`;
        }).join('')}</div>
        <div class="clo-drawer-box">
          <div class="clo-drawer-title">Tiroir-caisse</div>
          ${dLines.map((l) => `<div class="clo-drawer-line ${l[2]}"><span>${l[0]}</span><span class="mono">${l[1]}</span></div>`).join('')}
          <div class="clo-count-row">
            <label for="bqclo-count">Espèces comptées</label>
            <input class="clo-count-input" id="bqclo-count" type="number" inputmode="numeric" min="0" step="10" placeholder="·" />
          </div>
          <div class="clo-ecart-line" id="bqclo-ecart-line">
            <span>Écart</span><span class="mono" id="bqclo-ecart">·</span>
          </div>
        </div>
        <div class="clo-highlight">
          <div class="clo-highlight-icon"><i data-lucide="shopping-bag"></i></div>
          <div class="clo-highlight-text">${hlText}</div>
        </div>
        <div class="clo-actions">
          <button class="clo-btn secondary" id="bqclo-print"><i data-lucide="printer"></i><span>Imprimer le rapport Z</span></button>
          <button class="clo-btn primary" id="bqclo-close"><i data-lucide="lock"></i><span>Fermer la caisse</span></button>
        </div>
        <div class="clo-foot"><button id="bqclo-continue">Continuer le service</button></div>
      </div>`;
    v.classList.add('is-open');
    icons();

    v.querySelector('#bqclo-count').addEventListener('input', bqUpdateEcart);
    v.querySelector('#bqclo-continue').onclick = () => v.classList.remove('is-open');
    /* Imprimer AVANT de fermer — un tirage avec le comptage saisi à l'instant,
       aucune écriture (même contrat que #clo-print côté restaurant). */
    v.querySelector('#bqclo-print').onclick = () => {
      const raw = v.querySelector('#bqclo-count').value;
      const pair = zPair(bqBuildReport, raw === '' || raw == null ? null : parseFloat(raw), 0, null);
      if (!pair) { toast('Rapport indisponible'); return; }
      zPrintPair(bqPrintReport, pair, 'AVANT CLÔTURE');
    };
    v.querySelector('#bqclo-close').onclick = bqCloseRegister;
  }

  /* L'ORDRE COMPTE (cf. closeRegister() restaurant) : le rapport s'écrit AVANT
     d'effacer le poste et avant le rechargement. Les ventes ne sont jamais
     touchées — une clôture produit un document, elle ne modifie pas le registre. */
  function bqCloseRegister() {
    const v = bqCloVeil;
    const raw = v ? v.querySelector('#bqclo-count').value : '';
    const counted = (raw === '' || raw == null) ? null : parseFloat(raw);
    if (v) v.classList.remove('is-open');
    let report = null, reportSaved = false;
    try {
      report = bqBuildReport(counted, tillNow());
      if (report && window.KiwiDayReport) {
        report.closed = true;
        const saved = window.KiwiDayReport.save(report, { by: (STAFF.caissiere && STAFF.caissiere.name) || '' });
        const persisted = window.KiwiDayReport.load(report.day, report.store?.slug);
        reportSaved = !!saved && (!window.KiwiDayReport.isReal() ||
          (persisted?.closedAt === report.closedAt && persisted?.sessionId === report.sessionId));
        /* La page se recharge dans un instant : sans flush(), la remontée
           serveur débattue partirait après la mort de l'onglet — jamais. */
        window.KiwiDayReport.flush();
      }
    } catch (_) {}
    if (!report || !reportSaved) {
      if (v) v.classList.add('is-open');
      toast('Clôture non enregistrée · poste conservé. Vérifiez le stockage puis réessayez.');
      return;
    }
    /* Émis AVANT d'effacer le poste : l'événement porte openedAt et sessionId,
       qui n'existent plus une fois bqShift remis à zéro. Un comptage laissé
       vide reste un poste fermé — on annonce alors l'attendu comme compté, et
       l'écart nul, plutôt que de ne rien dire du tout au rapprochement. */
    const countedCash = counted == null ? bqCloExpected : counted;
    bqCashEvent('close', {
      expectedCents: bqCents(bqCloExpected),
      countedCents: bqCents(countedCash),
      gapCents: bqCents(countedCash) - bqCents(bqCloExpected),
    });
    bqZQueue(true); const pair = zPair(bqBuildReport, counted, report && report.closedAt, report);   /* les deux tickets du Z, avant d'effacer le poste */
    bqShift = null;
    bqShiftPersist();
    if (report) bqShowPostClose(report, pair); else bqFinishClose();
  }
  function bqFinishClose() {
    const z = document.getElementById('mz-zsheet');
    if (z) z.classList.remove('is-open');
    toast('Caisse fermée · à bientôt');
    setTimeout(() => location.reload(), 640);
  }
  /* L'écran d'après-clôture : une décision, la trace papier. */
  function bqShowPostClose(report, pair) {
    bqClosedReport = report; bqClosedPair = pair || null;
    const DR = window.KiwiDayReport;
    const V = DR ? DR.vocab() : { items: 'articles', cats: 'rayons', cat: 'rayon' };
    const nCat = (report.categories || []).length;
    const nItems = (report.categories || []).reduce((s, c) => s + (c.qty || 0), 0);
    const bits = [`${report.txns} transaction${report.txns > 1 ? 's' : ''}`];
    if (nCat) bits.push(`${nItems} ${V.items} · ${nCat} ${nCat > 1 ? V.cats : V.cat}`);
    if (report.cash && report.cash.ecart != null && Math.abs(report.cash.ecart) > 0.5) {
      bits.push(`écart ${(report.cash.ecart > 0 ? '+ ' : '− ')}${fmtMAD(Math.abs(report.cash.ecart))}`);
    }
    const z = document.createElement('div');
    z.className = 'cloture-veil is-open';
    z.id = 'mz-zsheet';
    z.setAttribute('role', 'dialog');
    z.setAttribute('aria-modal', 'true');
    z.innerHTML = `
      <div class="cloture-card zs-card">
        <div class="clo-eyebrow">Journée clôturée</div>
        <div class="clo-title">Rapport journalier</div>
        ${zCloseTotals(pair, report.net, fmtMAD, esc)}
        <div class="clo-meta">${bits.join(' · ')}</div>
        <div class="clo-actions">
          <button class="clo-btn primary" id="bqzs-print"><i data-lucide="printer"></i><span>Imprimer le rapport</span></button>
          <button class="clo-btn secondary" id="bqzs-reprint" hidden><i data-lucide="copy"></i><span>Réimprimer</span></button>
        </div>
        <div class="clo-foot"><button id="bqzs-skip">Continuer sans imprimer</button></div>
        <div class="zs-note">Le rapport reste disponible dans le tableau de bord, section Rapport journalier · même après un rechargement ou depuis un autre appareil.</div>
      </div>`;
    document.body.appendChild(z);
    icons();
    const print = z.querySelector('#bqzs-print'), reprint = z.querySelector('#bqzs-reprint');
    const doPrint = (btn) => {
      if (!bqClosedReport) return bqFinishClose();
      btn.disabled = true;
      const copy = btn === reprint ? 'DUPLICATA' : '';
      (bqClosedPair ? zPrintPair(bqPrintReport, bqClosedPair, copy) : bqPrintReport(bqClosedReport, copy)).then((res) => {
        btn.disabled = false;
        if (res?.ok && reprint) { reprint.hidden = false; icons(); }
      });
    };
    print.onclick = () => doPrint(print);
    reprint.onclick = () => doPrint(reprint);
    z.querySelector('#bqzs-skip').onclick = bqFinishClose;
  }

  /* La boutique n'encaisse pas dans le journal partagé (KiwiPosSale) : elle
     tient SALES, qui couvre la semaine et porte le ticket figé de chaque vente.
     Elle s'annonce donc au bouton « Réimprimer », qui sinon lirait un journal
     vide et conclurait qu'aucune vente n'a été prise de la journée.
     Traduit vers la forme commune du journal, et `rc` suit : c'est lui qui fait
     ressortir le VRAI ticket remis plutôt qu'une recomposition. */
  try {
    if (window.KiwiPosReprint) {
      /* Le prix vient de la LIGNE (ln.unit, figé à l'encaissement), jamais du
         catalogue actuel : lineUnit() lit P[ln.pid].price et lève sur un article
         supprimé depuis — le cas qui avait déjà vidé la page des échanges — et
         relirait de toute façon un prix qui a pu changer depuis la vente. */
      const lineName = (ln) => ((P[ln.pid] && P[ln.pid].name) || 'Article') + (ln.size ? ' ' + ln.size : '');
      /* TOUTE la fenêtre du journal, pas seulement aujourd'hui. salesToday()
         est fait pour l'ARGENT — la recette du jour ne doit jamais sommer une
         semaine — et la réimpression n'est pas de l'argent : c'est du papier.
         Une cliente qui revient le lendemain sans son ticket ne trouvait donc
         personne pour le lui ressortir, alors que l'écran des échanges affichait
         sa vente juste à côté et que `rc` en garde le document exact.
         C'est pos-reprint.js qui tranche ensuite : au-delà du jour, il n'accepte
         que les ventes portant ce ticket figé. Lui passer la fenêtre entière
         évite de refaire ici un filtre qui vit là-bas. */
      const salesWeek = () => SALES.filter((s) => s && !s.voided && withinRetention(s.at));
      /* Ticket #0026 · registered under our own vertical id: the dispatcher
       * mounts with id='maison', so 'boutique' here starved our journal AND
       * clobbered the boutique provider on last-mounted-wins. */
      window.KiwiPosReprint.provide('maison', () => salesWeek().map((s) => {
        const lines = (s.lines || []).map((ln) => ({
          name: lineName(ln),
          qty: ln.qty,
          total: Math.round((+ln.unit || 0) * ln.qty * 100) / 100,
        }));
        const pieces = lines.reduce((n, l) => n + l.qty, 0);
        const head = lines[0];
        return {
          ts: (s.at instanceof Date ? s.at : new Date(s.at)).getTime(),
          total: s.total,
          ref: s.id,
          label: !head ? 'Vente'
            : (lines.length > 1 ? head.name + ' +' + (pieces - head.qty) + ' art.' : head.name),
          raw: s.methods,
          rc: s.rc || null,
          lines: lines,
        };
      }));
    }
  } catch (_) {}

  window.KiwiPosDispatch.register({
    id: 'maison',
    greet: {
      line1: 'Bonjour,',
      em: 'bienvenue.',
      sub: 'Vogue Home <em>·</em> art de table & décoration',
    },
    mount,
    onShow,
  });


  /* ───────────────────────── helpers ───────────────────────── */
  const $  = (s, r) => (r || document).querySelector(s);
  const $$ = (s, r) => Array.from((r || document).querySelectorAll(s));
  const esc = (s) => String(s == null ? '' : s).replace(/[&<>"']/g, (c) =>
    ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
  const fmtMAD = (n) => globalThis.KiwiMoney.format(n) + ' MAD';
  /* La caisse Maison garde le prix au centime, comme la caisse boutique
     (décision propriétaire, 2026-10-26, docs/decisions/2026-10-26-wave-q.md :
     un prix configuré est encaissé au centime, un prix entier reste entier).
     Elle n'encaisse JAMAIS plus que le prix affiché : un prix de catalogue à
     249,90, une pièce de service à 83,33, une promotion ou une remise qui tombe
     sur 220,505 descendent au centime inférieur, partout : grille, fiche,
     ticket, échange et reçu disent le même chiffre. Le petit epsilon absorbe
     0,1 + 0,2 et ses cousins, jamais un vrai centime. */
  const shelf = (n) => Math.max(0, Math.floor((+n || 0) * 100 + 1e-6) / 100);
  const icons  = () => { if (window.lucide) try { window.lucide.createIcons(); } catch (e) {} };
  const lens   = () => { if (window.KiwiLens) try { window.KiwiLens.rescan(); } catch (e) {} };
  const DAYS   = ['dim.', 'lun.', 'mar.', 'mer.', 'jeu.', 'ven.', 'sam.'];
  const MONTHS = ['janv.', 'févr.', 'mars', 'avr.', 'mai', 'juin', 'juil.', 'août', 'sept.', 'oct.', 'nov.', 'déc.'];
  const pad2   = (n) => String(n).padStart(2, '0');
  const fmtDT  = (d) => `${DAYS[d.getDay()]} ${d.getDate()} ${MONTHS[d.getMonth()]} · ${pad2(d.getHours())}:${pad2(d.getMinutes())}`;
  const fmtDay = (d) => `${DAYS[d.getDay()]} ${d.getDate()} ${MONTHS[d.getMonth()]}`;
  /* Un avoir vit six mois : son échéance tombe presque toujours l'année suivante.
     Sans millésime, « sam. 14 févr. » sur un bon papier ne dit pas si c'est celui
     de cette année ou du suivant — et c'est le seul chiffre qui décide si la
     cliente est remboursée ou renvoyée. Les dates d'avoir portent l'année. */
  const fmtDayY = (d) => `${fmtDay(d)} ${d.getFullYear()}`;
  /* Dernière journée commerciale où un avoir reste utilisable. Le serveur le fait
     expirer à la bascule (05:00 par défaut) qui CLÔT cette journée : la date civile
     de cet instant serait le lendemain. On lit donc la journée commerciale de
     l'instant qui le précède, avec la bascule et le fuseau du magasin
     (KiwiDayReport), comme le tableau de bord. */
  const creditLastDay = (until) => {
    const t = +new Date(until);
    let day = '';
    try { if (window.KiwiDayReport && window.KiwiDayReport.businessDay) day = String(window.KiwiDayReport.businessDay(t - 1)); } catch (_) {}
    const m = /^(\d{4})-(\d{2})-(\d{2})$/.exec(day);
    return m ? new Date(+m[1], +m[2] - 1, +m[3], 12) : new Date(t - 5 * 3600000 - 1);
  };
  const fmtValidUntil = (until) => fmtDayY(creditLastDay(until));
  const fmtHM  = (d) => `${pad2(d.getHours())}:${pad2(d.getMinutes())}`;
  const MIN = 60 * 1000;

  /* Deterministic pseudo-barcode (Code-39 lookalike) from any id. */
  function barcode(seed, h) {
    h = h || 30;
    let bars = '', x = 0, s = 7;
    const len = Math.max(seed.length * 4, 26);
    for (let i = 0; i < len; i++) {
      s = (s * 31 + seed.charCodeAt(i % seed.length) + i * 11) % 97;
      const w = 1 + (s % 3);
      bars += `<rect x="${x}" y="0" width="${w}" height="${h}"></rect>`;
      x += w + 1 + ((s >> 3) % 2);
    }
    return `<svg viewBox="0 0 ${x} ${h}" preserveAspectRatio="none" style="height:${h}px" fill="currentColor" aria-hidden="true">${bars}</svg>`;
  }

  /* Product-icon "database" for the create/edit picker — ordered + labelled.
     artOf() takes a product (its own photo, else a photo picked by its name, retail-photos.js)
     or an icon key, and falls back to the price tag so nothing is blank. */
  const artOf = (p, colour) => (p && typeof p === 'object' && p.photo
    ? `<img class="mz-product-photo" src="${esc(p.photo)}" alt="" loading="lazy" decoding="async">`
    : photoImg(p, 'mz-art-photo', 'tag', colour));
  const ICON_LABELS = {
    bougie: 'Bougie', diffuseur: 'Diffuseur', diffuseur_voiture: 'Diffuseur voiture', coffret: 'Coffret cadeau',
    bougeoir: 'Bougeoir', cloche: 'Cloche', eteignoir: 'Éteignoir', coupe_meche: 'Coupe-mèche',
    assiette: 'Assiette', bol: 'Bol', tasse: 'Tasse', verre: 'Verre', carafe: 'Carafe', coupe: 'Coupe',
    plateau: 'Plateau', miroir: 'Miroir', vase: 'Vase', coussin: 'Coussin', plaid: 'Plaid',
    polo: 'Polo', jean: 'Jean', manteau: 'Manteau', trench: 'Trench', cape: 'Cape', doudoune: 'Doudoune',
    gilet_doudoune: 'Gilet doudoune', costume: 'Costume / Tailleur', ensemble: 'Ensemble', ensemble_jean: 'Ensemble jean', survetement: 'Survêtement',
    tshirt: 'T-shirt / Haut', chemise: 'Chemise', debardeur: 'Débardeur', pull: 'Pull', sweat: 'Sweat / Hoodie',
    pantalon: 'Pantalon', short: 'Short', jupe: 'Jupe', robe: 'Robe', combinaison: 'Combinaison',
    veste: 'Veste', chaussures: 'Chaussures', basket: 'Basket', botte: 'Bottes', sandale: 'Sandales',
    chapeau: 'Chapeau', casquette: 'Casquette', bonnet: 'Bonnet', ceinture: 'Ceinture', cravate: 'Cravate',
    echarpe: 'Écharpe', gants: 'Gants', chaussettes: 'Chaussettes', lunettes: 'Lunettes', montre: 'Montre',
    bracelet: 'Bracelet', bague: 'Bague', collier: 'Collier', boucles: 'Boucles d’oreille', broche: 'Broche / Bijou',
    parfum: 'Parfum', sac_main: 'Sac à main', sac: 'Sac', sac_dos: 'Sac à dos', cabas: 'Cabas',
    pochette: 'Pochette', portefeuille: 'Portefeuille', valise: 'Valise', parapluie: 'Parapluie', tag: 'Étiquette',
    cintre: 'Cintre', caftan: 'Caftan', takchita: 'Takchita', djellaba: 'Djellaba', gandoura: 'Gandoura',
    jabador: 'Jabador', selham: 'Selham', tarbouche: 'Tarbouche', foulard: 'Foulard', chale: 'Châle',
    mdamma: 'Mdamma', babouche: 'Babouche',
  };
  const ICON_KEYS = [
    // Bougies & parfum d'intérieur
    'bougie', 'diffuseur', 'diffuseur_voiture', 'coffret', 'bougeoir', 'cloche', 'eteignoir', 'coupe_meche',
    // Table & décoration
    'assiette', 'bol', 'tasse', 'verre', 'carafe', 'coupe', 'plateau', 'miroir', 'vase', 'coussin', 'plaid',
    // Hauts
    'tshirt', 'polo', 'chemise', 'debardeur', 'pull', 'sweat',
    // Bas
    'pantalon', 'jean', 'short', 'jupe',
    // Pièces entières
    'robe', 'combinaison', 'ensemble', 'ensemble_jean', 'survetement', 'costume',
    // Vestes & manteaux
    'veste', 'manteau', 'trench', 'cape', 'doudoune', 'gilet_doudoune',
    // Traditionnel marocain
    'caftan', 'takchita', 'djellaba', 'gandoura', 'jabador', 'selham',
    // Chaussures
    'chaussures', 'basket', 'botte', 'sandale', 'babouche',
    // Couvre-chef
    'chapeau', 'casquette', 'bonnet', 'tarbouche',
    // Accessoires & bijoux
    'ceinture', 'cravate', 'echarpe', 'foulard', 'chale', 'gants', 'chaussettes',
    'lunettes', 'montre', 'bracelet', 'bague', 'collier', 'boucles', 'broche', 'mdamma', 'parfum',
    // Sacs & maroquinerie
    'sac_main', 'sac', 'sac_dos', 'cabas', 'pochette', 'portefeuille', 'valise',
    // Divers
    'parapluie', 'tag', 'cintre',
  ];
  function iconPickerHtml(sel) {
    return `<div class="mzi-iconpick">${ICON_KEYS.map((k) => `<button type="button" class="mzi-icon${k === sel ? ' on' : ''}" data-icon-key="${k}" title="${esc(ICON_LABELS[k] || k)}">${artOf(k)}</button>`).join('')}</div>`;
  }
  function wireIconPicker(el, onPick) {
    el.querySelectorAll('.mzi-icon').forEach((b) => b.addEventListener('click', () => {
      el.querySelectorAll('.mzi-icon').forEach((x) => x.classList.remove('on'));
      b.classList.add('on');
      if (onPick) onPick(b.getAttribute('data-icon-key'));
    }));
  }

  /* ───────────────────────── couleurs ─────────────────────────
     Aucune palette n'est définie ici. Ce module lisait autrefois sa propre liste
     de treize nuances, copiée à l'identique dans boutique-catalog.js : deux
     copies d'une même vérité finissent toujours par diverger. Le vocabulaire
     vit dans assets/color-palette.js (window.KiwiColors) — des FAMILLES
     générales, choisies à la pastille, jamais à la nuance. `colorOf()` accepte
     n'importe quelle valeur historique ou importée et rend toujours une famille
     affichable : une variante ne peut pas devenir grise faute de correspondance. */
  const KC = () => window.KiwiColors || null;
  const KC_MISS = { id: 'gris', label: 'Gris', hex: '#9AA0A6' };
  function colorOf(id) { const k = KC(); return (k && k.normalize(id)) || KC_MISS; }
  function colorLabel(id) { return colorOf(id).label; }
  function colorHex(id) { return colorOf(id).hex; }
  // Une pastille non cliquable (ligne de ticket, retour, tableau) — même dessin
  // que dans le tableau de bord, nom porté par title/aria plutôt qu'écrit.
  function colorDot(id, size) {
    const k = KC();
    if (k) return k.swatch(id, { size: size || 'sm' });
    return `<i class="kc-sw kc-sm" style="background-color:${KC_MISS.hex}" title="${KC_MISS.label}"></i>`;
  }
  function variantColor(v) {
    const k = KC();
    return (k && k.display ? k.display(v.colorId, v.colorLabel, v.colorHex) : colorOf(v.colorFamily || v.colorId));
  }

  /* ── clients: real store = the shared KiwiClients book (assets/clients-store.js) ──
     A REAL/paired boutique reads its picker, ticket and « Nouvelle cliente » from
     KiwiClients — so it shows its OWN clients (empty until captured on the till) and
     any client added in the dashboard « Clients » appears here too. The pitch demo
     (unpaired PIN 0002) keeps the rich hard-coded CLIENTES above. */
  function isDemoStore() { try { return !bqReal(); } catch (_) { return true; } }   // pitch demo = local, unpaired, not signed-in
  function useKiwiCl() { return !isDemoStore() && !!window.KiwiClients; }
  function fromKiwi(c) {
    if (!c) return null;
    return { id: c.id, name: c.name || 'Sans nom', phone: c.phone || '', points: c.points || 0,
      taille: '', achats: c.visits || 0, spent: c.spend || 0,
      vip: !!(window.KiwiClients && KiwiClients.segment(c) === 'vip'), prefs: c.notes ? [c.notes] : [], history: Array.isArray(c.history) ? c.history : [] };
  }
  // A REAL store shows ONLY its own KiwiClients book (empty until captured) — NEVER
  // the demo CLIENTES. The pitch demo keeps the rich hard-coded set.
  function clientList() {
    if (isDemoStore()) return CLIENTES;
    return window.KiwiClients ? window.KiwiClients.list().map(fromKiwi) : [];
  }
  function clById(id) {
    if (!id || id === 'passage') return null;
    if (isDemoStore()) return CL[id] || null;
    const c = window.KiwiClients && window.KiwiClients.get(id);
    return c ? fromKiwi(c) : null;
  }
  /* Fidélité — la récompense de CE client, lue sur le programme réel du magasin
     (KiwiClients.config). « Prête » = la carte est pleine / le seuil de points est
     atteint. Le type se déduit du modèle : amount → une remise en % sur le ticket
     (boutique « −10 % ») ; visit/product → un article offert (carte à tampons).
     Renvoie null pour la démo (pas de KiwiClients) et pour la cliente de passage. */
  function clReward(id) {
    if (isDemoStore() || !window.KiwiClients || !id || id === 'passage') return null;
    const raw = window.KiwiClients.get(id);
    if (!raw) return null;
    const cfg = (window.KiwiClients.config && window.KiwiClients.config()) || {};
    const ready = window.KiwiClients.progress ? window.KiwiClients.progress(raw, cfg) >= 1 : false;
    let kind = 'percent', value = 10, label = '−10 %';
    if (cfg.model === 'amount') {
      const txt = (cfg.amount && cfg.amount.reward) || '−10 %';
      const m = String(txt).match(/(\d+)\s*%/);
      kind = 'percent'; value = m ? +m[1] : 10; label = txt;
    } else {
      const txt = (cfg.model === 'product' ? (cfg.product && cfg.product.reward) : (cfg.visit && cfg.visit.reward)) || '1 offert';
      kind = 'free'; label = txt;
    }
    return { ready: ready, kind: kind, value: value, label: label };
  }

  /* ═══════════════════════ VENTE — grille par rayon / marque / motif ═══════════════════════ */
  function listAllDistinctMarques() {
    const s = new Set();
    RAYONS.forEach((r) => r.items.forEach((p) => { if (p.marque) s.add(p.marque); }));
    return Array.from(s).sort();
  }
  function listAllDistinctMotifs() {
    const s = new Set();
    RAYONS.forEach((r) => r.items.forEach((p) => { if (p.motif) s.add(p.motif); }));
    return Array.from(s).sort();
  }
  function countFragileItems() {
    let count = 0;
    RAYONS.forEach((r) => r.items.forEach((p) => { if (p.fragile) count++; }));
    return count;
  }

  function renderCats() {
    const all = RAYONS.reduce((s, r) => s + r.items.length, 0);
    const promoN = promoedIds().size;
    const fragileN = countFragileItems();
    const marques = listAllDistinctMarques();
    const motifs = listAllDistinctMotifs();
    const axis = state.filterAxis || 'rayons';

    const axisRow = `
      <div class="mz-filter-axis">
        <button class="mz-axis-btn ${axis === 'rayons' ? 'on' : ''}" data-mz-axis="rayons"><i data-lucide="layout-grid"></i>Rayons</button>
        ${marques.length ? `<button class="mz-axis-btn ${axis === 'marques' ? 'on' : ''}" data-mz-axis="marques"><i data-lucide="tag"></i>Marques (${marques.length})</button>` : ''}
        ${motifs.length ? `<button class="mz-axis-btn ${axis === 'motifs' ? 'on' : ''}" data-mz-axis="motifs"><i data-lucide="sparkles"></i>Motifs (${motifs.length})</button>` : ''}
        ${promoN ? `<button class="mz-axis-btn ${axis === 'promo' ? 'on' : ''}" data-mz-axis="promo"><i data-lucide="flame"></i>En promo (${promoN})</button>` : ''}
        ${fragileN ? `<button class="mz-axis-btn ${axis === 'fragile' ? 'on' : ''}" data-mz-axis="fragile"><i data-lucide="shield-alert"></i>Fragile (${fragileN})</button>` : ''}
      </div>`;

    let chipsRow = '';
    if (axis === 'rayons') {
      chipsRow = `
        <div class="mz-cats-row">
          <button class="mz-cat ${state.rayon === 'tous' ? 'on' : ''}" data-mz-cat="tous">Tous <span class="mz-cat-ct">${all}</span></button>
          ${RAYONS.map((r) => `<button class="mz-cat ${state.rayon === r.id ? 'on' : ''}" data-mz-cat="${r.id}">${esc(r.label)} <span class="mz-cat-ct">${r.items.length}</span></button>`).join('')}
        </div>`;
    } else if (axis === 'marques') {
      chipsRow = `
        <div class="mz-cats-row">
          <button class="mz-cat ${state.selectedMarque === 'tous' ? 'on' : ''}" data-mz-marque="tous">Toutes les marques</button>
          ${marques.map((m) => {
            const count = RAYONS.reduce((acc, r) => acc + r.items.filter((p) => p.marque === m).length, 0);
            return `<button class="mz-cat ${state.selectedMarque === m ? 'on' : ''}" data-mz-marque="${esc(m)}">${esc(m)} <span class="mz-cat-ct">${count}</span></button>`;
          }).join('')}
        </div>`;
    } else if (axis === 'motifs') {
      chipsRow = `
        <div class="mz-cats-row">
          <button class="mz-cat ${state.selectedMotif === 'tous' ? 'on' : ''}" data-mz-motif-filter="tous">Tous les motifs</button>
          ${motifs.map((mot) => {
            const count = RAYONS.reduce((acc, r) => acc + r.items.filter((p) => p.motif === mot).length, 0);
            return `<button class="mz-cat ${state.selectedMotif === mot ? 'on' : ''}" data-mz-motif-filter="${esc(mot)}">${esc(mot)} <span class="mz-cat-ct">${count}</span></button>`;
          }).join('')}
        </div>`;
    } else if (axis === 'promo') {
      chipsRow = `<div class="mz-cats-row"><button class="mz-cat on" data-mz-cat="_promo">Articles en promotion (${promoN})</button></div>`;
    } else if (axis === 'fragile') {
      chipsRow = `<div class="mz-cats-row"><button class="mz-cat on" data-mz-axis="fragile">Articles céramique & verrerie fragile (${fragileN})</button></div>`;
    }

    const catsEl = $('#mz-cats', root);
    if (!catsEl) return;
    catsEl.innerHTML = `<div class="mz-filter-wrap">${axisRow}${chipsRow}</div>`;

    catsEl.onclick = (e) => {
      const axisB = e.target.closest('[data-mz-axis]');
      if (axisB) {
        state.filterAxis = axisB.dataset.mzAxis;
        if (state.filterAxis === 'rayons') state.rayon = 'tous';
        if (state.filterAxis === 'marques') state.selectedMarque = 'tous';
        if (state.filterAxis === 'motifs') state.selectedMotif = 'tous';
        renderCats(); renderGrid(); icons();
        return;
      }
      const catB = e.target.closest('[data-mz-cat]');
      if (catB) {
        state.rayon = catB.dataset.mzCat || catB.dataset.mzCat;
        renderCats(); renderGrid(); icons();
        return;
      }
      const marqB = e.target.closest('[data-mz-marque]');
      if (marqB) {
        state.selectedMarque = marqB.dataset.mzMarque;
        renderCats(); renderGrid(); icons();
        return;
      }
      const motB = e.target.closest('[data-mz-motif-filter]');
      if (motB) {
        state.selectedMotif = motB.dataset.mzMotifFilter;
        renderCats(); renderGrid(); icons();
        return;
      }
    };
  }

  function cardFlag(p) {
    const st = p && p.format === 'service' ? sellableStockOf(p) : stockOf(p);
    if (st === 0) return '<span class="mz-card-flag out">épuisé</span>';
    if (st <= 2) return '<span class="mz-card-flag low">stock bas</span>';
    if (p.flag) return `<span class="mz-card-flag">${esc(p.flag)}</span>`;
    return '';
  }

  /* Les articles qui portent une étiquette promo en ce moment. Un Set : deux
     promotions sur le même article ne le comptent pas deux fois. */
  function promoedIds() {
    const out = new Set();
    if (!window.KiwiPromos) return out;
    RAYONS.forEach((r) => r.items.forEach((it) => { if (promoFor(it.id)) out.add(it.id); }));
    return out;
  }

  function renderGrid() {
    let rayons = RAYONS;
    const axis = state.filterAxis || 'rayons';

    if (axis === 'promo') {
      const ids = promoedIds();
      rayons = RAYONS.map((r) => ({ ...r, items: r.items.filter((it) => ids.has(it.id)) })).filter((r) => r.items.length);
    } else if (axis === 'fragile') {
      rayons = RAYONS.map((r) => ({ ...r, items: r.items.filter((it) => !!it.fragile) })).filter((r) => r.items.length);
    } else if (axis === 'marques') {
      if (state.selectedMarque && state.selectedMarque !== 'tous') {
        rayons = RAYONS.map((r) => ({ ...r, items: r.items.filter((it) => it.marque === state.selectedMarque) })).filter((r) => r.items.length);
      }
    } else if (axis === 'motifs') {
      if (state.selectedMotif && state.selectedMotif !== 'tous') {
        rayons = RAYONS.map((r) => ({ ...r, items: r.items.filter((it) => it.motif === state.selectedMotif) })).filter((r) => r.items.length);
      }
    } else {
      rayons = state.rayon === 'tous' ? RAYONS : RAYONS.filter((r) => r.id === state.rayon);
    }

    let i = 0;
    $('#mz-gridwrap', root).innerHTML = (rayons.length ? rayons.map((r) => `
      <div class="mz-cat-head">${esc(r.label)}</div>
      <div class="mz-grid">${r.items.map((p) => {
        const pr = promoFor(p.id);
        return `
        <button class="mz-card ${(p.format === 'service' ? sellableStockOf(p) : stockOf(p)) === 0 ? 'is-out' : ''}${pr ? ' is-promo' : ''}" data-mz-item="${p.id}" style="--i:${i++}">
          <span class="mz-card-art">${artOf(p)}</span>
          ${p.marque ? `<span class="mz-card-brand">${esc(p.marque)}</span>` : ''}
          ${isConsignedProduct(p) ? `<span class="mz-consign-tag" title="Catégorie B">B</span>` : ''}
          <span class="mz-card-name">${esc(p.name)}</span>
          <div style="display:flex; flex-wrap:wrap; gap:4px; margin-top:2px;">
            ${p.motif ? `<span class="mz-card-motif">${esc(p.motif)}</span>` : ''}
            ${p.format === 'service' ? `<span class="mz-card-fmt">Service ${p.servicePieces ? p.servicePieces + ' pcs' : ''}</span>` : ''}
            ${p.fragile ? `<span class="mz-card-fragile"><i data-lucide="shield-alert"></i>Fragile</span>` : ''}
          </div>
          <span class="mz-card-price">${pr ? `<s>${fmtMAD(pr.was)}</s> ` : ''}${fmtMAD(pr ? pr.price : shelf(p.price))}</span>
          ${cardFlag(p)}
          ${pr ? `<span class="mz-card-promo" title="${esc(pr.promo.name)}">${esc(pr.badge)}</span>` : ''}
        </button>`; }).join('')}
      </div>`).join('') : '<div class="mz-empty" style="margin:40px auto; text-align:center;">Aucun article dans cette sélection.</div>');
    $('#mz-gridwrap', root).onclick = (e) => {
      const b = e.target.closest('[data-mz-item]');
      if (b) openSheet(b.dataset.mzItem || b.dataset.mzItem, state.exchange ? { exchange: true } : null);
    };
  }

  function renderExchNote() {
    const slot = $('#mz-exch-slot', root);
    if (!state.exchange) { slot.innerHTML = ''; return; }
    const sale = findSale(state.exchange.saleId);
    const ln = sale.lines[state.exchange.idx];
    slot.innerHTML = `
      <div class="mz-exch-note">
        <i data-lucide="arrow-left-right"></i>
        <span class="l">Échange <b>${sale.id}</b>, retour <b>${esc((P[ln.pid] && P[ln.pid].name) || ln.name || 'Article')} · ${esc(ln.size)}</b> (${fmtMAD(ln.unit)}).
        Touchez l'article de remplacement dans la grille.</span>
        <button class="mz-exch-cancel" id="mz-exch-cancel">Annuler l'échange</button>
      </div>`;
    $('#mz-exch-cancel', slot).onclick = () => {
      state.exchange = null;
      renderExchNote();
      toast('Échange annulé, rien n\'a bougé');
      icons();
    };
    icons();
  }

  /* ═══════════════════════ TICKET ═══════════════════════ */
  function clientRow(t) {
    if (!t.client) {
      return `<button class="mz-tk-row" id="mz-tk-client"><i data-lucide="user-plus"></i>
        <span class="l"><b>Attacher une cliente</b><span>Téléphone d'abord, points et taille suivent</span></span>
        <span class="edit">Chercher</span></button>`;
    }
    if (t.client === 'passage') {
      return `<button class="mz-tk-row is-set" id="mz-tk-client"><i data-lucide="user"></i>
        <span class="l"><b>Cliente de passage</b><span>Sans fiche, retrouvable par n° de ticket</span></span>
        <span class="edit">Changer</span></button>`;
    }
    const c = clById(t.client);
    if (!c) return `<button class="mz-tk-row" id="mz-tk-client"><i data-lucide="user-plus"></i>
        <span class="l"><b>Attacher une cliente</b><span>Téléphone d'abord, points et taille suivent</span></span>
        <span class="edit">Chercher</span></button>`;
    const sub = [esc(c.phone) || '·', c.points + ' pts', c.taille ? 'taille ' + esc(c.taille) : ''].filter(Boolean).join(' · ');
    return `<button class="mz-tk-row is-set" id="mz-tk-client"><i data-lucide="user-check"></i>
      <span class="l"><b>${esc(c.name)}</b><span>${sub}</span></span>
      ${c.vip ? '<span class="mz-vip-chip">VIP</span>' : ''}
      <span class="edit">Changer</span></button>`;
  }

  /* La récompense fidélité au moment d'encaisser : quand la cliente attachée a
     assez de points / une carte pleine, une pastille « Utiliser » apparaît sous
     sa fiche. Un geste : la remise s'applique au ticket, les points ne sont
     débités qu'au paiement (redeem dans onPaid) — annulable tant qu'on n'a pas
     encaissé. Rien en démo ni pour la cliente de passage. */
  function rewardRow(t) {
    if (!t.client || t.client === 'passage') return '';
    if (t.reward && t.reward.clientId === t.client) {
      return `<button class="mz-reward-row is-on" id="mz-reward-toggle"><i data-lucide="gift"></i>
        <span class="l"><b>Récompense appliquée · ${esc(t.reward.label)}</b><span>Points débités à l'encaissement</span></span>
        <span class="edit">Annuler</span></button>`;
    }
    const rw = clReward(t.client);
    if (rw && rw.ready) {
      return `<button class="mz-reward-row" id="mz-reward-toggle"><i data-lucide="gift"></i>
        <span class="l"><b>Récompense prête · ${esc(rw.label)}</b><span>${rw.kind === 'percent' ? 'Remise fidélité sur ce ticket' : 'Un article offert sur ce ticket'}</span></span>
        <span class="edit">Utiliser</span></button>`;
    }
    return '';
  }

  const openTicketRemise = () => mzTicketRemise({ state, root, $, $$, esc, icons, toast, openVeil, closeVeil, openApprove, renderTicket, renderGrid, renderBadges, policyKey: _bqKey });

  function renderTicket() {
    const t = state.ticket;
    const { promo, remise, reward, total } = ticketTotals(t);
    const count = ticketCount(t);
    const el = $('#mz-ticket', root);
    const skin = mzSkinOn();
    el.innerHTML = `
      <div class="mz-tk-head">
        <div><span class="mz-tk-title">Ticket</span> <span class="mz-tk-num${t.num ? '' : t.numError ? ' err' : ''}">· ${t.num || (t.numError ? 'numéro indisponible' : 'attribution…')}${isOfflineRef(t.num) ? ' · hors-ligne' : ''} · par ${esc(STAFF.caissiere.name)}</span></div>
        ${!t.num && t.numError ? '<button class="mz-tk-retry" id="mz-tk-retry">Réessayer</button>' : ''}
        ${t.lines.length ? '<button class="mz-tk-reset" id="mz-tk-reset">Vider</button>' : ''}
      </div>
      <div class="mz-tk-meta">${clientRow(t)}${rewardRow(t)}</div>
      <div class="mz-tk-lines" id="mz-tk-lines">
        ${t.lines.length ? t.lines.map((ln, i) => lineRow(ln, i)).join('') : `
          <div class="mz-tk-empty">
            <i data-lucide="shopping-bag"></i>
            <div>Le ticket est vide.<br>Touchez un article dans la grille, ou scannez son code-barres.</div>
          </div>`}
      </div>
      <div class="mz-tk-foot">
        ${t.lines.length && !skin ? `
        <div class="mz-tk-opt-bar">
          <button class="mz-tk-opt-btn ${remise ? 'on' : ''}" id="mz-tk-remise"><i data-icon="percent"></i> ${remise ? 'Remise · −' + fmtMAD(remise) : 'Remise'}</button>
        </div>` : ''}
        <div class="mz-tk-tot">
          <span class="pcs"><i data-lucide="tag"></i> ${count} article${count > 1 ? 's' : ''}</span>
          ${promo ? `<span class="rem promo">Promotions · −${fmtMAD(promo)}</span>` : ''}
          ${remise ? `<span class="rem">Remise · −${fmtMAD(remise)}</span>` : ''}
          ${reward ? `<span class="rem rew">Récompense · −${fmtMAD(reward)}</span>` : ''}
        </div>
        <div class="mz-tk-total"><span class="lbl">Total</span><span class="val">${fmtMAD(total)}</span></div>
        <button class="mz-validate" id="mz-validate" ${t.lines.length && t.num ? '' : 'disabled'}>
          <i data-lucide="banknote"></i> ${t.num ? `Encaisser · ${fmtMAD(total)}` : t.numError ? 'Numéro de ticket indisponible' : 'Attribution du numéro…'}
        </button>
      </div>`;
    const retry = $('#mz-tk-retry', el);
    if (retry) retry.onclick = () => {
      retry.disabled = true;
      assignTicketNumber(t).then(
        () => toast('Numéro attribué · ticket ' + t.num),
        () => toast('Numéro de ticket toujours indisponible', state.ticketStorageError
          ? 'Le stockage sécurisé de cette tablette est indisponible. Contactez le support.'
          : 'Reconnectez cette caisse pour réserver sa prochaine série.')
      );
    };
    const reset = $('#mz-tk-reset', el);
    if (reset) reset.onclick = () => {
      t.lines.forEach((ln) => releaseStock(ln.pid, ln.size, ln.qty, ln.isPiece));
      freshTicket();                      /* ticket ET cliente remis à zéro — pas d'attache auto */
      renderTicket(); renderGrid(); renderBadges(); icons();
      toast('Ticket vidé, articles remis en stock');
    };
    $('#mz-tk-client', el).onclick = openClientModal;
    const rwBtn = $('#mz-reward-toggle', el);
    if (rwBtn) rwBtn.onclick = () => {
      if (t.reward && t.reward.clientId === t.client) {
        t.reward = null;
        toast('Récompense retirée du ticket');
      } else {
        const rw = clReward(t.client);
        if (!rw || !rw.ready) { toast('Pas encore de récompense pour cette cliente'); return; }
        t.reward = { clientId: t.client, kind: rw.kind, value: rw.value, label: rw.label };
        toast('Récompense appliquée', rw.label);
      }
      renderTicket(); icons();
    };
    const remBtn = $('#mz-tk-remise', el);
    if (remBtn) remBtn.onclick = openTicketRemise;
    $('#mz-validate', el).onclick = checkout;
    $('#mz-tk-lines', el).onclick = (e) => {
      const minus = e.target.closest('[data-mz-minus]');
      const plus = e.target.closest('[data-mz-plus]');
      const idx = minus ? +minus.dataset.mzMinus : plus ? +plus.dataset.mzPlus : -1;
      if (idx < 0) return;
      const ln = t.lines[idx];
      if (plus) {
        const u = holdStock(ln.pid, ln.size, 1, ln.isPiece);
        if (u === false) {
          toast(`${P[ln.pid].name} · ${ln.size}, plus de stock, dernière pièce déjà sur le ticket`);
          return;
        }
        ln.units = (ln.units || 0) + u;
        ln.qty++;
      } else {
        ln.units = (ln.units || 0) - releaseStock(ln.pid, ln.size, 1, ln.isPiece);
        ln.qty--;
        if (ln.qty <= 0) t.lines.splice(idx, 1);
      }
      renderTicket(); renderGrid(); renderBadges(); icons();
    };
    /* Peau 2027 : le pied du ticket de la boutique (Clients et Remise, puis
       Encaisser pleine largeur), remonté à CHAQUE rendu. */
    mzKitTicketFoot(el, $, icons, skin, {
      clientLabel: mzClientLabel(t, clById, firstName),
      canRemise: !!t.lines.length, onRemise: openTicketRemise,
    });
    icons();
  }
  /* Peau 2027 : la barre de vente répond dès le premier chiffre tapé, comme la
     boutique. La douchette garde son chemin (commitEan), la tuile le sien. */
  const wireSellSearch = (bar, input) => mzSellSearch(bar, input, mzSkinOn(), {
    commit: commitEan, money: fmtMAD, esc, icons, artOf,
    open: (pid) => openSheet(pid, state.exchange ? { exchange: true } : null),
    catalog: () => ({ P, BY_EAN, promoFor, shelf, stockOf, colorLabel, availableStock: (pid, size) => (P[pid] && P[pid].sizes && P[pid].sizes[size]) || 0 }),
  });

  function lineRow(ln, i) {
    const p = P[ln.pid];
    const u = lineUnit(ln);
    const pr = linePromo(ln);
    const origPrice = shelf((ln.customPrice != null) ? ln.customPrice : (p ? p.price : 0));
    return `<div class="mz-line">
      <span class="mz-line-art">${artOf(p, ln.color)}</span>
      <span class="mz-line-mid">
        ${(ln.marque || p.marque) ? `<span class="mz-line-brand">${esc(ln.marque || p.marque)}</span>` : ''}
        ${isConsignedProduct(p) ? `<span class="mz-consign-tag" title="Catégorie B">B</span>` : ''}
        <span class="mz-line-name">${esc(p.name)}</span>
        <span class="mz-line-sub">
          ${colorDot(ln.color)}
          <span class="sz">${esc(ln.size)}</span> ${esc(colorLabel(ln.color))}
          ${ln.format === 'service' ? `<span class="mz-line-fmt">Service (${ln.servicePieces || p.servicePieces || 18} pcs)</span>` : (ln.isPiece ? '<span class="mz-line-fmt">À la pièce</span>' : '')}
          ${(ln.motif || p.motif) ? `<span class="mz-line-motif">${esc(ln.motif || p.motif)}</span>` : ''}
          ${(ln.fragile || p.fragile) ? '<span class="mz-line-fragile">Fragile</span>' : ''}
          ${ln.registryTitle ? `<span class="mz-line-reg">Liste : ${esc(ln.registryTitle)}</span>` : ''}
          ${pr ? `<span class="mz-line-promo" title="${esc(pr.name || 'Promotion')}"><i data-lucide="tag"></i>${esc(pr.badge)}</span>` : ''}
          ${ln.remise ? `<span class="mz-line-rem">−${ln.remise} %</span>` : ''}
        </span>
      </span>
      <span class="mz-line-right">
        <span class="mz-line-price">${(ln.remise || pr) ? `<span class="was">${fmtMAD(origPrice * ln.qty)}</span>` : ''}${fmtMAD(u * ln.qty)}</span>
        <span class="mz-line-qty">
          <button data-mz-minus="${i}" aria-label="Retirer">−</button><b>${ln.qty}</b><button data-mz-plus="${i}" aria-label="Ajouter">+</button>
        </span>
      </span>
    </div>`;
  }

  /* ───────────────── STOCK ARITHMETIC : Service vs Pièce ─────────────────
   * Un service complet (ex: service 18 pièces) est stocké comme une unité (1 set).
   * 1. Vente d'un service complet : décrémente 1 unité entière du stock de la déclinaison.
   * 2. Vente d'une pièce individuelle hors service : facturée à `piecePriceMAD`.
   *    Au niveau de l'inventaire matériel, la vente d'une pièce décrémente
   *    le stock de la déclinaison avec le motif explicite 'vente · pièce hors service'
   *    ou gère le ratio 1/N pièces pour que le commerçant conserve la traçabilité exacte
   *    du set dépareillé sans fausser le décompte des services complets.
   * ────────────────────────────────────────────────────────────────────────── */
  /* ───────────────── PIÈCES DÉPAREILLÉES ─────────────────
   * Une cliente qui casse une assiette revient en racheter UNE, pas un service
   * de dix-huit. Décrémenter un set entier à chaque pièce vendue sortait
   * 1 450 MAD de stock pour 85 MAD encaissés : après quatre assiettes le stock
   * de services affichait zéro pendant que 68 pièces restaient en rayon.
   *
   * On fait donc ce que fait le magasin : on OUVRE un set, et les N−1 pièces
   * restantes deviennent du dépareillé qui sert les ventes suivantes. Le
   * décompte des services complets reste vrai, les pièces libres sont comptées,
   * et un retour qui reconstitue un set entier le referme.
   *
   * Rangé par commerce, comme les listes cadeaux et le journal de casse : une
   * caisse qui change de commerce par jumelage ne doit pas hériter du
   * dépareillé du voisin. */
  const LOOSE_KEY = 'kiwi:mzLoose';
  let LOOSE = null;
  function loadLoose() {
    if (LOOSE) return LOOSE;
    try { LOOSE = JSON.parse(localStorage.getItem(LOOSE_KEY + ':' + merchantSlug()) || '{}'); } catch (_) { LOOSE = null; }
    if (!LOOSE || typeof LOOSE !== 'object') LOOSE = {};
    return LOOSE;
  }
  function saveLoose() {
    try { localStorage.setItem(LOOSE_KEY + ':' + merchantSlug(), JSON.stringify(loadLoose())); } catch (_) {}
  }
  const looseKey = (pid, size) => pid + '·' + size;
  function looseOf(pid, size) { return +loadLoose()[looseKey(pid, size)] || 0; }
  function setLoose(pid, size, n) {
    const d = loadLoose(), k = looseKey(pid, size);
    if (n > 0) d[k] = n; else delete d[k];
    saveLoose();
  }
  const piecesPerSet = (p) => Math.max(1, +p.servicePieces || 1);
  /* Une ligne se compte en pièces détachées seulement si elle est vendue à la
     pièce ET que l'article est un service — une assiette vendue seule, qui est
     son propre article, garde le décompte normal. */
  const sellsLoose = (p, isPiece) => !!isPiece && (p.format === 'service' || +p.servicePieces > 0);

  /* Retire `qty` pièces : d'abord le dépareillé, puis en ouvrant des sets.
     Renvoie false si les sets ne suffisent pas — et ne modifie alors RIEN. */
  function takeLoose(pid, size, qty) {
    const p = P[pid], per = piecesPerSet(p);
    let free = looseOf(pid, size);
    const open = free >= qty ? 0 : Math.ceil((qty - free) / per);
    if (open > (p.sizes[size] || 0)) return false;
    if (open) { stockAdd(pid, size, -open); free += open * per; }
    setLoose(pid, size, free - qty);
    return open;
  }
  /* Rend `qty` pièces, et referme tout set entier reconstitué. */
  function giveLoose(pid, size, qty) {
    const p = P[pid], per = piecesPerSet(p);
    let free = looseOf(pid, size) + qty;
    const whole = Math.floor(free / per);
    if (whole) { stockAdd(pid, size, whole); free -= whole * per; }
    setLoose(pid, size, free);
    return whole;
  }
  /* Les quatre chemins qui bougent du stock pour un ticket passent par ces
     deux-là — ajout, stepper, vidage, reprise — pour que la règle pièce/set
     n'existe qu'à un seul endroit. */
  /* Les deux renvoient un nombre d'UNITÉS DE CATALOGUE — des sets, pas des
     pièces. C'est ce que le catalogue partagé compte, donc c'est ce que la
     vente doit lui écrire : vendre une assiette prise dans du dépareillé ne
     bouge rien côté catalogue (0), n'ouvrir un set en écrit qu'un seul.
     holdStock renvoie false, et n'a rien modifié, si le stock ne suffit pas. */
  function holdStock(pid, size, qty, isPiece) {
    const p = P[pid];
    if (!p) return false;
    if (sellsLoose(p, isPiece)) return takeLoose(pid, size, qty);
    if ((p.sizes[size] || 0) < qty) return false;
    stockAdd(pid, size, -qty);
    return qty;
  }
  function releaseStock(pid, size, qty, isPiece) {
    const p = P[pid];
    if (!p) return 0;
    if (sellsLoose(p, isPiece)) return giveLoose(pid, size, qty);
    stockAdd(pid, size, qty);
    return qty;
  }

  function stockAvailable(pid, size, isPiece) {
    const p = P[pid];
    if (!p) return 0;
    return sellsLoose(p, isPiece)
      ? looseOf(pid, size) + (p.sizes[size] || 0) * piecesPerSet(p)
      : (p.sizes[size] || 0);
  }

  function sellableStockOf(p) {
    if (!p) return 0;
    return sizesOf(p).reduce((sum, size) => sum + stockAvailable(p.id, size, true), 0);
  }

  /* UI mirror of holdStock. It must use the same loose-piece arithmetic or a
     product with loose stock appears sold out even though the sale can work. */
  function canHoldStock(pid, size, qty, isPiece) {
    const p = P[pid];
    if (!p) return false;
    if (sellsLoose(p, isPiece)) {
      return looseOf(pid, size) + (p.sizes[size] || 0) * piecesPerSet(p) >= qty;
    }
    return (p.sizes[size] || 0) >= qty;
  }

  function addToTicket(pid, cfg, opts) {
    const p = P[pid];
    if (!p) return false;
    cfg = cfg || {};
    const size = cfg.size || sizesOf(p)[0];
    const color = cfg.color || p.colors[0];
    const qty = cfg.qty || 1;
    const isPiece = !!cfg.isPiece;
    const format = cfg.format || p.format || 'piece';
    const customPrice = cfg.customPrice != null ? shelf(cfg.customPrice) : (isPiece ? pieceUnitPrice(p) : null);

    const heldUnits = holdStock(pid, size, qty, isPiece);
    if (heldUnits === false) {
      toast(`${p.name} · ${size}, stock insuffisant`);
      return false;
    }
    const pr = promoForLine({ pid, isPiece, customPrice, servicePieces: p.servicePieces });
    const stamp = pr ? { price: pr.price, badge: pr.badge, name: pr.promo.name, id: pr.promo.id } : null;
    const same = state.ticket.lines.find((l) => l.pid === pid && l.size === size && l.color === color && l.remise === (cfg.remise || 0) && l.isPiece === isPiece && l.registryId === (cfg.registryId || null));
    if (same) {
      same.qty += qty;
      same.units = (same.units || 0) + heldUnits;
      if (stamp && (!same.promo || stamp.price < same.promo.price)) same.promo = stamp;
    } else {
      state.ticket.lines.push({
        pid, size, color, qty, remise: cfg.remise || 0, promo: stamp,
        /* `units` = ce que le CATALOGUE doit bouger au règlement ; `qty` = ce
           que la cliente emporte. Les deux diffèrent dès qu'on vend à la pièce. */
        units: heldUnits,
        format, isPiece, customPrice, servicePieces: p.servicePieces || null,
        marque: p.marque || '', motif: p.motif || '', fragile: !!p.fragile,
        registryId: cfg.registryId || null, registryTitle: cfg.registryTitle || null,
      });
    }
    renderTicket(); renderGrid(); renderBadges(); icons();
    if (!opts || !opts.quiet) toast(`${p.name} · ${isPiece ? 'À la pièce' : (format === 'service' ? 'Service complet' : size)}, sur le ticket`);
    return true;
  }

  /* ═══════════════════════ VARIANT SHEET ═══════════════════════ */
  const sheet = { pid: null, size: null, color: null, qty: 1, remise: 0, exchange: false, format: 'piece' };

  function defaultSize(p) {
    const c = ticketClient();
    if (!sheet.exchange && c && p.kind === 'taille' && (p.sizes[c.taille] || 0) > 0) return c.taille;
    return firstFree(p) || sizesOf(p)[0];
  }

  function openSheet(pid, opts) {
    window.KiwiDiscountPolicy?.refresh?.(); // the owner may have changed the allowed percentages
    const p = P[pid];
    Object.assign(sheet, {
      pid,
      size: null, color: p.colors[0], qty: 1, remise: 0,
      exchange: !!(opts && opts.exchange),
      format: p.format || 'piece',
    });
    sheet.size = defaultSize(p);
    renderSheet();
    openVeil('#mz-sheet-veil');
    icons();
    lens();
  }

  function renderSheet() {
    const p = P[sheet.pid];
    const c = ticketClient();
    const sheetPiece = p.format === 'service' && sheet.format === 'piece';
    const pieceBase = sheetPiece ? pieceUnitPrice(p) : null;
    const shPromo = promoForLine({ pid: sheet.pid, isPiece: sheetPiece, customPrice: pieceBase, servicePieces: p.servicePieces });
    const servicePromo = promoForLine({ pid: sheet.pid, isPiece: false });
    let shBase = shPromo ? shPromo.price : shelf(p.price);
    if (sheetPiece && !shPromo) shBase = pieceBase;
    const unit = shelf(shBase * (100 - sheet.remise) / 100);
    const canAdd = canHoldStock(sheet.pid, sheet.size, 1, sheetPiece);
    const el = $('#mz-sheetm', root);
    el.innerHTML = `
      <button class="mz-modal-x" data-mz-close aria-label="Fermer"><i data-icon="close"></i></button>
      <div class="mz-sheet-head">
        <span class="mz-sheet-art">${artOf(p)}</span>
        <span class="mz-sheet-title">
          ${p.marque ? `<div class="mz-card-brand">${esc(p.marque)}</div>` : ''}
          ${isConsignedProduct(p) ? `<div class="mz-f-hint"><span class="mz-consign-tag" title="Catégorie B">B</span> Catégorie B${p.consignor ? ` · ${esc(p.consignor)}` : ''}</div>` : ''}
          <h3>${esc(p.name)}</h3>
          <span class="sub">
            ${esc((RAYONS.find((r) => r.id === p.rayon) || { label: 'Divers' }).label)}
            ${p.motif ? ` · Motif : <b>${esc(p.motif)}</b>` : ''}
            ${p.fragile ? ` · <span style="color:#B25E00;font-weight:700;">Fragile</span>` : ''}
            ${p.ean ? ` · ${esc(p.ean)}` : ''}
          </span>
        </span>
        <span class="mz-sheet-price">
          <span class="val" id="mz-sheet-total">${fmtMAD(unit * sheet.qty)}</span>
          <span class="per ${sheet.remise ? 'rem' : ''}" id="mz-sheet-per">${sheet.remise ? `−${sheet.remise} % · accord gérante` : `${unit} MAD × ${sheet.qty}`}</span>
        </span>
      </div>
      ${shPromo ? `
      <div class="mz-sheet-promo">
        <i data-lucide="tag"></i>
        <span class="l"><b>${esc(shPromo.promo.name)}</b><span>${esc(shPromo.badge)} · ${fmtMAD(shPromo.price)} au lieu de ${fmtMAD(shPromo.was)}</span></span>
      </div>` : ''}

      ${p.format === 'service' ? `
      <div class="mz-f">
        <div class="mz-f-lbl">Format de vente</div>
        <div class="mz-seg" id="mz-format-seg">
          <button class="mz-seg-it ${sheet.format !== 'piece' ? 'on' : ''}" data-mz-format="service">
            Service complet (${p.servicePieces || 18} pcs)
            <small>${fmtMAD(servicePromo ? servicePromo.price : shelf(p.price))}</small>
          </button>
          <button class="mz-seg-it ${sheet.format === 'piece' ? 'on' : ''}" data-mz-format="piece">
            À la pièce (1 unité)
            <small>${fmtMAD(pieceUnitPrice(p))}</small>
          </button>
        </div>
        ${(() => {
          /* Le dépareillé se VOIT, sinon la vendeuse ouvre un set neuf sans
             savoir qu'il reste des pièces d'un set déjà entamé. */
          const free = looseOf(p.id, sheet.size || sizesOf(p)[0]);
          return free
            ? `<div class="mz-f-hint">${free} pièce${free > 1 ? 's' : ''} dépareillée${free > 1 ? 's' : ''} d’un set déjà ouvert · servies en premier.</div>`
            : `<div class="mz-f-hint">Aucune pièce dépareillée : vendre à la pièce ouvrira un set.</div>`;
        })()}
      </div>` : ''}

      <div class="mz-f">
        <div class="mz-f-lbl">${sizeWord(p)} <span class="opt">· stock par modèle en direct</span></div>
        <div class="mz-seg" data-lens-demo id="mz-size-seg">
          ${sizesOf(p).map((s) => {
            const st = stockAvailable(p.id, s, sheetPiece);
            const usual = !sheet.exchange && c && p.kind === 'taille' && s === c.taille;
            return `<button class="mz-seg-it ${s === sheet.size ? 'on' : ''}" data-lens-item data-mz-size="${esc(s)}" ${st === 0 ? 'disabled' : ''}>
              ${usual ? '<span class="mz-seg-usual">habituelle</span>' : ''}${esc(s)}<small>${st === 0 ? 'épuisé' : `${st} ${sheetPiece ? 'pièce' + (st > 1 ? 's' : '') : 'en stock'}`}</small></button>`;
          }).join('')}
        </div>
      </div>

      <div class="mz-f">
        <div class="mz-f-lbl">Couleur / Motif</div>
        <div id="mz-colors">
          ${KC() ? KC().picker('mz-color', sheet.color, { ids: p.colors, size: 'lg' }) : ''}
        </div>
      </div>

      ${sheet.exchange ? '' : `
      <div class="mz-row-2">
        <div class="mz-f">
          <div class="mz-f-lbl">Quantité</div>
          <div class="mz-stepper">
            <button id="mz-qty-minus" aria-label="Moins">−</button>
            <b id="mz-qty-val">${sheet.qty}</b>
            <button id="mz-qty-plus" aria-label="Plus">+</button>
          </div>
        </div>
        <div class="mz-f">
          <div class="mz-f-lbl">Remise <span class="opt">· accord gérante</span></div>
          <div class="mz-chips" id="mz-remise">
            ${[0, ...(window.KiwiDiscountPolicy?.percentages(_bqKey) || [5, 10, 15, 20])].map((r) => `<button class="mz-chip ${sheet.remise === r ? 'on' : ''}" data-mz-rem="${r}">${r === 0 ? 'Sans' : `−${r} %`}${r > 0 && !state.ticket.remiseAuth ? ' <i data-lucide="lock"></i>' : ''}</button>`).join('')}
          </div>
        </div>
      </div>`}

      <div class="mz-sheet-foot">
        <button class="mz-btn secondary" data-mz-close>Annuler</button>
        ${sheet.exchange
          ? `<button class="mz-btn primary" id="mz-sheet-add" ${canAdd ? '' : 'disabled'}><i data-lucide="arrow-left-right"></i>Choisir cet article · ${fmtMAD(shBase)}</button>`
          : `<button class="mz-btn primary" id="mz-sheet-add" ${canAdd ? '' : 'disabled'}><i data-lucide="plus"></i>Ajouter au ticket · <span id="mz-sheet-cta">${fmtMAD(unit * sheet.qty)}</span></button>`}
      </div>`;

    const refreshPrice = () => {
      const piece = p.format === 'service' && sheet.format === 'piece';
      const base = piece ? pieceUnitPrice(p) : null;
      const activePromo = promoForLine({ pid: sheet.pid, isPiece: piece, customPrice: base, servicePieces: p.servicePieces });
      const bPrice = activePromo ? activePromo.price : (piece ? base : shelf(p.price));
      const u = shelf(bPrice * (100 - sheet.remise) / 100);
      $('#mz-sheet-total', el).textContent = fmtMAD(u * sheet.qty);
      $('#mz-sheet-per', el).textContent = sheet.remise ? `−${sheet.remise} % · accord gérante` : `${u} MAD × ${sheet.qty}`;
      $('#mz-sheet-per', el).classList.toggle('rem', !!sheet.remise);
      const cta = $('#mz-sheet-cta', el);
      if (cta) cta.textContent = fmtMAD(u * sheet.qty);
      const qv = $('#mz-qty-val', el);
      if (qv) qv.textContent = sheet.qty;
    };

    const fmtSeg = $('#mz-format-seg', el);
    if (fmtSeg) {
      fmtSeg.onclick = (e) => {
        const b = e.target.closest('[data-mz-format]');
        if (!b) return;
        sheet.format = b.dataset.mzFormat;
        const piece = p.format === 'service' && sheet.format === 'piece';
        if (!canHoldStock(sheet.pid, sheet.size, 1, piece)) {
          const next = sizesOf(p).find((s) => canHoldStock(sheet.pid, s, 1, piece));
          if (next) sheet.size = next;
        }
        renderSheet(); icons(); lens();
      };
    }

    $('#mz-size-seg', el).onclick = (e) => {
      const b = e.target.closest('[data-mz-size]');
      if (!b || b.disabled) return;
      sheet.size = b.dataset.mzSize || b.dataset.mzSize;
      const piece = p.format === 'service' && sheet.format === 'piece';
      const maxQty = stockAvailable(p.id, sheet.size, piece);
      if (sheet.qty > maxQty) sheet.qty = Math.max(1, maxQty);
      $$('[data-mz-size]', el).forEach((x) => x.classList.toggle('on', x === b));
      refreshPrice();
    };
    $('#mz-colors', el).addEventListener('kc:change', (e) => { sheet.color = e.detail.value; });
    const qMinus = $('#mz-qty-minus', el);
    if (qMinus) qMinus.onclick = () => { if (sheet.qty > 1) { sheet.qty--; refreshPrice(); } };
    const qPlus = $('#mz-qty-plus', el);
    if (qPlus) qPlus.onclick = () => {
      const piece = p.format === 'service' && sheet.format === 'piece';
      const maxQty = stockAvailable(p.id, sheet.size, piece);
      if (sheet.qty >= maxQty) { toast(`${p.name} · ${sheet.size}, ${maxQty} en stock, pas plus`); return; }
      sheet.qty++; refreshPrice();
    };
    const remRow = $('#mz-remise', el);
    if (remRow) remRow.onclick = (e) => {
      const b = e.target.closest('[data-mz-rem]');
      if (!b) return;
      const r = +b.dataset.mzRem;
      if (r > 0 && window.KiwiDiscountPolicy && !window.KiwiDiscountPolicy.allowed(r, _bqKey)) { toast('Pourcentage non autorisé'); return; }
      if (r > 0 && !state.ticket.remiseAuth) { openApprove(r, () => { sheet.remise = r; renderSheet(); icons(); lens(); }); return; }
      sheet.remise = r;
      $$('[data-mz-rem]', el).forEach((x) => x.classList.toggle('on', +x.dataset.mzRem === r));
      refreshPrice();
    };
    $$('[data-mz-close]', el).forEach((b) => { b.onclick = () => closeVeil('#mz-sheet-veil'); });
    const add = $('#mz-sheet-add', el);
    if (add) add.onclick = () => {
      if (sheet.exchange) {
        closeVeil('#mz-sheet-veil');
        openExchSummary(sheet.pid, sheet.size, sheet.color);
        return;
      }
      const isPiece = (sheet.format === 'piece' && p.format === 'service');
      const piecePrice = isPiece ? pieceUnitPrice(p) : null;
      if (addToTicket(sheet.pid, {
        size: sheet.size,
        color: sheet.color,
        qty: sheet.qty,
        remise: sheet.remise,
        format: sheet.format,
        isPiece: isPiece,
        customPrice: piecePrice,
        marque: p.marque,
        motif: p.motif,
        fragile: p.fragile,
      })) {
        closeVeil('#mz-sheet-veil');
      }
    };
    icons();
  }

  /* ---------- approbation gérante (remise) ---------- */
  /* Ce que l'accord laisse derrière lui. Le pied du modal promet « tracé dans le
     journal » — et seul un booléen partait dans la vente : impossible, trois jours
     plus tard, de dire qui avait accordé les 20 % ni combien avaient été lâchés.
     On garde le nom (jamais le code), l'heure et le pourcentage demandé. */
  function markRemiseAuth(pct, by, role) {
    state.ticket.remiseAuth = { pct, by: by || '', role: role || '', at: new Date().toISOString() };
  }

  /* Sur une boutique RÉELLE, la remise passe par le vrai code responsable — le
     même portier que le remboursement et la fermeture de caisse, validé contre la
     liste du serveur. La liste d'équipe est neutralisée sur un vrai magasin
     (« Vendeur 1 »), donc la rangée « Aicha approuve » n'y était plus qu'un
     décor : un appui suffisait, sans code, sans nom. La démo locale garde sa
     distribution nommée — elle n'a pas de portier à interroger. */
  function openApprove(pct, onOk) {
    if (pvReal() && typeof window.requireManager === 'function') {
      if (window.KiwiAuthAct) window.KiwiAuthAct({ kind: 'discount', key: 'act.discount.pct', args: { pct: `${pct}\u202f%` } });
      window.requireManager(`Remise −${pct} % sur le ticket ${state.ticket.num}`, () => {
        let mgr = null;
        try { mgr = window.KiwiCaissePairing?.lastManager?.() || null; } catch (_) {}
        markRemiseAuth(pct, mgr && mgr.name, mgr && mgr.role);
        toast(mgr && mgr.name ? `Remise −${pct} %, accord ${mgr.name}` : `Remise −${pct} % autorisée`);
        onOk();
      });
      return;
    }
    const el = $('#mz-approvem', root);
    el.innerHTML = `
      <button class="mz-modal-x" data-mz-close aria-label="Fermer"><i data-icon="close"></i></button>
      <h3 class="modal-title">Remise −${pct} %</h3>
      <p class="modal-subtle">Une remise s'applique avec l'accord de la gérante, qui valide ?</p>
      <button class="mz-staff-row" id="mz-app-ok">
        <span class="mz-staff-ava">${initials(STAFF.gerante.name)}</span>
        <span class="l"><b>${esc(STAFF.gerante.name)}</b><span>${esc(STAFF.gerante.role)}, peut approuver</span></span>
        <span class="ok">Approuver</span>
      </button>
      <button class="mz-staff-row is-no" id="mz-app-no">
        <span class="mz-staff-ava">${initials(STAFF.conseil.name)}</span>
        <span class="l"><b>${esc(STAFF.conseil.name)}</b><span>${esc(STAFF.conseil.role)}</span></span>
        <span class="ok">Non habilitée</span>
      </button>
      <div class="mz-foot-note">L'accord vaut pour tout le ticket ${state.ticket.num}, tracé dans le journal.</div>`;
    openVeil('#mz-approve-veil');
    icons();
    $$('[data-mz-close]', el).forEach((b) => { b.onclick = () => closeVeil('#mz-approve-veil'); });
    $('#mz-app-ok', el).onclick = () => {
      markRemiseAuth(pct, STAFF.gerante.name, STAFF.gerante.role);
      closeVeil('#mz-approve-veil');
      toast(`Remise −${pct} %, accord ${STAFF.gerante.name}`);
      onOk();
    };
    $('#mz-app-no', el).onclick = () => toast(`${STAFF.conseil.name} n'est pas habilitée, seule la gérante approuve une remise`);
  }

  /* ═══════════════════════ CLIENTE — phone & name search (modal du ticket) ═══════ */
  function foldClientText(s) {
    return String(s || '').normalize('NFD').replace(/[\u0300-\u036f]/g, '').toLowerCase().trim();
  }
  function clienteHits(q) {
    const raw = String(q || '').trim();
    const src = clientList();
    if (!raw) return src;
    const qFold = foldClientText(raw);
    const digits = raw.replace(/\D/g, '');
    return src.filter((c) => {
      if (foldClientText(c.name).includes(qFold)) return true;
      if (c.email && foldClientText(c.email).includes(qFold)) return true;
      if (digits.length >= 2) {
        const cDigits = (c.phone || '').replace(/\D/g, '');
        if (cDigits.includes(digits)) return true;
        const cLocal = cDigits.replace(/^212/, '0');
        const qLocal = digits.replace(/^212/, '0');
        if (cLocal && qLocal && (cLocal.includes(qLocal) || qLocal.includes(cLocal))) return true;
      }
      return false;
    });
  }
  function clAvoirOf(c) {
    return activeAvoirs().find((a) => a.holderId === c.id) || null;
  }

  function openClientModal() {
    const el = $('#mz-clientm', root);
    let mode = 'search';
    if (window.KiwiClients && KiwiClients.pull) {
      KiwiClients.pull((changed) => {
        if (!changed || !root) return;
        const i = $('#mz-cl-q', el);
        if (i && $('#mz-client-veil.is-open', root)) {
          const val = i.value;
          render(val);
          icons();
          const next = $('#mz-cl-q', el);
          if (next) { next.focus(); moveCaretEnd(next); }
        }
      });
    }
    const render = (q) => {
      const hits = clienteHits(q);
      const isDigits = (q || '').replace(/\D/g, '').length > (q || '').replace(/\d/g, '').trim().length;
      const namePrefill = isDigits ? '' : (q || '').trim();
      const phonePrefill = isDigits ? (q || '').trim() : '';
      el.innerHTML = `
        <button class="mz-modal-x" data-mz-close aria-label="Fermer"><i data-icon="close"></i></button>
        <h3 class="modal-title">Cliente</h3>
        <p class="modal-subtle">Rechercher par nom ou par numéro de téléphone.</p>
        <div class="mz-phone-in"><i data-lucide="search"></i>
          <input id="mz-cl-q" type="text" enterkeyhint="search" autocorrect="off" autocapitalize="words" placeholder="Nom ou 06…" value="${esc(q || '')}" autocomplete="off" />
        </div>
        ${mode === 'search' ? `
          <div class="mz-cl-results">
            ${hits.map((c) => {
              const av = clAvoirOf(c);
              return `<button class="mz-cl-row" data-mz-cl="${c.id}">
                <span class="mz-cl-ava">${esc(initials(c.name))}</span>
                <span class="mz-cl-mid">
                  <span class="mz-cl-name">${esc(c.name)} ${c.vip ? '<span class="mz-vip-chip">VIP</span>' : ''}</span>
                  <span class="mz-cl-sub">${esc(c.phone) || '·'}${c.taille ? ' · taille ' + esc(c.taille) : ''}</span>
                </span>
                <span class="mz-cl-right"><b>${c.points} pts</b>${av ? `<span class="av">avoir ${fmtMAD(av.balance)}</span>` : `${c.achats} achat${c.achats > 1 ? 's' : ''}`}</span>
              </button>`;
            }).join('') || `<div class="mz-empty">Aucune fiche pour « ${esc(q)} »</div>`}
          </div>
          <button class="mz-cl-new" id="mz-cl-new"><i data-lucide="user-plus"></i>Nouvelle cliente${q && !hits.length ? ` · « ${esc(q)} »` : ''}</button>
          <div class="mz-sheet-foot" style="margin-top:10px;">
            <button class="mz-btn ghost" id="mz-cl-guest">Cliente de passage, sans fiche</button>
          </div>` : `
          <div class="mz-cl-form">
            <input class="mz-in" id="mz-cl-name" placeholder="Nom et prénom" value="${esc(namePrefill)}" />
            <input class="mz-in" id="mz-cl-tel" type="tel" inputmode="tel" autocomplete="tel" placeholder="06… / +212… (optionnel)" value="${esc(phonePrefill)}" />
            <div class="mz-sheet-foot" style="margin-top:4px;">
              <button class="mz-btn secondary" id="mz-cl-back">Retour</button>
              <button class="mz-btn primary" id="mz-cl-create"><i data-lucide="check"></i>Créer la fiche</button>
            </div>
          </div>`}`;
      $('#mz-cl-q', el).oninput = (e) => { render(e.target.value); icons(); const i = $('#mz-cl-q', el); i.focus(); moveCaretEnd(i); };
      $$('[data-mz-close]', el).forEach((b) => { b.onclick = () => closeVeil('#mz-client-veil'); });
      $$('[data-mz-cl]', el).forEach((b) => {
        b.onclick = () => {
          const c = clById(b.dataset.mzCl);
          if (!c) return;
          state.ticket.client = c.id;
          closeVeil('#mz-client-veil');
          const tt = [c.taille ? 'taille ' + c.taille : '', c.points + ' pts'].filter(Boolean).join(', ');
          toast(`${c.name}${tt ? ' · ' + tt : ''}${clAvoirOf(c) ? ', un avoir actif' : ''}`);
          renderTicket(); icons();
        };
      });
      const newBtn = $('#mz-cl-new', el);
      if (newBtn) newBtn.onclick = () => { mode = 'create'; render(q); icons(); };
      const guest = $('#mz-cl-guest', el);
      if (guest) guest.onclick = () => {
        state.ticket.client = 'passage';
        closeVeil('#mz-client-veil');
        renderTicket(); icons();
      };
      const back = $('#mz-cl-back', el);
      if (back) back.onclick = () => { mode = 'search'; render(q); icons(); };
      const create = $('#mz-cl-create', el);
      if (create) create.onclick = () => {
        const name = $('#mz-cl-name', el).value.trim();
        const tel = $('#mz-cl-tel', el).value.trim();
        if (!name) { toast('Le nom est requis pour la fiche'); return; }
        let cid;
        if (useKiwiCl()) {
          const rec = window.KiwiClients.upsert({ name, phone: tel, consent: true, source: 'caisse' });
          cid = rec.id;                                   // unified — appears in the dashboard « Clients » too
        } else {
          cid = 'cx' + Date.now().toString(36);
          const c = { id: cid, name, phone: tel, points: 0, taille: '', achats: 0, spent: 0, prefs: [], history: [] };
          CLIENTES.unshift(c); CL[cid] = c;
        }
        state.ticket.client = cid;
        closeVeil('#mz-client-veil');
        queueIfOffline('Fiche cliente');
        toast(`Fiche créée, ${name}`);
        renderTicket(); renderBadges(); icons();
      };
    };
    render('');
    openVeil('#mz-client-veil');
    icons();
    // Pas de focus auto : sur tablette le clavier couvrait la liste. La recherche reste au toucher.
  }
  function moveCaretEnd(input) { const v = input.value; input.value = ''; input.value = v; }

  /* ═══════════════════════ VUE CLIENTES ═══════════════════════ */
  function renderClientes() {
    const panel = $('[data-mz-panel="clientes"]', root);
    const q = state.clQuery;
    const hits = clienteHits(q);
    panel.innerHTML = `
      <div class="mz-clients mz-page">
        <header class="mz-head">
          <div><h1>Clientes</h1><div class="mz-head-sub">Rechercher par nom ou téléphone, la fiche suit la cliente</div></div>
          <div class="mz-search"><i data-lucide="search"></i>
            <input id="mz-clv-q" type="text" enterkeyhint="search" placeholder="Nom ou 06…" value="${esc(q)}" /></div>
        </header>
        <div class="mz-cl-scroll">
          <div class="mz-cl-grid">
            ${hits.map((c) => {
              const av = clAvoirOf(c);
              return `<button class="mz-clcard" data-mz-fiche="${c.id}">
                <span class="mz-clcard-top">
                  <span class="mz-cl-ava">${esc(initials(c.name))}</span>
                  <span class="l">
                    <span class="mz-cl-name">${esc(c.name)} ${c.vip ? '<span class="mz-vip-chip">VIP</span>' : ''}</span>
                    <span class="mz-cl-sub">${esc(c.phone)}</span>
                  </span>
                </span>
                <span class="mz-clcard-stats">
                  <span class="mz-mini ok"><i data-lucide="star"></i>${c.points} pts</span>
                  <span class="mz-mini"><i data-lucide="ruler"></i>taille ${esc(c.taille)}</span>
                  <span class="mz-mini"><i data-lucide="receipt"></i>${c.achats} achat${c.achats > 1 ? 's' : ''}</span>
                  ${av ? `<span class="mz-mini warn"><i data-lucide="ticket"></i>avoir ${fmtMAD(av.balance)}</span>` : ''}
                </span>
              </button>`;
            }).join('') || `<div class="mz-empty" style="grid-column:1/-1;">Aucune fiche pour « ${esc(q)} »</div>`}
          </div>
        </div>
      </div>`;
    $('#mz-clv-q', panel).oninput = (e) => {
      state.clQuery = e.target.value;
      renderClientes(); icons();
      const i = $('#mz-clv-q', panel); i.focus(); moveCaretEnd(i);
    };
    panel.onclick = (e) => {
      const b = e.target.closest('[data-mz-fiche]');
      if (b) openFiche(b.dataset.mzFiche);
    };
    icons();
  }

  function creditHistoryRows(credits) {
    const rows = Array.isArray(credits) ? credits : [];
    if (!rows.length) return '<div class="mz-empty" style="padding:16px;">Aucun avoir enregistré.</div>';
    return rows.map((credit) => {
      const issued = (credit.events || []).find((event) => event.action === 'issue') || {};
      const lines = Array.isArray(issued.lines) ? issued.lines : [];
      const eventRows = (credit.events || []).filter((event) => event.action !== 'issue').map((event) =>
        `<small style="display:block;margin-top:4px;color:var(--ink-3);">${event.action === 'redeem' ? 'Utilisé' : event.action === 'cancel' ? 'Annulé' : esc(event.action)} · ${fmtMAD((event.amountCents || 0) / 100)} · ${whenLabel(event.ts)} · ${esc(event.actor || 'Caisse')} · solde ${fmtMAD((event.balanceAfterCents || 0) / 100)}</small>`
      ).join('');
      return `<div class="mz-fhist-row" style="align-items:flex-start;">
        <span class="when">${whenLabel(credit.at)}<small style="display:block;">expire ${fmtValidUntil(credit.until)}</small></span>
        <span class="what"><b>${esc(credit.code)}</b> · vente ${esc(credit.from || '·')}<small style="display:block;">${lines.length ? esc(lines.map((line) => `${line.qty || 1}× ${line.name || 'Article'}`).join(' + ')) : esc(credit.motif || 'Retour')} · ${esc(issued.actor || 'Caisse')}</small>${eventRows}</span>
        <span class="amt">${fmtMAD(credit.amount)}<small style="display:block;color:var(--ink-3);">reste ${fmtMAD(credit.balance)}</small></span>
      </div>`;
    }).join('');
  }

  async function fillClientCreditHistory(cid, host) {
    if (!host) return;
    try {
      const credits = IS_DEMO ? AVOIRS.filter((item) => item.holderId === cid)
        : (await creditRequest(null, '&customerId=' + encodeURIComponent(cid))).credits.map(creditFromServer);
      if (!host.isConnected) return;
      host.innerHTML = creditHistoryRows(credits);
      icons();
    } catch (_) {
      if (host.isConnected) host.innerHTML = '<div class="mz-empty" style="padding:16px;">Historique des avoirs indisponible. Réessayez.</div>';
    }
  }

  function openFiche(cid) {
    const c = clById(cid);   // clById, pas CL[…] : sur une vraie boutique le carnet vit dans KiwiClients (CL est vide)
    if (!c) return;
    const el = $('#mz-fichem', root);
    const av = clAvoirOf(c);
    const cloudHistory = (c.history || []).map((h) => ({
      when: h.when || whenLabel(h.ts || h.createdAt || 0),
      what: h.what || (Array.isArray(h.items) && h.items.length ? h.items.map((it) => `${it.qty || 1}× ${it.name || 'Article'}`).join(' + ') : (h.ref || 'Achat')),
      amt: h.amt != null ? h.amt : h.amount,
      method: h.method || '', ref: h.ref || '', ts: +(h.ts || h.createdAt || 0),
    }));
    const syncedRefs = new Set(cloudHistory.map((h) => String(h.ref || '')).filter(Boolean));
    const localOnly = SALES.filter((s) => s.clientId === cid && !s.voided
      && !syncedRefs.has(String(s.id || '')) && !syncedRefs.has(String(s.num || ''))).map((s) => ({
      when: whenLabel(s.at),
      // idem : une vente de la semaine peut porter un article supprimé depuis.
      what: s.lines.map((l) => `${(P[l.pid] && P[l.pid].name) || l.name || 'Article'} · ${l.size}`).join(' + '),
      amt: s.total, method: s.methods || '', ref: s.id || s.num || '', ts: +s.at || 0,
    }));
    const hist = localOnly.concat(cloudHistory).sort((a, b) => Number(b.ts || 0) - Number(a.ts || 0));
    /* c.spent already includes every locally recorded purchase immediately and
       every acknowledged purchase after sync. Adding today's rows again made
       the fiche double its turnover. */
    const spent = c.spent || 0;
    el.innerHTML = `
      <button class="mz-modal-x" data-mz-close aria-label="Fermer"><i data-icon="close"></i></button>
      <div class="mz-fiche-head">
        <span class="mz-fiche-ava">${esc(initials(c.name))}</span>
        <div>
          <h3>${esc(c.name)} ${c.vip ? '<span class="mz-vip-chip">VIP</span>' : ''}</h3>
          <div class="tel">${esc(c.phone || 'sans téléphone')}</div>
        </div>
      </div>
      <div class="mz-fstats">
        <div class="mz-fstat"><b>${c.points}</b><span>points fidélité</span></div>
        <div class="mz-fstat"><b>${esc(c.taille)}</b><span>taille habituelle</span></div>
        <div class="mz-fstat"><b>${fmtMAD(spent)}</b><span>dépensé</span></div>
      </div>
      ${(c.prefs || []).length ? `<div class="mz-fnotes">${c.prefs.map((p) => `<div class="mz-fnote"><i data-lucide="heart"></i>${esc(p)}</div>`).join('')}</div>` : ''}
      ${av ? `<button class="mz-favoir" id="mz-fiche-av"><i data-lucide="ticket"></i>Avoir actif <b>${av.code}</b> · ${fmtMAD(av.balance)}, utilisable en caisse<span class="see">Voir</span></button>` : ''}
      <div class="mz-f-lbl" style="margin-bottom:6px;">Historique</div>
      <div class="mz-fhist">
        ${hist.length ? hist.map((h) => `<div class="mz-fhist-row"><span class="when">${esc(h.when)}${h.method ? `<small style="display:block;">${esc(h.method)}</small>` : ''}</span><span class="what">${esc(h.what)}${h.ref ? `<small style="display:block;">Ticket ${esc(h.ref)}</small>` : ''}</span><span class="amt">${fmtMAD(h.amt)}</span></div>`).join('') : '<div class="mz-empty">Aucun achat enregistré.</div>'}
      </div>
      <div class="mz-f-lbl" style="margin:16px 0 6px;">Avoirs et remboursements</div>
      <div class="mz-fhist" id="mz-fiche-credits"><div class="mz-empty" style="padding:16px;">Chargement du registre…</div></div>
      <div class="mz-sheet-foot">
        <button class="mz-btn secondary" data-mz-close>Fermer</button>
        <button class="mz-btn primary" id="mz-fiche-sell"><i data-lucide="shopping-bag"></i>Nouvelle vente pour elle</button>
      </div>`;
    openVeil('#mz-fiche-veil');
    icons();
    $$('[data-mz-close]', el).forEach((b) => { b.onclick = () => closeVeil('#mz-fiche-veil'); });
    const avB = $('#mz-fiche-av', el);
    if (avB) avB.onclick = () => { closeVeil('#mz-fiche-veil'); openVoucher(av, { mode: 'view' }); };
    $('#mz-fiche-sell', el).onclick = () => {
      state.ticket.client = c.id;
      closeVeil('#mz-fiche-veil');
      switchView('vente');
      toast(`${firstName(c.name)} au comptoir, taille ${c.taille} pré-sélectionnée`);
    };
    void fillClientCreditHistory(cid, $('#mz-fiche-credits', el));
  }

  /* ═══════════════════════ SCAN ═══════════════════════ */
  /* Demo « douchette » cycle — a handful of real, in-stock articles from the
     live catalogue (each carries a scannable primary barcode). */
  function scanCycle() {
    const out = [];
    for (const r of RAYONS) for (const it of r.items) if (firstFree(it) && it.ean) out.push(it.id);
    return out.length ? out : Object.keys(P);
  }

  /* Rayon (catégorie) auquel appartient un article, pour la fiche de vérif. */
  function rayonOf(pid) {
    const r = RAYONS.find((ry) => ry.items.some((it) => it.id === pid));
    return r ? r.label : '';
  }

  /* La fiche « disponibilité » d'un article vérifié : prix, tailles, stock,
     couleurs — lecture seule, aucun impact sur le ticket. */
  function lookupCardHtml() {
    const lk = state.lookup;
    if (!lk || !P[lk.pid]) return '';
    const p = P[lk.pid];
    const tot = stockOf(p);
    const status = tot === 0 ? { cls: 'out', label: 'Épuisé' }
                 : tot <= 3 ? { cls: 'low', label: 'Stock bas' }
                 : { cls: 'ok', label: 'Disponible' };
    const sizes = sizesOf(p).map((s) => {
      const q = p.sizes[s] || 0;
      const cls = q === 0 ? 'out' : q <= 2 ? 'low' : '';
      const on = s === lk.size ? ' is-on' : '';
      return `<span class="mz-look-size ${cls}${on}"><b>${esc(s)}</b><i>${q}</i></span>`;
    }).join('');
    const colors = (p.colors || []).map((cid) => {
      const on = cid === lk.color ? ' is-on' : '';
      return `<span class="mz-look-color${on}">${colorDot(cid)}${esc(colorLabel(cid))}</span>`;
    }).join('');
    const ray = rayonOf(lk.pid);
    return `
      <div class="mz-look">
        <div class="mz-look-top">
          <span class="mz-look-art">${artOf(p)}</span>
          <div class="mz-look-id">
            <b>${esc(p.name)}</b>
            <span>${ray ? esc(ray) + ' · ' : ''}EAN ${esc(lk.ean)} · ${fmtHM(lk.at)}</span>
          </div>
          <span class="mz-look-price">${(function () {
            /* La fiche « disponibilité » est ce qu'on montre à une cliente qui
               demande « il coûte combien ? » : citer le prix catalogue pendant
               une promotion, c'est annoncer un prix qu'on n'encaissera pas. */
            const pr = promoFor(lk.pid);
            return pr ? `<s>${fmtMAD(pr.was)}</s> ${fmtMAD(pr.price)}` : fmtMAD(shelf(p.price));
          })()}</span>
        </div>
        <div class="mz-look-avail">
          <div class="mz-look-avail-head">
            <span class="mz-look-status ${status.cls}">${status.label}</span>
            <span class="mz-look-tot">${tot} pièce${tot > 1 ? 's' : ''} en stock</span>
          </div>
          <div class="mz-look-sizes">${sizes || '<span class="mz-look-empty">Taille unique</span>'}</div>
          ${colors ? `<div class="mz-look-colors">${colors}</div>` : ''}
        </div>
        <button class="mz-btn secondary mz-look-sell" id="mz-look-sell" ${tot === 0 ? 'disabled' : ''}>
          <i data-lucide="shopping-bag"></i>Envoyer vers la vente
        </button>
      </div>`;
  }

  /* ── « et dans l'autre boutique ? » ────────────────────────────────────────
     Le panneau qui répond sans décrocher le téléphone. Il ne s'affiche que pour
     un compte à plusieurs établissements — le serveur ne renvoie rien d'autre
     quand il n'y en a qu'un, et le module de catalogue arrête alors de demander.

     Trois états, et le troisième compte autant que les deux autres :
       · en cours   — le scan local a déjà répondu, ceci arrive derrière
       · trouvé     — combien, dans quelle taille, dans quel magasin
       · INCONNU    — ce magasin n'a pas encore d'inventaire en ligne. On l'écrit
                      ainsi, jamais « 0 en stock » : ne pas savoir n'est pas la
                      même chose que ne pas en avoir, et un vendeur qui renvoie
                      une cliente à Marrakech sur un faux zéro ne recommence pas. */
  function crossCardHtml() {
    const cx = state.cross;
    if (!cx) return '';
    // L'attente porte le MÊME cadre et le même titre que le résultat : quand la
    // réponse arrive, seules les lignes changent. Un encadré séparé qui
    // disparaît ferait sauter la fiche article que le vendeur est en train de
    // lire — et, isolé, se lisait comme un champ de recherche vide.
    if (cx.loading) {
      return `<div class="mz-cross">
        <div class="mz-cross-h"><i data-lucide="store"></i>Vos autres établissements</div>
        <div class="mz-cross-wait"><i data-lucide="loader"></i>Recherche en cours…</div>
      </div>`;
    }
    if (!cx.stores || !cx.stores.length) return '';

    const rows = cx.stores.map((s) => {
      const name = esc(s.name || s.merchant);
      if (!s.known) {
        return `<div class="mz-cross-row is-unknown">
            <span class="mz-cross-store">${name}</span>
            <span class="mz-cross-note">inventaire pas encore synchronisé</span>
          </div>`;
      }
      if (!s.hits || !s.hits.length) {
        return `<div class="mz-cross-row is-none">
            <span class="mz-cross-store">${name}</span>
            <span class="mz-cross-note">aucun exemplaire</span>
          </div>`;
      }
      const detail = s.hits.map((h) => {
        const dim = [h.color, h.size].filter(Boolean).map(esc).join(' · ');
        // Une recherche par nom rapporte le produit et le détail par taille ;
        // un scan rapporte la variante exacte. Les deux se lisent pareil ici.
        const sizes = Array.isArray(h.sizes) && h.sizes.length
          ? h.sizes.map((z) => `<span class="mz-cross-sz"><b>${esc(z.size)}</b><i>${z.stock | 0}</i></span>`).join('')
          : '';
        const n = h.stock | 0;
        return `<div class="mz-cross-hit">
            <span class="mz-cross-prod">${esc(h.product)}${dim ? ' <em>' + dim + '</em>' : ''}</span>
            <span class="mz-cross-qty ${n === 0 ? 'out' : n <= 2 ? 'low' : ''}">${n}</span>
          </div>${sizes ? `<div class="mz-cross-sizes">${sizes}</div>` : ''}`;
      }).join('');
      return `<div class="mz-cross-row">
          <span class="mz-cross-store">${name}</span>
          <div class="mz-cross-hits">${detail}</div>
        </div>`;
    }).join('');

    return `<div class="mz-cross">
        <div class="mz-cross-h"><i data-lucide="store"></i>Vos autres établissements</div>
        ${rows}
        <div class="mz-cross-foot">Stock lu à l'instant sur le serveur. Appelez avant de faire déplacer une cliente.</div>
      </div>`;
  }

  /* Lance la recherche inter-magasins pour le code qui vient d'être scanné et
     redessine quand elle revient. Volontairement APRÈS l'affichage local : le
     scan doit rester instantané, ceci n'est qu'un complément. */
  function askCross(code, pid) {
    const cat = window.KiwiBoutiqueCatalog;
    if (!cat || !cat.crossStock || !code) { state.cross = null; return; }
    /* La référence commune de CE produit part avec le code. C'est elle qui fait
       le rapprochement quand le commerçant a étiqueté lui-même sa marchandise :
       l'étiquette de Casa ne veut rien dire à Rabat, la référence si. */
    let sku = '';
    try {
      const p = pid ? (P[pid] || null) : null;
      sku = (p && p.sku) || '';
    } catch (_) { sku = ''; }
    state.cross = { code, loading: true, stores: null };
    cat.crossStock({ code, sku }).then((res) => {
      // Un autre code a été scanné entre-temps : cette réponse ne le concerne
      // plus, l'afficher sous le nouveau serait un mensonge.
      if (!state.cross || state.cross.code !== code) return;
      state.cross = res && res.stores && res.stores.length
        ? { code, loading: false, stores: res.stores }
        : null;
      if (state.view === 'scan') renderScan();
    });
  }

  /* ── Caméra : lecture RÉELLE d'un code-barres ──────────────────────────────
     La douchette USB n'a jamais eu besoin de code : c'est un clavier, elle tape
     dans le champ et valide par Entrée. Ce qui manquait, c'est de pouvoir
     scanner SANS douchette, avec le téléphone ou la tablette qui sert de caisse.
     Zéro dépendance et zéro build : l'API navigateur BarcodeDetector décode
     directement le flux getUserMedia. Elle n'existe pas partout (Chrome
     Android / macOS / ChromeOS oui, Safari iOS non) : quand elle manque on le
     dit franchement plutôt que d'ouvrir une caméra qui ne déchiffrerait rien. */
  const CAM_WANT = ['ean_13', 'ean_8', 'upc_a', 'upc_e', 'code_128', 'code_39', 'itf', 'codabar', 'qr_code'];
  function camSupported() {
    try { return !!(navigator.mediaDevices && navigator.mediaDevices.getUserMedia && window.BarcodeDetector); }
    catch (_) { return false; }
  }
  /* Bip court : la caissière doit ENTENDRE que ça a mordu sans quitter le client
     des yeux — c'est ce que fait une vraie douchette. */
  function camBlip() {
    try {
      const AC = window.AudioContext || window.webkitAudioContext;
      if (AC) {
        const ac = new AC();
        const o = ac.createOscillator(), g = ac.createGain();
        o.type = 'square';
        o.frequency.value = 2100;
        g.gain.setValueAtTime(0.05, ac.currentTime);
        g.gain.exponentialRampToValueAtTime(0.0001, ac.currentTime + 0.12);
        o.connect(g); g.connect(ac.destination);
        o.start(); o.stop(ac.currentTime + 0.13);
        setTimeout(() => { try { ac.close(); } catch (_) {} }, 320);
      }
    } catch (_) {}
  }

  let camBusy = false;
  function openCamScan(onCode) {
    if (camBusy) return;
    if (!camSupported()) {
      toast('Lecture caméra indisponible sur ce navigateur, utilisez la douchette ou tapez le code');
      return;
    }
    camBusy = true;
    const veil = document.createElement('div');
    veil.className = 'mz-cam';
    veil.innerHTML = `
      <div class="mz-cam-box">
        <video class="mz-cam-video" playsinline muted></video>
        <div class="mz-cam-frame"><i></i><i></i><i></i><i></i><div class="mz-cam-laser"></div></div>
        <div class="mz-cam-bar">
          <div class="mz-cam-hint" id="mz-cam-hint">Placez le code-barres dans le cadre</div>
          <div class="mz-cam-acts">
            <button class="mz-cam-btn" id="mz-cam-torch" hidden>Lampe</button>
            <button class="mz-cam-btn is-close" id="mz-cam-close">Fermer</button>
          </div>
        </div>
      </div>`;
    document.body.appendChild(veil);
    const video = $('.mz-cam-video', veil);
    const hint = $('#mz-cam-hint', veil);
    video.muted = true;
    let stream = null, raf = 0, stopped = false;

    const stop = () => {
      if (stopped) return;
      stopped = true;
      camBusy = false;
      if (raf) cancelAnimationFrame(raf);
      try { if (stream) stream.getTracks().forEach((t) => t.stop()); } catch (_) {}
      try { video.srcObject = null; } catch (_) {}
      veil.remove();
      document.removeEventListener('keydown', onKey);
    };
    function onKey(e) { if (e.key === 'Escape') stop(); }
    document.addEventListener('keydown', onKey);
    $('#mz-cam-close', veil).onclick = stop;
    veil.addEventListener('click', (e) => { if (e.target === veil) stop(); });

    (async () => {
      let detector;
      try {
        let fmts = CAM_WANT;
        try {
          const sup = await window.BarcodeDetector.getSupportedFormats();
          const inter = CAM_WANT.filter((f) => sup.indexOf(f) >= 0);
          if (inter.length) fmts = inter;
        } catch (_) {}
        detector = new window.BarcodeDetector({ formats: fmts });
      } catch (_) {
        hint.textContent = 'Lecture caméra indisponible sur cet appareil';
        return;
      }
      try {
        stream = await navigator.mediaDevices.getUserMedia({
          video: { facingMode: { ideal: 'environment' }, width: { ideal: 1280 }, height: { ideal: 720 } },
          audio: false,
        });
      } catch (err) {
        const n = err && err.name;
        hint.textContent = n === 'NotAllowedError' || n === 'SecurityError'
          ? 'Accès caméra refusé, autorisez-le dans le navigateur puis réessayez'
          : n === 'NotFoundError' || n === 'OverconstrainedError' ? 'Aucune caméra utilisable sur cet appareil'
          : 'Caméra indisponible';
        return;
      }
      if (stopped) { try { stream.getTracks().forEach((t) => t.stop()); } catch (_) {} return; }
      video.srcObject = stream;
      try { await video.play(); } catch (_) {}

      /* Lampe — une réserve ou une cabine d'essayage est rarement bien éclairée.
         Seuls certains téléphones l'exposent ; sinon le bouton reste caché. */
      try {
        const track = stream.getVideoTracks()[0];
        const caps = track && track.getCapabilities ? track.getCapabilities() : null;
        if (caps && caps.torch) {
          const tb = $('#mz-cam-torch', veil);
          let on = false;
          tb.hidden = false;
          tb.onclick = () => {
            on = !on;
            try { track.applyConstraints({ advanced: [{ torch: on }] }); } catch (_) {}
            tb.classList.toggle('is-on', on);
          };
        }
      } catch (_) {}

      let last = 0;
      const tick = async (ts) => {
        if (stopped) return;
        /* ~8 lectures/seconde : assez vif pour mordre tout de suite, assez lâche
           pour ne pas saturer le CPU d'une tablette d'entrée de gamme. */
        if (ts - last > 120 && video.readyState >= 2) {
          last = ts;
          try {
            const hits = await detector.detect(video);
            if (hits && hits.length) {
              const code = String(hits[0].rawValue || '').trim();
              if (code) { camBlip(); stop(); onCode(code); return; }
            }
          } catch (_) { /* une frame illisible n'interrompt pas la boucle */ }
        }
        raf = requestAnimationFrame(tick);
      };
      raf = requestAnimationFrame(tick);
    })();
  }

  /* ═══════════════════════ LISTES CADEAUX (MARIAGE & NAISSANCE) ═══════════════════ */
  const REGISTRY_KEY = 'kiwi:mzRegistries';
  const DEFAULT_REGISTRIES = [
    {
      id: 'reg-mariage-sarah-mehdi',
      type: 'mariage',
      typeLabel: 'Liste de Mariage',
      title: 'Mariage Sarah & Mehdi Benjelloun',
      beneficiaries: 'Sarah & Mehdi',
      phone: '0661 42 18 30',
      eventDate: '2026-09-15',
      note: 'Livraison groupée Tanger Marshan après la cérémonie.',
      items: [
        { pid: 'mz_fes_bleu_service', name: 'Service 18 pièces Fès Bleu', marque: 'Vogue Table', format: 'service', qtyRequested: 1, qtyPurchased: 0, price: 1450, color: 'bleu', size: 'TU' },
        { pid: 'mz_vase_majorelle', name: 'Vase céramique émaillée 35cm', marque: 'Céramique Majorelle', format: 'piece', qtyRequested: 2, qtyPurchased: 1, price: 650, color: 'emeraude', size: 'TU' },
        { pid: 'mz_verres_beldi_set', name: 'Verres soufflés Beldi (Set de 6)', marque: 'Beldi Glass', format: 'service', qtyRequested: 4, qtyPurchased: 2, price: 140, color: 'emeraude', size: 'TU' },
        { pid: 'mz_baobab_feathers', name: 'Bougie Max 24 Totem Feathers', marque: 'Baobab Collection', format: 'piece', qtyRequested: 1, qtyPurchased: 0, price: 1850, color: 'ivoire', size: 'TU' },
        { pid: 'mz_carafe_beldi', name: 'Carafe soufflée Beldi 1.5L', marque: 'Beldi Glass', format: 'piece', qtyRequested: 2, qtyPurchased: 1, price: 120, color: 'transparent', size: 'TU' },
      ],
    },
    {
      id: 'reg-naissance-ines',
      type: 'naissance',
      typeLabel: 'Liste de Naissance',
      title: 'Naissance Bébé Inès',
      beneficiaries: 'Ghita & Youssef Alami',
      phone: '0664 77 02 19',
      eventDate: '2026-10-20',
      note: 'Emballages cadeaux avec mot personnalisé pour chaque invité.',
      items: [
        { pid: 'mz_coupes_dessert', name: 'Coupes à dessert dorées (Lot 6)', marque: 'Cristal Atlas', format: 'piece', qtyRequested: 4, qtyPurchased: 2, price: 75, color: 'dore', size: 'TU' },
        { pid: 'mz_diffuseur_oranger', name: 'Diffuseur Fleur d’Oranger Tanger', marque: 'Les Senteurs de Tanger', format: 'piece', qtyRequested: 2, qtyPurchased: 0, price: 480, color: 'ambre', size: 'TU' },
        { pid: 'mz_plateau_martele', name: 'Plateau laiton martelé main', marque: 'Artisanat Fès', format: 'piece', qtyRequested: 1, qtyPurchased: 1, price: 420, color: 'dore', size: 'TU' },
      ],
    }
  ];

  let REGISTRIES = null;
  let REGISTRY_STORE = null;
  function registryStore() {
    if (REGISTRY_STORE || !window.KiwiStore?.define) return REGISTRY_STORE;
    REGISTRY_STORE = window.KiwiStore.define('giftregistries', {
      cloud: 'giftregistries',
      blank: () => ({ list: [] }),
      seedFor: () => IS_DEMO ? ({ list: JSON.parse(JSON.stringify(DEFAULT_REGISTRIES)) }) : null,
      isEmpty: (d) => !d || !Array.isArray(d.list) || !d.list.length,
      merge: (mine, theirs) => {
        const map = new Map();
        [].concat(theirs?.list || [], mine?.list || []).forEach((row) => {
          if (!row?.id) return;
          const old = map.get(row.id);
          if (!old || +(row.updatedAt || 0) >= +(old.updatedAt || 0)) map.set(row.id, row);
        });
        return { list: Array.from(map.values()).filter((row) => !row.deletedAt).slice(0, 500) };
      },
    });
    return REGISTRY_STORE;
  }
  function loadRegistries() {
    if (REGISTRIES) return REGISTRIES;
    const store = registryStore();
    if (store) {
      const doc = store.get(merchantSlug());
      if (doc && Array.isArray(doc.list)) REGISTRIES = doc.list;
    }
    try {
      const stored = localStorage.getItem(REGISTRY_KEY + ':' + merchantSlug());
      /* One-time adoption of the pre-cloud list.  Prefer it only when the new
         document is still empty, then save it through the shared store. */
      if (stored && (!Array.isArray(REGISTRIES) || !REGISTRIES.length)) REGISTRIES = JSON.parse(stored);
    } catch (_) {}
    if (!Array.isArray(REGISTRIES)) REGISTRIES = IS_DEMO ? JSON.parse(JSON.stringify(DEFAULT_REGISTRIES)) : [];
    if (store) store.set({ list: REGISTRIES }, merchantSlug());
    return REGISTRIES;
  }
  function saveRegistries() {
    try {
      localStorage.setItem(REGISTRY_KEY + ':' + merchantSlug(), JSON.stringify(REGISTRIES || []));
    } catch (_) {}
    const store = registryStore();
    if (store) store.set({ list: REGISTRIES || [] }, merchantSlug());
  }
  function updateRegistryContribution(sale) {
    if (!sale || !sale.lines) return;
    const regs = loadRegistries();
    let touched = false;
    sale.lines.forEach((ln) => {
      if (!ln.registryId) return;
      const reg = regs.find((r) => r.id === ln.registryId);
      if (!reg) return;
      const target = reg.items.find((it) => it.pid === ln.pid || (P[ln.pid] && P[ln.pid].name === it.name));
      if (target) {
        target.qtyPurchased = Math.min(target.qtyRequested, (target.qtyPurchased || 0) + (ln.qty || 1));
        touched = true;
      }
    });
    if (touched) saveRegistries();
  }

  function renderRegistries() {
    const panel = $('[data-mz-panel="registries"]', root);
    if (!panel) return;
    const regs = loadRegistries();
    const q = (state.registriesQuery || '').toLowerCase().trim();
    const hits = q ? regs.filter((r) => r.title.toLowerCase().includes(q) || r.beneficiaries.toLowerCase().includes(q) || r.phone.includes(q)) : regs;

    panel.innerHTML = `
      <div class="mz-registries">
        <header class="mz-head">
          <div>
            <h1>Listes Cadeaux &amp; Mariage</h1>
            <div class="mz-head-sub">Gestion des listes d'invités, contributions et suivi des pièces offertes</div>
          </div>
          <div style="display:flex;align-items:center;gap:8px;">
            <div class="mz-search">
              <i data-icon="search"></i>
              <input id="mz-reg-q" placeholder="Nom ou téléphone…" value="${esc(state.registriesQuery || '')}" />
            </div>
            <button class="mz-btn primary" id="mz-reg-new"><i data-lucide="plus"></i>Nouvelle liste</button>
          </div>
        </header>

        <div class="mz-reg-grid">
          ${hits.map((reg) => {
            const totRequested = reg.items.reduce((s, it) => s + (it.qtyRequested || 1), 0);
            const totPurchased = reg.items.reduce((s, it) => s + (it.qtyPurchased || 0), 0);
            const pct = totRequested > 0 ? Math.round((totPurchased / totRequested) * 100) : 0;
            const valPurchased = reg.items.reduce((s, it) => s + (it.qtyPurchased || 0) * it.price, 0);
            const valTotal = reg.items.reduce((s, it) => s + (it.qtyRequested || 1) * it.price, 0);
            return `
            <div class="mz-reg-card">
              <div class="mz-reg-head">
                <div>
                  <h3 class="mz-reg-title">${esc(reg.title)}</h3>
                  <div class="mz-reg-sub">${esc(reg.beneficiaries)} · Tél. ${esc(reg.phone)} · Événement : ${esc(reg.eventDate)}</div>
                </div>
                <span class="mz-reg-badge">${esc(reg.typeLabel || 'Mariage')}</span>
              </div>
              <div style="display:flex; justify-content:space-between; font-size:12px; color:var(--ink-2); font-weight:600;">
                <span>Progression : ${totPurchased} / ${totRequested} articles offerts</span>
                <span style="font-family:var(--mono);">${fmtMAD(valPurchased)} / ${fmtMAD(valTotal)}</span>
              </div>
              <div class="mz-reg-prog-bar">
                <div class="mz-reg-prog-fill" style="width:${pct}%;"></div>
              </div>
              <div class="mz-reg-items">
                ${reg.items.map((it) => {
                  const p = P[it.pid] || { name: it.name, price: it.price, marque: it.marque };
                  const remaining = Math.max(0, (it.qtyRequested || 1) - (it.qtyPurchased || 0));
                  const isDone = remaining === 0;
                  return `
                  <div class="mz-reg-item">
                    <div class="item-info">
                      <b>${esc(it.name)}</b>
                      <span>${it.marque ? esc(it.marque) + ' · ' : ''}${fmtMAD(shelf(it.price))} · ${it.qtyPurchased}/${it.qtyRequested} offert(s)</span>
                    </div>
                    <div class="item-cta">
                      ${isDone ? '<span class="mz-mini ok">Complet</span>' : `
                        <button class="mz-btn secondary sm" data-mz-reg-add="${reg.id}:${it.pid}">
                          <i data-lucide="gift"></i>Offrir (${remaining} dispo)
                        </button>`}
                    </div>
                  </div>`;
                }).join('')}
              </div>
              <div style="display:flex;gap:8px;justify-content:flex-end;padding-top:8px;border-top:1px solid var(--line);">
                <button class="mz-btn secondary sm" data-mz-reg-item-add="${reg.id}"><i data-lucide="plus"></i>Ajouter un article</button>
                <button class="mz-btn secondary sm" data-mz-reg-delete="${reg.id}"><i data-lucide="trash-2"></i>Supprimer</button>
              </div>
              ${reg.note ? `<div style="font-size:11.5px; color:var(--ink-3); border-top:1px solid var(--line); padding-top:8px;">Note : ${esc(reg.note)}</div>` : ''}
            </div>`;
          }).join('') || `<div class="mz-empty" style="grid-column:1/-1;min-height:240px;"><i data-lucide="gift"></i><b>Aucune liste cadeau</b><span>Créez une liste de mariage, naissance ou événement, puis ajoutez les articles du catalogue.</span></div>`}
        </div>
      </div>`;

    const create = $('#mz-reg-new', panel);
    if (create) create.onclick = openNewRegistry;

    const qInput = $('#mz-reg-q', panel);
    if (qInput) {
      qInput.oninput = (e) => {
        state.registriesQuery = e.target.value;
        renderRegistries(); icons();
        const i = $('#mz-reg-q', panel); if (i) { i.focus(); moveCaretEnd(i); }
      };
    }

    panel.onclick = (e) => {
      const addBtn = e.target.closest('[data-mz-reg-add]');
      if (addBtn) {
        const [regId, pid] = addBtn.dataset.mzRegAdd.split(':');
        const reg = regs.find((r) => r.id === regId);
        const item = reg && reg.items.find((it) => it.pid === pid);
        if (reg && item) {
          addToTicket(item.pid, {
            size: item.size || 'TU',
            color: item.color || 'defaut',
            qty: 1,
            format: item.format || 'piece',
            isPiece: (item.format !== 'service'),
            marque: item.marque,
            registryId: reg.id,
            registryTitle: reg.title,
          });
          switchView('vente');
          toast(`Article ajouté pour : ${reg.title}`);
        }
        return;
      }
      const itemAdd = e.target.closest('[data-mz-reg-item-add]');
      if (itemAdd) { openRegistryItem(itemAdd.dataset.mzRegItemAdd); return; }
      const del = e.target.closest('[data-mz-reg-delete]');
      if (del) {
        const reg = regs.find((r) => r.id === del.dataset.mzRegDelete);
        if (reg && confirm((window.KiwiCaisseLang ? window.KiwiCaisseLang.tr : function (s) { return s; })(`Supprimer « ${reg.title} » ?`))) {
          REGISTRIES = regs.filter((r) => r.id !== reg.id);
          saveRegistries(); renderRegistries(); renderBadges(); icons();
          toast('Liste supprimée');
        }
      }
    };
    icons();
  }

  function openNewRegistry() {
    const html = `
      <button class="mz-modal-x" data-inv-x aria-label="Fermer"><i data-lucide="x"></i></button>
      <div class="mzi-modh"><div><h3>Nouvelle liste cadeau</h3><span>La liste sera disponible sur toutes les caisses du magasin.</span></div></div>
      <div class="mzi-form">
        <div class="mzi-frow"><div class="mzi-fg"><label>Type</label><select id="mz-rn-type"><option value="mariage">Mariage</option><option value="naissance">Naissance</option><option value="evenement">Événement</option></select></div><div class="mzi-fg"><label>Date</label><input id="mz-rn-date" type="date" /></div></div>
        <div class="mzi-fg"><label>Titre</label><input id="mz-rn-title" placeholder="Ex. Mariage Sara &amp; Adam" /></div>
        <div class="mzi-frow"><div class="mzi-fg"><label>Bénéficiaires</label><input id="mz-rn-who" placeholder="Sara &amp; Adam" /></div><div class="mzi-fg"><label>Téléphone</label><input id="mz-rn-phone" inputmode="tel" placeholder="06…" /></div></div>
        <div class="mzi-fg"><label>Note</label><input id="mz-rn-note" maxlength="300" placeholder="Livraison, emballage, message…" /></div>
      </div>
      <div class="mzi-modfoot"><button class="mz-btn secondary" data-inv-x>Annuler</button><button class="mz-btn primary" id="mz-rn-save">Créer la liste</button></div>`;
    invSetModal(html, (el) => {
      $('#mz-rn-save', el).onclick = () => {
        const title = $('#mz-rn-title', el).value.trim();
        const who = $('#mz-rn-who', el).value.trim();
        if (!title || !who) { toast('Indiquez le titre et les bénéficiaires'); return; }
        const type = $('#mz-rn-type', el).value;
        const now = Date.now();
        loadRegistries().unshift({ id: `reg-${now.toString(36)}-${Math.random().toString(36).slice(2,7)}`, type,
          typeLabel: type === 'mariage' ? 'Liste de Mariage' : type === 'naissance' ? 'Liste de Naissance' : 'Liste Cadeau',
          title, beneficiaries: who, phone: $('#mz-rn-phone', el).value.trim(), eventDate: $('#mz-rn-date', el).value,
          note: $('#mz-rn-note', el).value.trim(), items: [], createdAt: now, updatedAt: now });
        saveRegistries(); closeVeil('#mz-inv-veil'); renderRegistries(); renderBadges(); icons(); toast('Liste créée');
      };
    });
  }

  function openRegistryItem(registryId) {
    const reg = loadRegistries().find((r) => r.id === registryId);
    const products = catDB()?.listProducts?.({}) || [];
    if (!reg) return;
    const html = `
      <button class="mz-modal-x" data-inv-x aria-label="Fermer"><i data-lucide="x"></i></button>
      <div class="mzi-modh"><div><h3>Ajouter un article</h3><span>${esc(reg.title)}</span></div></div>
      <div class="mzi-form">
        <div class="mzi-fg"><label>Article du catalogue</label><select id="mz-ri-product">${products.map((p) => `<option value="${p.id}">${esc(p.name)} · ${fmtMAD(shelf(p.priceMAD))}</option>`).join('')}</select></div>
        <div class="mzi-fg"><label>Quantité souhaitée</label><input id="mz-ri-qty" type="number" min="1" step="1" value="1" /></div>
      </div>
      <div class="mzi-modfoot"><button class="mz-btn secondary" data-inv-x>Annuler</button><button class="mz-btn primary" id="mz-ri-save" ${products.length ? '' : 'disabled'}>Ajouter</button></div>`;
    invSetModal(html, (el) => {
      $('#mz-ri-save', el).onclick = () => {
        const pid = $('#mz-ri-product', el).value;
        const p = P[pid] || catDB()?.getProduct?.(pid)?.product;
        if (!p) return;
        const qty = Math.max(1, parseInt($('#mz-ri-qty', el).value, 10) || 1);
        const old = reg.items.find((it) => it.pid === pid);
        if (old) old.qtyRequested += qty;
        else reg.items.push({ pid, name: p.name, marque: p.marque || '', format: p.format || 'piece', qtyRequested: qty, qtyPurchased: 0, price: p.priceMAD || p.price || 0, color: 'defaut', size: 'TU' });
        reg.updatedAt = Date.now(); saveRegistries(); closeVeil('#mz-inv-veil'); renderRegistries(); icons(); toast('Article ajouté à la liste');
      };
    });
  }

  /* ═══════════════════════ FOURNISSEURS & ACHATS ═══════════════════════
     The procurement ledger was already loaded, but Maison had no route to it.
     This counter view reads and writes the same suppliers, orders, receipts and
     returns as the dashboard. */
  const procurement = () => window.KiwiProcurement || null;
  function supplierName(doc, id) { return (doc.suppliers || []).find((s) => s.id === id)?.name || 'Fournisseur'; }
  function renderSuppliers() {
    const panel = $('[data-mz-panel="fournisseurs"]', root);
    const api = procurement();
    if (!panel) return;
    if (!api) {
      panel.innerHTML = `<div class="bqi mz-page">
        <header class="mz-head"><div><h1>Fournisseurs &amp; achats</h1><div class="mz-head-sub">Annuaire, commandes, réceptions, retours et coûts · synchronisés avec le dashboard</div></div></header>
        <div class="mz-empty mz-empty-room">Approvisionnement indisponible. Rechargez la caisse pour retrouver les fournisseurs et commandes.</div>
      </div>`;
      return;
    }
    const doc = api.doc() || {}, suppliers = (doc.suppliers || []).filter((s) => s.active !== false), orders = doc.orders || [];
    panel.innerHTML = `<div class="bqi mz-page">
      <header class="mz-head">
        <div><h1>Fournisseurs &amp; achats</h1><div class="mz-head-sub">Annuaire, commandes, réceptions, retours et coûts · synchronisés avec le dashboard</div></div>
        <div class="mz-head-actions"><button class="mz-btn secondary" id="mz-sup-receive"><i data-lucide="package-plus"></i>Réception directe</button><button class="mz-btn primary" id="mz-sup-new"><i data-lucide="plus"></i>Nouveau fournisseur</button></div>
      </header>
      <div class="mzi-kpis"><div class="mzi-kpi"><span class="l">Fournisseurs actifs</span><span class="v">${suppliers.length}</span></div><div class="mzi-kpi"><span class="l">Commandes ouvertes</span><span class="v">${orders.filter((o) => !['received','cancelled'].includes(o.status)).length}</span></div><div class="mzi-kpi"><span class="l">Réceptions</span><span class="v">${(doc.receipts || []).length}</span></div></div>
      <div class="mz-section-head"><h2>Annuaire</h2>${api.isUltra() ? '<button class="mz-btn secondary" id="mz-po-new"><i data-lucide="file-plus"></i>Nouveau bon de commande</button>' : ''}</div>
      <div class="mz-reg-grid">${suppliers.map((s) => `<div class="mz-reg-card"><div class="mz-reg-head"><div><h3 class="mz-reg-title">${esc(s.name)}</h3><div class="mz-reg-sub">${esc([s.phone,s.email].filter(Boolean).join(' · ') || 'Coordonnées à compléter')}</div></div><span class="mz-reg-badge">${s.leadDays || 0} j</span></div>
        ${s.address ? `<div class="mz-reg-sub">${esc(s.address)}</div>` : ''}${s.taxId ? `<div class="mz-reg-sub">ICE / IF · ${esc(s.taxId)}</div>` : ''}${s.paymentTerms ? `<div class="mz-reg-sub">Conditions · ${esc(s.paymentTerms)}</div>` : ''}${s.categories ? `<div class="mz-reg-sub">Articles · ${esc(s.categories)}</div>` : ''}
        <div class="mz-card-actions"><button class="mz-btn secondary sm" data-mz-sup-receive="${s.id}">Réception</button><button class="mz-btn secondary sm" data-mz-sup-return="${s.id}">Retour fournisseur</button></div></div>`).join('') || '<div class="mz-empty mz-empty-room">Ajoutez votre premier fournisseur pour enregistrer les réceptions et les coûts.</div>'}</div>
      <div class="mz-section-head"><h2>Commandes</h2></div><div class="mzi-list mz-section-surface">${orders.map((o) => `<div class="mzi-row"><span class="mzi-info"><b>${esc(o.number)}</b><span>${esc(supplierName(doc,o.supplierId))} · ${esc(o.status)}${o.expectedDate ? ' · '+esc(o.expectedDate) : ''}</span></span><span class="mzi-price">${fmtMAD((o.lines||[]).reduce((n,l)=>n+(+l.qty||0)*(+l.unitCost||0),0))}</span><span class="mz-row-actions">${o.status==='draft' ? `<button class="mzi-mini" data-mz-po-send="${o.id}" title="Marquer envoyée"><i data-lucide="send"></i></button>` : ''}${!['received','cancelled'].includes(o.status) ? `<button class="mzi-mini" data-mz-po-receive="${o.id}" title="Réceptionner"><i data-lucide="package-check"></i></button><button class="mzi-mini" data-mz-po-cancel="${o.id}" title="Annuler"><i data-lucide="x"></i></button>` : ''}</span></div>`).join('') || '<div class="mz-empty">Aucune commande.</div>'}</div>
    </div>`;
    $('#mz-sup-new', panel).onclick = openSupplierForm;
    $('#mz-sup-receive', panel).onclick = () => openProcurementMove('receipt', '');
    const poNew = $('#mz-po-new', panel); if (poNew) poNew.onclick = openPurchaseOrder;
    panel.onclick = (e) => {
      const receive = e.target.closest('[data-mz-sup-receive]'); if (receive) { openProcurementMove('receipt', receive.dataset.mzSupReceive); return; }
      const ret = e.target.closest('[data-mz-sup-return]'); if (ret) { openProcurementMove('return', ret.dataset.mzSupReturn); return; }
      const send = e.target.closest('[data-mz-po-send]'); if (send) { api.markSent(send.dataset.mzPoSend); renderSuppliers(); toast('Commande marquée envoyée'); return; }
      const receivePo = e.target.closest('[data-mz-po-receive]'); if (receivePo) { openProcurementMove('order', receivePo.dataset.mzPoReceive); return; }
      const cancel = e.target.closest('[data-mz-po-cancel]'); if (cancel && confirm((window.KiwiCaisseLang ? window.KiwiCaisseLang.tr : function (s) { return s; })('Annuler ce bon de commande ?'))) { api.cancelOrder(cancel.dataset.mzPoCancel, 'Annulé depuis la caisse'); renderSuppliers(); toast('Commande annulée'); }
    };
    icons();
  }

  function openSupplierForm() {
    const html = `<button class="mz-modal-x" data-inv-x aria-label="Fermer"><i data-lucide="x"></i></button><div class="mzi-modh"><div><h3>Nouveau fournisseur</h3><span>Coordonnées, fiscalité et conditions d'achat.</span></div></div><div class="mzi-form">
      <div class="mzi-frow"><div class="mzi-fg"><label>Nom *</label><input id="mz-sf-name"></div><div class="mzi-fg"><label>Téléphone</label><input id="mz-sf-phone" inputmode="tel"></div></div><div class="mzi-frow"><div class="mzi-fg"><label>Email</label><input id="mz-sf-email" type="email"></div><div class="mzi-fg"><label>ICE / IF</label><input id="mz-sf-tax"></div></div><div class="mzi-fg"><label>Adresse</label><input id="mz-sf-address"></div><div class="mzi-frow"><div class="mzi-fg"><label>Délai (jours)</label><input id="mz-sf-lead" type="number" min="0" value="0"></div><div class="mzi-fg"><label>Conditions de paiement</label><input id="mz-sf-terms" placeholder="30 jours, comptant…"></div></div><div class="mzi-fg"><label>Marques / catégories</label><input id="mz-sf-cats"></div><div class="mzi-fg"><label>Notes</label><input id="mz-sf-notes" maxlength="500"></div></div><div class="mzi-modfoot"><button class="mz-btn secondary" data-inv-x>Annuler</button><button class="mz-btn primary" id="mz-sf-save">Enregistrer</button></div>`;
    invSetModal(html, (el) => { $('#mz-sf-save', el).onclick = () => { const name=$('#mz-sf-name',el).value.trim(); if(!name){toast('Le nom est requis');return;} procurement().addSupplier({name,phone:$('#mz-sf-phone',el).value,email:$('#mz-sf-email',el).value,address:$('#mz-sf-address',el).value,taxId:$('#mz-sf-tax',el).value,paymentTerms:$('#mz-sf-terms',el).value,categories:$('#mz-sf-cats',el).value,notes:$('#mz-sf-notes',el).value,leadDays:$('#mz-sf-lead',el).value}); closeVeil('#mz-inv-veil'); renderSuppliers(); toast('Fournisseur enregistré'); }; });
  }
  function procurementLineFields(doc, supplierId) {
    const products = catDB()?.listProducts?.({}) || [];
    const variants = products.flatMap((p) => (catDB()?.getProduct?.(p.id)?.variants || []).map((v) => ({ p, v })));
    return `<div class="mzi-frow"><div class="mzi-fg"><label>Fournisseur</label><select id="mz-pm-sup">${(doc.suppliers||[]).map((s)=>`<option value="${s.id}" ${s.id===supplierId?'selected':''}>${esc(s.name)}</option>`).join('')}</select></div><div class="mzi-fg"><label>Article · variante</label><select id="mz-pm-product">${variants.map(({p,v})=>`<option value="${v.id}" data-pid="${p.id}">${esc(p.name)} · ${esc(v.size || 'TU')} ${esc(v.colorLabel || '')}</option>`).join('')}</select></div></div><div class="mzi-frow"><div class="mzi-fg"><label>Quantité</label><input id="mz-pm-qty" type="number" min="1" value="1"></div><div class="mzi-fg"><label>Coût unitaire (MAD)</label><input id="mz-pm-cost" type="number" min="0" step="0.01"></div></div><div class="mzi-fg"><label>Référence / note</label><input id="mz-pm-ref" maxlength="100"></div>`;
  }
  function procurementLine(el) { const select=$('#mz-pm-product',el),opt=select?.selectedOptions?.[0],pid=opt?.dataset.pid||'',p=P[pid]||catDB()?.getProduct?.(pid)?.product; return {itemId:pid,variantId:select?.value||'',name:p?.name||'Article',qty:Math.max(1,+$('#mz-pm-qty',el).value||1),unit:'pièce',unitCost:Math.max(0,+$('#mz-pm-cost',el).value||0)}; }
  function procurementVariant(line) {
    const card = catDB()?.getProduct?.(line.itemId);
    return (card?.variants || []).find((v) => v.id === line.variantId) || ((card?.variants || []).length === 1 ? card.variants[0] : null);
  }
  async function postMaisonProcurement(kind, lines, ref, supplierId) {
    const MZ=window.KiwiMaisonStock, doc=procurement().doc(), supplier=supplierName(doc,supplierId), applied=[];
    if (!MZ?.requestManual) return {error:'stock-journal-unavailable',lines:[]};
    for (const line of lines) {
      const variant=procurementVariant(line);
      if (!variant) return {error:'variant-required',lines:applied};
      const normalized={...line,variantId:variant.id};
      const moved=await MZ.requestManual({productId:line.itemId,variantId:variant.id,type:kind==='return'?'retour-fourn':'reception',qty:line.qty,ref,note:ref,supplier,source:'caisse'});
      if (!moved?.ok) return {error:moved?.reason||'stock-move-failed',lines:applied};
      if (kind!=='return' && line.unitCost>0) catDB().updateProduct(line.itemId,{cost:line.unitCost});
      applied.push(normalized);
    }
    return {lines:applied};
  }
  function openProcurementMove(kind, id) {
    const api=procurement(),doc=api.doc(),order=kind==='order'?(doc.orders||[]).find((o)=>o.id===id):null,supplierId=order?.supplierId||id;
    const title=kind==='return'?'Retour fournisseur':kind==='order'?'Réception de commande':'Réception directe';
    const html=`<button class="mz-modal-x" data-inv-x aria-label="Fermer"><i data-lucide="x"></i></button><div class="mzi-modh"><div><h3>${title}</h3><span>Le mouvement et le coût sont inscrits dans l'historique de stock.</span></div></div><div class="mzi-form">${order?'':procurementLineFields(doc,supplierId)}${order?`<div class="mzi-fg"><label>Lignes à réceptionner</label>${order.lines.map((l)=>`<div>${esc(l.name)} · ${l.qty-(l.receivedQty||0)} restant(s)</div>`).join('')}</div><div class="mzi-fg"><label>Référence</label><input id="mz-pm-ref"></div>`:''}</div><div class="mzi-modfoot"><button class="mz-btn secondary" data-inv-x>Annuler</button><button class="mz-btn primary" id="mz-pm-save">Enregistrer</button></div>`;
    invSetModal(html,(el)=>{$('#mz-pm-save',el).onclick=async()=>{const save=$('#mz-pm-save',el);save.disabled=true;const ref=$('#mz-pm-ref',el).value;const supplier=order?.supplierId||$('#mz-pm-sup',el).value;const wanted=order?order.lines.map((l)=>({...l,qty:Math.max(0,l.qty-(l.receivedQty||0))})).filter((l)=>l.qty>0):[procurementLine(el)];const posted=await postMaisonProcurement(kind,wanted,ref,supplier);if(posted.error){save.disabled=false;toast('Opération refusée',5200,'danger',posted.error==='variant-required'?'Choisissez la variante exacte de chaque article.':'Le mouvement de stock n’a pas été autorisé.');return;}const input={supplierId:supplier,externalRef:ref,lines:posted.lines,skipMovements:true,skipCosts:true};const res=order?api.receiveOrder(order.id,input):kind==='return'?api.returnToSupplier(input):api.receiveDirect(input);if(res?.error){save.disabled=false;toast('Opération refusée',5200,'danger','Le document fournisseur n’a pas pu être enregistré.');return;}closeVeil('#mz-inv-veil');renderSuppliers();toast(kind==='return'?'Retour fournisseur enregistré':'Réception enregistrée');};});
  }
  function openPurchaseOrder() {
    const api=procurement(),doc=api.doc();
    const html=`<button class="mz-modal-x" data-inv-x aria-label="Fermer"><i data-lucide="x"></i></button><div class="mzi-modh"><div><h3>Nouveau bon de commande</h3><span>Créez le brouillon, puis marquez-le envoyé depuis la liste.</span></div></div><div class="mzi-form">${procurementLineFields(doc,'')}<div class="mzi-fg"><label>Date attendue</label><input id="mz-po-date" type="date"></div></div><div class="mzi-modfoot"><button class="mz-btn secondary" data-inv-x>Annuler</button><button class="mz-btn primary" id="mz-po-save">Créer</button></div>`;
    invSetModal(html,(el)=>{$('#mz-po-save',el).onclick=()=>{const res=api.createOrder({supplierId:$('#mz-pm-sup',el).value,expectedDate:$('#mz-po-date',el).value,note:$('#mz-pm-ref',el).value,lines:[procurementLine(el)]});if(res?.error){toast('Fournisseur et article requis');return;}closeVeil('#mz-inv-veil');renderSuppliers();toast(`Commande ${res.number} créée`);};});
  }

  /* ═══════════════════════ CASSE & GESTION DES PERTES ═══════════════════ */
  /* La casse en boutique d'art de la table & décoration (céramique, verrerie, cristal, bougies)
   * est un fait d'exploitation régulier. Tracée via `KiwiBoutiqueCatalog.adjustStock`
   * et le grand livre `KiwiInventory` (reason: 'loss') avec le coût d'achat réel. */
  const CASSE_KEY = 'kiwi:mzCasseLog';
  let CASSE_LOG = null;
  function loadCasseLog() {
    if (CASSE_LOG) return CASSE_LOG;
    try {
      const stored = localStorage.getItem(CASSE_KEY + ':' + merchantSlug());
      if (stored) CASSE_LOG = JSON.parse(stored);
    } catch (_) {}
    if (!Array.isArray(CASSE_LOG)) {
      CASSE_LOG = IS_DEMO ? [
        { id: 'casse-1', ts: Date.now() - 36 * 3600 * 1000, pid: 'mz_fes_bleu_assiette', name: 'Assiette plate 27cm Fès Bleu', qty: 2, unitCost: 45, totalLoss: 90, reason: 'Chute déballage carton', by: 'Kenza Tazi' },
        { id: 'casse-2', ts: Date.now() - 90 * 3600 * 1000, pid: 'mz_verres_beldi_set', name: 'Verres soufflés Beldi (Lot 6)', qty: 1, unitCost: 75, totalLoss: 75, reason: 'Manipulation client rayon verrerie', by: 'Yasmine' },
      ] : [];
    }
    return CASSE_LOG;
  }
  function saveCasseLog() {
    try {
      localStorage.setItem(CASSE_KEY + ':' + merchantSlug(), JSON.stringify(CASSE_LOG || []));
    } catch (_) {}
  }
  function recordCasse(pid, size, color, qty, reason) {
    qty = Math.max(1, parseInt(qty, 10) || 1);
    const p = P[pid];
    if (!p) { toast('Article introuvable'); return false; }
    const cat = window.KiwiBoutiqueCatalog;
    const v = cat && cat.findVariant ? cat.findVariant(pid, color, size) : null;
    const vid = v ? v.id : null;
    const unitCost = +p.cost || Math.round(p.price * 0.55);
    const totalLoss = unitCost * qty;
    const why = 'casse · ' + (reason || 'Casse magasin');

    /* Une casse est un motif DISCRÉTIONNAIRE : le serveur ne l'accepte d'une
       caisse qu'avec le code d'un responsable (functions/api/inventory/
       movements.js). Écrite ici sans autorisation, elle bougeait le stock mais
       sa ligne était refusée et restait sur la tablette — la page « Mouvements
       de stock » du tableau de bord ne voyait jamais la pièce cassée. Elle
       passe donc par le même geste que « Déclarer un mouvement » : le pavé du
       responsable, puis l'envoi autorisé. Un refus remet la pièce en stock. */
    const MZ = window.KiwiMaisonStock;
    if (vid && MZ && MZ.requestManual && pvReal()) {
      ensureStockJournal();
      return Promise.resolve(MZ.requestManual({
        productId: pid, variantId: vid, type: 'casse', qty,
        note: reason || 'Casse magasin', source: 'caisse',
      })).then((res) => {
        if (!res || !res.ok) {
          toast(res && res.reason === 'stock-insuffisant' ? `Stock insuffisant : il n'y a que ${res.before} pièce(s).`
            : res && res.reason === 'non-autorise' ? 'Casse non autorisée · code responsable requis'
              : res && res.reason === 'reseau' ? 'Réseau indisponible · réessayez pour faire autoriser la casse'
                : 'Casse impossible');
          return false;
        }
        return logCasse(p, pid, size, qty, unitCost, totalLoss, reason);
      });
    }

    if (vid && cat && cat.adjustStock) {
      cat.adjustStock(vid, -qty, why);
    } else {
      stockAdd(pid, size, -qty);
    }
    
    try {
      if (window.KiwiInventory && window.KiwiInventory.add) {
        window.KiwiInventory.add({
          itemId: pid, qty: -qty, reason: 'loss', refType: 'breakage',
          refId: `casse-${Date.now().toString(36)}`, note: `Casse Vogue Home: ${reason}`,
          unitCost: unitCost
        });
      }
    } catch (_) {}
    return logCasse(p, pid, size, qty, unitCost, totalLoss, reason);
  }
  function logCasse(p, pid, size, qty, unitCost, totalLoss, reason) {
    const entry = {
      id: `casse-${Date.now().toString(36)}`,
      ts: Date.now(),
      pid,
      name: p.name + (size && size !== 'TU' ? ' · ' + size : ''),
      qty,
      unitCost,
      totalLoss,
      reason: reason || 'Non précisé',
      by: (STAFF && STAFF.caissiere && STAFF.caissiere.name) || 'Caisse'
    };
    const log = loadCasseLog();
    log.unshift(entry);
    saveCasseLog();
    rebuildCatalog();
    renderAll();
    toast(`Casse enregistrée · −${qty} pièce(s) (perte financière : ${fmtMAD(totalLoss)})`);
    return true;
  }

  const CASSE_REASONS = [
    ['Chute lors du déballage en réserve', 'Chute déballage'],
    ['Manipulation client en rayon', 'Accident client en rayon'],
    ["Défaut d'émail / fêlure découverte", "Fêlure / défaut d'émail"],
    ['Casse lors de la livraison fragile', 'Casse transport / livraison'],
    ['Autre incident magasin', 'Autre incident'],
  ];

  function renderCasse() {
    const panel = $('[data-mz-panel="casse"]', root);
    if (!panel) return;
    const log = loadCasseLog();
    const totalCasseLoss = log.reduce((acc, row) => acc + (row.totalLoss || 0), 0);
    // Choix en cours, gardé d'un rendu à l'autre (une casse enregistrée relance renderCasse).
    const cs = state.casse || (state.casse = { pid: '', qty: 1, reason: CASSE_REASONS[0][0], rayon: 'tous', q: '' });
    if (cs.pid && !P[cs.pid]) cs.pid = '';

    panel.innerHTML = `
      <div class="mz-casse-view mz-page">
        <header class="mz-head">
          <div>
            <button class="mz-btn ghost mz-back-inv" data-mz-back-inv><i data-icon="arrow_back"></i>Inventaire</button><h1>Déclaration de Casse &amp; Pertes</h1>
            <div class="mz-head-sub">Dépréciation immédiate, valorisation au coût d'achat et traçabilité inventaire</div>
          </div>
          <div class="mz-head-metric is-danger">
            Perte totale enregistrée : ${fmtMAD(totalCasseLoss)}
          </div>
        </header>

        <div class="mz-casse-box">
          <h2 class="mz-section-title">Déclarer un article cassé / détérioré</h2>
          <div class="mz-casse-pick">
            <div class="mz-casse-search">
              <i data-icon="search"></i>
              <input id="mz-casse-q" type="search" placeholder="Rechercher un article, une marque, un motif…" value="${esc(cs.q)}" autocomplete="off" />
            </div>
            <div class="mz-casse-chips" id="mz-casse-rayons">
              <button type="button" class="mz-casse-chip${cs.rayon === 'tous' ? ' on' : ''}" data-casse-rayon="tous">Tout</button>
              ${RAYONS.filter((r) => r.items.length).map((r) => `<button type="button" class="mz-casse-chip${cs.rayon === r.id ? ' on' : ''}" data-casse-rayon="${esc(r.id)}">${esc(r.label)}</button>`).join('')}
            </div>
            <div class="mz-grid mz-casse-grid" id="mz-casse-grid"></div>
          </div>

          <div class="mz-casse-form">
            <div class="mz-casse-sel" id="mz-casse-sel"></div>
            <div class="mz-casse-row">
              <div>
                <div class="mz-casse-lbl">Quantité cassée</div>
                <div class="mz-casse-step">
                  <button type="button" data-casse-step="-1" aria-label="Moins"><i data-icon="remove"></i></button>
                  <input id="mz-casse-qty" type="number" min="1" inputmode="numeric" value="${cs.qty}" />
                  <button type="button" data-casse-step="1" aria-label="Plus"><i data-icon="add"></i></button>
                </div>
              </div>
              <div class="mz-casse-why">
                <div class="mz-casse-lbl">Motif</div>
                <div class="mz-casse-chips" id="mz-casse-reasons">
                  ${CASSE_REASONS.map(([v, l]) => `<button type="button" class="mz-casse-chip${cs.reason === v ? ' on' : ''}" data-casse-reason="${esc(v)}">${esc(l)}</button>`).join('')}
                </div>
              </div>
            </div>

            <div class="mz-casse-cost-preview" id="mz-casse-preview">
              <span>Coût d'achat imputé : <b id="mz-casse-preview-unit">0 MAD</b></span>
              <span>Perte financière magasin : <b id="mz-casse-preview-total">0 MAD</b></span>
            </div>

            <div class="mz-card-actions">
              <button class="mz-btn primary is-danger" id="mz-casse-submit">
                <i data-icon="gpp_maybe"></i>Enregistrer la casse &amp; décrémenter le stock
              </button>
            </div>
          </div>
        </div>

        <div class="mz-casse-box">
          <h2 class="mz-section-title">Historique des déclarations de casse</h2>
          ${log.length ? `
          <table class="mz-casse-table">
            <thead>
              <tr>
                <th>Date</th>
                <th>Article</th>
                <th>Qté</th>
                <th>Coût d'achat</th>
                <th>Perte totale</th>
                <th>Motif</th>
                <th>Déclaré par</th>
              </tr>
            </thead>
            <tbody>
              ${log.map((row) => `
                <tr>
                  <td>${fmtDT(new Date(row.ts))}</td>
                  <td><b>${esc(row.name)}</b></td>
                  <td><b>${row.qty}×</b></td>
                  <td style="font-family:var(--mono);">${fmtMAD(row.unitCost)}</td>
                  <td style="font-family:var(--mono); color:#BA1A1A; font-weight:700;">${fmtMAD(row.totalLoss)}</td>
                  <td>${esc(row.reason)}</td>
                  <td>${esc(row.by)}</td>
                </tr>`).join('')}
            </tbody>
          </table>` : '<div class="mz-empty">Aucune casse enregistrée.</div>'}
        </div>
      </div>`;

    const qtyIn = $('#mz-casse-qty', panel);
    const grid = $('#mz-casse-grid', panel);
    const submitBtn = $('#mz-casse-submit', panel);
    const norm = (t) => String(t || '').toLowerCase().normalize('NFD').replace(/[\u0300-\u036f]/g, '');
    let busy = false;

    const updatePreview = () => {
      const p = P[cs.pid];
      const unit = p ? (+p.cost || Math.round(p.price * 0.55)) : 0;
      $('#mz-casse-preview-unit', panel).textContent = fmtMAD(unit);
      $('#mz-casse-preview-total', panel).textContent = fmtMAD(unit * cs.qty);
      submitBtn.disabled = busy || !p;
    };

    const renderSel = () => {
      const p = P[cs.pid];
      $('#mz-casse-sel', panel).innerHTML = p
        ? `<span class="mz-casse-sel-art">${artOf(p)}</span>
           <span class="mz-casse-sel-txt"><b>${esc(p.name)}</b><span>${p.marque ? esc(p.marque) + ' · ' : ''}${stockOf(p)} ${esc(tr('en stock'))} · ${fmtMAD(shelf(p.price))}</span></span>
           <button type="button" class="mz-casse-sel-x" data-casse-clear aria-label="${esc(tr("Changer d'article"))}"><i data-icon="close"></i></button>`
        : '<span class="mz-casse-sel-empty">' + esc(tr('Touchez l\u2019article cassé dans la liste ci-dessus.')) + '</span>';
      icons();
    };

    const renderPick = () => {
      const q = norm(cs.q).trim();
      const items = [];
      RAYONS.forEach((r) => {
        if (cs.rayon !== 'tous' && r.id !== cs.rayon) return;
        r.items.forEach((p) => {
          if (q && !norm([p.name, p.marque, p.motif, r.label].join(' ')).includes(q)) return;
          items.push(p);
        });
      });
      grid.innerHTML = items.length ? items.map((p) => {
        const st = stockOf(p);
        return `
        <button type="button" class="mz-card${st === 0 ? ' is-out' : ''}${cs.pid === p.id ? ' is-picked' : ''}" data-casse-pid="${p.id}">
          <span class="mz-card-art">${artOf(p)}</span>
          ${p.marque ? `<span class="mz-card-brand">${esc(p.marque)}</span>` : ''}
          <span class="mz-card-name">${esc(p.name)}</span>
          <span class="mz-card-price">${fmtMAD(shelf(p.price))} · ${st} ${esc(tr('en stock'))}</span>
        </button>`; }).join('')
        : '<div class="mz-empty" style="grid-column:1/-1;">' + esc(tr('Aucun article ne correspond.')) + '</div>';
    };

    const setQty = (n) => {
      cs.qty = Math.max(1, Math.min(999, parseInt(n, 10) || 1));
      qtyIn.value = cs.qty;
      updatePreview();
    };

    $('#mz-casse-q', panel).oninput = (e) => { cs.q = e.target.value; renderPick(); };
    panel.onclick = (e) => {
      const card = e.target.closest('[data-casse-pid]');
      if (card) {
        cs.pid = card.dataset.cassePid;
        grid.querySelectorAll('.is-picked').forEach((b) => b.classList.remove('is-picked'));
        card.classList.add('is-picked');
        renderSel(); updatePreview();
        return;
      }
      const ray = e.target.closest('[data-casse-rayon]');
      if (ray) {
        cs.rayon = ray.dataset.casseRayon;
        $('#mz-casse-rayons', panel).querySelectorAll('.mz-casse-chip').forEach((b) => b.classList.toggle('on', b === ray));
        renderPick();
        return;
      }
      const why = e.target.closest('[data-casse-reason]');
      if (why) {
        cs.reason = why.dataset.casseReason;
        $('#mz-casse-reasons', panel).querySelectorAll('.mz-casse-chip').forEach((b) => b.classList.toggle('on', b === why));
        return;
      }
      const step = e.target.closest('[data-casse-step]');
      if (step) { setQty(cs.qty + (+step.dataset.casseStep)); return; }
      if (e.target.closest('[data-casse-clear]')) {
        cs.pid = '';
        grid.querySelectorAll('.is-picked').forEach((b) => b.classList.remove('is-picked'));
        renderSel(); updatePreview();
      }
    };
    qtyIn.oninput = () => { cs.qty = Math.max(1, parseInt(qtyIn.value, 10) || 1); updatePreview(); };
    qtyIn.onblur = () => setQty(qtyIn.value);

    submitBtn.onclick = () => {
      const p = P[cs.pid];
      if (!p) { toast(tr('Choisissez d\u2019abord l\u2019article cassé')); return; }
      busy = true; updatePreview();   // le pavé du responsable peut rester ouvert : pas de double déclaration
      Promise.resolve(recordCasse(cs.pid, sizesOf(p)[0] || 'TU', p.colors[0] || 'defaut', cs.qty, cs.reason))
        .then((ok) => { if (ok) { cs.pid = ''; cs.qty = 1; } })
        .finally(() => { busy = false; renderCasse(); icons(); });
    };

    renderPick();
    renderSel();
    updatePreview();
    icons();
  }

  /* ═══════════════════════ LIVRAISON FRAGILE & BONS DE LIVRAISON ═══════════════════ */
  function openDeliveryModal() {
    const el = $('#mz-deliverym', root);
    const d = state.ticket.delivery || {
      name: ticketClient() ? ticketClient().name : '',
      phone: ticketClient() ? ticketClient().phone : '',
      address: '',
      quartier: 'Marshan',
      slot: 'Aujourd’hui (15h - 19h)',
      reinforcedWrap: state.ticket.lines.some((l) => l.fragile || (P[l.pid] && P[l.pid].fragile)),
      instructions: 'Manipuler avec précaution (céramique & cristal).',
    };
    const QUARTIERS_TANGER = [
      'Marshan', 'Malabata', 'Centre-Ville / Boulevard', 'Iberia',
      'California / Vieille Montagne', 'Achakar / Cap Spartel', 'Val Fleuri',
      'Mesnana / Boukhalef', 'Gzenaya', 'Zone Franche'
    ];
    el.innerHTML = `
      <button class="mz-modal-x" data-mz-close aria-label="Fermer"><i data-icon="close"></i></button>
      <h3 class="modal-title">Livraison Fragile · Tanger</h3>
      <p class="modal-subtle">Bon de livraison et emballage sécurisé</p>
      <div class="mz-delivery-form">
        <label><span>Nom du destinataire</span>
          <input id="mz-del-name" placeholder="Nom et prénom" value="${esc(d.name)}" />
        </label>
        <label><span>Téléphone (WhatsApp livreur)</span>
          <input id="mz-del-tel" inputmode="tel" placeholder="06… ou 07…" value="${esc(d.phone)}" />
        </label>
        <label><span>Quartier de Tanger</span>
          <select id="mz-del-quartier">
            ${QUARTIERS_TANGER.map((q) => `<option value="${esc(q)}" ${d.quartier === q ? 'selected' : ''}>${esc(q)}</option>`).join('')}
          </select>
        </label>
        <label><span>Adresse précise (Rue, Résidence, Étage)</span>
          <input id="mz-del-addr" placeholder="Ex: Résidence Al Andalous, Imm B, Apt 14" value="${esc(d.address)}" />
        </label>
        <label><span>Créneau de livraison souhaité</span>
          <select id="mz-del-slot">
            <option value="Matin (10h - 13h)">Matin (10h - 13h)</option>
            <option value="Après-midi (15h - 19h)" selected>Après-midi (15h - 19h)</option>
            <option value="Demain matin">Demain matin</option>
            <option value="Sur rendez-vous">Sur rendez-vous client</option>
          </select>
        </label>
        <label style="flex-direction:row; align-items:center; gap:8px; margin-top:4px;">
          <input type="checkbox" id="mz-del-wrap" ${d.reinforcedWrap ? 'checked' : ''} />
          <span style="font-size:12.5px; font-weight:600; color:var(--riad,#053B2C);">Emballage renforcé requis (Protection bulle + calage)</span>
        </label>
        <label><span>Instructions de transport</span>
          <input id="mz-del-inst" placeholder="Instructions chauffeur" value="${esc(d.instructions)}" />
        </label>
      </div>
      <div class="modal-actions is-visible" style="margin-top:16px;">
        <button class="ma-btn secondary" id="mz-del-cancel">Annuler</button>
        ${state.ticket.delivery ? '<button class="ma-btn secondary" id="mz-del-remove" style="color:var(--danger,#BA1A1A);">Supprimer livraison</button>' : ''}
        <button class="ma-btn primary" id="mz-del-save"><i data-lucide="check"></i>Enregistrer la livraison</button>
      </div>`;
    icons();
    $$('[data-mz-close]', el).forEach((b) => { b.onclick = () => closeVeil('#mz-delivery-veil'); });
    const cancel = $('#mz-del-cancel', el);
    if (cancel) cancel.onclick = () => closeVeil('#mz-delivery-veil');
    const remove = $('#mz-del-remove', el);
    if (remove) remove.onclick = () => {
      state.ticket.delivery = null;
      closeVeil('#mz-delivery-veil');
      renderTicket(); icons();
      toast('Livraison retirée du ticket');
    };
    const save = $('#mz-del-save', el);
    if (save) save.onclick = () => {
      const name = $('#mz-del-name', el).value.trim();
      const phone = $('#mz-del-tel', el).value.trim();
      const quartier = $('#mz-del-quartier', el).value;
      const address = $('#mz-del-addr', el).value.trim();
      const slot = $('#mz-del-slot', el).value;
      const reinforcedWrap = $('#mz-del-wrap', el).checked;
      const instructions = $('#mz-del-inst', el).value.trim();
      if (!name) { toast('Le nom du destinataire est requis'); return; }
      state.ticket.delivery = { name, phone, quartier, address, slot, reinforcedWrap, instructions };
      closeVeil('#mz-delivery-veil');
      renderTicket(); icons();
      toast(`Livraison enregistrée · ${quartier}`);
    };
    openVeil('#mz-delivery-veil');
  }

  function printDeliveryNoteNow(opts, parts) {
    const sale = opts.sale || {};
    const del = (sale.delivery) || (state.ticket && state.ticket.delivery) || {
      name: opts.customer ? opts.customer.name : 'Client',
      phone: opts.customer ? opts.customer.phone : '',
      quartier: 'Tanger Centre', address: 'À préciser', slot: 'Journée',
      reinforcedWrap: true, instructions: 'Attention fragile.'
    };
    const html = `
      <div style="font-family:system-ui,-apple-system,sans-serif; max-width:480px; margin:20px auto; padding:24px; border:2px solid #0B6E4F; border-radius:12px; background:#fff; color:#0A0F0D;">
        <div style="text-align:center; border-bottom:2px solid #0B6E4F; padding-bottom:12px; margin-bottom:14px;">
          <h2 style="margin:0; font-size:18px; text-transform:uppercase; letter-spacing:0.06em; color:#0B6E4F;">Vogue Home · Tanger</h2>
          <div style="font-size:12px; font-weight:700; color:#555; margin-top:2px;">BON DE LIVRAISON SÉCURISÉ · N° ${esc(opts.ref || sale.id || 'LIV')}</div>
          <div style="font-size:11px; color:#777;">${fmtDT(new Date())} · Conseiller: ${esc((STAFF && STAFF.caissiere && STAFF.caissiere.name) || 'Caisse')}</div>
        </div>
        <div style="background:rgba(217,154,43,0.18); border:1px solid #B25E00; border-radius:8px; padding:10px; margin-bottom:14px; text-align:center;">
          <b style="color:#B25E00; font-size:13px; text-transform:uppercase; display:block;">ATTENTION TRÈS FRAGILE</b>
          <span style="font-size:11px; color:#8A6210;">Articles en céramique & verrerie fine · Maintenir à plat, ne pas superposer de charges lourdes.</span>
        </div>
        <div style="margin-bottom:14px; font-size:12.5px; line-height:1.5;">
          <div><b>Destinataire :</b> ${esc(del.name)} (${esc(del.phone || 'Non renseigné')})</div>
          <div><b>${del.city ? 'Ville' : 'Quartier'} :</b> ${esc([del.city, del.quartier].filter(Boolean).join(' · '))}</div>
          <div><b>Adresse :</b> ${esc(del.address || 'Au comptoir')}</div>
          <div><b>Créneau :</b> ${esc(del.slot || 'Standard')}</div>
          ${del.instructions ? `<div><b>Note :</b> <i>${esc(del.instructions)}</i></div>` : ''}
        </div>
        <table style="width:100%; border-collapse:collapse; font-size:12px; margin-bottom:16px;">
          <thead>
            <tr style="border-bottom:1px solid #ccc; text-align:left;">
              <th style="padding:6px 4px;">Qté</th>
              <th style="padding:6px 4px;">Article</th>
              <th style="padding:6px 4px;">Marque / Format</th>
              <th style="padding:6px 4px; text-align:right;">Contrôle</th>
            </tr>
          </thead>
          <tbody>
            ${(opts.lines || []).map((l) => `
              <tr style="border-bottom:1px solid #eee;">
                <td style="padding:6px 4px; font-weight:700;">${l.qty || 1}×</td>
                <td style="padding:6px 4px;">${esc(l.name)}</td>
                <td style="padding:6px 4px; font-size:11px; color:#555;">${esc(l.marque || '')} ${l.format === 'service' ? '(Service)' : ''}</td>
                <td style="padding:6px 4px; text-align:right; font-size:14px;">[ &nbsp; ]</td>
              </tr>`).join('')}
          </tbody>
        </table>
        <div style="border-top:1px dashed #ccc; padding-top:12px; display:flex; justify-content:space-between; font-size:11px; color:#666;">
          <div>Signature Chauffeur / Livreur :<br><br>____________________</div>
          <div>Signature & Date Réception Client :<br><br>____________________</div>
        </div>
      </div>`;
    const w = window.open('', '_blank', 'width=520,height=680');
    if (w) {
      w.document.write(`<!DOCTYPE html><html><head><title>Bon de Livraison - ${esc(opts.ref)}</title></head><body style="margin:0; background:#f4f4f4;">${html}<script>window.onload=function(){window.print();};<\/script></body></html>`);
      w.document.close();
      toast('Bon de livraison prêt à imprimer');
    } else {
      toast('Impression bloquée par le navigateur');
    }
  }

  function renderScan() {
    const panel = $('[data-mz-panel="scan"]', root);
    panel.innerHTML = `
      <div class="mz-scan mz-page">
        <header class="mz-head">
            <div><h1>Scan produit</h1><div class="mz-head-sub">Scannez un article pour voir son prix, ses tailles et son stock. Rien n'est ajouté au ticket.</div></div>
        </header>
        <div class="mz-scan-inner mz-section-surface">
          <div class="mz-ean-in"><i data-lucide="scan-line"></i>
            <input id="mz-ean" placeholder="Scannez ou tapez un code-barres…" autocomplete="off" />
          </div>
          <div class="mz-scan-or">ou</div>
          ${pvReal()
            ? (camSupported()
                ? `<button class="mz-scan-mock" id="mz-scan-cam"><i data-lucide="camera"></i>Scanner avec la caméra</button>`
                : `<div class="mz-scan-nocam">Ce navigateur ne sait pas lire un code-barres par la caméra. La douchette USB fonctionne, elle tape directement dans le champ ci-dessus.</div>`)
            : `<button class="mz-scan-mock" id="mz-scan-mock"><i data-lucide="scan-line"></i>Scanner un article (douchette démo)</button>`}
          <button class="mz-scan-diag" id="mz-scan-diag"><i data-lucide="activity"></i>Tester la douchette</button>
          <div class="mz-scan-stage" id="mz-scan-stage"><span id="mz-scan-stage-ean"></span><div class="mz-scan-laser"></div></div>
          ${lookupCardHtml()}
          ${crossCardHtml()}
          ${state.scanLog.length ? `
          <div class="mz-scan-log-h">Derniers articles vérifiés</div>
          <div class="mz-scan-log">
            ${state.scanLog.slice(0, 6).map((l) => `
              <div class="mz-scan-log-row ${l.ok ? '' : 'is-err'}">
                <i data-lucide="${l.ok ? 'check-circle-2' : 'x'}"></i>
                <span class="when">${fmtHM(l.at)}</span>
                <span>${esc(l.label)}</span>
                <span class="ean">${esc(l.ean)}</span>
              </div>`).join('')}
          </div>` : (state.lookup ? '' : `<div class="mz-empty">Aucun article vérifié pour l'instant, la douchette USB tape ici toute seule.</div>`)}
        </div>
      </div>`;
    const diag = $('#mz-scan-diag', panel);
    if (diag) diag.onclick = () => openScannerTest();
    const input = $('#mz-ean', panel);
    input.onkeydown = (e) => { if (e.key === 'Enter') { const v = input.value; input.value = ''; lookupScan(v); } };
    input.oninput = () => { if (input.value.replace(/\D/g, '').length >= 13) { const v = input.value; input.value = ''; lookupScan(v); } };
    input.onblur = () => {
      setTimeout(() => {
        if (state.view !== 'scan') return;
        if ($$('.modal-veil.is-open', root).length) return;
        const i = $('#mz-ean', root);
        if (i) i.focus();
      }, 120);
    };
    /* Un seul des deux existe selon le contexte (vraie boutique vs démo). */
    const mk = $('#mz-scan-mock', panel);
    if (mk) mk.onclick = mockScan;
    const cam = $('#mz-scan-cam', panel);
    if (cam) cam.onclick = () => openCamScan(lookupScan);
    const sell = $('#mz-look-sell', panel);
    if (sell) sell.onclick = () => {
      const lk = state.lookup;
      if (!lk || !P[lk.pid]) return;
      const p = P[lk.pid];
      const size = (p.sizes[lk.size] || 0) > 0 ? lk.size : firstFree(p);
      if (!size) { toast(`${p.name}, épuisé dans toutes les tailles`); return; }
      switchView('vente');
      addToTicket(lk.pid, { size, color: lk.color || p.colors[0], qty: 1, remise: 0 });
    };
    icons();
    setTimeout(() => { const i = $('#mz-ean', panel); if (i) i.focus(); }, 60);
  }

  /* SELL path — a code scanned/typed in Vente (the scan bar or the USB douchette)
     drops the EXACT variant (colour + size) straight onto the ticket, like a
     supermarket lane. Resolves EAN-13 or any old/alphanumeric code registered on
     an article. Unknown → offer to register it on a product (no reprint). */
  function commitEan(raw) {
    /* A douchette keeps firing while the payment (or any other) window is open.
       The item would land on a ticket that is already being charged and leave
       with the customer uncharged: refuse, exactly as pos-boutique does. */
    if (root && $$('.modal-veil.is-open', root).length) {
      toast('Terminez la fenêtre ouverte avant de scanner');
      return;
    }
    const code = normScan(raw);
    if (!code) return;
    const hit = window.KiwiBoutiqueCatalog ? window.KiwiBoutiqueCatalog.resolveScan(code) : null;
    const pid = hit ? hit.pid : BY_EAN[code];
    if (!pid || !P[pid]) {
      toast(`Code ${code} inconnu, enregistrez-le sur un article`);
      offerRegister(code);
      return;
    }
    const p = P[pid];
    const c = ticketClient();
    let size = (hit && hit.size && (p.sizes[hit.size] || 0) > 0) ? hit.size
             : (c && p.kind === 'taille' && (p.sizes[c.taille] || 0) > 0) ? c.taille
             : firstFree(p);
    if (!size) {
      toast(`${p.name}, épuisé dans toutes les tailles`);
      return;
    }
    const color = (hit && hit.colorFamily && p.colors.includes(hit.colorFamily)) ? hit.colorFamily : p.colors[0];
    addToTicket(pid, { size, color, qty: 1, remise: 0 }, { quiet: true });
    /* A scanned item added to the bill is an Adjust, on the frame the line is added (design 2027, §20.3). */
    try { if (window.KiwiHaptics) window.KiwiHaptics.play('Adjust', window.KiwiHaptics.gid('scan-add')); } catch (_) {}
    toast(`Bip, ${p.name} · ${size} sur le ticket (${fmtMAD(shelf(p.price))})`);
    if (state.view === 'vente') renderTicket();
    renderBadges();
  }

  /* LOOKUP path — the Scan tab: an employee scans/types a code to SEE the article
     (price, sizes, live stock, colours). Read-only — nothing touches the ticket. */
  function lookupScan(raw) {
    const code = normScan(raw);
    if (!code) return;
    const hit = window.KiwiBoutiqueCatalog ? window.KiwiBoutiqueCatalog.resolveScan(code) : null;
    const pid = hit ? hit.pid : BY_EAN[code];
    if (!pid || !P[pid]) {
      state.lookup = null;
      state.scanLog.unshift({ at: new Date(), ok: false, label: 'Code inconnu, non référencé', ean: code, pid: null, size: '' });
      toast(`Code ${code} inconnu, aucun article ne le porte`);
      /* Le cas où la question vaut le plus cher : l'article n'est pas d'ICI.
         Il est peut-être de l'autre boutique — et c'est la réponse que le
         vendeur cherchait avant même de savoir qu'il pouvait la demander. */
      askCross(code);
      if (state.view === 'scan') renderScan();
      renderBadges();
      offerRegister(code);
      return;
    }
    const p = P[pid];
    /* on affiche la variante scannée même si elle est à zéro — c'est justement le
       stock qu'on vient vérifier. À défaut de taille scannée, la 1re taille. */
    const size = (hit && hit.size && p.sizes[hit.size] != null) ? hit.size : (firstFree(p) || sizesOf(p)[0] || '');
    const color = (hit && hit.colorFamily && p.colors.includes(hit.colorFamily)) ? hit.colorFamily : p.colors[0];
    state.lookup = { pid, size, color, ean: code, at: new Date() };
    state.scanLog.unshift({ at: new Date(), ok: true, label: `${p.name}${size ? ' · ' + size : ''}, vérifié`, ean: code, pid, size });
    const tot = stockOf(p);
    toast(tot > 0 ? `${p.name} · ${tot} en stock` : `${p.name}, épuisé`);
    askCross(code, pid);
    if (state.view === 'scan') renderScan();
    renderBadges();
  }

  function mockScan() {
    if (state.scanBusy) return;
    const cycle = scanCycle();
    if (!cycle.length) return;
    state.scanBusy = true;
    const pid = cycle[state.scanIdx % cycle.length];
    state.scanIdx++;
    const code = P[pid] ? P[pid].ean : '';
    const stage = $('#mz-scan-stage', root);
    const lbl = $('#mz-scan-stage-ean', root);
    if (stage) { stage.classList.add('is-on'); if (lbl) lbl.textContent = code; }
    setTimeout(() => {
      state.scanBusy = false;
      lookupScan(code);
    }, 620);
  }

  /* ═══════════════════════ ÉCHANGES & AVOIRS (signature) ═══════════════════ */
  function saleMatches(s, q) {
    if (!q) return true;
    const ql = q.toLowerCase();
    const digits = q.replace(/\D/g, '');
    const c = saleClient(s);
    return s.id.toLowerCase().includes(ql) ||
      (c && c.name.toLowerCase().includes(ql)) ||
      (c && digits.length >= 2 && c.phone.replace(/\D/g, '').includes(digits));
  }

  function renderEchanges() {
    const panel = $('[data-mz-panel="echanges"]', root);
    const q = state.retQuery;
    /* Une vente sortie des livres ne se retourne pas : elle n'a plus eu lieu, sa
       marchandise est déjà revenue en stock, et l'échanger créerait un avoir
       adossé à un encaissement que le serveur ne connaît plus. */
    const dateKey = businessDateKey;
    const todayKey = dateKey(Date.now());
    const yesterdayKey = shiftDateKey(todayKey, -1), oldestKey = shiftDateKey(todayKey, -(RETAIN_DAYS - 1));
    if (state.retDate < oldestKey || state.retDate > todayKey) state.retDate = todayKey;
    const hits = SALES.filter((s) => !s.voided && dateKey(s.at) === state.retDate && saleMatches(s, q));
    const ret = state.ret;
    panel.innerHTML = `
      <div class="mz-ret mz-page">
        <header class="mz-head">
          <div><h1>Retours, remboursements &amp; avoirs</h1><div class="mz-head-sub">Avoir boutique ou remboursement sur le moyen d’origine · remboursement protégé par un responsable</div></div>
          <div class="mz-search"><i data-lucide="search"></i>
            <input id="mz-ret-q" placeholder="N° de ticket ou téléphone…" value="${esc(q)}" /></div>
        </header>
        <div class="mz-ret-bar mz-page-toolbar">
          <button class="mz-pill ${state.retDate === todayKey ? 'ok' : ''}" type="button" data-mz-ret-day="${todayKey}">Aujourd'hui</button>
          <button class="mz-pill ${state.retDate === yesterdayKey ? 'ok' : ''}" type="button" data-mz-ret-day="${yesterdayKey}">Hier</button>
          <label class="mz-ret-bar-lbl">Date
            <input id="mz-ret-date" type="date" min="${oldestKey}" max="${todayKey}" value="${state.retDate}" />
          </label>
        </div>
        <div class="mz-ret-scroll"><div class="mz-ret-inner">
          ${activeAvoirs().length ? `
            <div class="mz-ret-bar" style="margin-top:14px;">
              <div class="mz-ret-bar-lbl">Avoirs actifs · ${activeAvoirs().length}</div>
              ${activeAvoirs().map((a) => `
                <button class="mz-favoir" data-mz-av="${a.code}" style="margin-bottom:6px;">
                  <i data-lucide="ticket"></i><b>${a.code}</b> · ${fmtMAD(a.balance)}, ${esc(a.holderName)}<span class="see">Voir</span>
                </button>`).join('')}
            </div>` : ''}
          ${hits.map((s) => saleCard(s, ret)).join('') || (String(q).trim()
            ? `<div class="mz-empty">Rien pour « ${esc(q)} », vérifiez le n° de ticket ou le téléphone.</div>`
            /* Rien tapé encore : une boutique sans vente du jour ouvrait cette page
               sur « Rien pour «  » », un échec de recherche que personne n'a lancée. */
            : `<div class="mz-empty">Scannez le ticket de la cliente, ou tapez son numéro de téléphone.</div>`)}
        </div></div>
      </div>`;
    $('#mz-ret-q', panel).oninput = (e) => {
      state.retQuery = e.target.value;
      renderEchanges(); icons();
      const i = $('#mz-ret-q', panel); i.focus(); moveCaretEnd(i);
    };
    $('#mz-ret-date', panel).onchange = (e) => {
      state.retDate = String(e.target.value || todayKey);
      state.ret = null;
      renderEchanges(); icons();
    };
    panel.onclick = (e) => {
      const dayB = e.target.closest('[data-mz-ret-day]');
      if (dayB) { state.retDate = dayB.dataset.mzRetDay; state.ret = null; renderEchanges(); icons(); return; }
      const avB = e.target.closest('[data-mz-av]');
      if (avB) { openVoucher(AVOIRS.find((a) => a.code === avB.dataset.mzAv), { mode: 'view' }); return; }
      const qtyB = e.target.closest('[data-mz-ret-qty]');
      if (qtyB && state.ret) {
        const [saleId, idxS, deltaS] = qtyB.dataset.mzRetQty.split(':');
        const idx = Number(idxS), sale = findSale(saleId);
        if (sale && state.ret.saleId === saleId && state.ret.picks.has(idx)) {
          const current = pickedQty(state.ret, idx, sale.lines[idx]);
          state.ret.quantities.set(idx, Math.max(1, Math.min(lineAvailableQty(sale.lines[idx]), current + Number(deltaS))));
          renderEchanges(); icons();
        }
        return;
      }
      const lnB = e.target.closest('[data-mz-pick]');
      if (lnB) { togglePick(lnB.dataset.mzPick); return; }
      const lockB = e.target.closest('[data-mz-locked]');
      if (lockB) { toast('Pièce déjà retournée, rien à reprendre dessus'); return; }
      const motif = e.target.closest('[data-mz-motif]');
      if (motif && state.ret) { state.ret.motif = motif.dataset.mzMotif; renderEchanges(); icons(); return; }
      const exch = e.target.closest('[data-mz-do-exch]');
      if (exch) { doExchange(); return; }
      const avoir = e.target.closest('[data-mz-do-avoir]');
      if (avoir) { void doAvoir(); return; }
      const refund = e.target.closest('[data-mz-do-refund]');
      if (refund) { void doRefund(); return; }
    };
    icons();
  }

  const MOTIFS = ['Taille', 'Couleur', 'Défaut', 'Changement d\'avis'];

  /* A ticket line can contain several identical pieces. Older tickets only
     carried the boolean `returned`; keep understanding that format while new
     returns remember exactly how many pieces came back. */
  function lineReturnedQty(ln) {
    const sold = Math.max(0, Number(ln && ln.qty) || 0);
    if (ln && ln.returned) return sold;
    return Math.max(0, Math.min(sold, Number(ln && ln.returnedQty) || 0));
  }
  function lineAvailableQty(ln) { return Math.max(0, (Number(ln && ln.qty) || 0) - lineReturnedQty(ln)); }
  function pickedQty(ret, idx, ln) {
    const wanted = ret && ret.quantities && ret.quantities.get(idx);
    return Math.max(1, Math.min(lineAvailableQty(ln), Number(wanted) || 1));
  }
  function markLineReturned(ln, qty, note) {
    const next = Math.min(Number(ln.qty) || 0, lineReturnedQty(ln) + Math.max(0, Number(qty) || 0));
    ln.returnedQty = next;
    ln.returned = next >= (Number(ln.qty) || 0);
    ln.note = note;
  }

  /* ── Ce qui se REND, c'est ce que la cliente a PAYÉ, au centime (paid-share.js : plus fort reste, rendu en cumul) ── */
  function paidAmount(sale, ln, qty) {
    const i = ((sale && sale.lines) || []).indexOf(ln);
    return i < 0 ? (+(ln && ln.unit) || 0) * qty : paidCents(sale, i, lineReturnedQty(ln), qty) / 100;
  }
  function paidUnit(sale, ln) { return paidAmount(sale, ln, 1); }

  function saleCard(s, ret) {
    const c = saleClient(s);
    const sel = ret && ret.saleId === s.id ? ret.picks : new Set();
    const selVal = s.lines.reduce((t, l, i) => t + (sel.has(i) ? paidAmount(s, l, pickedQty(ret, i, l)) : 0), 0);
    const hasRet = s.lines.some((l) => lineReturnedQty(l) > 0);
    return `<div class="mz-sale">
      <div class="mz-sale-top">
        <span class="mz-sale-num">${s.id}</span>
        <!-- whenLabel et non fmtHM : la liste couvre la semaine, et « 14:32 »
             tout court ne dit pas si la vente est de ce matin ou de mardi. -->
        <span class="mz-sale-when">${whenLabel(s.at)} · par ${esc(s.by)}</span>
        <span class="mz-pill ${s.kind === 'echange' ? 'warn' : 'ok'}">${s.kind === 'echange' ? 'échange' : esc(s.methods)}</span>
        ${hasRet ? '<span class="mz-pill warn">retour</span>' : ''}
        ${s.kind === 'acompte' ? '<span class="mz-pill warn">Acompte · retour suspendu, contacter le responsable</span>' : ''}
        <span class="mz-sale-who"><i data-lucide="${c ? 'user' : 'users'}"></i>${c ? esc(c.name) : 'Cliente de passage'} · ${fmtMAD(s.total)}</span>
      </div>
      <div class="mz-sale-lines">
        ${s.lines.map((l, i) => {
          /* Le journal couvre la semaine : un article vendu mardi peut avoir été
             supprimé du catalogue depuis. Sans ce repli, P[l.pid] valait
             undefined et TOUTE la page des échanges se vidait — donc plus aucun
             retour possible, y compris sur les ventes intactes. Le nom du
             produit est retrouvé dans la ligne de vente quand il y est, sinon on
             le dit franchement ; le montant payé, lui, vient de la ligne et
             reste toujours juste. */
          const p = P[l.pid] || { name: l.name || 'Article retiré du catalogue', art: '' };
          const returnedQty = lineReturnedQty(l);
          const availableQty = lineAvailableQty(l);
          if (!availableQty) {
            return `<button class="mz-sline is-locked" data-mz-locked="1">
              <span class="tick"></span>
              <span class="mz-line-art">${artOf(p)}</span>
              <span class="mid"><span class="mz-line-name">${esc(p.name)}</span>
                <span class="mz-line-sub"><span class="sz">${esc(l.size)}</span> ${esc(l.note || 'retournée')}</span></span>
              <span class="mz-pill warn">retournée</span>
            </button>`;
          }
          const chosenQty = sel.has(i) ? pickedQty(ret, i, l) : 1;
          return `<button class="mz-sline ${sel.has(i) ? 'on' : ''}" data-mz-pick="${s.id}:${i}">
            <span class="tick"><i data-lucide="check"></i></span>
            <span class="mz-line-art">${artOf(p)}</span>
            <span class="mid"><span class="mz-line-name">${esc(p.name)}</span>
              <span class="mz-line-sub">
                ${colorDot(l.color)}
                <span class="sz">${esc(l.size)}</span> ${availableQty > 1 ? `× ${availableQty} disponibles` : ''} ${returnedQty ? `· ${returnedQty} déjà retournée${returnedQty > 1 ? 's' : ''}` : ''} ${l.remise ? `· remise −${l.remise} %` : ''}
              </span></span>
            <span class="amt">${fmtMAD(paidAmount(s, l, availableQty))}</span>
          </button>${sel.has(i) && availableQty > 1 ? `
            <div class="mz-ret-qty" style="display:flex;align-items:center;justify-content:flex-end;gap:10px;padding:7px 12px 10px;">
              <span style="font-size:12px;color:var(--ink-3);">Quantité à retourner</span>
              <button class="mz-chip" type="button" data-mz-ret-qty="${s.id}:${i}:-1" aria-label="Retirer une pièce">−</button>
              <b>${chosenQty}</b>
              <button class="mz-chip" type="button" data-mz-ret-qty="${s.id}:${i}:1" aria-label="Ajouter une pièce">+</button>
              <strong>${fmtMAD(paidAmount(s, l, chosenQty))}</strong>
            </div>` : ''}`;
        }).join('')}
      </div>
      ${sel.size ? `
      <div class="mz-ret-bar">
        <div class="mz-ret-bar-lbl">Motif du retour</div>
        <div class="mz-chips">
          ${MOTIFS.map((m) => `<button class="mz-chip ${ret.motif === m ? 'on' : ''}" data-mz-motif="${esc(m)}">${esc(m)}</button>`).join('')}
        </div>
        ${refundPreviewHTML(s, ret, selVal)}
        <div class="mz-ret-actions">
          <button class="mz-btn secondary" data-mz-do-exch><i data-lucide="arrow-left-right"></i>Échanger la pièce</button>
          <button class="mz-btn secondary" data-mz-do-refund ${state.retBusy ? 'disabled aria-busy="true"' : ''}><i data-lucide="credit-card"></i>Rembourser sur le moyen d’origine · ${fmtMAD(selVal)}</button>
          <button class="mz-btn primary" data-mz-do-avoir ${state.retBusy ? 'disabled aria-busy="true"' : ''}><i data-lucide="ticket"></i>${state.retBusy ? 'Émission en cours…' : `Émettre un avoir · ${fmtMAD(selVal)}`}</button>
        </div>
      </div>` : ''}
    </div>`;
  }

  /* ── CE QUE LE REMBOURSEMENT FERA, DIT AVANT L'ACCORD ──
     Depuis le 22 octobre, le serveur rend l'argent dans le moyen choisi, puis
     recrédite les avoirs qui avaient payé le ticket pour ce qui dépasse.
     L'ancien écran annonçait un seul versement (« 120 MAD · carte ») alors que
     le serveur pouvait écrire 80 carte + 40 sur l'avoir AV-… : la caissière
     rendait au mauvais endroit. L'aperçu applique maintenant la MÊME règle que
     le serveur (assets/refund-split.js) : l'argent du ticket tel que le serveur
     l'a reçu (originalSalePayload), ses avoirs par code, et ce que ce ticket a
     déjà rendu. Le reçu, lui, imprime ce que le serveur a réellement fait. */
  const PAYOUT_SRV = { 'carte': 'card', 'espèces': 'cash', 'virement': 'transfer', 'chèque': 'cheque' };
  const PAYOUT_FR = { card: 'carte', cash: 'espèces', transfer: 'virement', cheque: 'chèque' };
  const PAYOUT_LABEL = { 'carte': 'Rendu sur la carte', 'espèces': 'Rendu en espèces', 'virement': 'Rendu par virement', 'chèque': 'Rendu par chèque' };
  function refundPayout(sale) {
    const paid = (sale.parts || []).filter(part => part && part.m !== 'avoir' && part.m !== 'livraison');
    const preferred = ['carte', 'espèces', 'virement', 'chèque'].find(method => paid.some(part => part.m === method));
    return preferred || (String(sale.methods || '').includes('carte') ? 'carte' : 'espèces');
  }
  /* Allocations (serveur ou aperçu) → lignes de reçu de la caisse. */
  function refundRows(allocations) {
    return (allocations || []).filter(p => p && Number(p.amountCents) > 0).map(p => p.method === 'credit'
      ? { m: 'avoir', code: String(p.code || p.creditId || ''), amount: Number(p.amountCents) / 100 }
      : { m: PAYOUT_FR[p.method] || 'espèces', amount: Number(p.amountCents) / 100 });
  }
  function refundPreview(sale, amount) {
    const split = globalThis.KiwiRefundSplit;
    if (!split || !sale || !(amount > 0)) return null;
    const payout = refundPayout(sale);
    let moneyCents = 0;
    try { const payload = originalSalePayload(sale); moneyCents = payload ? Number(payload.amountCents) || 0 : 0; } catch (_) {}
    const plan = split.preview({
      moneyCents, credits: split.creditsFromParts(sale.parts), method: PAYOUT_SRV[payout],
      previousCents: Number(sale.refundedCents) || 0, amountCents: Math.round(amount * 100),
    });
    return { payout, plan, rows: refundRows(plan.allocations) };
  }
  function refundPreviewHTML(sale, ret, amount) {
    if (!ret || !ret.picks || sale.kind === 'acompte') return '';
    if (Array.from(ret.picks).some(i => sale.lines[i] && sale.lines[i].consigned)) return '';
    const pv = refundPreview(sale, amount);
    if (!pv) return '';
    const total = pv.rows.reduce((sum, r) => sum + r.amount, 0);
    return `<div class="mz-ret-bar-lbl" style="margin-top:11px;">En cas de remboursement</div>
        <div class="mz-pay-break" data-mz-refund-preview>
          ${pv.rows.map(r => `<div class="row"><span>${r.m === 'avoir' ? `<span>Recrédité sur l’avoir</span> ${esc(r.code)}` : `<span>${PAYOUT_LABEL[r.m] || 'Rendu en espèces'}</span>`}</span><b>${fmtMAD(r.amount)}</b></div>`).join('')}
          ${pv.plan.leftCents > 0 ? `<div class="row"><span>Déjà remboursé, refusé</span><b>${fmtMAD(pv.plan.leftCents / 100)}</b></div>` : ''}
          <div class="row"><span>Total remboursé</span><b>${fmtMAD(total)}</b></div>
        </div>`;
  }

  async function doRefund() {
    const ret = state.ret;
    if (!ret || state.retBusy) return;
    const sale = findSale(ret.saleId);
    if (!sale) return;
    /* Même garde que l'avoir et l'échange : un ticket d'acompte n'a encaissé
       qu'une partie de son prix, rendre ses lignes au prix plein rembourserait
       un solde que la cliente n'a pas versé. */
    if (sale.kind === 'acompte') { toast('Retour suspendu sur un acompte'); return; }
    const idxs = Array.from(ret.picks);
    const quantities = new Map(idxs.map((i) => [i, pickedQty(ret, i, sale.lines[i])]));
    const amount = idxs.reduce((sum, i) => sum + paidAmount(sale, sale.lines[i], quantities.get(i)), 0);
    if (!amount) return;
    const consignedSelected = idxs.some((i) => sale.lines[i] && sale.lines[i].consigned);
    if (consignedSelected) {
      toast('Remboursement original indisponible pour la catégorie B', 5200, 'warn', 'Émettez un avoir boutique pour les articles en dépôt-vente.');
      return;
    }
    const motif = ret.motif || 'Non précisé';
    const resellable = motif !== 'Défaut';
    state.retBusy = true; renderEchanges(); icons();
    let originalSaleId;
    try { originalSaleId = await ensureOriginalSale(sale); }
    catch (_) {
      state.retBusy = false; renderEchanges(); icons();
      toast('Remboursement suspendu', 5200, 'danger', 'La vente d’origine n’a pas pu être vérifiée. Rien n’a été remis en stock.');
      return;
    }
    const refundId = stableRefundId(sale, quantities, amount * 100);
    const preview = refundPreview(sale, amount);
    const payout = preview ? preview.payout : refundPayout(sale);
    const refundMethod = PAYOUT_SRV[payout];
    /* Le responsable accorde ce qui va se passer, pas un versement unique. */
    const planned = preview && preview.rows.length ? preview.rows : [{ m: payout, amount }];
    const said = planned.map(r => r.m === 'avoir' ? `avoir ${r.code} ${fmtMAD(r.amount)}` : `${r.m} ${fmtMAD(r.amount)}`).join(' + ');
    state.retBusy = false; renderEchanges(); icons();
    if (typeof window.requireManager !== 'function') {
      toast('Autorisation responsable indisponible', 5200, 'danger');
      return;
    }
    if (window.KiwiAuthAct) window.KiwiAuthAct({ kind: 'refund', key: 'act.refund', args: { amount: fmtMAD(amount) } });
    window.requireManager(`Remboursement ${fmtMAD(amount)} · ${said} · ticket ${sale.id}`, async (manager) => {
      state.retBusy = true; renderEchanges(); icons();
      try {
        let done = planned;
        if (!IS_DEMO) {
          const response = await fetch('/api/sale/refund', {
            method: 'POST', credentials: 'same-origin', headers: { 'Content-Type': 'application/json', Accept: 'application/json' },
            body: JSON.stringify({
              merchant: merchantSlug(), id: refundId, originalSaleId, amountCents: Math.round(amount * 100), refundMethod,
              ref: `REM-${sale.id}`, reason: motif, approval: manager && manager.approval,
            }),
          });
          let data = null; try { data = await response.json(); } catch (_) {}
          if (!response.ok || !data || data.error) {
            const error = new Error((data && data.error) || `http-${response.status}`);
            error.code = (data && data.error) || `http-${response.status}`; throw error;
          }
          /* Le reçu dit ce que le serveur a fait, au centime, même si une autre
             caisse avait déjà rendu une partie de ce ticket. */
          if (Array.isArray(data.allocations) && data.allocations.length) done = refundRows(data.allocations);
          if (done.some(r => r.m === 'avoir')) refreshRemoteAvoirs();
        }
        sale.refundedCents = (Number(sale.refundedCents) || 0) + Math.round(amount * 100);
        if (resellable) restoreLines(sale, idxs, quantities, `remboursement (${motif.toLowerCase()})`);
        else markDamagedLines(sale, idxs, quantities, `retour non revendable (${motif.toLowerCase()})`);
        recordReturn(sale, idxs, amount, motif, resellable ? 'refund' : 'refund-damaged', refundId, quantities);
        state.ret = null; refreshOps();
        printReceiptNow({
          ref: `REM-${sale.id}`, title: 'Remboursement', amount,
          lines: idxs.map((i) => ({ qty: quantities.get(i), name: sale.lines[i].name || (P[sale.lines[i].pid] && P[sale.lines[i].pid].name) || 'Article', amount: paidAmount(sale, sale.lines[i], quantities.get(i)), ref: sale.lines[i].pid })),
          customer: saleClient(sale) ? { name: saleClient(sale).name, phone: saleClient(sale).phone } : null,
        }, done);
        toast('Remboursement enregistré', 4200, 'success', `${fmtMAD(amount)} · accord ${manager && manager.name ? manager.name : 'responsable'}`);
      } catch (error) {
        const detail = error && error.code === 'refund-exceeds-sale'
          ? 'Le montant disponible sur cette vente a déjà été remboursé.'
          : 'Le registre financier a refusé l’opération. Rien n’a été remis en stock.';
        toast('Remboursement non effectué', 5200, 'danger', detail);
      } finally {
        state.retBusy = false; renderEchanges(); icons();
      }
    }, { kind: 'refund', refundId, originalSaleId, amountCents: Math.round(amount * 100), refundMethod });
  }

  function togglePick(key) {
    const [saleId, idxS] = key.split(':');
    if (findSale(saleId)?.kind === 'acompte') {
      toast('Retour suspendu : cette vente a plusieurs reçus d’acompte. Contacter le responsable.'); return;
    }
    const idx = +idxS;
    /* Pas de motif par défaut. Le champ démarrait sur « Taille » : une vendeuse
       qui ne touchait aucune puce classait quand même le retour en problème de
       taille — et c'est exactement la statistique que la patronne lit dans le
       registre des retours pour décider quoi racheter. Tant que personne n'a
       choisi, le registre dit « Non précisé ». */
    if (!state.ret || state.ret.saleId !== saleId) state.ret = { saleId, picks: new Set(), quantities: new Map(), motif: null };
    const picks = state.ret.picks;
    if (picks.has(idx)) { picks.delete(idx); state.ret.quantities.delete(idx); }
    else { picks.add(idx); state.ret.quantities.set(idx, 1); }
    if (!picks.size) state.ret = null;
    renderEchanges(); icons();
  }

  function doExchange() {
    const ret = state.ret;
    if (!ret) return;
    if (ret.picks.size !== 1) { toast('L\'échange se fait pièce par pièce, gardez une seule ligne cochée'); return; }
    const idx = ret.picks.values().next().value;
    const sale = findSale(ret.saleId);
    if (sale?.kind === 'acompte') { toast('Retour suspendu sur un acompte'); return; }
    const ln = sale.lines[idx];
    const qty = pickedQty(ret, idx, ln);
    if (qty !== 1) { toast('L\'échange se fait une pièce à la fois, choisissez la quantité 1'); return; }
    /* Le motif choisi sur la fiche de retour suit l'échange jusqu'au registre :
       sans lui, tout échange y était classé « Echange », c'est-à-dire rien —
       la colonne motif répétait la colonne type et le registre ne disait plus
       pourquoi la pièce était revenue. */
    state.exchange = { saleId: ret.saleId, idx, qty: 1, motif: ret.motif || '' };
    state.ret = null;
    switchView('vente');
    toast(`Échange ${sale.id}, choisissez l'article de remplacement dans la grille`);
  }

  async function doAvoir() {
    const ret = state.ret;
    if (!ret || state.retBusy) return;
    const sale = findSale(ret.saleId);
    if (sale?.kind === 'acompte') { toast('Retour suspendu sur un acompte'); return; }
    if (!sale) return;
    const idxs = Array.from(ret.picks);
    const quantities = new Map(idxs.map((i) => [i, pickedQty(ret, i, sale.lines[i])]));
    const amount = idxs.reduce((t, i) => t + paidAmount(sale, sale.lines[i], quantities.get(i)), 0);
    if (!amount) return;
    /* `ret.motif` vaut null tant qu'aucune puce n'a été choisie : on l'écrit tel
       quel plutôt que d'inventer un motif que personne n'a donné. */
    const motif = ret.motif || 'Non précisé';
    const c = saleClient(sale);
    const resellable = motif !== 'Défaut';
    state.retBusy = true;
    renderEchanges(); icons();
    try {
      /* The credit is booked before stock or the local sale changes.  A lost
         connection therefore leaves the return untouched, not a free item in
         stock with no liability recorded. */
      const originalSaleId = sale.serverId || sale.syncId || sale.id;
      const av = await issueAvoir(amount, c, `${motif}, retour ${sale.id}`, originalSaleId, {
        requestId: stableCreditIssueId(sale, quantities, amount * 100),
        originalRef: sale.num || sale.id, resellable, originalSale: sale,
        lines: idxs.map((i) => ({
          itemId: sale.lines[i].pid, variantId: sale.lines[i].variantId || '',
          name: (P[sale.lines[i].pid] && P[sale.lines[i].pid].name) || sale.lines[i].name || 'Article',
          size: sale.lines[i].size || '', qty: quantities.get(i), unitCents: Math.round(paidUnit(sale, sale.lines[i]) * 100), amountCents: Math.round(paidAmount(sale, sale.lines[i], quantities.get(i)) * 100),
        })),
      });
      if (resellable) restoreLines(sale, idxs, quantities, `avoir (${motif.toLowerCase()})`);
      else markDamagedLines(sale, idxs, quantities, `retour abîmé (${motif.toLowerCase()})`);
      recordReturn(sale, idxs, amount, motif, resellable ? 'avoir' : 'avoir-damaged', av.code, quantities);
      /* L'argent rendu en avoir sort de la dépense et des points de la cliente ;
         l'avoir dépensé plus tard y rentrera, une seule fois. Clé = le code de
         l'avoir : un double clic ne reprend pas deux fois (même geste que la
         caisse boutique). */
      if (c && useKiwiCl() && window.KiwiClients && window.KiwiClients.recordRefund) {
        try {
          window.KiwiClients.recordRefund(c.id, { amount, saleRef: sale.id, eventRef: av.code,
            items: idxs.map((i) => ({ name: (P[sale.lines[i].pid] && P[sale.lines[i].pid].name) || sale.lines[i].name || 'Article', qty: Number(quantities.get(i)) || 1, id: sale.lines[i].pid || '' })) });
        } catch (_) {}
      } else if (c && !useKiwiCl()) {
        c.spent = Math.max(0, (Number(c.spent) || 0) - amount);
      }
      state.ret = null;
      refreshOps();
      openVoucher(av, { mode: 'fresh' });
    } catch (error) {
      toast('Avoir non émis', 5200, 'danger', creditErrorDetail(error));
    } finally {
      state.retBusy = false;
      if (state.ret) { renderEchanges(); icons(); }
    }
  }

  function restoreLines(sale, idxs, quantities, note) {
    idxs.forEach((i) => {
      const ln = sale.lines[i];
      const qty = Math.min(lineAvailableQty(ln), Number(quantities.get(i)) || 0);
      if (!qty) return;
      markLineReturned(ln, qty, note);
      /* Une pièce rendue retourne au dépareillé ; le catalogue ne rebouge que
         si le retour reconstitue un set entier. */
      const back = releaseStock(ln.pid, ln.size, qty, ln.isPiece);
      persistStock(ln.pid, ln.size, ln.color, back, { ref: sale.num || sale.id, why: 'retour' });
    });
    persistDay();  // le retour change la recette du jour, pas seulement l'affichage
  }

  function markDamagedLines(sale, idxs, quantities, note) {
    idxs.forEach((i) => {
      const ln = sale.lines[i];
      const qty = Math.min(lineAvailableQty(ln), Number(quantities.get(i)) || 0);
      if (!qty) return;
      const afterReturned = lineReturnedQty(ln) + qty;
      markLineReturned(ln, qty, note);
      /* Non revendable does not mean physically absent. Keep it out of the
         sellable catalogue, but put the returned unit in a dedicated damaged
         location in the durable movement ledger. The deterministic id makes a
         retry harmless. */
      try {
        window.KiwiInventory?.add?.({
          id: `damaged-${String(sale.serverId || sale.syncId || sale.id).replace(/[^A-Za-z0-9._-]/g, '').slice(0, 40)}-${i}-${afterReturned}`,
          itemId: ln.pid, variantId: ln.variantId || '', locationId: 'damaged', qty,
          reason: 'sale-reversal', refType: 'damaged-return', refId: sale.num || sale.id,
          note: note || 'Retour non revendable', actor: (window.KiwiStaff && window.KiwiStaff.name) || 'Caisse',
          meta: { stockStatus: 'damaged', resellable: false },
        });
      } catch (_) {}
    });
    /* The unit physically came back but is not sellable.  The sale remains
       reduced while catalogue stock stays unchanged; the return audit carries
       resellable=false through the server credit event. */
    persistDay();
  }

  /* ---------- voucher print preview (modeled on the pressing tags) ------- */
  // Real boutique identity from the pairing / hosted session — the printed credit
  // note (BON D'AVOIR) shows the real store name+city, never the demo "Maison
  // Mansour" / its street address. Local demo (unpaired) unchanged.
  function bqPaired() { try { return window.KiwiPlatform?.pairedVenue?.() || JSON.parse(localStorage.getItem('kiwiPairedVenue') || 'null'); } catch (_) { return null; } }
  function bqReal()   { try { return !!(window.KiwiEnv && window.KiwiEnv.isReal && window.KiwiEnv.isReal()) || !!window.KiwiPlatform?.isPaired?.() || !!bqPaired(); } catch (_) { return !!bqPaired(); } }
  function bqName(demo) { const p = bqPaired(); return (p && p.name) || (bqReal() ? '' : demo); }
  function bqCity(demo) { const p = bqPaired(); return (p && p.location) || (bqReal() ? '' : demo); }

  function voucherHTML(av) {
    return `<div class="mz-avoir">
      <div class="c b lg">${esc((bqName('Maison Mansour') || 'Boutique').toUpperCase())}</div>
      <div class="c mut">${bqReal() ? (bqCity('') ? esc(bqCity('')) + ' · ' : '') + 'propulsé par Kiwi' : '12 rue Aïn Harrouda, Maarif, Casablanca<br>05 22 25 XX XX · propulsé par Kiwi'}</div>
      <hr>
      <div class="c b">BON D'AVOIR</div>
      <div class="mz-avoir-amt">${fmtMAD(av.balance)}</div>
      ${av.balance !== av.amount ? `<div class="c mut">émis pour ${fmtMAD(av.amount)}, solde restant</div>` : ''}
      <hr>
      <div class="row"><span>Code</span><span class="b">${av.code}</span></div>
      <div class="row"><span>Cliente</span><span>${esc(av.holderName)}</span></div>
      <div class="row"><span>Motif</span><span>${esc(av.motif)}</span></div>
      ${av.from ? `<div class="row"><span>Vente d'origine</span><span>${esc(av.from)}</span></div>` : ''}
      <div class="row"><span>Émis le</span><span>${fmtDayY(av.at)}</span></div>
      <div class="row b"><span>VALABLE JUSQU'AU</span><span>${fmtValidUntil(av.until)}</span></div>
      <hr>
      <div class="c">${window.KiwiBarcode && window.KiwiBarcode.svg ? window.KiwiBarcode.svg(av.code, { format: 'code128', height: 40, showText: false }) : barcode(av.code + '-MM', 26)}</div>
      <div class="mz-avoir-code">${av.code} · ${esc((bqName('Maison Mansour') || 'Boutique').toUpperCase())}</div>
      <div class="c mut" style="margin-top:6px;">Utilisable en caisse, en une ou plusieurs fois.<br>Ni repris, ni remboursé en espèces.</div>
    </div>`;
  }

  function openVoucher(av, ctx) {
    if (!av) return;
    const fresh = ctx && ctx.mode === 'fresh';
    const el = $('#mz-avoirmm', root);
    el.innerHTML = `
      <button class="mz-modal-x" data-mz-close aria-label="Fermer"><i data-lucide="x"></i></button>
      <h3 class="modal-title">${fresh ? `Avoir émis, ${av.code}` : `Avoir ${av.code}`}</h3>
      <p class="modal-subtle">${esc(av.holderName)} · ${fmtMAD(av.balance)} ${av.balance > 0 ? 'disponibles' : 'consommé'}</p>
      ${voucherHTML(av)}
      <div class="mz-avoir-note"><i data-lucide="shield-check"></i>Le code-barres revient en caisse comme moyen de paiement, il se déduit tout seul à l'encaissement.</div>
      <div class="mz-sheet-foot">
        <button class="mz-btn secondary" id="mz-av-print"><i data-lucide="printer"></i>Imprimer l'avoir</button>
        <button class="mz-btn primary" data-mz-close><i data-lucide="check"></i>${fresh ? 'Terminer' : 'Fermer'}</button>
      </div>`;
    openVeil('#mz-avoir-veil');
    icons();
    $$('[data-mz-close]', el).forEach((b) => { b.onclick = () => closeVeil('#mz-avoir-veil'); });
    $('#mz-av-print', el).onclick = () => {
      /* Le même papier que le reçu (thermique, file durable), plus l'impression
         système qui le transformait en PDF. Code-barres Code 128 scannable. */
      const K = window.KiwiReceipt;
      if (!K || !K.printVoucher) { toast('Impression indisponible sur cet appareil'); return; }
      toast('Impression de l’avoir…');
      K.printVoucher({ code: av.code, amount: av.amount, balance: av.balance, holderName: av.holderName,
        motif: av.motif, from: av.from, at: av.at, until: av.until, untilText: fmtValidUntil(av.until) }).then(
        (r) => toast(!r || !r.ok ? 'Impression échouée'
          : r.queued ? 'Avoir envoyé à l’imprimante'
          : r.thermalFailed ? 'Imprimante injoignable · avoir ouvert dans l’impression système'
          : r.via === 'pdf' || r.via === 'browser' ? 'Avoir ouvert dans l’impression système' : 'Avoir imprimé'),
        () => toast('Impression échouée'));
    };
  }

  /* ---------- exchange summary ---------- */
  function openExchSummary(newPid, newSize, newColor) {
    const ex = state.exchange;
    if (!ex) return;
    const sale = findSale(ex.saleId);
    const ln = sale.lines[ex.idx];
    /* L'article RENDU peut ne plus être au catalogue (le journal couvre la
       semaine) ; celui qui le remplace vient forcément de la grille, donc il y
       est. Le prix du retour se lit sur la ligne de vente — le montant payé —
       et pas sur la fiche produit, qui a pu changer de prix depuis. */
    const oldP = P[ln.pid] || { name: ln.name || 'Article retiré du catalogue', art: '' };
    const newP = P[newPid];
    if (!newP) { toast('Article de remplacement introuvable'); return; }
    /* Review gap R5 · a piece return takes a piece replacement (same format,
     * same loose-aware stock, same per-kind promo conversion) — never a set.
     * The return side stays the frozen amount actually paid (ln.unit). */
    const newIsPiece = !!ln.isPiece;
    const newEff = lineDeal({ pid: newPid, isPiece: newIsPiece, customPrice: newIsPiece ? pieceUnitPrice(newP) : undefined }).price;
    const diff = Math.round((newEff - paidUnit(sale, ln)) * 100) / 100;
    const c = saleClient(sale);
    const el = $('#mz-exchm', root);
    el.innerHTML = `
      <button class="mz-modal-x" data-mz-close aria-label="Fermer"><i data-lucide="x"></i></button>
      <h3 class="modal-title">Échange, ${sale.id}</h3>
      <p class="modal-subtle">${c ? esc(c.name) : 'Cliente de passage'} · la pièce rendue repart en stock</p>
      <div class="mz-exch-row is-ret">
        <span class="mz-line-art">${artOf(oldP)}</span>
        <span class="mid"><b>${esc(oldP.name)}</b><span>retour · ${esc(ln.size)} · ${colorDot(ln.color)} ${esc(colorLabel(ln.color))}${ln.remise ? ` · payé avec −${ln.remise} %` : ''}</span></span>
        <span class="amt">−${fmtMAD(paidUnit(sale, ln))}</span>
      </div>
      <div class="mz-exch-row is-new">
        <span class="mz-line-art">${artOf(newP)}</span>
        <span class="mid"><b>${esc(newP.name)}</b><span>remplacement · ${esc(newSize)}${newIsPiece ? ' · à la pièce' : ''} · ${colorDot(newColor)} ${esc(colorLabel(newColor))}</span></span>
        <span class="amt">+${fmtMAD(newEff)}</span>
      </div>
      <div class="mz-exch-diff ${diff > 0 ? 'pos' : diff < 0 ? 'neg' : 'zero'}">
        <span>${diff > 0 ? 'Différence à encaisser' : diff < 0 ? 'Différence en faveur de la cliente, part en avoir' : 'Aucun écart, échange direct'}</span>
        <span class="amt">${diff === 0 ? '0 MAD' : fmtMAD(Math.abs(diff))}</span>
      </div>
      <div class="mz-sheet-foot">
        <button class="mz-btn secondary" data-mz-close>Retour</button>
        ${diff > 0
          ? `<button class="mz-btn primary" id="mz-exch-go"><i data-lucide="banknote"></i>Encaisser ${fmtMAD(diff)}</button>`
          : diff < 0
            ? `<button class="mz-btn primary" id="mz-exch-go"><i data-lucide="ticket"></i>Échanger + avoir ${fmtMAD(-diff)}</button>`
            : `<button class="mz-btn primary" id="mz-exch-go"><i data-lucide="check"></i>Confirmer l'échange</button>`}
      </div>`;
    openVeil('#mz-exch-veil');
    icons();
    $$('[data-mz-close]', el).forEach((b) => { b.onclick = () => closeVeil('#mz-exch-veil'); });

    let applied = false;
    const apply = () => {
      if (applied) return true;
      /* Take the replacement FIRST (piece-aware), abort untouched on miss. */
      const held = holdStock(newPid, newSize, 1, newIsPiece);
      if (held === false) {
        toast(`${newP.name} · ${newSize}, stock insuffisant pour l'échange`);
        return false;
      }
      applied = true;
      const back = releaseStock(ln.pid, ln.size, 1, ln.isPiece);
      // Commit the swap to the shared inventory: rendered piece back in, replacement out.
      /* Un échange est DEUX mouvements, jamais un seul : la pièce rendue rentre,
         la pièce emportée sort, et le registre le raconte dans les deux sens. */
      persistStock(ln.pid, ln.size, ln.color, back, { ref: sale.num || sale.id, why: 'retour' });
      persistStock(newPid, newSize, newColor, -held, { ref: sale.num || sale.id, why: 'vente' });
      state.exchange = null;
      persistDay();
      queueIfOffline(`Échange ${sale.id}`);
      renderExchNote(); renderGrid(); renderBadges();
      return true;
    };

    $('#mz-exch-go', el).onclick = async () => {
      /* Pre-check before any money moves (piece-aware like the take). */
      if (!canHoldStock(newPid, newSize, 1, newIsPiece)) {
        toast(`${newP.name} · ${newSize}, stock insuffisant pour l'échange`);
        return;
      }
      if (diff > 0) {
        const go = $('#mz-exch-go', el);
        if (go) go.disabled = true;
        nextStandaloneTicketNumber().then((exchangeNumber) => {
          closeVeil('#mz-exch-veil');
          openPay({
            amount: diff,
            customerId: sale.clientId || null,
            title: 'Différence échange',
            subtitle: `${sale.id} · ${esc(oldP.name)} → ${esc(newP.name)}`,
            ref: exchangeNumber,
            lines: [{
              qty: 1,
              name: `Différence échange · ${oldP.name} → ${newP.name}`,
              amount: diff,
              ref: newPid,
              barcode: newP.barcode || '',
            }],
            subtotal: diff,
            doneLabel: 'Terminer',
            waName: c ? firstName(c.name) : null, waPhone: c ? c.phone : null,
            onPaid: (parts) => {
              const swapped = apply();
              /* The paid path kills the old line too, like every return. */
              if (swapped) {
                markLineReturned(ln, 1, `échange ${sale.id}`);
                recordReturn(sale, [ex.idx], paidUnit(sale, ln), `Échange ${sale.id}`, 'echange', exchangeNumber);
              }
              const rec = {
                id: exchangeNumber, syncId: newSaleId(), tenderVersion: 2, at: new Date(), clientId: sale.clientId, by: STAFF.caissiere.name, kind: 'echange',
                methods: parts.map((x) => x.m).join(' + '),
                parts: parts.map((x) => ({ m: x.m, amount: Math.round((+x.amount || 0) * 100) / 100 })),
                lines: swapped ? [{ pid: newPid, size: newSize, color: newColor, qty: 1, remise: 0, unit: diff, isPiece: newIsPiece, returned: false, note: `différence échange ${sale.id}` }] : [],
                total: diff,
                note: swapped ? '' : 'échange non appliqué (rupture entre-temps), différence encaissée à régulariser',
              };
              SALES.unshift(rec);
              persistDay();
              bqSaveProvisional();
              try {
                if (window.KiwiLive && window.KiwiLive.isOn()) {
                  const pm = (parts || []).map((x) => x.m);
                  const isDelivery = pm.indexOf('livraison') >= 0;
                  const method = bqPaymentMethod(parts);
                  const cashIn = (parts || []).reduce((s, x) => s + (x.m === 'avoir' || x.m === 'livraison' ? 0 : (+x.amount || 0)), 0);
                  bqPost(rec, {
                    id: rec.syncId,
                    amount: cashIn,
                    method,
                    paymentParts: bqPaymentParts(parts), ticketAmountCents: Math.round(diff * 100),
                    ...(cashIn <= 0 ? { settlementKind: isDelivery ? 'receivable' : 'store-credit',
                      creditAmountCents: Math.round((parts || []).filter(x => x.m === 'avoir').reduce((sum, x) => sum + (+x.amount || 0), 0) * 100) } : {}),
                    channel: isDelivery ? 'delivery' : 'counter',
                    label: `Différence échange ${sale.id}`,
                    ref: rec.id,
                    time: rec.at,
                    lines: swapped ? [{ name: newP.name + (newSize ? ' ' + newSize : ''), qty: 1, total: diff, cat: rayonOf(newPid) || '' }] : [],
                  });
                }
              } catch (_) {}
              $('#mz-today', root).textContent = headSubVente();
              refreshOps();
              if (!swapped) toast('Échange non appliqué (rupture entre-temps)', 5200, 'danger', 'La différence est encaissée et tracée : régularisez l’échange manuellement.');
              return { ref: rec.id, sale: rec, line: swapped ? `Échange ${sale.id} réglé, différence ${fmtMAD(diff)}` : `Différence ${sale.id} encaissée sans échange, à régulariser` };
            },
          });
        }).catch(() => {
          if (go) go.disabled = false;
          toast('Numéro de ticket indisponible', 5200, 'danger', 'Reconnectez cette caisse pour réserver sa prochaine série.');
        });
      } else if (diff < 0) {
        const quantities = new Map([[ex.idx, 1]]);
        const originalSaleId = sale.serverId || sale.syncId || sale.id;
        const go = $('#mz-exch-go', el);
        if (go) go.disabled = true;
        try {
          /* Book the liability first. If the network or server refuses, the old
             item and both stock positions remain untouched. The deterministic
             request id makes a lost response safe to retry. */
          const av = await issueAvoir(-diff, c, `Différence échange ${sale.id}`, originalSaleId, {
            requestId: stableCreditIssueId(sale, quantities, -diff * 100),
            originalRef: sale.num || sale.id, originalSale: sale,
            resellable: true,
            lines: [{
              itemId: ln.pid, variantId: ln.variantId || '',
              name: oldP.name || 'Article', size: ln.size || '', qty: 1,
              unitCents: Math.round(paidUnit(sale, ln) * 100),
            }],
          });
          closeVeil('#mz-exch-veil');
          if (!apply()) {
            toast('Avoir émis, échange à régulariser', 5200, 'warn', `${av.code} existe mais le remplacement est devenu indisponible.`);
            refreshOps();
            openVoucher(av, { mode: 'fresh' });
            return;
          }
          markLineReturned(ln, 1, `échange ${sale.id}`);
          persistDay();
          recordReturn(sale, [ex.idx], paidUnit(sale, ln), `Échange ${sale.id}`, 'echange', av.code);
          refreshOps();
          openVoucher(av, { mode: 'fresh' });
        } catch (error) {
          if (go) go.disabled = false;
          toast('Avoir non émis', 5200, 'danger', creditErrorDetail(error));
        }
      } else {
        closeVeil('#mz-exch-veil');
        if (!apply()) { refreshOps(); return; }
        markLineReturned(ln, 1, `échange ${sale.id}`);
        recordReturn(sale, [ex.idx], paidUnit(sale, ln), `Échange ${sale.id}`, 'echange', '');
        persistDay();
        refreshOps();
        toast(`Échange ${sale.id}, ${oldP.name} ${ln.size} contre ${newP.name} ${newSize}`);
      }
    };
  }

  /* ═══════════════════════ ENCAISSEMENT ═══════════════════════ */
  /* File d'impression durable : le comptoir garde le ticket jusqu'à ce qu'une
     imprimante le prenne. Rien ici n'invente une file — on réutilise celle du
     poste (KiwiKitchenPrint), la même qui sert déjà avant l'appel direct. */
  function requeueReceipt(opts, doc) {
    const queue = window.KiwiKitchenPrint;
    if (!opts || !opts.sale || !queue || typeof queue.enqueueReceipt !== 'function') return false;
    try {
      const queued = queue.enqueueReceipt('maison:' + opts.sale.id + ':retry', doc, 'original');
      return !!(queued && (queued.accepted || queued.pending));
    } catch (_) { return false; }
  }

  function printReceiptNow(opts, parts, printOpts) {
    printOpts = printOpts || {};
    const isGift = !!printOpts.gift;
    const KP = window.KiwiPrinter;
    const pv = pvPaired();
    const shopName = (pv && pv.name) || 'Vogue Home';
    const lines = (opts.lines || []).map((l) => ({
      qty: l.qty,
      name: l.name + (l.marque ? ' · ' + l.marque : '') + (l.motif ? ' (' + l.motif + ')' : ''),
      price: isGift ? '' : fmtMAD(l.amount),
      total: isGift ? null : l.amount,
      ref: l.ref,
      barcode: l.barcode,
    }));

    if (isGift) {
      // Impression Ticket Cadeau sans montants ni prix
      const giftDoc = {
        shop: shopName + ' · Ticket Cadeau',
        ref: opts.ref || '',
        date: fmtDT(new Date()),
        lines: lines,
        total: '',
        method: '',
        gift: true,
        note: 'Ticket Cadeau / Bon d’échange · Valable 30 jours pour échange ou avoir sur présentation de ce ticket.'
      };
      if (KP && KP.isConnected && KP.isConnected()) {
        toast('Impression du ticket cadeau…');
        /* Une promesse tenue n'est pas une impression réussie : `printReceipt`
           résout aussi sur `{ok:false}`. On lit le résultat. */
        KP.printReceipt(giftDoc).then(
          (r) => toast(r && r.ok === false
            ? ('Échec impression ticket cadeau : ' + ((r && r.reason) || 'inconnu'))
            : 'Ticket cadeau imprimé'),
          (e) => toast('Échec impression ticket cadeau : ' + ((e && e.message) || 'erreur'))
        );
        return;
      }
      if (KP && KP.browserReceipt) {
        KP.browserReceipt(giftDoc);
        toast('Ticket cadeau affiché');
        return;
      }
      const giftHtml = `
        <div style="font-family:monospace; max-width:300px; margin:20px auto; padding:16px; border:1px solid #000; text-align:center;">
          <h3 style="margin:0;">${esc(shopName)}</h3>
          <div style="font-size:12px; margin:4px 0;">TANGER · ART DE TABLE & DÉCORATION</div>
          <div style="font-size:13px; font-weight:bold; margin:10px 0; border-top:1px dashed #000; border-bottom:1px dashed #000; padding:6px 0;">
            *** TICKET CADEAU ***<br>BON D'ÉCHANGE
          </div>
          <div style="text-align:left; font-size:11px; margin-bottom:10px;">
            Ticket: ${esc(opts.ref)}<br>
            Date: ${fmtDT(new Date())}<br>
            Conseiller: ${esc((STAFF && STAFF.caissiere && STAFF.caissiere.name) || 'Caisse')}<br>
            ${opts.customer ? `Cliente: ${esc(opts.customer.name)}<br>` : ''}
          </div>
          <table style="width:100%; border-collapse:collapse; font-size:11px; text-align:left; margin-bottom:12px;">
            <thead>
              <tr style="border-bottom:1px solid #000;"><th>Qté</th><th>Article / Marque</th></tr>
            </thead>
            <tbody>
              ${lines.map((l) => `<tr><td style="padding:4px 0; vertical-align:top; font-weight:bold;">${l.qty || 1}×</td><td style="padding:4px 0;">${esc(l.name)}</td></tr>`).join('')}
            </tbody>
          </table>
          <div style="font-size:10.5px; border-top:1px dashed #000; padding-top:8px; line-height:1.4;">
            Échangeable sous 30 jours dans notre boutique sur présentation de ce bon.<br>
            Articles non utilisés et dans leur emballage d'origine.
          </div>
          <div style="margin-top:12px;">
            ${barcode(opts.ref || 'GIFT', 24)}
          </div>
        </div>`;
      const gw = window.open('', '_blank', 'width=360,height=500');
      if (gw) {
        gw.document.write(`<!DOCTYPE html><html><head><title>Ticket Cadeau - ${esc(opts.ref)}</title></head><body>${giftHtml}<script>window.onload=function(){window.print();};<\/script></body></html>`);
        gw.document.close();
      }
      return;
    }

    if (!KP || !KP.printReceipt) { toast('Impression indisponible sur cet appareil'); return; }

    const K = window.KiwiReceipt;
    if (K) {
      const doc = K.build({
        ref: opts.ref || '',
        ts: (opts.sale && opts.sale.at) || Date.now(),
        cashier: (STAFF && STAFF.caissiere && STAFF.caissiere.name) || '',
        lines: (opts.lines || []).map((l) => ({ qty: l.qty, name: l.name, total: l.amount, ref: l.ref, barcode: l.barcode })),
        subtotal: opts.subtotal,
        promo: opts.promo || null,
        discount: opts.discount,
        total: opts.amount,
        acompte: opts.acompte || null,
        customer: opts.customer || null,
        pay: (parts || []).map((x) => ({ label: x.m === 'avoir' ? ('Avoir ' + (x.code || '')) : x.m, amount: x.amount })),
        received: (function () {
          const c = (parts || []).find((x) => x.m === 'espèces' && x.rendu > 0);
          return c ? (+c.amount || 0) + (+c.rendu || 0) : null;
        })(),
        change: (parts || []).reduce((r, x) => r || x.rendu || 0, 0) || null,
      });
      try {
        if (opts.sale) { opts.sale.rc = K.snapshot(doc); persistDay(); }
      } catch (_) {}
      const queue = window.KiwiKitchenPrint;
      if (opts.sale && queue && typeof queue.enqueueReceipt === 'function') {
        try {
          const queued = queue.enqueueReceipt('maison:' + opts.sale.id, doc, 'original');
          if (queued && (queued.accepted || queued.pending)) return;
        } catch (_) {}
      }
      toast('Impression du reçu…');
      Promise.resolve(K.print(doc)).then(
        (r) => {
          /* Le thermique a échoué et seul le repli navigateur est sorti : on le
             dit, et on remet le ticket en file pour un vrai réessai — sinon la
             vendeuse croit le reçu imprimé et la cliente repart sans rien. */
          if (r && r.thermalFailed) {
            const retried = requeueReceipt(opts, doc);
            toast('Imprimante thermique injoignable', null, 'warn',
              (retried ? 'Reçu remis en file d\'impression. ' : '') + 'Sortie de secours par l\'imprimante système.');
            return;
          }
          toast(r && r.ok
            ? (r.via === 'pdf' ? 'Reçu prêt · imprimer ou partager le PDF' : r.via === 'browser' ? 'Reçu ouvert dans l\'impression système' : ('Reçu imprimé · ' + (r.via === 'bluetooth' ? 'Bluetooth' : r.via === 'usb' ? 'USB' : 'réseau')))
            : 'Impression échouée');
        },
        () => { requeueReceipt(opts, doc); toast('Impression échouée'); }
      );
      return;
    }

    const label = { 'carte': 'Carte', 'avoir': 'Avoir', 'espèces': 'Espèces', 'virement': 'Virement / Versement', 'chèque': 'Chèque', 'livraison': 'Livraison · à recevoir' };
    const doc = {
      shop: shopName,
      ref: opts.ref || '',
      date: fmtDT(new Date()),
      lines: lines.length ? lines : [{ name: opts.title || 'Vente', price: fmtMAD(opts.amount) }],
      total: fmtMAD(opts.amount),
      method: (parts || []).map((x) => label[x.m] || x.m).join(' + '),
    };

    if (!KP.isConnected || !KP.isConnected()) {
      const cfg = (KP.getConfig && KP.getConfig()) || {};
      if (cfg.browserFallback && KP.browserReceipt) { KP.browserReceipt(doc); return; }
      toast('Aucune imprimante connectée');
      try {
        KP.openSetup(KP.browserReceipt ? {
          kind: 'receipt',
          onBrowserPrint: () => {
            try { KP.setConfig({ browserFallback: true }); } catch (_) {}
            KP.browserReceipt(doc);
          },
        } : {});
      } catch (_) {}
      return;
    }
    toast('Impression du reçu…');
    KP.printReceipt(doc).then(
      (r) => toast(r && r.ok
        ? ('Reçu imprimé · ' + (r.via === 'bluetooth' ? 'Bluetooth' : r.via === 'usb' ? 'USB' : 'réseau'))
        : ('Impression échouée : ' + ((r && r.reason) || 'inconnu'))),
      (e) => toast('Impression échouée : ' + ((e && e.message) || 'erreur'))
    );
  }

  /* ── UNE VENTE, PLUSIEURS RÈGLEMENTS ──────────────────────────────────────
     « La moitié en espèces, la moitié en carte » n'est pas deux ventes : c'est
     une vente à deux règlements. La caisse ne savait faire qu'un seul mode par
     vente (l'avoir excepté), et la caissière devait donc encaisser deux tickets
     — deux numéros, deux lignes dans le journal, un panier moyen faux et un
     tiroir qui ne tombe jamais juste.

     `settled` porte ce qui est déjà réglé ; `share` la part que le prochain
     mode prendra. Le reste retourne à l'écran des modes tant qu'il n'est pas
     couvert, ce qui donne gratuitement les partages à trois. */
  function renderAcomptes() {
    const panel = $('[data-mz-panel="acomptes"]', root);
    const R = window.KiwiRetailBalances;
    if (!R) { panel.textContent = 'Registre des acomptes indisponible'; return; }
    void R.render(panel, {
      merchant: merchantSlug(), prefix: 'mz',
      customerName: id => (clById(id) || {}).name || id,
      customerIdForName: query => (clientList().find(c => c.name.toLowerCase().includes(query.toLowerCase())) || {}).id,
      onSelect: payExistingBalance,
    });
  }
  function openPay(opts) {
    const el = $('#mz-paym', root);
    const ownAvoirs = () => opts.customerId
      ? activeAvoirs().filter((a) => a.holderId === opts.customerId) : [];
    let avoirPart = null;                   /* { m:'avoir', amount, code } */
    const settled = [];                     /* les règlements déjà posés */
    let committed = false;                  /* double tap must never book twice */
    const creditCommitId = creditIntent('credit-redeem');
    const appliedAvoirCodes = () => {
      const codes = [];
      if (avoirPart) codes.push(avoirPart.code);
      for (const p of settled) if (p.m === 'avoir' && p.code) codes.push(p.code);
      return codes;
    };
    const remainingAvoirs = () => {
      const used = new Set(appliedAvoirCodes());
      return ownAvoirs().filter((a) => !used.has(a.code));
    };
    let share = 1;                          /* 1 = tout le reste ; 0.5 = la moitié */
    let custom = 0;                          /* un montant saisi à la main */
    const r2 = (n) => Math.round((+n || 0) * 100) / 100;
    const paid = () => settled.reduce((s, p) => s + (+p.amount || 0), 0);
    const due = () => r2(opts.amount - (avoirPart ? avoirPart.amount : 0) - paid());
    /* Ce que prend le prochain mode. Jamais plus que le reste : une part de 50 %
       sur un reste de 3 MAD ne doit pas produire un règlement de 1,50 MAD qu'on
       n'a pas les pièces pour rendre — mais surtout jamais PLUS que dû. */
    const portion = () => {
      if (custom > 0) return Math.min(custom, due());
      if (share >= 1) return due();
      return Math.min(due(), Math.max(0.01, r2(due() * share)));
    };
    const closeBtns = () => $$('[data-mz-close]', el).forEach((b) => {
      b.onclick = () => {
        /* Once one payment part is confirmed, closing would forget money already
           received (especially a card charge) while leaving the cart unpaid.
           Finish the remaining balance; the success screen can close normally. */
        if (!committed && (settled.length || avoirPart)) {
          toast('Paiement commencé', `Il reste ${fmtMAD(due())} à régler avant de fermer.`);
          return;
        }
        closeVeil('#mz-pay-veil');
      };
    });

    const mLabel = (m) => (m === 'espèces' ? 'Espèces' : m === 'carte' ? 'Carte' : m === 'virement' ? 'Virement / Versement' : m === 'chèque' ? 'Chèque' : m === 'livraison' ? 'Livraison' : m === 'avoir' ? 'Avoir' : m);

    const appliedBanner = () => {
      const rows = [];
      if (avoirPart) rows.push(`<i data-lucide="ticket"></i> Avoir <b>${avoirPart.code}</b> appliqué, −${fmtMAD(avoirPart.amount)}`);
      settled.forEach((p) => rows.push(`<i data-lucide="check"></i> ${mLabel(p.m)} <b>${fmtMAD(p.amount)}</b> réglé`));
      return rows.map((r) => `<div class="mz-pay-applied">${r}</div>`).join('');
    };

    /* Le partage. Volontairement à quatre touches et pas un clavier de plus :
       au comptoir, « la moitié » est le cas qui revient, et tout le reste se
       saisit au montant. */
    const splitBar = () => `
      <div class="mz-split" role="group" aria-label="Partager le paiement">
        <span class="mz-split-l">Partager</span>
        <button class="mz-split-c${share >= 1 && !custom ? ' is-on' : ''}" data-mz-share="1">Tout</button>
        <button class="mz-split-c${share === 0.5 && !custom ? ' is-on' : ''}" data-mz-share="0.5">50 %</button>
        <button class="mz-split-c${share === 0.25 && !custom ? ' is-on' : ''}" data-mz-share="0.25">25 %</button>
        <button class="mz-split-c${custom ? ' is-on' : ''}" data-mz-share="x">Montant…</button>
        <input class="mz-split-in mono" id="mz-split-in" type="number" inputmode="decimal" min="0" step="1"
               placeholder="MAD" value="${custom || ''}" ${custom ? '' : 'hidden'} aria-label="Montant de cette part" />
      </div>
      <p class="mz-split-note"${portion() < due() ? '' : ' hidden'}>Cette part : ${fmtMAD(portion())} · restera ${fmtMAD(r2(due() - portion()))}</p>`;

    const stepMethods = () => {
      const avs = ownAvoirs();
      const remAvoirs = remainingAvoirs();
      el.innerHTML = `
        <button class="mz-modal-x" data-mz-close aria-label="Fermer"><i data-lucide="x"></i></button>
        <h3 class="modal-title">${esc(opts.title)}</h3>
        <p class="modal-subtle">${settled.length ? `Reste à régler sur ${fmtMAD(opts.amount)}` : opts.subtitle}</p>
        <div class="modal-amount size-md">${fmtMAD(due())}</div>
        ${appliedBanner()}
        ${due() > 0.01 ? splitBar() : ''}
        ${settled.length === 1 && due() > 0.009 && opts.customerId
          && ['espèces','carte','virement','chèque'].includes(settled[0].m)
          ? `<button class="mz-btn secondary" id="mz-save-acompte">Acompte reçu · garder ${fmtMAD(due())} à régler</button>` : ''}
        <div class="mz-pay-opts">
          <button class="mz-pay-opt" data-mz-m="especes">
            <span class="ic"><i data-lucide="banknote"></i></span>
            <span class="l"><b>Espèces</b><span>Rendu calculé, flous comptés une fois</span></span>
            <span class="amt">${fmtMAD(portion())}</span>
          </button>
          <button class="mz-pay-opt" data-mz-m="carte">
            <span class="ic"><i data-lucide="credit-card"></i></span>
            <span class="l"><b>Carte</b><span>Lecteur partenaire, paiement sur votre terminal</span></span>
            <span class="amt">${fmtMAD(portion())}</span>
          </button>
          <button class="mz-pay-opt" data-mz-m="virement">
            <span class="ic"><img src="assets/icons/material/account_balance.svg" alt=""></span>
            <span class="l"><b>Virement / Versement</b><span>Confirmer uniquement après réception en banque</span></span>
            <span class="amt">${fmtMAD(portion())}</span>
          </button>
          <button class="mz-pay-opt" data-mz-m="cheque">
            <span class="ic"><img src="assets/icons/material/receipt_long.svg" alt=""></span>
            <span class="l"><b>Chèque</b><span>Confirmer après réception du chèque</span></span>
            <span class="amt">${fmtMAD(portion())}</span>
          </button>
          <button class="mz-pay-opt" data-mz-m="livraison">
            <span class="ic"><i data-lucide="truck"></i></span>
            <span class="l"><b>Livraison</b><span>Vente enregistrée, paiement à recevoir du transporteur</span></span>
            <span class="amt">${fmtMAD(portion())}</span>
          </button>
          ${remAvoirs.length ? `
          <button class="mz-pay-opt" data-mz-m="avoir">
            <span class="ic"><i data-lucide="ticket"></i></span>
            <span class="l"><b>Avoir</b><span>${remAvoirs.length === 1 && !avoirPart ? `${remAvoirs[0].code} · ${fmtMAD(remAvoirs[0].balance)}, ${esc(remAvoirs[0].holderName)}` : `${remAvoirs.length} bon${remAvoirs.length > 1 ? 's' : ''} disponible${remAvoirs.length > 1 ? 's' : ''}, scanner ou choisir`}</span></span>
            <span class="amt">−${fmtMAD(Math.min(remAvoirs[0].balance, portion()))}</span>
          </button>` : `
          <button class="mz-pay-opt" data-mz-m="avoir">
            <span class="ic"><i data-lucide="ticket"></i></span>
            <span class="l"><b>Code d’avoir</b><span>${avs.length ? 'Tous les bons de cette cliente sont déjà posés · scanner ou saisir un autre code' : 'Scanner ou saisir le code du bon'}</span></span>
          </button>`}
        </div>`;
      icons(); closeBtns();
      const saveAcompte = $('#mz-save-acompte', el);
      if (saveAcompte) saveAcompte.onclick = () => { void commit(true); };
      const inp = $('#mz-split-in', el);
      $$('[data-mz-share]', el).forEach((b) => {
        b.onclick = () => {
          const v = b.dataset.mzShare;
          if (v === 'x') {
            /* On ne re-rend pas : le champ apparaît sous la main de la caissière
               et prend le curseur. Un re-rendu le lui reprendrait. */
            if (inp) { inp.hidden = false; inp.focus(); inp.select(); }
            return;
          }
          custom = 0; share = +v || 1; stepMethods();
        };
      });
      if (inp) {
        inp.oninput = () => {
          custom = Math.max(0, Math.min(due(), r2(inp.value)));
          /* La pastille suit la saisie. On ne re-rend pas la barre (le champ
             perdrait le curseur en pleine frappe), donc on déplace le marqueur
             à la main — sans quoi « Tout » reste allumé sur une part de 100 MAD. */
          $$('[data-mz-share]', el).forEach((b) => {
            b.classList.toggle('is-on', custom > 0 ? b.dataset.mzShare === 'x' : b.dataset.mzShare === String(share));
          });
          const note = $('.mz-split-note', el);
          if (note) {
            note.hidden = !(portion() < due());
            note.textContent = `Cette part : ${fmtMAD(portion())} · restera ${fmtMAD(r2(due() - portion()))}`;
          }
          /* L'avoir se déduit du total, mais jamais plus que la part choisie :
             sa ligne suit donc la saisie comme les autres, en gardant son signe
             et son plafond propre (le solde du bon). */
          $$('[data-mz-m]', el).forEach((b) => {
            const a = $('.amt', b); if (!a) return;
            if (/^avoir/.test(b.dataset.mzM)) {
              const bal = (remainingAvoirs()[0] || {}).balance;
              if (bal != null) a.textContent = '−' + fmtMAD(Math.min(bal, portion()));
              return;
            }
            a.textContent = fmtMAD(portion());
          });
        };
      }
      $$('[data-mz-m]', el).forEach((b) => {
        b.onclick = () => {
          const m = b.dataset.mzM;
          if (m === 'especes') stepCash(portion());
          else if (m === 'carte') stepCard(portion());
          else if (m === 'virement' || m === 'cheque') stepExternal(m, portion());
          else if (m === 'livraison') {
            /* La fiche destinataire est obligatoire, comme en boutique ; la livraison
               fragile saisie sur le ticket la préremplit et en reçoit le résultat. */
            const amount = portion(), t = state.ticket || {};
            mzDeliveryCard(el, { amount, esc, fmtMAD, icons, closeBtns, prev: (settled.find((p) => p.card) || {}).card,
              ticket: t.delivery || { reinforcedWrap: (t.lines || []).some((l) => l.fragile || (P[l.pid] && P[l.pid].fragile)) }, client: opts.customerId ? clById(opts.customerId) : null, back: stepMethods,
              done: (card, fragile) => {
                if (state.ticket && !opts.balanceExisting) state.ticket.delivery = Object.assign({}, t.delivery || {}, { name: card.name, phone: card.phone, city: card.city, address: card.address, quartier: '' }, fragile);
                settle({ m: 'livraison', amount, card });
              } });
          }
          else if (m === 'avoir') stepAvoir();
          else toast('Aucun avoir actif, émettez-en un depuis Échanges & avoirs');
        };
      });
    };

    /* Un règlement de plus est posé. Tant qu'il reste quelque chose à payer on
       revient aux modes — c'est ce retour, et rien d'autre, qui rend possibles
       les partages à trois ou quatre. */
    const settle = (part) => {
      settled.push(part);
      share = 1; custom = 0;
      if (opts.balanceExisting) void commit(due() > 0.009);
      else if (due() > 0.009) { toast(`Reste ${fmtMAD(due())} à régler`); stepMethods(); }
      else commit();
    };

    const stepAvoir = () => {
      const avs = remainingAvoirs();
      el.innerHTML = `
        <button class="mz-modal-x" data-mz-close aria-label="Fermer"><i data-lucide="x"></i></button>
        <h3 class="modal-title">Avoir en paiement</h3>
        <p class="modal-subtle">Scannez le bon, ou choisissez-le, il se déduit du total</p>
        <form id="mz-av-code-form" style="display:flex;gap:8px;margin:12px 0;">
          <input class="sk-input mono" id="mz-av-code" autocomplete="off" autocapitalize="characters" placeholder="Scanner ou saisir AV-…" aria-label="Code de l’avoir" style="flex:1;min-width:0;" />
          <button class="mz-btn secondary" type="submit">Utiliser</button>
        </form>
        <div class="mz-pay-opts">
          ${avs.map((a) => `
            <button class="mz-pay-opt" data-mz-av-use="${a.code}">
              <span class="ic"><i data-lucide="scan-line"></i></span>
              <span class="l"><b>${a.code} · ${fmtMAD(a.balance)}</b><span>${esc(a.holderName)} · ${esc(a.motif)} · valable jusqu'au ${fmtValidUntil(a.until)}</span></span>
              <span class="amt">−${fmtMAD(Math.min(a.balance, portion()))}</span>
            </button>`).join('')}
        </div>
        <div class="mz-sheet-foot"><button class="mz-btn secondary" id="mz-av-back" style="flex:1;">Retour</button></div>`;
      icons(); closeBtns();
      $('#mz-av-back', el).onclick = stepMethods;
      const applyCode = async (rawCode) => {
        const code = String(rawCode || '').trim().toUpperCase();
        if (!code) return;
        let av = AVOIRS.find((item) => String(item.code).toUpperCase() === code);
        if (!av && !IS_DEMO) {
          try {
            const data = await creditRequest(null, '&code=' + encodeURIComponent(code));
            const row = data.credits && data.credits[0];
            if (row) {
              av = creditFromServer(row);
              const old = AVOIRS.findIndex((item) => item.code === av.code);
              if (old >= 0) AVOIRS.splice(old, 1, av); else AVOIRS.unshift(av);
              persistAvoirs();
            }
          } catch (_) {}
        }
        if (!av || !activeAvoirs().includes(av)) {
          toast('Bon indisponible', 'Code introuvable, expiré ou déjà consommé.');
          return;
        }
        const applied = Math.min(av.balance, portion());
        if (avoirPart) settled.push({ m: 'avoir', amount: avoirPart.amount, code: avoirPart.code });
        avoirPart = { m: 'avoir', amount: applied, code: av.code };
        share = 1; custom = 0;
        if (due() <= 0.009) void commit();
        else { toast(`${av.code} appliqué, reste ${fmtMAD(due())} à payer`); stepMethods(); }
      };
      $('#mz-av-code-form', el).onsubmit = (event) => {
        event.preventDefault();
        void applyCode($('#mz-av-code', el).value);
      };
      $('#mz-av-code', el).focus();
      $$('[data-mz-av-use]', el).forEach((b) => {
        b.onclick = () => { void applyCode(b.dataset.mzAvUse); };
      });
    };

    const stepCash = (amount) => {
      amount = amount > 0 ? amount : due();
      const rest = r2(due() - amount);
      let received = amount;
      el.innerHTML = `
        <button class="mz-modal-x" data-mz-close aria-label="Fermer"><i data-lucide="x"></i></button>
        <h3 class="modal-title">Espèces · ${fmtMAD(amount)}</h3>
        <p class="modal-subtle">${rest > 0.009 ? `Part sur ${fmtMAD(due())} · restera ${fmtMAD(rest)}` : opts.subtitle}</p>
        ${appliedBanner()}
        <div class="cash-grid">
          <div class="cash-input-row">
            <label class="cash-input-label" for="mz-cash-in">Espèces reçues</label>
            <input class="cash-input mono" id="mz-cash-in" type="number" inputmode="numeric" min="0" step="1" value="${amount}" />
          </div>
          <div class="cash-presets" aria-label="Ajout rapide">
            <button class="cash-preset" data-add="20">+20</button>
            <button class="cash-preset" data-add="50">+50</button>
            <button class="cash-preset" data-add="100">+100</button>
            <button class="cash-preset" data-add="200">+200</button>
          </div>
          <div class="cash-rendu"><span class="lbl">Rendu</span><span class="val mono" id="mz-cash-rendu">0 MAD</span></div>
          <button class="cash-confirm" id="mz-cash-ok">Confirmer</button>
        </div>`;
      icons(); closeBtns();
      const refresh = () => {
        $('#mz-cash-rendu', el).textContent = fmtMAD(Math.max(0, received - amount));
        $('#mz-cash-ok', el).disabled = received < amount;
      };
      $('#mz-cash-in', el).oninput = (e) => { received = +e.target.value || 0; refresh(); };
      $$('[data-add]', el).forEach((b) => {
        b.onclick = () => { received += +b.dataset.add; $('#mz-cash-in', el).value = received; refresh(); };
      });
      refresh();
      $('#mz-cash-ok', el).onclick = () => {
        settle({ m: 'espèces', amount, rendu: Math.max(0, received - amount) });
      };
    };

    const stepCard = (amount) => {
      amount = amount > 0 ? amount : due();
      const rest = r2(due() - amount);
      el.innerHTML = `
        <button class="mz-modal-x" data-mz-close aria-label="Fermer"><i data-lucide="x"></i></button>
        <h3 class="modal-title">Carte · ${fmtMAD(amount)}</h3>
        <p class="modal-subtle">${rest > 0.009 ? `Part sur ${fmtMAD(due())} · restera ${fmtMAD(rest)}` : opts.subtitle} · Kiwi affiche, le lecteur encaisse</p>
        <div class="reader-stage">
          <div class="reader-disc is-pulsing" id="mz-reader-disc"><i data-lucide="credit-card"></i></div>
          <div class="reader-status" id="mz-reader-status">Montant envoyé au lecteur<span class="ellipsis"></span></div>
          <div class="reader-method">Lecteur partenaire, paiement sur votre terminal</div>
        </div>
        <div class="mz-card-confirm" id="mz-card-confirm" hidden>
          <button class="cash-confirm" id="mz-card-ok"><i data-lucide="check"></i> Encaissement confirmé sur le lecteur</button>
          <button class="mz-btn ghost" id="mz-card-cancel">Paiement refusé · annuler</button>
        </div>`;
      icons(); closeBtns();
      /* On simule l'aller au lecteur, puis — contrairement à avant — on n'encaisse
         PAS tout seul : la caissière confirme d'un geste que le lecteur a approuvé.
         AVANT, l'encaissement carte partait d'un minuteur de ~2,8 s ; fermer l'écran
         carte pendant l'animation (réflexe normal, le vrai paiement se fait sur le
         lecteur partenaire) perdait TOUTE la vente et ses points fidélité — d'où
         « en carte la cliente ne gagne pas de points ». La confirmation explicite
         enregistre la vente de façon fiable, exactement comme les espèces. */
      setTimeout(() => {
        const disc = $('#mz-reader-disc', el);
        if (!disc || !el.closest('.modal-veil').classList.contains('is-open')) return;
        disc.classList.remove('is-pulsing');
        disc.classList.add('is-success');
        disc.innerHTML = '<i data-lucide="check"></i>';
        $('#mz-reader-status', el).textContent = 'Confirmez l\'encaissement sur le lecteur';
        $('#mz-reader-status', el).classList.add('is-success');
        const cw = $('#mz-card-confirm', el);
        if (cw) cw.hidden = false;
        icons();
        const ok = $('#mz-card-ok', el);
        if (ok) ok.onclick = () => settle({ m: 'carte', amount });
        const cancel = $('#mz-card-cancel', el);
        if (cancel) cancel.onclick = () => {
          if (settled.length || avoirPart) stepMethods();
          else closeVeil('#mz-pay-veil');
        };
      }, 1400);
    };

    const stepExternal = (method, amount) => {
      const cheque = method === 'cheque';
      const label = cheque ? 'Chèque' : 'Virement / Versement';
      el.innerHTML = `
        <button class="mz-modal-x" data-mz-close aria-label="Fermer">×</button>
        <h3 class="modal-title">${label} · ${fmtMAD(amount)}</h3>
        <p class="modal-subtle">${cheque ? 'Le chèque a-t-il été remis au comptoir ?' : 'Les fonds sont-ils visibles sur le compte bancaire ?'} Aucun montant ne sera attendu dans le tiroir.</p>
        <div class="mz-sheet-foot">
          <button class="mz-btn secondary" id="mz-external-back">Retour</button>
          <button class="cash-confirm" id="mz-external-ok">${cheque ? 'Chèque reçu' : 'Versement reçu'} · confirmer</button>
        </div>`;
      closeBtns();
      $('#mz-external-back', el).onclick = stepMethods;
      $('#mz-external-ok', el).onclick = () => settle({ m: cheque ? 'chèque' : 'virement', amount });
    };

    const commit = async (partial) => {
      if (committed) return;
      if (partial && (!opts.customerId || settled.length !== 1 || avoirPart
          || !['espèces','carte','virement','chèque'].includes(settled[0].m))) {
        toast('Acompte : une cliente et un seul règlement sont requis'); return;
      }
      const parts = (avoirPart ? [avoirPart] : []).concat(settled);
      const paidNow = Math.round(parts.reduce((sum, part) => sum + (+part.amount || 0), 0) * 100) / 100;
      for (const part of parts) {
        if (part.m !== 'avoir') continue;
        const av = AVOIRS.find((a) => a.code === part.code);
        if (!av || avoirExpired(av) || !(av.balance >= part.amount)) {
          toast(`Avoir ${part.code} inutilisable`, !av ? 'Bon introuvable en caisse.' : avoirExpired(av) ? 'Bon expiré entre-temps.' : 'Solde insuffisant, montants recalculés.');
          return;
        }
      }
      committed = true;
      if (opts.beforePaid && !await opts.beforePaid()) { committed = false; return; }
      const creditParts = parts.filter((part) => part.m === 'avoir');
      try {
        let remote = null;
        if (!IS_DEMO && creditParts.length) {
          /* All vouchers are consumed by ONE server statement.  Either every
             balance is still valid or none changes; a second caisse cannot
             spend the same code between local validation and checkout. */
          remote = await creditRequest({
            action: 'redeem-batch', id: creditCommitId,
            saleId: opts.sale && opts.sale.id,
            detail: opts.title || 'Vente Maison',
            credits: creditParts.map((part) => ({ code: part.code, amountCents: Math.round(part.amount * 100) })),
          });
        }
        const remoteByCode = new Map(((remote && remote.credits) || []).map((row) => [row.code, creditFromServer(row)]));
        for (const part of creditParts) {
          const av = AVOIRS.find((a) => a.code === part.code);
          if (!av) continue;
          const saved = remoteByCode.get(part.code);
          av.balance = saved ? saved.balance : Math.max(0, av.balance - part.amount);
          av.status = saved ? saved.status : (av.balance > 0 ? 'active' : 'consumed');
          toast(av.balance > 0 ? `${av.code}, reste ${fmtMAD(av.balance)} dessus` : `${av.code} consommé en totalité`);
        }
        persistAvoirs();
      } catch (error) {
        committed = false;
        await refreshRemoteAvoirs();
        toast('Avoir refusé par le registre', 'Le solde a changé, le bon a expiré ou une autre caisse vient de l’utiliser. Aucun encaissement n’a été enregistré.');
        stepMethods();
        return;
      }
      const res = opts.onPaid(parts, { partial: !!partial, paidNow }) || {};
      if (res.error) { committed = false; stepMethods(); return; }
      if (res.sale) opts.sale = res.sale;
      if (partial || opts.balanceExisting) {
        opts.acompte = { total: opts.balanceTotal || opts.amount,
          paid: (opts.balancePaid || 0) + paidNow,
          remaining: Math.max(0, (opts.balanceTotal || opts.amount) - (opts.balancePaid || 0) - paidNow) };
        opts.amount = paidNow;
        opts.title = partial ? 'Acompte' : 'Solde de l’acompte';
      }
      if (res.delivery || parts.some((x) => x.m === 'livraison')) stepSuccess(parts, res);
      else { closeVeil('#mz-pay-veil'); printReceiptNow(opts, parts); }
    };

    const stepSuccess = (parts, res) => {
      const cash = parts.find((x) => x.m === 'espèces');
      const delivery = parts.some((x) => x.m === 'livraison') || (opts.sale && !!opts.sale.delivery);
      el.innerHTML = `
        <button class="mz-modal-x" data-mz-close aria-label="Fermer"><i data-lucide="x"></i></button>
        <h3 class="modal-title">${delivery ? 'Livraison enregistrée' : "C'est encaissé"}</h3>
        <p class="modal-subtle">${res.line ? esc(res.line) : esc(opts.title)}</p>
        ${cash && cash.rendu > 0 ? `
          <div class="cash-success-rendu">${fmtMAD(cash.rendu)}</div>
          <div class="cash-success-label">rendu à la cliente</div>` : `
          <div class="modal-amount size-md">${fmtMAD(opts.amount)}</div>`}
        <div class="mz-pay-break">
          ${parts.map((x) => `<div class="row"><span>${x.m === 'avoir' ? `Avoir ${x.code}` : x.m === 'carte' ? 'Carte, lecteur partenaire' : x.m === 'livraison' ? 'Livraison · à recevoir' : mLabel(x.m)}</span><b>${fmtMAD(x.amount)}</b></div>`).join('')}
        </div>
        <div class="modal-actions is-visible">
          <button class="ma-btn secondary" id="mz-pay-print"><i data-lucide="printer"></i>Reçu 80 mm</button>
          <button class="ma-btn secondary" id="mz-pay-gift"><i data-lucide="gift"></i>Ticket Cadeau</button>
          ${delivery ? '<button class="ma-btn secondary" id="mz-pay-del-note"><i data-lucide="truck"></i>Bon Livraison</button>' : ''}
          <button class="ma-btn secondary" id="mz-pay-wa"><i data-lucide="message-circle"></i>Reçu WhatsApp</button>
        </div>
        <div class="modal-actions is-visible" style="margin-top:10px;">
          <button class="ma-btn primary" id="mz-pay-done"><i data-lucide="check"></i>${esc(opts.doneLabel || 'Nouvelle vente')}</button>
        </div>`;
      icons(); closeBtns();
      $('#mz-pay-print', el).onclick = () => printReceiptNow(opts, parts);
      $('#mz-pay-gift', el).onclick = () => printReceiptNow(opts, parts, { gift: true });
      const delNoteBtn = $('#mz-pay-del-note', el);
      if (delNoteBtn) delNoteBtn.onclick = () => printDeliveryNoteNow(opts, parts);
      $('#mz-pay-wa', el).onclick = () => {
        if (!opts.waPhone) { toast('Cliente de passage, pas de numéro WhatsApp sur le ticket'); return; }
        const pv = pvPaired();
        const body = [
          (pv && pv.name) || 'Vogue Home',
          opts.ref ? ('Reçu ' + opts.ref) : 'Reçu',
          '',
          ...(opts.lines || []).map((l) => `${l.qty ? l.qty + '× ' : ''}${l.name} · ${fmtMAD(l.amount)}`),
          '',
          `TOTAL ${fmtMAD(opts.amount)}`,
          (parts || []).map((x) => x.m === 'avoir' ? 'Avoir' : x.m === 'livraison' ? 'Livraison · à recevoir' : mLabel(x.m)).join(' + '),
          '',
          'Merci !',
        ].filter((x) => x !== undefined).join('\n');
        const num = String(opts.waPhone).replace(/\D/g, '');
        try {
          window.open('https://wa.me/' + num + '?text=' + encodeURIComponent(body), '_blank', 'noopener');
          toast(`WhatsApp ouvert pour ${opts.waName || 'la cliente'}, appuyez sur envoyer`);
        } catch (_) { toast('Impossible d\'ouvrir WhatsApp'); }
      };
      $('#mz-pay-done', el).onclick = () => closeVeil('#mz-pay-veil');
    };

    stepMethods();
    openVeil('#mz-pay-veil');
  }

  /* ═══════════════════════ OFFLINE + VRAIE FILE SERVEUR ══════════════════ */
  function syncNetworkState(snapshot) {
    try {
      const q = snapshot || (window.KiwiLive && window.KiwiLive.queueStatus && window.KiwiLive.queueStatus());
      if (q) {
        state.queued = +q.pending || 0;
        state.syncStorageError = !!q.storageError;
        state.syncBlocked = state.syncStorageError || (+q.blocked || 0) > 0;
      }
    } catch (_) {}
    const browserOffline = typeof navigator !== 'undefined' && navigator.onLine === false;
    state.offline = !!state.simulatedOffline || browserOffline;
    if (root) renderNet();
  }

  function toggleOffline() {
    if (!IS_DEMO) {
      syncNetworkState();
      toast(state.syncBlocked ? 'Synchronisation bloquée, contactez le support'
        : state.offline ? 'Wi-Fi indisponible, les ventes restent sur cette caisse'
          : state.queued ? `${state.queued} vente${state.queued > 1 ? 's' : ''} en cours de synchronisation`
            : 'Caisse en ligne, toutes les ventes sont synchronisées');
      return;
    }
    state.simulatedOffline = !state.simulatedOffline;
    syncNetworkState();
    toast(state.offline ? 'Mode hors-ligne simulé, la boutique continue' : 'Réseau simulé rétabli');
  }
  function renderNet() {
    const net = $('#mz-net', root);
    if (!net) return;
    net.classList.toggle('is-off', state.offline || state.syncBlocked);
    $('.mz-net-label', net).textContent = state.syncBlocked ? 'Sync bloquée' : state.offline ? 'Hors-ligne' : state.queued ? 'Synchronisation' : 'En ligne';
    let q = $('.mz-net-queue', net);
    if (state.queued) {
      if (!q) { q = document.createElement('b'); q.className = 'mz-net-queue'; net.appendChild(q); }
      q.textContent = state.queued;
    } else if (q) q.remove();
    const note = $('#mz-offline-note', root);
    if (!note) return;
    note.hidden = !state.offline && !state.syncBlocked;
    if (state.syncBlocked) {
      note.innerHTML = 'La synchronisation est bloquée. Les ventes restent sur cette caisse : contactez le support avant de vider les données du navigateur. <b id="mz-queue-count"></b>';
    } else {
      note.innerHTML = 'Hors-ligne, les ventes sont enregistrées sur la tablette et synchronisées au retour du réseau. <b id="mz-queue-count"></b>';
    }
    const count = $('#mz-queue-count', root);
    if (count) count.textContent = state.queued ? `${state.queued} en attente` : '';
  }

  /* ═══════════════════════ register ═══════════════════════ */
  /* ═══════════════════════════════════════════════════════════════════════════
   * INVENTAIRE — the caisse is for operational stock and barcode work only.
   * Catalogue ownership (product names, prices, categories and variants) stays
   * in the dashboard so the team has one controlled source of truth. The caisse
   * can still receive/adjust stock and register or print existing labels.
   * ─────────────────────────────────────────────────────────────────────────── */
  const catDB = () => window.KiwiBoutiqueCatalog;
  const fmtNum = (n) => globalThis.KiwiMoney.format(n || 0);

  function injectInvCss() {
    if (document.getElementById('mzi-css')) return;
    const st = document.createElement('style');
    st.id = 'mzi-css';
    st.textContent = `
      .bqi { height: 100%; overflow-y: auto; padding-bottom: 40px; }
      .mzi-tools { display: flex; gap: 12px; align-items: center; padding: 14px 22px 6px; }
      .mzi-scan { flex: 1; display: flex; align-items: center; gap: 10px; background: var(--paper); border: 1.5px solid var(--atlas); border-radius: 14px; padding: 12px 16px; }
      .mzi-scan svg { width: 20px; height: 20px; color: var(--atlas); }
      .mzi-scan input { flex: 1; border: none; background: transparent; outline: none; font: inherit; font-size: 15px; color: var(--ink); }
      .mzi-pills { display: flex; gap: 8px; flex-wrap: wrap; padding: 6px 22px; }
      .mzi-pill { border: 1px solid rgba(10,15,13,.14); background: var(--paper); border-radius: 999px; padding: 6px 13px; font-size: 12.5px; cursor: pointer; color: var(--ink); }
      .mzi-pill.on { background: var(--atlas); color: #fff; border-color: var(--atlas); }
      .mzi-kpis { display: flex; gap: 10px; padding: 6px 22px 10px; }
      .mzi-kpi { flex: 1; background: var(--paper); border: 1px solid rgba(10,15,13,.08); border-radius: 12px; padding: 10px 14px; display: flex; flex-direction: column; gap: 2px; }
      .mzi-kpi .l { font-size: 10px; letter-spacing: .06em; text-transform: uppercase; color: #77807b; }
      .mzi-kpi .v { font-size: 18px; font-weight: 600; font-family: var(--mono); }
      .mzi-kpi.warn { border-color: #E7B24D; background: #FBF3E2; }
      .mzi-list { padding: 4px 22px; display: flex; flex-direction: column; gap: 8px; }
      .mzi-row { display: flex; align-items: center; gap: 14px; background: var(--paper); border: 1px solid rgba(10,15,13,.08); border-radius: 14px; padding: 12px 16px; cursor: pointer; transition: border-color .15s; }
      .mzi-row:hover { border-color: var(--atlas); }
      .mzi-art { width: 40px; height: 40px; flex: 0 0 40px; color: var(--riad); }
      .mzi-art svg, .mzi-art img { width: 40px; height: 40px; }
      .mzi-info { flex: 1; min-width: 0; display: flex; flex-direction: column; gap: 2px; }
      .mzi-info b { font-size: 14.5px; }
      .mzi-info span { font-size: 12px; color: #77807b; }
      .mzi-stock { font-family: var(--mono); font-size: 15px; font-weight: 600; min-width: 34px; text-align: right; }
      .mzi-stock.bas { color: #B8860B; } .mzi-stock.rupture { color: #9B2F22; }
      .mzi-price { font-family: var(--mono); font-size: 14px; min-width: 90px; text-align: right; }
      .mzi-mini { width: 34px; height: 34px; border-radius: 9px; border: 1px solid rgba(10,15,13,.14); background: var(--paper); cursor: pointer; color: var(--ink); display: inline-flex; align-items: center; justify-content: center; }
      .mzi-mini:hover { background: #f0eee7; } .mzi-mini svg { width: 16px; height: 16px; }
      .mzi-mini.danger { color: #9B2F22; }
      .mz-invm { width: min(720px, 94vw); max-height: 88vh; overflow-y: auto; padding: 0; }
      .mzi-modh { display: flex; align-items: center; gap: 14px; padding: 22px 24px 14px; border-bottom: 1px solid rgba(10,15,13,.08); }
      .mzi-modh h3 { margin: 0; font-size: 18px; } .mzi-modh > div { flex: 1; } .mzi-modh > div span { font-size: 12.5px; color: #77807b; }
      .mzi-vtable-wrap { padding: 8px 24px; }
      .mzi-vtable { width: 100%; border-collapse: collapse; font-size: 13px; }
      .mzi-vtable th { text-align: left; font-size: 10px; letter-spacing: .05em; text-transform: uppercase; color: #77807b; padding: 8px 6px; }
      .mzi-vtable td { padding: 9px 6px; border-top: 1px solid rgba(10,15,13,.07); vertical-align: middle; }
      .mzi-dot { display: inline-block; width: 13px; height: 13px; border-radius: 50%; border: 1px solid rgba(0,0,0,.18); vertical-align: -1px; margin-right: 6px; }
      .mzi-stk { display: inline-flex; align-items: center; gap: 5px; }
      .mzi-stk input { width: 46px; text-align: center; font-family: var(--mono); font-size: 14px; padding: 5px; border: 1px solid rgba(10,15,13,.16); border-radius: 8px; background: var(--paper); color: var(--ink); }
      .mzi-stk button { width: 28px; height: 28px; border-radius: 8px; border: 1px solid rgba(10,15,13,.16); background: var(--paper); cursor: pointer; font-size: 17px; line-height: 1; color: var(--ink); }
      .mzi-bc { display: flex; align-items: center; gap: 8px; }
      .mzi-code { font-family: var(--mono); font-size: 11px; color: #555; display: flex; flex-direction: column; }
      .mzi-code em { font-style: normal; font-size: 8.5px; letter-spacing: .04em; text-transform: uppercase; font-weight: 700; }
      .mzi-code em.gen { color: #0B6E4F; } .mzi-code em.imp { color: #8A6210; }
      .mzi-nocode { color: #99a; font-size: 12px; }
      .mzi-vact { display: flex; gap: 5px; justify-content: flex-end; }
      .mzi-modfoot { display: flex; gap: 8px; padding: 14px 24px 22px; flex-wrap: wrap; }
      .mzi-modfoot .mz-btn.danger { color: #9B2F22; }

      /* Douchette · diagnostic */
      .mz-scan-diag { display: inline-flex; align-items: center; gap: 8px; margin: 12px auto 0; padding: 9px 15px; background: transparent; border: 1px solid var(--n-200, #e7e3da); border-radius: 11px; font: inherit; font-size: 13px; color: var(--n-600, #5d6b63); cursor: pointer; }
      .mz-scan-diag:hover { border-color: var(--atlas); color: var(--atlas); }
      .mz-scan-diag svg { width: 15px; height: 15px; }
      .bqsd { padding: 4px 24px 0; }
      .bqsd-wait { display: flex; align-items: center; gap: 10px; padding: 26px 18px; color: var(--n-500, #7c8a80); background: var(--paper); border-radius: 14px; }
      .bqsd-wait svg { width: 20px; height: 20px; }
      .bqsd-v { padding: 13px 15px; border-radius: 12px; line-height: 1.5; font-size: 14px; }
      .bqsd-v.good { background: rgba(11,110,79,.07); color: var(--riad, #053B2C); }
      .bqsd-v.warn { background: rgba(184,124,32,.09); color: #7a5310; }
      .bqsd-v.bad  { background: rgba(155,47,34,.08); color: #9B2F22; }
      .bqsd-grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(132px, 1fr)); gap: 8px; margin-top: 12px; }
      .bqsd-grid > div { background: var(--paper); border-radius: 11px; padding: 9px 12px; }
      .bqsd-grid span { display: block; font-size: 11px; letter-spacing: .04em; text-transform: uppercase; color: var(--n-500, #7c8a80); }
      .bqsd-grid b { font-family: var(--mono, monospace); font-size: 14px; font-weight: 600; word-break: break-all; }
      .bqsd-ok, .bqsd-no { margin-top: 12px; padding: 11px 14px; border-radius: 11px; font-size: 14px; }
      .bqsd-ok { background: rgba(11,110,79,.07); color: var(--riad, #053B2C); }
      .bqsd-no { background: var(--paper); color: var(--n-600, #5d6b63); }
      .bqsd-det { margin-top: 12px; font-size: 13px; }
      .bqsd-det summary { cursor: pointer; color: var(--n-600, #5d6b63); padding: 4px 0; }
      .bqsd-t { width: 100%; border-collapse: collapse; margin-top: 8px; font-family: var(--mono, monospace); font-size: 12px; }
      .bqsd-t th { text-align: left; font-weight: 500; color: var(--n-500, #7c8a80); padding: 4px 8px; border-bottom: 1px solid var(--n-200, #e7e3da); }
      .bqsd-t td { padding: 3px 8px; border-bottom: 1px solid rgba(0,0,0,.04); }
      .mzi-form { padding: 20px 24px 8px; }
      .mzi-fg { margin-bottom: 14px; } .mzi-fg label { display: block; font-size: 11px; letter-spacing: .05em; text-transform: uppercase; color: #77807b; margin-bottom: 6px; }
      .mzi-fg input, .mzi-fg select { width: 100%; padding: 11px 13px; border: 1px solid rgba(10,15,13,.16); border-radius: 10px; font: inherit; font-size: 14px; background: var(--paper); color: var(--ink); }
      .mzi-frow { display: flex; gap: 12px; } .mzi-frow .mzi-fg { flex: 1; }
      .mzi-cat-form { padding-bottom: 20px; }
      .mzi-cat-create { display:grid; grid-template-columns:minmax(0,1fr) auto; gap:10px; align-items:end; padding:16px; border:1px solid rgba(11,110,79,.16); border-radius:14px; background:rgba(11,110,79,.045); }
      .mzi-cat-create .mzi-fg { margin:0; }
      .mzi-cat-create .mz-btn { min-height:42px; }
      .mzi-cat-list { display:grid; gap:10px; margin-top:18px; }
      .mzi-cat-empty { padding:24px 16px; border:1px dashed rgba(10,15,13,.14); border-radius:14px; color:#77807b; text-align:center; font-size:13px; }
      .mzi-cat-row { display:grid; grid-template-columns:minmax(0,1fr) auto; gap:14px; align-items:center; padding:14px 16px; border:1px solid rgba(10,15,13,.10); border-radius:14px; background:var(--paper); }
      .mzi-cat-main { min-width:0; }
      .mzi-cat-meta { display:flex; align-items:center; justify-content:space-between; gap:10px; margin-bottom:7px; }
      .mzi-cat-meta b { font-size:13px; color:var(--ink); }
      .mzi-cat-count { padding:3px 8px; border-radius:999px; background:rgba(10,15,13,.06); color:#77807b; font-size:11px; white-space:nowrap; }
      .mzi-cat-main input { width:100%; padding:10px 12px; border:1px solid rgba(10,15,13,.14); border-radius:9px; font:inherit; font-size:14px; background:var(--paper); color:var(--ink); }
      .mzi-cat-actions { display:flex; gap:7px; align-items:center; }
      .mzi-cat-actions .mz-btn { min-height:38px; padding:8px 11px; }
      .mzi-cat-actions .mz-btn i { width:15px; height:15px; }
      .mzi-ab { display:grid; grid-template-columns:repeat(2,minmax(0,1fr)); gap:10px; }
      .mzi-ab label { display:flex; align-items:center; gap:10px; min-height:54px; margin:0; padding:11px 13px; border:1px solid rgba(10,15,13,.13); border-radius:12px; background:var(--paper); cursor:pointer; text-transform:none; letter-spacing:0; color:var(--ink); }
      .mzi-ab label:has(input:checked) { border-color:var(--atlas,#0b6e4f); box-shadow:0 0 0 2px rgba(11,110,79,.10); background:rgba(11,110,79,.045); }
      .mzi-ab input { width:auto; margin:0; accent-color:var(--atlas,#0b6e4f); }
      .mzi-ab b { display:block; font-size:13.5px; }
      .mzi-ab span { display:block; margin-top:2px; color:#77807b; font-size:11.5px; line-height:1.25; }
      .mzi-photo { display:grid; grid-template-columns:86px minmax(0,1fr); gap:12px; align-items:center; padding:12px; border:1px solid rgba(10,15,13,.12); border-radius:14px; background:rgba(10,15,13,.025); }
      .mzi-photo-preview { width:86px; height:86px; border-radius:11px; border:1px dashed rgba(10,15,13,.18); background:var(--paper); display:grid; place-items:center; overflow:hidden; color:#9aa09d; }
      .mzi-photo-preview img { width:100%; height:100%; object-fit:cover; }
      .mzi-photo-preview i { width:24px; height:24px; }
      .mzi-photo-copy { min-width:0; }
      .mzi-photo-copy b { display:block; font-size:13px; margin-bottom:3px; }
      .mzi-photo-status { min-height:16px; color:#77807b; font-size:11.5px; line-height:1.35; }
      .mzi-photo-actions { display:flex; gap:7px; flex-wrap:wrap; margin-top:9px; }
      .mzi-photo-actions .mz-btn { padding:7px 10px; min-height:36px; }
      @media (max-width:700px) {
        .mzi-cat-create, .mzi-cat-row { grid-template-columns:1fr; }
        .mzi-cat-actions { justify-content:flex-end; }
        .mzi-cat-create .mz-btn { width:100%; }
        .mzi-ab { grid-template-columns:1fr; }
        .mzi-photo { grid-template-columns:70px minmax(0,1fr); }
        .mzi-photo-preview { width:70px; height:70px; }
      }
      /* Le sélecteur de couleur vient de color-palette.js (.kc-*) · rien à
         redéfinir ici, c'est tout l'intérêt. Restent la pastille cliquable de la
         ligne variante et le rappel discret de la nuance d'origine. */
      .mzi-cbtn { display: inline-flex; align-items: center; gap: 6px; background: none; border: 0; padding: 2px 4px; margin: -2px -4px; border-radius: 7px; font: inherit; color: inherit; cursor: pointer; }
      .mzi-cbtn:hover { background: rgba(125,242,176,.14); }
      .mzi-dashboard-only { display: inline-flex; align-items: center; min-height: 34px; padding: 0 12px; border: 1px solid rgba(10,15,13,.12); border-radius: 9px; background: var(--paper-soft, #f3f1eb); color: #77807b; font: 600 11px var(--sans, sans-serif); white-space: nowrap; }
      .mzi-cbtn.is-locked, .mzi-mini.is-locked { opacity: .72; cursor: not-allowed; }
      .mzi-csrc { font-style: normal; font-size: 11px; opacity: .6; margin-left: 5px; }
      .mzi-iconpick { display: grid; grid-template-columns: repeat(auto-fill, minmax(46px, 1fr)); gap: 8px; max-height: 168px; overflow-y: auto; padding: 8px; border: 1px solid rgba(10,15,13,.14); border-radius: 12px; background: var(--paper); }
      .mzi-icon { aspect-ratio: 1; border: 1.5px solid rgba(10,15,13,.10); border-radius: 10px; background: var(--paper); cursor: pointer; padding: 5px; color: var(--riad); display: flex; align-items: center; justify-content: center; }
      .mzi-icon:hover { border-color: rgba(11,110,79,.5); }
      .mzi-icon.on { border-color: var(--atlas); border-width: 2px; background: #EAF5EF; }
      .mzi-icon .mz-art-photo { width: 100%; height: 100%; }
      .mzi-help { font-size: 12px; color: #77807b; margin-top: -6px; margin-bottom: 12px; }
      .mzi-help.is-good { color: var(--atlas); }
      .mzi-help.is-bad  { color: #9B2F22; }
      /* .mzi-help remonte de 6px pour se coller sous un <input> nu ; sous une
         boîte de scan (qui a sa propre bordure) ce retrait la fait chevaucher
         le cadre. */
      .bqx-scanbox + .mzi-help { margin-top: 7px; }
      .mzi-first { padding: 40px 26px; text-align: center; display: flex; flex-direction: column; align-items: center; gap: 8px; }
      .mzi-first svg { width: 34px; height: 34px; color: var(--atlas); margin-bottom: 4px; }
      .mzi-first b { font-size: 16px; color: var(--ink); }
      .mzi-first span { font-size: 13.5px; color: #6d766f; max-width: 46ch; line-height: 1.55; }
      .mzi-first em { font-style: normal; font-size: 12.5px; color: #8d968f; margin-top: 6px; }

      /* ─── Reprise de stock (saisie à la douchette) ─── */
      .bqx-head { display: flex; align-items: center; gap: 16px; padding: 20px 24px 14px; border-bottom: 1px solid rgba(10,15,13,.08); }
      .bqx-head-t { flex: 1; min-width: 0; }
      .bqx-head-t h3 { margin: 0 0 2px; font-size: 18px; }
      .bqx-head-t span { font-size: 12.5px; color: #77807b; line-height: 1.45; display: block; }
      .bqx-tally { display: flex; align-items: baseline; gap: 6px; background: var(--paper); border: 1px solid rgba(10,15,13,.08); border-radius: 12px; padding: 8px 14px; flex: 0 0 auto; }
      .bqx-tally b { font-family: var(--mono); font-size: 19px; font-weight: 600; color: var(--atlas); }
      .bqx-tally span { font-size: 11px; color: #77807b; }
      .bqx-tally i { width: 1px; height: 18px; background: rgba(10,15,13,.12); margin: 0 4px; }
      .bqx-body { padding: 18px 24px 6px; }
      .bqx-scanbox { display: flex; align-items: center; gap: 12px; background: var(--paper); border: 2px solid var(--atlas); border-radius: 14px; padding: 15px 17px; }
      .bqx-scanbox.slim { padding: 11px 14px; border-width: 1.5px; }
      .bqx-scanbox > svg { width: 22px; height: 22px; color: var(--atlas); flex: 0 0 auto; }
      .bqx-scanbox.slim > svg { width: 18px; height: 18px; }
      .bqx-scanbox input { flex: 1; min-width: 0; border: 0; background: transparent; outline: none; font: inherit; font-size: 17px; font-family: var(--mono); letter-spacing: .02em; color: var(--ink); }
      .bqx-scanbox.slim input { font-size: 15px; }
      .bqx-mini { width: 34px; height: 34px; flex: 0 0 34px; border-radius: 9px; border: 0; background: var(--atlas); color: #fff; cursor: pointer; display: inline-flex; align-items: center; justify-content: center; }
      .bqx-mini svg { width: 17px; height: 17px; }
      .bqx-hint { font-size: 12.5px; color: #77807b; margin: 9px 2px 0; line-height: 1.45; }
      .bqx-hint.is-good { color: var(--atlas); }
      .bqx-hint.is-bad  { color: #9B2F22; font-weight: 500; }
      .bqx-hint.is-warn { color: #8A6210; }
      .bqx-alt { display: flex; gap: 8px; flex-wrap: wrap; margin: 14px 0 4px; }
      .bqx-log { display: flex; flex-direction: column; gap: 5px; margin: 14px 0 4px; }
      .bqx-log-row { display: flex; align-items: center; gap: 9px; background: var(--paper); border-radius: 10px; padding: 8px 12px; font-size: 13px; }
      .bqx-log-row svg { width: 15px; height: 15px; flex: 0 0 15px; color: var(--atlas); }
      .bqx-log-row span { flex: 1; min-width: 0; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }
      .bqx-log-row em { font-style: normal; font-family: var(--mono); font-size: 11px; color: #8d968f; }
      .bqx-log-row.is-erreur svg { color: #9B2F22; }
      .bqx-log-row.is-recu svg { color: #8A6210; }
      .bqx-log-empty { margin: 16px 0 4px; padding: 16px; text-align: center; font-size: 12.5px; color: #8d968f; background: var(--paper); border-radius: 12px; line-height: 1.5; }
      .bqx-found { display: flex; align-items: center; gap: 13px; padding: 15px 24px; }
      .bqx-found svg { width: 22px; height: 22px; flex: 0 0 22px; }
      .bqx-found b { display: block; font-size: 14.5px; }
      .bqx-found.is-new { background: rgba(11,110,79,.06); } .bqx-found.is-new svg { color: var(--atlas); }
      .bqx-found.is-known { background: rgba(184,124,32,.09); } .bqx-found.is-known svg { color: #8A6210; }
      .bqx-found.is-fix { background: rgba(155,47,34,.06); } .bqx-found.is-fix svg { color: #9B2F22; }
      .bqx-codeline { font-family: var(--mono); font-size: 12.5px; color: #5d6b63; display: inline-flex; align-items: center; gap: 8px; flex-wrap: wrap; }
      .bqx-sym { font-family: 'Inter Tight', sans-serif; font-size: 10.5px; letter-spacing: .04em; text-transform: uppercase; font-weight: 700; color: var(--atlas); background: rgba(11,110,79,.10); border-radius: 5px; padding: 2px 6px; }
      .bqx-sym.warn { color: #8A6210; background: rgba(184,124,32,.14); }
      .bqx-form { padding-top: 16px; }
      .bqx-foot { border-top: 1px solid rgba(10,15,13,.08); margin-top: 4px; }
      .bqx-chain { display: flex; align-items: center; gap: 14px; margin: 14px 24px 0; padding: 13px 16px; background: var(--paper); border: 1px dashed rgba(11,110,79,.4); border-radius: 13px; }
      .bqx-chain.is-link { border-style: solid; border-color: rgba(184,124,32,.45); background: rgba(184,124,32,.05); }
      .bqx-chain > div { flex: 1; min-width: 0; }
      .bqx-linklist { display: flex; flex-direction: column; gap: 9px; margin-top: 10px; max-height: 300px; overflow-y: auto; }
      .bqx-linkprod { background: var(--paper); border: 1px solid rgba(10,15,13,.08); border-radius: 13px; padding: 11px 13px; }
      .bqx-linkhead { display: flex; align-items: center; gap: 11px; margin-bottom: 8px; }
      .bqx-linkhead .mzi-art, .bqx-linkhead .mzi-art svg, .bqx-linkhead .mzi-art img { width: 28px; height: 28px; flex: 0 0 28px; }
      .bqx-linkhead > div { flex: 1; min-width: 0; }
      .bqx-linkhead b { display: block; font-size: 14px; }
      .bqx-linkhead span { font-size: 11.5px; color: #77807b; }
      .bqx-chip.is-pick { cursor: pointer; font: inherit; font-size: 12.5px; color: var(--ink); }
      .bqx-chip.is-pick:hover { border-color: var(--atlas); background: rgba(11,110,79,.08); }
      .bqx-chain b { display: block; font-size: 13.5px; }
      .bqx-chain span { font-size: 12px; color: #77807b; line-height: 1.45; }
      .bqx-common { display: flex; align-items: baseline; gap: 10px; margin: 12px 24px 0; padding: 10px 14px; background: var(--paper); border-radius: 11px; }
      .bqx-common span { font-size: 10.5px; letter-spacing: .05em; text-transform: uppercase; color: #77807b; }
      .bqx-common b { font-size: 13.5px; }
      .bqx-known-card { display: flex; align-items: center; gap: 15px; padding: 16px 24px 8px; }
      .bqx-known-card > div { flex: 1; min-width: 0; }
      .bqx-known-card b { font-size: 16px; display: block; }
      .bqx-known-card span { display: block; font-size: 12.5px; color: #77807b; margin-top: 2px; }
      .bqx-thisvar { display: flex !important; align-items: center; gap: 7px; margin-top: 5px !important; }
      .bqx-thisvar i { width: 12px; height: 12px; border-radius: 50%; border: 1px solid rgba(0,0,0,.18); flex: 0 0 12px; }
      .bqx-existing { padding: 8px 24px 4px; }
      .bqx-existing > span { display: block; font-size: 10.5px; letter-spacing: .05em; text-transform: uppercase; color: #77807b; margin-bottom: 7px; }
      .bqx-chips { display: flex; gap: 6px; flex-wrap: wrap; }
      .bqx-chip { display: inline-flex; align-items: center; gap: 6px; background: var(--paper); border: 1px solid rgba(10,15,13,.10); border-radius: 999px; padding: 5px 11px; font-size: 12.5px; }
      .bqx-chip.on { border-color: var(--atlas); background: rgba(11,110,79,.08); }
      .bqx-chip i { width: 11px; height: 11px; border-radius: 50%; border: 1px solid rgba(0,0,0,.18); }
      .bqx-chip b { font-family: var(--mono); font-size: 12px; }
      .bqx-chip em { font-style: normal; color: #8d968f; }
      .bqx-acts { display: flex; flex-direction: column; gap: 9px; padding: 14px 24px 6px; }
      .bqx-act { background: var(--paper); border: 1px solid rgba(10,15,13,.08); border-radius: 13px; padding: 13px 16px; }
      .bqx-act-h { display: flex; align-items: center; gap: 8px; }
      .bqx-act-h svg { width: 16px; height: 16px; color: var(--atlas); }
      .bqx-act-h b { font-size: 13.5px; }
      .bqx-act p { margin: 4px 0 10px; font-size: 12px; color: #77807b; line-height: 1.45; }
      .bqx-qtyrow { display: flex; align-items: center; gap: 7px; }
      .bqx-qtyrow input { width: 62px; text-align: center; font-family: var(--mono); font-size: 16px; padding: 8px; border: 1px solid rgba(10,15,13,.16); border-radius: 9px; background: var(--surface, #fff); color: var(--ink); }
      .bqx-qtyrow .mz-btn { margin-left: 4px; }
      .bqx-pricediff { display: flex; align-items: center; justify-content: center; gap: 18px; padding: 20px 24px; }
      .bqx-pricediff > div { text-align: center; }
      .bqx-pricediff span { display: block; font-size: 10.5px; letter-spacing: .05em; text-transform: uppercase; color: #77807b; }
      .bqx-pricediff b { font-family: var(--mono); font-size: 19px; }
      .bqx-pricediff .next b { color: var(--atlas); }
      .bqx-pricediff > svg { width: 18px; height: 18px; color: #99a; }
      /* Le choix du code-barres à la création · trois options, la lentille liquide
         s'y attache via data-lens-demo / data-lens-item (assets/liquid-lens.js). */
      .bqx-choice { position: relative; display: grid; grid-template-columns: repeat(3, 1fr); gap: 7px; }
      .bqx-opt { position: relative; z-index: 1; text-align: left; background: var(--paper); border: 1.5px solid rgba(10,15,13,.10); border-radius: 12px; padding: 11px 13px; cursor: pointer; font: inherit; color: var(--ink); display: flex; flex-direction: column; gap: 2px; transition: border-color .15s; }
      .bqx-opt:hover { border-color: rgba(11,110,79,.45); }
      .bqx-opt.on { border-color: var(--atlas); background: rgba(11,110,79,.07); }
      .bqx-opt svg { width: 17px; height: 17px; color: var(--atlas); margin-bottom: 3px; }
      .bqx-opt b { font-size: 13px; }
      .bqx-opt span { font-size: 11.5px; color: #77807b; line-height: 1.38; }
      /* Quand la lentille liquide est attachée (assets/liquid-lens.js ajoute
         data-kw-lens), c'est ELLE qui porte le fond · dégradé atlas → riad. La
         pastille passe donc en transparent et son texte en clair, sinon on lit
         de l'encre sombre sur du vert sombre. Le style .on ci-dessus reste le
         repli lisible si la lentille n'est pas chargée. */
      .bqx-choice[data-kw-lens] .bqx-opt.on { background: transparent; border-color: transparent; }
      .bqx-choice[data-kw-lens] .bqx-opt.on b { color: #fff; }
      .bqx-choice[data-kw-lens] .bqx-opt.on span { color: rgba(255,255,255,.82); }
      .bqx-choice[data-kw-lens] .bqx-opt.on svg { color: var(--mint); }
      .bqx-choice .kw-lens { border-radius: 12px; }
      @media (max-width: 620px) {
        .bqx-choice { grid-template-columns: 1fr; }
        .bqx-head { flex-direction: column; align-items: flex-start; gap: 10px; }
      }
    `;
    document.head.appendChild(st);
  }

  /* ─── global keyboard-wedge : a USB scanner types fast + Enter, from anywhere ───
     A HID scanner (USB or Bluetooth — both enumerate as a keyboard, no driver) is
     just a very fast typist. Two things separate it from a human, and we use both:
     speed, and the terminating Enter.

     AZERTY: a scanner ships configured for a US layout and sends US SCANCODES. On
     a French/Moroccan AZERTY till the unshifted number row is & é " ' ( - è _ ç à,
     so reading e.key turned "2000000000015" into "é000000000015" and every scan
     came back "code inconnu" — the classic AZERTY failure in FR/MA shops. e.code
     is the PHYSICAL key and is layout-independent, so digits are read from it.
     That is correct for BOTH configurations: a US-layout scanner sends Digit2 for
     "2", and an AZERTY-configured one sends Shift+Digit2 — e.code is Digit2 either
     way. Letters stay on e.key (for a letter the two configurations genuinely
     disagree, and EAN/UPC/ITF — everything Kiwi prints and nearly all retail
     barcodes — are pure digits, so this is the safe side to err on). */
  /* Same AZERTY damage, other route: when a scan FIELD has focus (the Scan tab
     focuses one on open), the scanner's keystrokes arrive as normal text and the
     browser has already applied the layout — so the box literally contains
     "é000000000015". e.code can't help after the fact, but the corruption is a
     fixed, reversible substitution: the French unshifted number row. Only applied
     when the string is made ENTIRELY of those symbols and carries no digit at all,
     so a genuine alphanumeric code containing a "-" is never touched. */
  const AZ_ROW = { '&': '1', 'é': '2', '"': '3', "'": '4', '(': '5', '-': '6', 'è': '7', '_': '8', 'ç': '9', 'à': '0' };
  function normScan(raw) {
    const s = String(raw || '').trim();
    if (!s || /\d/.test(s)) return s;
    if (!/^[&é"'(\-è_çà]+$/.test(s)) return s;
    return s.replace(/./g, (ch) => AZ_ROW[ch] || ch);
  }
  function wedgeChar(e) {
    const c = e.code || '';
    if (/^Digit[0-9]$/.test(c)) return c.slice(5);
    if (/^Numpad[0-9]$/.test(c)) return c.slice(6);
    return (e.key && e.key.length === 1) ? e.key : '';
  }
  /* Non-null while the douchette diagnostic is open — see openScannerTest().
   * Declared here rather than beside it because the wedge listener below reads
   * it, and a `let` further down would sit in the temporal dead zone. */
  let scanDiagOff = null;

  function installWedgeScanner() {
    if (installWedgeScanner._done) return;
    installWedgeScanner._done = true;
    /* `started` datait la rafale EN COURS, mais n'était remis à zéro qu'après
     * 120 ms de silence — jamais après un Entrée. Deux scans séparés de moins de
     * 120 ms (un lecteur en mode présentation, ou une reprise de stock menée au
     * rythme) partageaient donc le même `started` : la durée mesurée du second
     * incluait le premier, `span/n` franchissait le seuil des 55 ms/caractère, et
     * la douchette cessait silencieusement d'être reconnue — sans erreur, sans
     * message, les scans suivants disparaissaient. Vu en test : sur une salve
     * continue, tout passait jusqu'au 97e article puis plus rien.
     * `started` est désormais posé au PREMIER caractère de chaque rafale (buf
     * vide), donc chaque scan est chronométré pour lui seul. */
    let buf = '', last = 0, started = 0;
    document.addEventListener('keydown', (e) => {
      if (!document.body.classList.contains('is-pos-maison')) return;
      /* While the diagnostic is open the scan belongs to it and to nothing else.
       * Without this the same keystrokes ALSO ran the normal route — dropping
       * the article on the ticket, or (on an unknown code) switching to the
       * inventory and opening "rattacher ce code". A test must not sell. */
      if (scanDiagOff) return;
      const tag = (e.target && e.target.tagName) || '';
      const typing = tag === 'INPUT' || tag === 'TEXTAREA' || (e.target && e.target.isContentEditable);
      const now = Date.now();
      if (now - last > 120) buf = '';        // rafale abandonnée en cours de route
      last = now;
      if (e.key === 'Enter') {
        const code = buf, span = now - started, n = code.length;
        buf = '';
        /* Average gap per character. A scanner runs ~2-15 ms; sustained sub-55 ms
           is ~220 WPM, which no one types. Without this a human pressing Enter
           after any 4 quick keys fired a phantom scan. */
        const fast = n >= 4 && (span / n) < 55;
        /* Pendant une saisie d'inventaire le scan appartient au formulaire, même
           si le curseur traîne dans un autre champ : sinon les chiffres tombent
           dans « Nom du produit » et l'employé les découvre à l'enregistrement. */
        if (fast && scanCapture) { e.preventDefault(); unleak(e.target, code); handleWedge(code); return; }
        if (fast && !typing) { e.preventDefault(); handleWedge(code); }
        return;
      }
      if (e.ctrlKey || e.metaKey || e.altKey) return;
      if (!buf) started = now;               // premier caractère de CETTE rafale
      buf += wedgeChar(e);
    }, true);
  }
  /* ─── à qui appartient le prochain scan ? ────────────────────────────────────
   * Non-null quand une SAISIE D'INVENTAIRE attend un code (reprise de stock déjà
   * étiqueté, rattachement, réception). Tant que c'est armé, la douchette n'écrit
   * QUE dans ce formulaire.
   *
   * Sans cela le routage ne regardait que `state.view`, et un scan pendant la
   * saisie partait quand même sur le ticket : l'employé qui reprend son stock
   * vendait ses articles un par un sans le voir. La règle du cahier des charges
   * est explicite — scanner pendant la mise en stock ne doit JAMAIS mettre au
   * panier, ni vendre, ni bouger le stock avant confirmation, ni imprimer. */
  let scanCapture = null;
  function armScanCapture(fn) { scanCapture = fn; }
  function disarmScanCapture(fn) { if (!fn || scanCapture === fn) scanCapture = null; }

  /* Les caractères d'une rafale sont tapés au fil de l'eau : seul « Entrée » est
   * interceptable après coup. Si le curseur était dans un autre champ, le code
   * vient de s'y écrire — on retire ce suffixe, et rien d'autre. La comparaison
   * porte sur le brut ET sur la version AZERTY mutilée (&é"' au lieu de 1234),
   * puisque c'est exactement ce que le champ a reçu. */
  function unleak(target, code) {
    if (!target || target.value == null || typeof target.value !== 'string') return;
    const val = target.value;
    const az = Object.entries(AZ_ROW).reduce((s, [ch, d]) => s.split(d).join(ch), code);
    for (const tail of [code, az]) {
      if (tail && val.length >= tail.length && val.slice(-tail.length) === tail) {
        target.value = val.slice(0, -tail.length);
        return;
      }
    }
  }

  function handleWedge(code) {
    if (scanCapture) { try { scanCapture(code); } catch (_) {} return; }  /* saisie inventaire */
    if (state.view === 'inventaire') { invScanHandle(code); return; }   /* fiche stock */
    if (state.view === 'scan') { lookupScan(code); return; }            /* vérif prix/stock */
    commitEan(code);                                                    /* vente → ticket */
  }

  /* ─── Douchette · diagnostic ─────────────────────────────────────────────
   * "La douchette ne marche pas" is, at the counter, always one of five things,
   * and from the merchant's side they look identical — nothing happens:
   *   1. the device sends nothing at all (cable/HID mode),
   *   2. it types through a keyboard layout that mangles the digits (a US-mode
   *      scanner on a French Windows sends &é"' where we expect 1234),
   *   3. it never sends the Enter suffix, so no scan is ever committed,
   *   4. it is genuinely too slow / it was a human typing,
   *   5. it reads perfectly and the code simply is not in the catalogue yet.
   * Guessing between those costs a shop visit. This captures one raw burst and
   * names which one it is. It also dumps code→key per character, because that
   * is the only way to tell a US-mode scanner from a locale-matched one — and
   * that determines whether letters (Code 128) need the same fix digits got. */
  function openScannerTest() {
    let ev = [], last = 0, burst = null;

    const finish = () => {
      const chars = ev.filter((x) => x.ch !== '');
      const raw = chars.map((x) => x.ch).join('');
      /* What the OS actually delivered, before wedgeChar() reads the key by its
       * physical position. On a US-mode scanner plugged into a French Windows
       * these differ (é000000000&( vs 2000000000015) — and that difference is
       * the ONLY way to show the merchant that a layout fix happened, since
       * `raw` is already corrected by the time we see it. */
      const typed = chars.map((x) => (x.key && x.key.length === 1) ? x.key : '').join('');
      burst = {
        ev: ev.slice(), raw, typed, norm: normScan(raw),
        n: chars.length,
        span: ev.length ? (ev[ev.length - 1].t - ev[0].t) : 0,
        enter: ev.some((x) => x.key === 'Enter'),
      };
      ev = [];
      paint();
    };

    const onKey = (e) => {
      const now = Date.now();
      if (now - last > 400) ev = [];       // new burst
      last = now;
      if (e.key === 'Enter') {
        e.preventDefault();
        ev.push({ code: e.code || '', key: 'Enter', ch: '', t: now });
        finish();
        return;
      }
      if (e.ctrlKey || e.metaKey || e.altKey) return;
      ev.push({ code: e.code || '', key: e.key, ch: wedgeChar(e), shift: !!e.shiftKey, t: now });
      // A scanner with no Enter suffix never calls finish() — settle it ourselves.
      clearTimeout(onKey._t);
      onKey._t = setTimeout(() => { if (ev.length) finish(); }, 500);
    };

    function verdict(b) {
      if (!b) return null;
      if (!b.n) return { tone: 'bad', t: 'Aucun caractère reçu. La douchette n\'est pas vue comme un clavier : vérifiez le câble USB, ou remettez-la en mode « HID / clavier » avec son code de configuration.' };
      const perChar = b.n > 1 ? b.span / b.n : 0;
      if (!b.enter) return { tone: 'warn', t: `${b.n} caractères lus, mais aucune touche Entrée. Kiwi valide un scan sur Entrée : configurez le suffixe « CR / Entrée » de la douchette (code de configuration dans sa notice).` };
      if (b.n >= 4 && perChar >= 55) return { tone: 'warn', t: `Lecture correcte mais lente (${Math.round(perChar)} ms/caractère). À cette vitesse Kiwi la prend pour une saisie au clavier. Si c'est bien la douchette, dites-le-nous, on relèvera le seuil.` };
      if (b.typed && b.typed !== b.raw) return { tone: 'good', t: `Douchette détectée. Elle est en clavier US sur un Windows français · Kiwi corrige toute seule (${esc(b.typed)} → ${esc(b.norm)}). Il n'y a rien à reconfigurer sur la douchette.` };
      return { tone: 'good', t: `Douchette détectée et lue correctement (${Math.round(perChar)} ms/caractère).` };
    }

    function match(code) {
      if (!code) return '';
      const cat = window.KiwiBoutiqueCatalog;
      const hit = cat && cat.resolveScan ? cat.resolveScan(code) : null;
      const pid = hit ? hit.pid : BY_EAN[code];
      if (pid && P[pid]) return `<div class="bqsd-ok">Article trouvé : <b>${esc(P[pid].name)}</b></div>`;
      return `<div class="bqsd-no">Code lu correctement, mais aucun article ne le porte encore. Enregistrez-le depuis l'inventaire.</div>`;
    }

    function paint() {
      const b = burst, v = verdict(b);
      const sym = (b && b.norm && window.KiwiBarcode && window.KiwiBarcode.detect) ? window.KiwiBarcode.detect(b.norm) : '';
      const rows = b ? b.ev.filter((x) => x.key !== 'Enter').map((x) =>
        `<tr><td>${esc(x.code || '·')}</td><td>${esc(x.key)}</td><td>${esc(x.ch || '·')}</td></tr>`).join('') : '';
      invSetModal(`
        <button class="mz-modal-x" data-inv-x aria-label="Fermer"><i data-lucide="x"></i></button>
        <div class="mzi-modh"><div><h3>Test de la douchette</h3><span>Scannez n'importe quel article. Rien n'est vendu, rien n'est modifié.</span></div></div>
        <div class="bqsd">
          ${!b ? `<div class="bqsd-wait"><i data-lucide="scan-line"></i>En attente d'un scan…</div>` : `
            <div class="bqsd-v ${v.tone}">${v.t}</div>
            <div class="bqsd-grid">
              <div><span>Code lu</span><b>${esc(b.norm) || '·'}</b></div>
              <div><span>Caractères</span><b>${b.n}</b></div>
              <div><span>Vitesse</span><b>${b.n > 1 ? Math.round(b.span / b.n) + ' ms/car.' : '·'}</b></div>
              <div><span>Touche Entrée</span><b>${b.enter ? 'oui' : 'non'}</b></div>
              <div><span>Symbologie</span><b>${esc(sym || '·')}</b></div>
              <div><span>Frappe clavier</span><b>${esc(b.typed) || '·'}</b></div>
            </div>
            ${b.n ? match(b.norm) : ''}
            <details class="bqsd-det"><summary>Détail touche par touche</summary>
              <table class="bqsd-t"><thead><tr><th>code physique</th><th>caractère reçu</th><th>lu par Kiwi</th></tr></thead><tbody>${rows}</tbody></table>
            </details>`}
        </div>
        <div class="mzi-modfoot">
          <button class="mz-btn secondary" id="bqsd-copy">Copier le diagnostic</button>
          <button class="mz-btn" data-inv-x>Terminer</button>
        </div>`, (el) => {
        const cp = $('#bqsd-copy', el);
        if (cp) cp.onclick = () => {
          const txt = JSON.stringify({ ua: navigator.userAgent, burst: burst && { raw: burst.raw, norm: burst.norm, n: burst.n, span: burst.span, enter: burst.enter, ev: burst.ev.map((x) => [x.code, x.key, x.ch]) } }, null, 1);
          (navigator.clipboard ? navigator.clipboard.writeText(txt) : Promise.reject()).then(
            () => toast('Diagnostic copié'), () => toast('Copie impossible sur cet appareil'));
        };
      });
    }

    if (scanDiagOff) scanDiagOff();
    document.addEventListener('keydown', onKey, true);
    // The panel must keep listening while it is open, and stop the moment the
    // veil closes — by the X, the footer button, Escape or a click outside.
    const veil = $('#mz-inv-veil', root);
    const obs = veil ? new MutationObserver(() => {
      if (!veil.classList.contains('is-open') && scanDiagOff) scanDiagOff();
    }) : null;
    if (obs) obs.observe(veil, { attributes: true, attributeFilter: ['class'] });
    scanDiagOff = () => {
      document.removeEventListener('keydown', onKey, true);
      clearTimeout(onKey._t);
      if (obs) obs.disconnect();
      scanDiagOff = null;
    };
    paint();
  }
  function invScanHandle(raw) {
    const code = normScan(raw);
    const cat = catDB(); if (!cat) return;
    const hit = cat.findByBarcode(code);
    if (hit) { toast(`${hit.product.name} · ${hit.variant.colorLabel} ${hit.variant.size}`); openInvProduct(hit.product.id); return; }
    /* Code inconnu depuis l'inventaire : c'est presque toujours un article que la
       boutique possède mais que Kiwi ne connaît pas encore. On ouvre la reprise
       de stock avec ce code, où il peut devenir un nouvel article OU une
       déclinaison du précédent — l'ancien sélecteur, lui, exigeait de choisir un
       produit déjà existant et ne savait pas en créer. */
    toast(`Code ${code} inconnu, à enregistrer`);
    intakeStartWith(code);
  }

  /* Entrer dans la reprise avec un code déjà lu (scan depuis l'inventaire). */
  function intakeStartWith(raw) {
    if (!catDB()) { toast('Base d\'inventaire indisponible'); return; }
    if (state.view !== 'inventaire') switchView('inventaire');
    if (!intake.open) { intake.open = true; intakeReset(); }
    intakeTake(raw);
  }/* Les messages créés ici passent par la langue de la caisse (assets/caisse-lang.js). */
const tr = (s) => (window.KiwiCaisseLang ? window.KiwiCaisseLang.tr(s) : s);
/* « ← Inventaire » en tête de Mouvements de stock et de Déclarer casse : leurs écrans se redessinent souvent, on écoute donc une fois, au document. */
try { document.addEventListener('click', (e) => { const b = e.target && e.target.closest && e.target.closest('[data-mz-back-inv]'); if (b && root && root.contains(b)) switchView('inventaire'); }); } catch (_) {}


  /* ═══════════════════════ PROMOTIONS ═══════════════════════
   * L'écran où le magasin décide de ses prix. La règle vit dans
   * assets/promos.js ; ici on ne fait que la composer et la montrer.
   *
   * Le pari de cet écran : un commerçant ne crée pas une promotion « en
   * pourcentage sur une catégorie » — il veut « écouler les caftans d'été » ou
   * « vider ce qui traîne depuis six mois ». Les cibles sont donc écrites dans
   * ces mots-là, et l'aperçu chiffre la décision AVANT de l'enregistrer :
   * combien d'articles, combien ça coûte, combien passeraient sous le prix
   * d'achat. Une promotion qu'on enregistre sans savoir ce qu'elle touche est
   * une promotion qu'on découvre au comptoir, article par article. */

  const PRM = () => window.KiwiPromos || null;
  const promoState = { filter: 'active' };

  const PROMO_DAY = 86400000;
  const startOfDay = (d) => { const x = new Date(d); x.setHours(0, 0, 0, 0); return x.getTime(); };
  const endOfDay   = (d) => { const x = new Date(d); x.setHours(23, 59, 59, 999); return x.getTime(); };

  /* La cible, écrite comme le commerçant la dirait à voix haute. Un « scope.type
     = avant » affiché tel quel n'apprend rien à personne. */
  function promoScopeText(p) {
    const sc = p.scope || {};
    if (sc.type === 'tout') return 'Tout le magasin';
    if (sc.type === 'rayon') {
      const names = (sc.ids || []).map((id) => (RAYONS.find((r) => r.id === id) || {}).label).filter(Boolean);
      if (!names.length) return 'Aucun rayon choisi';
      return names.length <= 2 ? names.join(' et ') : `${names[0]} et ${names.length - 1} autres rayons`;
    }
    if (sc.type === 'produits') {
      const n = (sc.ids || []).length;
      if (!n) return 'Aucun article choisi';
      if (n === 1) { const it = P[sc.ids[0]]; return it ? it.name : '1 article'; }
      return `${n} articles choisis`;
    }
    if (sc.type === 'avant') return sc.before ? `Entré en stock avant le ${fmtDay(new Date(sc.before))}` : 'Aucune date choisie';
    if (sc.type === 'stock') return `Il en reste ${sc.max || 0} ou moins`;
    return '·';
  }

  /* La période, en clair, avec ce qu'il reste à courir. « du 12 au 19 » ne dit
     pas si c'est fini ; « se termine dans 3 jours » se lit d'un coup d'œil. */
  /* Le créneau (« Mar, Jeu · 12:00–14:00 ») d'une promotion à jours ou à
     heures, et quand elle reprend si elle attend. Posé depuis le tableau de
     bord ; la caisse le dit, sans quoi « Hors créneau » ne s'expliquerait pas. */
  const PROMO_DAY_SHORT = ['Dim', 'Lun', 'Mar', 'Mer', 'Jeu', 'Ven', 'Sam'];
  const PROMO_DAY_LONG = ['dimanche', 'lundi', 'mardi', 'mercredi', 'jeudi', 'vendredi', 'samedi'];
  function promoSlotText(p, st, now) {
    const parts = [];
    if (p.days && p.days.length) parts.push([1, 2, 3, 4, 5, 6, 0].filter((d) => p.days.indexOf(d) >= 0).map((d) => PROMO_DAY_SHORT[d]).join(', '));
    if (p.start && p.end) parts.push(`${p.start}–${p.end}`);
    if (!parts.length || st === 'ended') return '';
    if (st === 'waiting') {
      const next = PRM().nextWindow ? PRM().nextWindow(p, now) : null;
      parts.push(next ? `Reprend ${next.day === 0 ? 'aujourd\'hui' : next.day === 1 ? 'demain' : PROMO_DAY_LONG[next.weekday]}${next.at ? ` à ${next.at}` : ''}` : 'Hors créneau');
    }
    return parts.join(' · ') + ' · ';
  }
  function promoWhenText(p, now) {
    now = now || Date.now();
    const st = PRM().status(p, now);
    return promoSlotText(p, st, now) + promoWhenBase(p, st, now);
  }
  function promoWhenBase(p, st, now) {
    if (st === 'paused') return 'En pause, aucun prix n\'est modifié';
    if (st === 'scheduled') {
      const j = Math.ceil((p.from - now) / PROMO_DAY);
      return `Démarre ${j <= 1 ? 'demain' : `dans ${j} jours`} · ${fmtDay(new Date(p.from))}`;
    }
    if (st === 'ended') return `Terminée le ${fmtDay(new Date(p.to))}`;
    if (!p.to) return 'Sans date de fin, jusqu\'à ce que vous l\'arrêtiez';
    const left = p.to - now;
    if (left < 2 * 3600000) return `Se termine à ${fmtHM(new Date(p.to))}`;
    const j = Math.ceil(left / PROMO_DAY);
    return j <= 1 ? `Se termine aujourd'hui à ${fmtHM(new Date(p.to))}` : `Se termine dans ${j} jours · ${fmtDay(new Date(p.to))}`;
  }

  /* Le catalogue vu comme une liste plate — ce que preview() attend. */
  const promoItems = () => Object.keys(P).filter((k) => P[k] && P[k].id === k).map((k) => P[k]);

  function promoCount(p) {
    const pr = PRM();
    if (!pr) return 0;
    return pr.preview(p, promoItems(), { stockOf: (it) => stockOf(it) }).count;
  }

  function renderPromos() {
    const pr = PRM();
    const el = $('[data-mz-panel="promotions"]', root);
    if (!pr) {
      el.innerHTML = `<div class="mz-pr-wrap"><div class="mz-pr-empty"><i data-lucide="tag"></i>
        <div><b>Promotions indisponibles</b><span>Le module de promotions n'a pas été chargé sur cette caisse.</span></div></div></div>`;
      icons(); return;
    }
    const now = Date.now();
    const all = pr.list();
    const st = pr.stats(now);
    /* En pause et programmée vivent dans le même onglet « à venir » : ce sont
       les deux façons d'avoir une promotion prête qui ne s'applique pas encore. */
    const groups = {
      active: all.filter((p) => ['active', 'waiting'].indexOf(pr.status(p, now)) >= 0),
      soon: all.filter((p) => ['scheduled', 'paused'].indexOf(pr.status(p, now)) >= 0),
      ended: all.filter((p) => pr.status(p, now) === 'ended'),
    };
    const shown = groups[promoState.filter] || groups.active;

    /* Ce que les promotions ont coûté aujourd'hui — la seule mesure qui dit si
       elles marchent. Lue sur les ventes du jour, pas estimée. */
    const offToday = salesToday().reduce((s, x) => s + (+x.promoOff || 0), 0);
    /* Seules celles qui s'appliquent À CET INSTANT remisent un article : une
       promotion « hors créneau » est sous l'onglet, pas sur l'étiquette. */
    const running = groups.active.filter((p) => pr.status(p, now) === 'active');
    const touched = running.length ? promoArticleCount(running) : 0;
    const sub = [
      `${st.active} promotion${st.active > 1 ? 's' : ''} en cours`,
      st.waiting ? `${st.waiting} hors créneau` : null,
      touched ? `${touched} article${touched > 1 ? 's' : ''} remisé${touched > 1 ? 's' : ''}` : null,
      offToday ? `${fmtMAD(offToday)} offerts aujourd'hui` : null,
    ].filter(Boolean).join(' · ');

    el.innerHTML = `
      <div class="mz-pr-wrap">
        <header class="mz-head">
          <div><h1>Promotions</h1><div class="mz-head-sub">${esc(sub)}</div></div>
          <button class="mz-btn primary mz-pr-new" id="mz-pr-new"><i data-lucide="plus"></i>Nouvelle promotion</button>
        </header>

        ${all.length ? `
        <div class="mz-seg mz-pr-seg" data-lens-demo id="mz-pr-filter">
          <button class="mz-seg-it ${promoState.filter === 'active' ? 'on' : ''}" data-lens-item data-prf="active">En cours<small>${groups.active.length}</small></button>
          <button class="mz-seg-it ${promoState.filter === 'soon' ? 'on' : ''}" data-lens-item data-prf="soon">À venir<small>${groups.soon.length}</small></button>
          <button class="mz-seg-it ${promoState.filter === 'ended' ? 'on' : ''}" data-lens-item data-prf="ended">Terminées<small>${groups.ended.length}</small></button>
        </div>` : ''}

        ${all.length ? (shown.length ? `
        <div class="mz-pr-list">
          ${shown.map((p) => promoCardHtml(p, now)).join('')}
        </div>` : `
        <div class="mz-pr-empty soft"><i data-lucide="tag"></i>
          <div><b>Rien ici</b><span>${promoState.filter === 'active' ? 'Aucune promotion ne tourne en ce moment.' : promoState.filter === 'soon' ? 'Aucune promotion en attente.' : 'Aucune promotion terminée.'}</span></div>
        </div>`) : promoEmptyHtml()}
      </div>`;

    $('#mz-pr-new', el).onclick = () => openPromoComposer(null);
    const seg = $('#mz-pr-filter', el);
    if (seg) seg.onclick = (e) => {
      const b = e.target.closest('[data-prf]');
      if (!b) return;
      promoState.filter = b.dataset.prf;
      renderPromos();
    };
    $$('[data-pr-starter]', el).forEach((b) => {
      b.onclick = () => openPromoComposer(promoStarter(b.dataset.prStarter));
    });
    $$('[data-pr-edit]', el).forEach((b) => { b.onclick = () => openPromoComposer(pr.get(b.dataset.prEdit)); });
    $$('[data-pr-toggle]', el).forEach((b) => {
      b.onclick = () => {
        const p = pr.get(b.dataset.prToggle); if (!p) return;
        pr.setPaused(p.id, !p.paused);
        toast(p.paused ? `${p.name} reprend` : `${p.name} en pause, les prix repassent au plein tarif`);
        renderPromos(); renderGrid(); renderBadges(); icons(); lens();
      };
    });
    $$('[data-pr-print]', el).forEach((b) => { b.onclick = () => openPromoLabels(b.dataset.prPrint); });
    $$('[data-pr-del]', el).forEach((b) => { b.onclick = () => confirmPromoDelete(b.dataset.prDel); });
    icons(); lens();
  }

  /* Combien d'articles portent une étiquette promo en ce moment, sans les
     compter deux fois quand deux promotions visent le même. */
  function promoArticleCount(running) {
    const seen = new Set();
    const items = promoItems();
    running.forEach((p) => {
      items.forEach((it) => { if (PRM().matches(p, it, stockOf(it))) seen.add(it.id); });
    });
    return seen.size;
  }

  function promoCardHtml(p, now) {
    const pr = PRM();
    const st = pr.status(p, now);
    const n = promoCount(p);
    const tone = st === 'active' ? 'on' : st === 'ended' ? 'off' : 'wait';
    return `
      <article class="mz-pr-card is-${tone}">
        <div class="mz-pr-ribbon"><b>${esc(pr.badgeOf(p))}</b><span>${p.kind === 'fixed' ? 'prix fixe' : 'de remise'}</span></div>
        <div class="mz-pr-body">
          <div class="mz-pr-top">
            <h3>${esc(p.name)}</h3>
            <span class="mz-pr-state ${tone}">${st === 'active' ? 'En cours' : st === 'waiting' ? 'Hors créneau' : st === 'scheduled' ? 'Programmée' : st === 'paused' ? 'En pause' : 'Terminée'}</span>
          </div>
          <div class="mz-pr-meta">
            <span><i data-lucide="target"></i>${esc(promoScopeText(p))}</span>
            <span><i data-lucide="clock"></i>${esc(promoWhenText(p, now))}</span>
          </div>
          <div class="mz-pr-foot">
            <span class="mz-pr-n">${n} article${n > 1 ? 's' : ''} concerné${n > 1 ? 's' : ''}</span>
            <span class="mz-pr-acts">
              ${n ? `<button class="mzi-mini" data-pr-print="${esc(p.id)}" title="Imprimer les étiquettes de cette promotion"><i data-lucide="printer"></i></button>` : ''}
              ${st !== 'ended' ? `<button class="mzi-mini" data-pr-toggle="${esc(p.id)}" title="${p.paused ? 'Reprendre' : 'Mettre en pause'}"><i data-lucide="${p.paused ? 'play' : 'pause'}"></i></button>` : ''}
              <button class="mzi-mini" data-pr-edit="${esc(p.id)}" title="Modifier"><i data-lucide="pencil"></i></button>
              <button class="mzi-mini danger" data-pr-del="${esc(p.id)}" title="Supprimer"><i data-lucide="trash-2"></i></button>
            </span>
          </div>
        </div>
      </article>`;
  }

  /* L'écran vide APPREND la fonctionnalité au lieu de la décrire. Trois
     promotions réelles, prêtes en un geste, qui couvrent les trois raisons pour
     lesquelles une boutique baisse ses prix : écouler l'ancien, finir les
     séries, faire venir du monde. Le commerçant touche, ajuste, enregistre. */
  const PROMO_STARTERS = {
    destock: { name: 'Déstockage', kind: 'percent', value: 30, scope: { type: 'avant' }, months: 6,
               title: 'Déstocker l\'ancienne saison', desc: 'Tout ce qui est en stock depuis plus de six mois, −30 %' },
    finserie: { name: 'Fins de série', kind: 'percent', value: 20, scope: { type: 'stock', max: 5 },
               title: 'Écouler les fins de série', desc: 'Les articles où il reste 5 pièces ou moins, −20 %' },
    weekend: { name: 'Week-end', kind: 'percent', value: 10, scope: { type: 'tout' }, days: 2,
               title: 'Animer le week-end', desc: 'Tout le magasin, −10 %, jusqu\'à dimanche soir' },
  };
  function promoStarter(key) {
    const s = PROMO_STARTERS[key];
    if (!s) return null;
    const now = Date.now();
    const p = { name: s.name, kind: s.kind, value: s.value, scope: JSON.parse(JSON.stringify(s.scope)) };
    if (s.months) p.scope.before = startOfDay(new Date(now - s.months * 30 * PROMO_DAY));
    if (s.days) p.to = endOfDay(new Date(now + s.days * PROMO_DAY));
    return p;
  }
  function promoEmptyHtml() {
    return `
      <div class="mz-pr-zero">
        <div class="mz-pr-zero-head">
          <i data-lucide="tag"></i>
          <h2>Baissez vos prix une fois, la caisse s'en souvient</h2>
          <p>Une promotion s'applique toute seule aux articles que vous visez, pendant la durée que vous fixez.
             Les étiquettes, la grille de vente et le reçu de la cliente suivent sans un geste de plus.</p>
        </div>
        <div class="mz-pr-starters">
          ${Object.keys(PROMO_STARTERS).map((k) => `
            <button class="mz-pr-starter" data-pr-starter="${k}">
              <b>${esc(PROMO_STARTERS[k].title)}</b>
              <span>${esc(PROMO_STARTERS[k].desc)}</span>
              <i data-lucide="arrow-right"></i>
            </button>`).join('')}
        </div>
      </div>`;
  }

  /* ─── réimprimer le rayon d'une promotion ────────────────────────────────
   * Le geste qui manquait entre « je lance ma promotion » et « mes étiquettes
   * disent le bon prix ». labelForVariant() pose déjà le prix promo et l'ancien
   * barré (voir plus bas) ; ce qui manquait, c'était de pouvoir sortir d'un coup
   * les étiquettes des articles que CETTE promotion touche, sans rouvrir
   * l'inventaire produit par produit pour les retrouver à la main.
   *
   * Deux filtres, tous deux volontaires :
   *  · pas de code-barres → pas d'étiquette. On ne peut pas imprimer une
   *    étiquette scannable pour une déclinaison qui n'a pas de code.
   *  · stock à zéro → pas d'étiquette. Une étiquette de promotion sur une
   *    étagère vide ne sert à rien, et sur un magasin entier ça peut faire des
   *    dizaines de vignettes jetées.
   * Le total est ANNONCÉ avant impression : une promotion « tout le magasin »
   * peut représenter plusieurs centaines de vignettes, et on ne découvre pas ça
   * au bruit de l'imprimante. */
  function promoLabelPlan(id) {
    const pr = PRM(); const p = pr && pr.get(id);
    const cat = catDB();
    const out = { promo: p, labels: [], products: 0, skippedNoCode: 0, skippedEmpty: 0 };
    if (!p || !cat) return out;
    promoItems().forEach((item) => {
      if (!pr.matches(p, item, stockOf(item))) return;
      const d = cat.getProduct(item.id);
      if (!d) return;
      let taken = 0;
      d.variants.forEach((v) => {
        if (!(v.stock > 0)) { out.skippedEmpty++; return; }
        const l = labelForVariant(item.id, v);
        if (!l) { out.skippedNoCode++; return; }
        out.labels.push(l); taken++;
      });
      if (taken) out.products++;
    });
    return out;
  }

  function openPromoLabels(id) {
    const plan = promoLabelPlan(id);
    if (!plan.promo) return;
    const el = $('#mz-promomm', root);
    const n = plan.labels.length;
    const notes = [];
    if (plan.skippedEmpty) notes.push(`${plan.skippedEmpty} déclinaison${plan.skippedEmpty > 1 ? 's' : ''} épuisée${plan.skippedEmpty > 1 ? 's' : ''}, sans étiquette`);
    if (plan.skippedNoCode) notes.push(`${plan.skippedNoCode} sans code-barres, générez-en un depuis l'inventaire`);
    el.innerHTML = `
      <button class="mz-modal-x" data-mz-close aria-label="Fermer"><i data-icon="close"></i></button>
      <h3 class="modal-title">Étiquettes · ${esc(plan.promo.name)}</h3>
      ${n ? `
        <p class="modal-subtle">Chaque étiquette portera le prix promotionnel, l'ancien prix barré à côté.
           Quand la promotion s'arrêtera, réimprimez pour revenir au prix plein.</p>
        <div class="mz-prl">
          <div class="mz-prl-n"><b>${n}</b><span>étiquette${n > 1 ? 's' : ''}</span></div>
          <div class="mz-prl-d">
            <span>${plan.products} article${plan.products > 1 ? 's' : ''} concerné${plan.products > 1 ? 's' : ''}</span>
            ${notes.map((t) => `<span class="note">${esc(t)}</span>`).join('')}
          </div>
        </div>
        ${n > 60 ? `<div class="mz-prc-warn"><i data-lucide="alert-triangle"></i>
          <span>C'est un gros tirage. Vérifiez le rouleau avant de lancer.</span></div>` : ''}
      ` : `
        <p class="modal-subtle">Aucune étiquette à imprimer pour cette promotion : les articles visés n'ont pas de
           code-barres, ou il n'en reste aucun en stock.${plan.skippedNoCode ? ' Générez leurs codes depuis l\'inventaire.' : ''}</p>`}
      <div class="mzi-modfoot">
        <button class="mz-btn secondary" data-mz-close>${n ? 'Annuler' : 'Fermer'}</button>
        ${n ? `<button class="mz-btn primary" id="mz-prl-go"><i data-lucide="printer"></i>Imprimer ${n} étiquette${n > 1 ? 's' : ''}</button>` : ''}
      </div>`;
    openVeil('#mz-promo-veil'); icons();
    $$('[data-mz-close]', el).forEach((b) => { b.onclick = () => closeVeil('#mz-promo-veil'); });
    const go = $('#mz-prl-go', el);
    if (go) go.onclick = () => {
      closeVeil('#mz-promo-veil');
      labelToast(window.KiwiBarcode.printLabels(plan.labels, { copies: 1 }), `${n} étiquette${n > 1 ? 's' : ''}`);
    };
  }

  function confirmPromoDelete(id) {
    const pr = PRM(); const p = pr.get(id); if (!p) return;
    const el = $('#mz-promomm', root);
    el.innerHTML = `
      <button class="mz-modal-x" data-mz-close aria-label="Fermer"><i data-icon="close"></i></button>
      <h3 class="modal-title">Supprimer « ${esc(p.name)} » ?</h3>
      <p class="modal-subtle">Les articles concernés repassent immédiatement au prix plein.
         Les ventes déjà encaissées gardent le prix payé · rien ne change dans le journal.</p>
      <div class="mzi-modfoot">
        <button class="mz-btn secondary" data-mz-close>Garder</button>
        <button class="mz-btn danger" id="mz-pr-delok"><i data-lucide="trash-2"></i>Supprimer</button>
      </div>`;
    openVeil('#mz-promo-veil'); icons();
    $$('[data-mz-close]', el).forEach((b) => { b.onclick = () => closeVeil('#mz-promo-veil'); });
    $('#mz-pr-delok', el).onclick = () => {
      pr.remove(id);
      closeVeil('#mz-promo-veil');
      toast(`${p.name} supprimée, prix pleins rétablis`);
      renderPromos(); renderGrid(); renderBadges(); icons();
    };
  }

  /* ─── le compositeur ─────────────────────────────────────────────────────
     Un seul écran, pas d'assistant en trois étapes : les trois décisions
     (combien, sur quoi, jusqu'à quand) se répondent l'une l'autre, et un
     assistant qui les sépare oblige à revenir en arrière pour comprendre ce
     qu'on vient de faire. L'aperçu se recalcule à chaque frappe. */
  const composer = { draft: null, editing: null };

  /* Les pourcentages autorisés dans les réglages, ou null quand rien n'est
     restreint. Un brouillon ne s'ouvre jamais sur une remise que la boutique
     refuse : sinon « Lancer » est grisé avant le premier geste. On prend le
     pourcentage autorisé le plus proche. */
  function allowedPercents() {
    const pol = window.KiwiDiscountPolicy;
    return pol && pol.configured(_bqKey) ? pol.percentages(_bqKey).slice().sort((a, b) => a - b) : null;
  }
  function fitPolicy(d) {
    const ok = allowedPercents();
    if (!ok || !ok.length || d.kind !== 'percent' || ok.includes(d.value)) return d;
    d.value = ok.reduce((best, v) => (Math.abs(v - d.value) < Math.abs(best - d.value) ? v : best), ok[0]);
    return d;
  }

  function openPromoComposer(seed) {
    const pr = PRM(); if (!pr) return;
    composer.editing = (seed && seed.id) ? seed.id : null;
    composer.draft = pr.normalize(seed || { name: '', kind: 'percent', value: 20, scope: { type: 'tout' } });
    if (!composer.editing) fitPolicy(composer.draft);
    if (!seed) composer.draft.name = '';
    renderPromoComposer();
    openVeil('#mz-promo-veil');
    icons(); lens();
  }

  const PROMO_SCOPES = [
    { id: 'tout', label: 'Tout le magasin', icon: 'store' },
    { id: 'rayon', label: 'Un rayon', icon: 'layout-grid' },
    { id: 'produits', label: 'Des articles', icon: 'shirt' },
    { id: 'avant', label: 'Ancien stock', icon: 'calendar-clock' },
    { id: 'stock', label: 'Fin de série', icon: 'package-minus' },
  ];

  function promoDraftValid(d) {
    if (!d.value) return 'Choisissez de combien vous baissez le prix';
    if (d.kind === 'percent' && window.KiwiDiscountPolicy?.configured(_bqKey)
        && !window.KiwiDiscountPolicy.allowed(d.value, _bqKey)) return 'Vos réglages autorisent seulement ' + (allowedPercents() || []).map((v) => '−' + v + ' %').join(', ');
    const sc = d.scope || {};
    if ((sc.type === 'rayon' || sc.type === 'produits') && !(sc.ids || []).length) return 'Choisissez au moins un élément à viser';
    if (sc.type === 'avant' && !sc.before) return 'Choisissez la date avant laquelle les articles sont visés';
    if (sc.type === 'stock' && !sc.max) return 'Indiquez à partir de combien de pièces l\'article est visé';
    if (d.to && d.from && d.to <= d.from) return 'La date de fin doit venir après le début';
    return '';
  }

  const toInput = (ms) => { if (!ms) return ''; const d = new Date(ms); return `${d.getFullYear()}-${pad2(d.getMonth() + 1)}-${pad2(d.getDate())}`; };

  function renderPromoComposer() {
    const pr = PRM();
    const d = composer.draft;
    const el = $('#mz-promomm', root);
    const prev = pr.preview(d, promoItems(), { stockOf: (it) => stockOf(it) });
    const problem = promoDraftValid(d);
    const sc = d.scope || {};

    el.innerHTML = `
      <button class="mz-modal-x" data-mz-close aria-label="Fermer"><i data-icon="close"></i></button>
      <h3 class="modal-title">${composer.editing ? 'Modifier la promotion' : 'Nouvelle promotion'}</h3>

      <div class="mz-prc">
        <div class="mz-prc-form">

          <div class="mz-f">
            <div class="mz-f-lbl">Nom <span class="opt">· ce que la cliente lira sur son reçu</span></div>
            <input class="mz-input" id="mz-prc-name" maxlength="80" placeholder="Soldes d'été, Déstockage annuel…" value="${esc(d.name)}" />
          </div>

          <div class="mz-f">
            <div class="mz-f-lbl">De combien</div>
            <div class="mz-seg" data-lens-demo id="mz-prc-kind">
              <button class="mz-seg-it ${d.kind === 'percent' ? 'on' : ''}" data-lens-item data-prk="percent">En pourcentage<small>−20 %</small></button>
              <button class="mz-seg-it ${d.kind === 'amount' ? 'on' : ''}" data-lens-item data-prk="amount">En dirhams<small>−50 MAD</small></button>
              <button class="mz-seg-it ${d.kind === 'fixed' ? 'on' : ''}" data-lens-item data-prk="fixed">Prix fixe<small>tout à 99</small></button>
            </div>
            <div class="mz-prc-val">
              <input class="mz-input" id="mz-prc-value" type="number" min="0" inputmode="numeric" value="${d.value}" />
              <span class="unit">${d.kind === 'percent' ? '%' : 'MAD'}</span>
              <div class="mz-chips" id="mz-prc-quick">
                ${(d.kind === 'percent' ? (window.KiwiDiscountPolicy?.percentages(_bqKey, [10, 20, 30, 50]) || [10, 20, 30, 50]) : d.kind === 'amount' ? [20, 50, 100, 200] : [49, 99, 149, 199]).map((v) =>
                  `<button class="mz-chip ${d.value === v ? 'on' : ''}" data-prv="${v}">${d.kind === 'percent' ? `−${v} %` : d.kind === 'amount' ? `−${v}` : v}</button>`).join('')}
              </div>
            </div>
          </div>

          <div class="mz-f">
            <div class="mz-f-lbl">Sur quoi</div>
            <div class="mz-prc-scopes" id="mz-prc-scope">
              ${PROMO_SCOPES.map((s) => `
                <button class="mz-prc-scope ${sc.type === s.id ? 'on' : ''}" data-prs="${s.id}">
                  <i data-lucide="${s.icon}"></i><span>${esc(s.label)}</span>
                </button>`).join('')}
            </div>
            <div class="mz-prc-scopebody" id="mz-prc-scopebody">${promoScopeControl(d)}</div>
          </div>

          <div class="mz-f">
            <div class="mz-f-lbl">Jusqu'à quand</div>
            <div class="mz-chips" id="mz-prc-when">
              ${[
                { k: 'today', l: 'Aujourd\'hui' }, { k: 'we', l: 'Ce week-end' },
                { k: '7', l: '7 jours' }, { k: '30', l: '30 jours' }, { k: 'none', l: 'Sans fin' },
              ].map((o) => `<button class="mz-chip" data-prw="${o.k}">${o.l}</button>`).join('')}
            </div>
            <div class="mz-row-2 mz-prc-dates">
              <div class="mz-f">
                <div class="mz-f-lbl">Début <span class="opt">· vide = tout de suite</span></div>
                <input class="mz-input" id="mz-prc-from" type="date" value="${toInput(d.from)}" />
              </div>
              <div class="mz-f">
                <div class="mz-f-lbl">Fin <span class="opt">· vide = sans fin</span></div>
                <input class="mz-input" id="mz-prc-to" type="date" value="${toInput(d.to)}" />
              </div>
            </div>
          </div>
        </div>

        <aside class="mz-prc-prev">
          <div class="mz-prc-prev-head">
            <span class="lbl">Ce que ça touche</span>
            <b class="n">${prev.count}</b>
            <span class="u">article${prev.count > 1 ? 's' : ''}</span>
          </div>
          ${prev.count ? `
            <div class="mz-prc-swap">
              <div><span>Valeur au prix plein</span><b>${fmtMAD(prev.from)}</b></div>
              <i data-lucide="arrow-right"></i>
              <div class="next"><span>Au prix promo</span><b>${fmtMAD(prev.to)}</b></div>
            </div>
            <div class="mz-prc-give">Vous offrez <b>${fmtMAD(prev.from - prev.to)}</b> si tout part.</div>
            ${prev.under ? `
              <div class="mz-prc-warn"><i data-lucide="alert-triangle"></i>
                <span><b>${prev.under} article${prev.under > 1 ? 's passeraient' : ' passerait'} sous son prix d'achat.</b>
                Déstocker à perte est parfois le bon choix · mais autant le décider en le sachant.</span>
              </div>` : ''}
            <div class="mz-prc-sample">
              ${prev.sample.map((x) => `
                <div class="mz-prc-srow ${x.under ? 'is-under' : ''}">
                  <span class="nm">${esc(x.name)}</span>
                  <span class="pz"><s>${fmtMAD(shelf(x.was))}</s><b>${fmtMAD(shelf(x.price))}</b></span>
                </div>`).join('')}
              ${prev.count > prev.sample.length ? `<div class="mz-prc-more">et ${prev.count - prev.sample.length} autre${prev.count - prev.sample.length > 1 ? 's' : ''}…</div>` : ''}
            </div>` : `
            <div class="mz-prc-none"><i data-lucide="search-x"></i>
              <span>${esc(problem || 'Aucun article ne correspond à cette cible.')}</span>
            </div>`}
        </aside>
      </div>

      <div class="mzi-modfoot mz-prc-foot">
        ${problem ? `<span class="mz-prc-block"><i data-lucide="info"></i>${esc(problem)}</span>` : '<span></span>'}
        <span class="acts">
          <button class="mz-btn secondary" data-mz-close>Annuler</button>
          <button class="mz-btn primary" id="mz-prc-save" ${problem || !prev.count ? 'disabled' : ''}>
            <i data-lucide="check"></i>${composer.editing ? 'Enregistrer' : 'Lancer la promotion'}
          </button>
        </span>
      </div>`;

    icons(); lens();
    wirePromoComposer(el);
  }

  function promoScopeControl(d) {
    const sc = d.scope || {};
    if (sc.type === 'tout') return '<div class="mz-prc-hint">Chaque article du magasin, sans exception.</div>';
    if (sc.type === 'rayon') {
      return `<div class="mz-chips wrap" id="mz-prc-rayons">
        ${RAYONS.map((r) => `<button class="mz-chip ${(sc.ids || []).indexOf(r.id) >= 0 ? 'on' : ''}" data-prr="${esc(r.id)}">${esc(r.label)}<small>${r.items.length}</small></button>`).join('')}
      </div>`;
    }
    if (sc.type === 'produits') {
      const ids = sc.ids || [];
      return `
        <div class="bqx-scanbox slim"><i data-lucide="search"></i>
          <input id="mz-prc-q" placeholder="Chercher un article, ou scanner son code-barres…" autocomplete="off" />
        </div>
        <div class="mz-prc-picked" id="mz-prc-picked">
          ${ids.length ? ids.map((id) => { const it = P[id]; return `<button class="mz-chip on" data-prp="${esc(id)}">${esc(it ? it.name : id)} <i data-lucide="x"></i></button>`; }).join('')
            : '<span class="mz-prc-hint">Aucun article choisi pour l\'instant.</span>'}
        </div>
        <div class="mz-prc-hits" id="mz-prc-hits"></div>`;
    }
    if (sc.type === 'avant') {
      /* Les raccourcis d'abord : « plus de six mois » est la phrase que le
         commerçant a en tête, pas une date de calendrier qu'il devra calculer. */
      return `
        <div class="mz-chips" id="mz-prc-age">
          ${[{ m: 3, l: 'Plus de 3 mois' }, { m: 6, l: 'Plus de 6 mois' }, { m: 12, l: 'Plus d\'un an' }].map((o) =>
            `<button class="mz-chip" data-pra="${o.m}">${o.l}</button>`).join('')}
        </div>
        <input class="mz-input" id="mz-prc-before" type="date" value="${toInput(sc.before)}" />
        <div class="mz-prc-hint">Vise les articles entrés dans l'inventaire avant cette date. Un arrivage postérieur n'est jamais remisé, même s'il porte le même nom.</div>`;
    }
    if (sc.type === 'stock') {
      return `
        <div class="mz-chips" id="mz-prc-max">
          ${[2, 3, 5, 10].map((n) => `<button class="mz-chip ${sc.max === n ? 'on' : ''}" data-prm="${n}">${n} ou moins</button>`).join('')}
        </div>
        <input class="mz-input" id="mz-prc-maxn" type="number" min="1" value="${sc.max || ''}" placeholder="ou un seuil à vous" />
        <div class="mz-prc-hint">La cible se recalcule toute seule : un article qui repasse au-dessus du seuil après un réassort sort de la promotion, un autre qui descend y entre.</div>`;
    }
    return '';
  }

  function wirePromoComposer(el) {
    const pr = PRM();
    const d = composer.draft;
    const redraw = () => renderPromoComposer();
    /* Le nom se saisit SANS redessiner : un re-rendu à chaque touche vole le
       curseur au milieu du mot. Il ne change aucun prix, il n'a rien à repeindre. */
    const nameEl = $('#mz-prc-name', el);
    if (nameEl) nameEl.oninput = () => { d.name = nameEl.value; const b = $('#mz-prc-save', el); if (b) b.disabled = !!promoDraftValid(d) || !pr.preview(d, promoItems(), { stockOf: (it) => stockOf(it) }).count; };

    $$('[data-prk]', el).forEach((b) => b.onclick = () => { d.kind = b.dataset.prk; fitPolicy(d); redraw(); });
    const val = $('#mz-prc-value', el);
    if (val) val.oninput = () => { d.value = Math.max(0, Math.round(+val.value || 0)); redraw(); };
    $$('[data-prv]', el).forEach((b) => b.onclick = () => { d.value = +b.dataset.prv; redraw(); });
    $$('[data-prs]', el).forEach((b) => b.onclick = () => { d.scope = pr.normalize({ scope: { type: b.dataset.prs } }).scope; redraw(); });

    $$('[data-prr]', el).forEach((b) => b.onclick = () => {
      const ids = d.scope.ids || (d.scope.ids = []);
      const i = ids.indexOf(b.dataset.prr);
      if (i >= 0) ids.splice(i, 1); else ids.push(b.dataset.prr);
      redraw();
    });
    $$('[data-prp]', el).forEach((b) => b.onclick = () => {
      const ids = d.scope.ids || [];
      const i = ids.indexOf(b.dataset.prp);
      if (i >= 0) ids.splice(i, 1);
      redraw();
    });
    const q = $('#mz-prc-q', el);
    if (q) {
      const hits = $('#mz-prc-hits', el);
      const paint = () => {
        const term = q.value.trim().toLowerCase();
        if (!term) { hits.innerHTML = ''; return; }
        /* Un code-barres scanné dans ce champ désigne un article précis : on
           passe par la base, pas par le nom, sinon la douchette ne sert à rien ici. */
        const byCode = BY_EAN[q.value.trim()];
        const found = byCode ? [P[byCode]].filter(Boolean)
          : promoItems().filter((it) => it.name.toLowerCase().indexOf(term) >= 0).slice(0, 8);
        hits.innerHTML = found.map((it) => `<button class="mz-prc-hit" data-prpick="${esc(it.id)}">
            <span>${esc(it.name)}</span><b>${fmtMAD(shelf(it.price))}</b></button>`).join('')
          || '<div class="mz-prc-hint">Aucun article ne porte ce nom.</div>';
        $$('[data-prpick]', hits).forEach((b) => b.onclick = () => {
          const ids = d.scope.ids || (d.scope.ids = []);
          if (ids.indexOf(b.dataset.prpick) < 0) ids.push(b.dataset.prpick);
          redraw();
        });
      };
      q.oninput = paint;
      q.onkeydown = (e) => { if (e.key === 'Enter') { e.preventDefault(); paint(); } };
    }
    $$('[data-pra]', el).forEach((b) => b.onclick = () => { d.scope.before = startOfDay(new Date(Date.now() - (+b.dataset.pra) * 30 * PROMO_DAY)); redraw(); });
    const before = $('#mz-prc-before', el);
    if (before) before.onchange = () => { d.scope.before = before.value ? startOfDay(new Date(before.value + 'T12:00:00')) : 0; redraw(); };
    $$('[data-prm]', el).forEach((b) => b.onclick = () => { d.scope.max = +b.dataset.prm; redraw(); });
    const maxn = $('#mz-prc-maxn', el);
    if (maxn) maxn.oninput = () => { d.scope.max = Math.max(0, Math.round(+maxn.value || 0)); redraw(); };

    $$('[data-prw]', el).forEach((b) => b.onclick = () => {
      const k = b.dataset.prw, now = new Date();
      if (k === 'none') { d.to = 0; }
      else if (k === 'today') { d.to = endOfDay(now); }
      else if (k === 'we') {
        /* « Ce week-end » = jusqu'à dimanche soir. Un dimanche, c'est ce soir —
           pas dans sept jours : le commerçant qui pose sa promotion le dimanche
           matin veut qu'elle finisse le soir même. */
        const toSunday = (7 - now.getDay()) % 7;
        d.to = endOfDay(new Date(now.getTime() + toSunday * PROMO_DAY));
      } else { d.to = endOfDay(new Date(now.getTime() + (+k) * PROMO_DAY)); }
      redraw();
    });
    const from = $('#mz-prc-from', el);
    if (from) from.onchange = () => { d.from = from.value ? startOfDay(new Date(from.value + 'T12:00:00')) : 0; redraw(); };
    const to = $('#mz-prc-to', el);
    if (to) to.onchange = () => { d.to = to.value ? endOfDay(new Date(to.value + 'T12:00:00')) : 0; redraw(); };

    $$('[data-mz-close]', el).forEach((b) => { b.onclick = () => closeVeil('#mz-promo-veil'); });
    const save = $('#mz-prc-save', el);
    if (save) save.onclick = () => {
      if (promoDraftValid(d)) return;
      if (!d.name.trim()) d.name = promoAutoName(d);
      if (composer.editing) d.id = composer.editing;
      pr.save(d);
      closeVeil('#mz-promo-veil');
      toast(composer.editing ? `${d.name} enregistrée` : `${d.name} lancée, les prix sont à jour`);
      renderPromos(); renderGrid(); renderBadges(); icons(); lens();
    };
  }

  /* Un nom laissé vide ne doit pas produire « Promotion » sur le reçu de la
     cliente : on écrit ce que la promotion FAIT, c'est plus utile qu'un blanc. */
  function promoAutoName(d) {
    const sc = d.scope || {};
    if (sc.type === 'avant') return 'Déstockage';
    if (sc.type === 'stock') return 'Fins de série';
    if (sc.type === 'rayon') return promoScopeText(d);
    if (sc.type === 'produits') return 'Sélection';
    return d.kind === 'percent' ? `Tout le magasin −${d.value} %` : 'Promotion';
  }

  /* ─── mouvements de stock ───────────────────────────────────────────────
   * La caisse lit exactement le même registre durable que le dashboard. Elle
   * ne possède pas un deuxième historique local : ventes, retours, casse,
   * réceptions et corrections restent donc réconciliables au même endroit. */
  function movementRows() {
    const MZ = window.KiwiMaisonStock;
    if (!MZ) return [];
    const filter = {
      q: state.movementQuery || '',
      type: state.movementType || '',
      categoryId: state.movementCategory || '',
    };
    if (state.movementDays) filter.from = Date.now() - state.movementDays * 86400000;
    return MZ.list(filter);
  }

  function movementSource(source) {
    if (source === 'caisse') return 'Caisse';
    if (source === 'dashboard') return 'Tableau de bord';
    if (source === 'import') return 'Import';
    return source || '·';
  }

  function movementTable(rows) {
    if (!rows.length) return `<div class="mz-empty mzm-empty">
      <i data-lucide="history"></i><b>Aucun mouvement trouvé</b>
      <span>Changez les filtres ou enregistrez une entrée ou une sortie.</span>
    </div>`;
    return `<div class="mzm-table-wrap" tabindex="0" role="region" aria-label="${esc(window.KiwiCaisseLang?.tr('Mouvements') || 'Mouvements')}"><table class="mzm-table">
      <thead><tr><th>Date</th><th>Produit</th><th>Type</th><th>Qté</th><th>Avant → après</th><th>Employé</th><th>Source</th><th>Référence · note</th></tr></thead>
      <tbody>${rows.map((m) => `<tr>
        <td class="mzm-muted">${esc(new Date(m.at).toLocaleString('fr-FR', { day: '2-digit', month: '2-digit', year: '2-digit', hour: '2-digit', minute: '2-digit' }))}${m.pending ? '<small>En attente de synchro</small>' : ''}</td>
        <td><b>${esc(m.product || '·')}</b>${m.variant ? `<small>${esc(m.variant)}</small>` : ''}</td>
        <td><span class="mzm-chip ${m.dir > 0 ? 'in' : 'out'}">${esc(m.typeLabel || 'Mouvement')}</span></td>
        <td class="mzm-qty ${m.dir > 0 ? 'in' : 'out'}">${m.dir > 0 ? '+' : '−'}${Math.abs(m.qty)}</td>
        <td class="mzm-muted">${m.before == null ? '·' : `${m.before} → ${m.after}`}</td>
        <td class="mzm-optional">${esc(m.actor || '·')}</td>
        <td class="mzm-optional mzm-muted">${esc(movementSource(m.source))}${m.supplier ? `<small>${esc(m.supplier)}</small>` : ''}</td>
        <td class="mzm-optional mzm-muted">${esc(m.ref || '·')}${m.note ? `<small>${esc(m.note)}</small>` : ''}</td>
      </tr>`).join('')}</tbody>
    </table></div>`;
  }

  function updateMovementResults(panel) {
    const MZ = window.KiwiMaisonStock;
    if (!MZ) return;
    const rows = movementRows();
    const totals = MZ.totals(rows);
    const balance = totals.entries - totals.exits;
    const kpis = $('#mzm-kpis', panel);
    if (kpis) kpis.innerHTML = `
      <div class="mzm-kpi"><span>Mouvements</span><b>${totals.count}</b><small>${state.movementDays ? `${state.movementDays} derniers jours` : 'Tout l’historique'}</small></div>
      <div class="mzm-kpi"><span>Entrées</span><b class="in">+${totals.entries}</b><small>Pièces ajoutées</small></div>
      <div class="mzm-kpi"><span>Sorties</span><b class="out">−${totals.exits}</b><small>Pièces sorties</small></div>
      <div class="mzm-kpi"><span>Solde</span><b>${balance >= 0 ? '+' : '−'}${Math.abs(balance)}</b><small>Variation nette</small></div>`;
    const table = $('#mzm-results', panel);
    if (table) table.innerHTML = movementTable(rows);
    icons();
  }

  function renderMovements() {
    const panel = $('[data-mz-panel="mouvements"]', root);
    const MZ = window.KiwiMaisonStock;
    const cat = catDB();
    if (!panel) return;
    if (!MZ || !cat) {
      panel.innerHTML = '<div class="mz-empty" style="margin:40px;">Registre des mouvements indisponible. Rechargez la caisse.</div>';
      return;
    }
    MZ.enable();
    const facets = MZ.facets();
    const categories = cat.listCategories() || [];
    const option = (value, label, current) => `<option value="${esc(value)}"${String(value) === String(current) ? ' selected' : ''}>${esc(label)}</option>`;
    panel.innerHTML = `<div class="mzm-view mz-page">
      <header class="mz-head mzm-head">
        <div><button class="mz-btn ghost mz-back-inv" data-mz-back-inv><i data-icon="arrow_back"></i>Inventaire</button><h1>Mouvements de stock</h1><div class="mz-head-sub">Chaque entrée et chaque sortie, avec le stock avant et après${state.movementSyncing ? ' · synchronisation…' : ''}</div></div>
        <button class="mz-btn primary" id="mzm-new"><i data-lucide="plus"></i>Nouveau mouvement</button>
      </header>
      <div class="mzm-kpis" id="mzm-kpis"></div>
      <div class="mzm-tools">
        <label class="mz-search mzm-search"><i data-lucide="search"></i><input id="mzm-search" value="${esc(state.movementQuery)}" placeholder="Produit, type, référence…" autocomplete="off" /></label>
        <select id="mzm-days" aria-label="Période">
          ${[['0', 'Tout'], ['7', '7 jours'], ['30', '30 jours'], ['90', '90 jours'], ['365', '12 mois']].map(([v, l]) => option(v, l, state.movementDays)).join('')}
        </select>
        <select id="mzm-kind" aria-label="Type de mouvement">
          ${option('', 'Tous les types', state.movementType)}
          ${MZ.types().filter((t) => !facets.types.length || facets.types.includes(t.id)).map((t) => option(t.id, `${t.dir > 0 ? '↑' : '↓'} ${t.label}`, state.movementType)).join('')}
        </select>
        <select id="mzm-category" aria-label="Catégorie">
          ${option('', 'Toutes catégories', state.movementCategory)}
          ${categories.map((c) => option(c.id, c.name, state.movementCategory)).join('')}
        </select>
      </div>
      <div class="mzm-results" id="mzm-results"></div>
      <div class="mzm-foot"><i data-lucide="shield-check"></i><span>Les ventes et retours s’écrivent ici automatiquement. Un mouvement manuel demande le code d’un responsable.</span></div>
    </div>`;
    updateMovementResults(panel);
    const search = $('#mzm-search', panel);
    search.addEventListener('input', () => { state.movementQuery = search.value.trim(); updateMovementResults(panel); });
    $('#mzm-days', panel).addEventListener('change', (e) => { state.movementDays = parseInt(e.target.value, 10) || 0; updateMovementResults(panel); });
    $('#mzm-kind', panel).addEventListener('change', (e) => { state.movementType = e.target.value; updateMovementResults(panel); });
    $('#mzm-category', panel).addEventListener('change', (e) => { state.movementCategory = e.target.value; updateMovementResults(panel); });
    $('#mzm-new', panel).addEventListener('click', openMovementPicker);
    icons();
  }

  function openMovementPicker() {
    const cat = catDB();
    if (!cat || !window.KiwiMaisonStock) return;
    const products = cat.listProducts({}) || [];
    const html = `
      <button class="mz-modal-x" data-inv-x aria-label="Fermer"><i data-lucide="x"></i></button>
      <div class="mzi-modh"><span class="mzi-art"><i data-lucide="package-plus"></i></span><div><h3>Nouveau mouvement de stock</h3><span>Choisissez l’article exact avant de saisir l’entrée ou la sortie.</span></div></div>
      <div class="mzi-form">
        ${products.length ? `<div class="mzi-fg"><label>Rechercher un produit</label><input id="mzm-pick-search" placeholder="Nom du produit…" autocomplete="off" /></div>
        <div class="mzi-fg"><label>Produit</label><select id="mzm-pick-product"></select></div>
        <div class="mzi-fg"><label>Variante</label><select id="mzm-pick-variant"></select></div>` : '<div class="mz-empty">Aucun produit actif. Ajoutez d’abord un article dans Inventaire.</div>'}
      </div>
      <div class="mzi-modfoot"><button class="mz-btn secondary" data-inv-x>Annuler</button><button class="mz-btn" id="mzm-pick-next"${products.length ? '' : ' disabled'}>Continuer</button></div>`;
    invSetModal(html, (el) => {
      const productSelect = $('#mzm-pick-product', el);
      const variantSelect = $('#mzm-pick-variant', el);
      const next = $('#mzm-pick-next', el);
      if (!products.length || !productSelect || !variantSelect || !next) return;
      const fillProducts = (query) => {
        const q = String(query || '').trim().toLowerCase();
        const matches = products.filter((p) => !q || String(p.name || '').toLowerCase().includes(q));
        const previous = productSelect.value;
        productSelect.innerHTML = matches.map((p) => `<option value="${esc(p.id)}">${esc(p.name)}</option>`).join('') || '<option value="">Aucun produit trouvé</option>';
        if (matches.some((p) => p.id === previous)) productSelect.value = previous;
        fillVariants();
      };
      const fillVariants = () => {
        const variants = productSelect.value ? (cat.listVariants(productSelect.value) || []) : [];
        variantSelect.innerHTML = variants.map((v) => `<option value="${esc(v.id)}">${esc([v.size, variantColor(v).label].filter(Boolean).join(' · '))} · ${v.stock} en stock</option>`).join('') || '<option value="">Aucune variante</option>';
        next.disabled = !productSelect.value || !variantSelect.value;
      };
      fillProducts('');
      productSelect.addEventListener('change', fillVariants);
      $('#mzm-pick-search', el).addEventListener('input', (e) => fillProducts(e.target.value));
      next.addEventListener('click', () => {
        if (productSelect.value && variantSelect.value) openStockMove(productSelect.value, variantSelect.value);
      });
    });
  }

  /* ─── the inventory panel ─── */
  const catalogueAdminEnabled = tillInventoryAllowed;   // interrupteur + qui est au pavé (till-inventory-access.js)
  function inventoryValueVisible() {
    return !(window.KiwiConfig && window.KiwiConfig.features && window.KiwiConfig.features.caisseInventoryValue === false);
  }
  function catalogDashboardOnly() {
    if (typeof toast === 'function') toast(tillInventoryRefusal());
  }

  /* Le panneau est repeint à chaque changement du catalogue (synchronisation,
     vente sur une autre caisse, retour sur l'onglet). Réécrire la barre d'outils
     faisait perdre le curseur de la recherche au bout d'une seconde : on
     cliquait, plus rien ne s'écrivait (propriétaire, 2026-10-30). Comme la
     boutique (pos-boutique/inv-tools.js › invPaint) : la barre déjà montée ne
     quitte jamais le document, on remplace seulement ce qui l'entoure. */
  function mzInvPaint(panel, html) {
    const box = panel.querySelector(':scope > .bqi');
    const tools = box && box.querySelector(':scope > .mzi-tools');
    if (!tools || !tools.querySelector('#mzi-scan')) { panel.innerHTML = html; return false; }
    const tmp = document.createElement('div');
    tmp.innerHTML = html;
    const fresh = tmp.querySelector(':scope > .bqi');
    const kids = fresh ? [...fresh.children] : [];
    const at = kids.findIndex((k) => k.classList.contains('mzi-tools'));
    if (at < 0) { panel.innerHTML = html; return false; }
    const mzKeepAround = (parent, keep, fresh, i) => {
      [...parent.children].forEach((k) => { if (k !== keep) k.remove(); });
      fresh.slice(0, i).forEach((k) => parent.insertBefore(k, keep));
      fresh.slice(i + 1).forEach((k) => parent.appendChild(k));
    };
    mzKeepAround(box, tools, kids, at);
    /* Dans la rangée aussi, seule la recherche reste : les boutons suivent le
       droit de la personne au pavé (Catégories, Nouvel article), qui peut
       arriver après le premier dessin. */
    const scanBox = tools.querySelector(':scope > .mzi-scan');
    const freshKids = [...kids[at].children];
    const sAt = freshKids.findIndex((k) => k.classList.contains('mzi-scan'));
    if (scanBox && sAt >= 0) mzKeepAround(tools, scanBox, freshKids, sAt);
    return true;
  }

  function renderInventaire() {
    const cat = catDB();
    const panel = $('[data-mz-panel="inventaire"]', root);
    if (!cat) { panel.innerHTML = '<div class="mz-empty" style="margin:40px;">Base d\'inventaire indisponible.</div>'; return; }
    const st = cat.stats();
    const cats = cat.listCategories();
    const filter = state.invFilter || 'all';
    const products = cat.listProducts({ categoryId: filter, q: state.invQuery || '' });
    mzInvPaint(panel, `
      <div class="bqi mz-page">
        <header class="mz-head">
          <div><h1>Inventaire</h1><div class="mz-head-sub">Douchette + imprimante étiquettes · ${st.products} ${st.products > 1 ? 'produits' : 'produit'} · ${st.variants} ${st.variants > 1 ? 'variantes' : 'variante'}, base partagée avec le dashboard</div></div>
        </header>
        <div class="mzi-tools">
          <div class="mzi-scan"><i data-lucide="scan-line"></i><input id="mzi-scan" placeholder="Scannez un article, ou tapez un code…" autocomplete="off" /></div>
          <button class="mz-btn primary" id="mzi-count" style="background:#059669;border-color:#047857;"><i data-lucide="clipboard-check"></i>Inventaire physique</button>
          <button class="mz-btn" id="mzi-moves"><i data-icon="history"></i>Mouvements de stock</button>
          <button class="mz-btn" id="mzi-casse"><i data-icon="gpp_maybe"></i>Déclarer casse</button>
          <button class="mz-btn" id="mzi-intake"><i data-lucide="scan-barcode"></i>Reprendre le stock</button>
          ${catalogueAdminEnabled() ? '<button class="mz-btn" id="mzi-category"><i data-icon="folder_copy"></i>Catégories</button><button class="mz-btn primary" id="mzi-new"><i data-icon="add"></i>Nouvel article</button>' : `<span class="mzi-dashboard-only">${esc(tillInventoryRefusal())}</span>`}
        </div>
        <div class="mzi-pills" id="mzi-pills">
          <button class="mzi-pill ${filter === 'all' ? 'on' : ''}" data-f="all">Tous · ${st.products}</button>
          ${cats.map((c) => `<button class="mzi-pill ${filter === c.id ? 'on' : ''}" data-f="${c.id}">${esc(c.name)} · ${cat.categoryCount(c.id)}</button>`).join('')}
        </div>
        <div class="mzi-kpis">
          <!-- boutique réelle : ce que le stock a COÛTÉ (chiffre de compta / assurance).
               La démo garde sa valeur au prix de vente. Voir stats() dans boutique-catalog.js. -->
          ${inventoryValueVisible() ? `<div class="mzi-kpi"><span class="l">Valeur de stock</span><span class="v">${fmtNum(IS_DEMO ? st.stockValue : st.stockCost)} MAD</span></div>` : ''}
          <div class="mzi-kpi"><span class="l">Pièces en stock</span><span class="v">${st.totalStock}</span></div>
          <div class="mzi-kpi ${st.low || st.ruptures ? 'warn' : ''}"><span class="l">Stock bas / rupture</span><span class="v">${st.low} + ${st.ruptures}</span></div>
        </div>
        <div class="mzi-list">
          ${products.length ? products.map((p) => invRow(p)).join('') : `<div class="mz-empty mzi-first">
              <i data-lucide="scan-barcode"></i>
              <b>Votre stock porte déjà des codes-barres ?</b>
              <span>Touchez « Reprendre le stock » et scannez vos articles un par un : Kiwi garde le code du fournisseur tel quel. Aucune étiquette à réimprimer.</span>
              <em>Pour créer un article ou modifier un prix, ouvrez le tableau de bord. Ici, vous pouvez reprendre le stock et les codes existants.</em>
            </div>`}
        </div>
      </div>`);
    const scan = $('#mzi-scan', panel);
    if (scan) scan.onkeydown = (e) => { if (e.key === 'Enter') { const v = scan.value.trim(); scan.value = ''; if (v) invScanHandle(v); } };
    mzInvSearch($('.mzi-scan', panel), scan, mzSkinOn(), { code: (c) => invScanHandle(c), open: (pid) => openInvProduct(pid), money: fmtMAD, esc, icons, artOf,
      catalog: () => ({ P, BY_EAN, promoFor, shelf, stockOf, colorLabel, availableStock: (pid, size) => (P[pid] && P[pid].sizes && P[pid].sizes[size]) || 0 }) });   // peau 2027 : la liste de la boutique
    const cb = $('#mzi-count', panel); if (cb) cb.onclick = () => window.KiwiPosInventoryCount?.open?.({ engine: 'maison' });
    /* Mouvements et casse vivent DANS l'Inventaire (propriétaire, 2026-10-30) : plus de place à eux dans le rail. */
    const mvb = $('#mzi-moves', panel); if (mvb) mvb.onclick = () => openMoves({ setModal: invSetModal, esc, icons, catDB, toast, onNew: openMovementPicker });   // la fenêtre de la boutique (inv-moves.js)
    const csb = $('#mzi-casse', panel); if (csb) csb.onclick = () => switchView('casse');
    const ib = $('#mzi-intake', panel); if (ib) ib.onclick = () => openIntake();
    const nb = $('#mzi-new', panel); if (nb) nb.onclick = openNewProduct;
    const mb = $('#mzi-category', panel); if (mb) mb.onclick = openCategories;
    const pills = $('#mzi-pills', panel);
    if (pills) pills.addEventListener('click', (e) => { const b = e.target.closest('[data-f]'); if (b) { state.invFilter = b.dataset.f; renderInventaire(); } });
    panel.querySelectorAll('[data-inv-open]').forEach((el) => el.addEventListener('click', () => openInvProduct(el.getAttribute('data-inv-open'))));
    panel.querySelectorAll('[data-inv-print]').forEach((el) => el.addEventListener('click', (e) => { e.stopPropagation(); printProductLabels(el.getAttribute('data-inv-print')); }));
    icons();
  }

  function invRow(p) {
    const cat = catDB();
    const d = cat.getProduct(p.id);
    const nBc = d.variants.reduce((s, v) => s + ((v.barcodes && v.barcodes.length) ? 1 : 0), 0);
    const cls = d.stock === 0 ? 'rupture' : (d.stock <= 5 ? 'bas' : '');
    return `<div class="mzi-row" data-inv-open="${p.id}">
      <span class="mzi-art">${artOf(p)}</span>
      <span class="mzi-info"><b>${esc(p.name)}</b><span>${d.category ? esc(d.category.name) : 'Divers'} · ${d.colors.length} coul. · ${d.sizes.length} taille${d.sizes.length > 1 ? 's' : ''} · ${nBc}/${d.variants.length} codes-barres</span></span>
      <span class="mzi-stock ${cls}">${d.stock}</span>
      <span class="mzi-price">${fmtMAD(shelf(p.priceMAD))}</span>
      <button class="mzi-mini" data-inv-print="${p.id}" title="Imprimer toutes les étiquettes"><i data-lucide="printer"></i></button>
    </div>`;
  }

  /* ─── single-veil modal host (content-swapping keeps it simple) ─── */
  function invSetModal(html, wire) {
    const el = $('#mz-invmm', root);
    if (!el) return;
    /* Chaque écran repart d'une douchette NON captée : c'est celui qui s'affiche
     * qui la réclame, dans son wire(). Sans ce reset, l'écran quitté garderait la
     * main et la douchette écrirait dans un formulaire qui n'existe plus — plus
     * aucun scan n'atteindrait jamais le ticket. */
    disarmScanCapture();
    el.style.width = '';   // seul l'écran des mouvements s'élargit ; les autres gardent la largeur livrée
    el.innerHTML = html;
    if (!$('#mz-inv-veil', root).classList.contains('is-open')) openVeil('#mz-inv-veil');
    el.querySelectorAll('[data-inv-x]').forEach((b) => b.addEventListener('click', () => {
      closeVeil('#mz-inv-veil');
      disarmScanCapture();
      intake.open = false;
    }));
    if (wire) wire(el);
    icons();
    lens();
  }

  function openInvProduct(pid) {
    const cat = catDB(); const d = cat.getProduct(pid); if (!d) return;
    const p = d.product;
    const movements = window.KiwiMaisonStock?.productHistory?.(pid, 20) || [];
    const rows = d.variants.length
      ? d.variants.map((v) => invVarRow(v)).join('')
      : '<tr><td colspan="4" style="text-align:center;padding:18px;color:#99a;">Aucune variante, ajoutez une couleur × taille.</td></tr>';
    const html = `
      <button class="mz-modal-x" data-inv-x aria-label="Fermer"><i data-lucide="x"></i></button>
      <div class="mzi-modh">
        <span class="mzi-art">${artOf(p)}</span>
        <div><h3>${esc(p.name)}</h3><span>${d.category ? esc(d.category.name) : 'Divers'} · ${fmtMAD(shelf(p.priceMAD))} · ${d.stock} en stock</span></div>
        ${catalogueAdminEnabled() ? `<button class="mz-btn secondary sm" data-inv-edit="${p.id}"><i data-lucide="pencil"></i>Modifier</button>` : '<span class="mzi-dashboard-only">Gestion complète désactivée</span>'}
      </div>
      <div class="mzi-vtable-wrap" tabindex="0" role="region" aria-label="${esc(p.name)}"><table class="mzi-vtable">
        <thead><tr><th>Couleur · Taille</th><th>Stock</th><th>Code-barres</th><th></th></tr></thead>
        <tbody>${rows}</tbody></table></div>
      <div class="mzi-form" style="padding-top:0;">
        <div class="mzi-fg"><label>Historique des mouvements</label>
          ${movements.length ? `<div class="mzi-vtable-wrap" tabindex="0" role="region" aria-label="${esc(p.name)}"><table class="mzi-vtable"><thead><tr><th>Date</th><th>Mouvement</th><th>Qté</th><th>Référence</th></tr></thead><tbody>${movements.map((m) => `<tr><td>${esc(whenLabel(m.at))}</td><td>${esc(m.typeLabel || m.reason || 'Mouvement')}${m.note ? `<div class="mzi-csrc">${esc(m.note)}</div>` : ''}</td><td><b>${m.qty > 0 ? '+' : ''}${m.qty}</b></td><td>${esc(m.ref || '·')}</td></tr>`).join('')}</tbody></table></div>` : '<div class="mzi-dashboard-only">Aucun mouvement enregistré pour cet article.</div>'}
        </div>
      </div>
      <div class="mzi-modfoot">
        ${catalogueAdminEnabled() ? `<button class="mz-btn secondary" data-inv-addvar><i data-lucide="plus"></i>Ajouter une variante</button>` : '<span class="mzi-dashboard-only">Variantes dans le tableau de bord</span>'}
        <button class="mz-btn secondary" data-inv-printall><i data-lucide="printer"></i>Imprimer les étiquettes</button>
        ${catalogueAdminEnabled() ? `<button class="mz-btn danger" data-inv-delete><i data-lucide="trash-2"></i>Supprimer</button>` : '<span class="mzi-dashboard-only">Suppression dans le tableau de bord</span>'}
      </div>`;
    invSetModal(html, (el) => {
      const cat2 = catDB();
      $('[data-inv-printall]', el).addEventListener('click', () => printProductLabels(pid));
      const edit = $('[data-inv-edit]', el); if (edit) edit.addEventListener('click', () => openEditProduct(pid));
      const addvar = $('[data-inv-addvar]', el); if (addvar) addvar.addEventListener('click', () => openAddVariant(pid));
      const del = $('[data-inv-delete]', el); if (del) del.addEventListener('click', () => confirmDeleteProduct(pid));
      el.querySelectorAll('[data-vgen]').forEach((b) => b.addEventListener('click', () => { const code = cat2.generateBarcode(b.dataset.vgen); if (code) toast(`EAN-13 ${code} généré`); openInvProduct(pid); }));
      el.querySelectorAll('[data-vprint]').forEach((b) => b.addEventListener('click', () => printVariantLabel(b.dataset.vprint)));
      el.querySelectorAll('[data-vreg]').forEach((b) => b.addEventListener('click', () => openRegisterOnVariant(b.dataset.vreg, pid)));
      el.querySelectorAll('[data-vmove]').forEach((b) => b.addEventListener('click', () => openStockMove(pid, b.dataset.vmove)));
      el.querySelectorAll('[data-vcolor]').forEach((b) => b.addEventListener('click', () => openVariantColor(b.dataset.vcolor, pid)));
      el.querySelectorAll('[data-vdelete]').forEach((b) => b.addEventListener('click', () => confirmDeleteVariant(b.dataset.vdelete, pid)));
    });
  }

  /* ── DÉCLARER UN MOUVEMENT DEPUIS LE COMPTOIR ─────────────────────────────
   * Une pièce cassée en vitrine, un carton reçu du fournisseur, une pièce
   * envoyée à l'autre magasin : ces gestes se font AU COMPTOIR, pas devant un
   * ordinateur, et jusqu'ici ils n'avaient nulle part où aller — le stock se
   * corrigeait à la main, sans rien raconter.
   * Le mouvement bouge le stock partagé ET écrit sa ligne au registre dans le
   * même geste (assets/maison-stock-movements.js). Si la personne qui tient la
   * caisse n'est pas responsable, le pavé d'autorisation s'ouvre : le code du
   * responsable est vérifié par le serveur, qui délivre une capacité liée à CE
   * mouvement-là. Un refus remet la marchandise exactement où elle était. */
  function openStockMove(pid, vid) {
    const MZ = window.KiwiMaisonStock;
    const cat = catDB(); const d = cat.getProduct(pid);
    if (!MZ || !d) return;
    MZ.enable();
    const v = (d.variants || []).find((x) => x.id === vid);
    if (!v) return;
    const kinds = MZ.types().filter((t) => t.manual);
    const html = `
      <button class="mz-modal-x" data-inv-x aria-label="Fermer"><i data-lucide="x"></i></button>
      <div class="mzi-modh">
        <span class="mzi-art">${artOf(d.product)}</span>
        <div><h3>Mouvement de stock</h3><span>${esc(d.product.name)} · ${esc(v.size)} ${esc(variantColor(v).label)} · ${v.stock} en stock</span></div>
      </div>
      <div class="mzi-form">
        <div class="mzi-fg"><label>Type de mouvement</label>
          <select id="mzm-type">${kinds.map((t) => `<option value="${t.id}">${t.dir > 0 ? '↑ Entrée · ' : '↓ Sortie · '}${esc(t.label)}</option>`).join('')}</select></div>
        <div class="mzi-frow">
          <div class="mzi-fg"><label>Quantité</label><input id="mzm-qty" type="number" min="1" step="1" value="1" /></div>
          <div class="mzi-fg"><label>Fournisseur / destination</label><input id="mzm-sup" placeholder="Facultatif" /></div>
        </div>
        <div class="mzi-frow">
          <div class="mzi-fg"><label>Référence</label><input id="mzm-ref" placeholder="Bon de livraison, ticket…" /></div>
          <div class="mzi-fg"><label>Note</label><input id="mzm-note" maxlength="200" placeholder="Facultatif" /></div>
        </div>
        <div class="bqx-hint" id="mzm-hint">Le stock et le registre bougent ensemble : ce mouvement restera lisible dans l'historique du produit.</div>
      </div>
      <div class="mzi-modfoot">
        <button class="mz-btn secondary" data-inv-back>Retour</button>
        <button class="mz-btn" id="mzm-save">Enregistrer le mouvement</button>
      </div>`;
    invSetModal(html, (el) => {
      $('[data-inv-back]', el).addEventListener('click', () => openInvProduct(pid));
      $('#mzm-save', el).addEventListener('click', () => {
        const type = $('#mzm-type', el).value;
        const qty = parseInt($('#mzm-qty', el).value, 10) || 0;
        const btn = $('#mzm-save', el);
        btn.disabled = true;
        Promise.resolve(MZ.requestManual({
          productId: pid, variantId: vid, type, qty,
          supplier: $('#mzm-sup', el).value.trim(), ref: $('#mzm-ref', el).value.trim(),
          note: $('#mzm-note', el).value.trim(), source: 'caisse',
        })).then((res) => {
          btn.disabled = false;
          if (!res || !res.ok) {
            const why = res && res.reason === 'stock-insuffisant'
              ? `Stock insuffisant : il n'y a que ${res.before} pièce(s).`
              : res && res.reason === 'quantite' ? 'Indiquez une quantité.'
                : res && res.reason === 'non-autorise' ? 'Mouvement non autorisé · code responsable requis.'
                  : res && res.reason === 'reseau' ? 'Réseau indisponible · réessayez pour faire autoriser ce mouvement.'
                    : 'Mouvement impossible.';
            const hint = $('#mzm-hint', el);
            if (hint) { hint.textContent = why; hint.className = 'bqx-hint is-warn'; }
            return;
          }
          toast(`${d.product.name} · ${v.size} : ${res.before} → ${res.after}`);
          if (state.view === 'mouvements') renderMovements();
          openInvProduct(pid);
        });
      });
    });
  }

  function invVarRow(v) {
    const primary = (v.barcodes || []).find((b) => b.primary) || (v.barcodes || [])[0];
    const bc = primary
      ? `<div class="mzi-bc">${window.KiwiBarcode.svg(primary.code, { height: 26, module: 1.1, showText: false })}<span class="mzi-code">${esc(primary.code)}<em class="${primary.type === 'imported' ? 'imp' : 'gen'}">${primary.type === 'imported' ? 'importé' : 'généré'}</em></span></div>`
      : '<span class="mzi-nocode">aucun code</span>';
    const genOrPrint = primary
      ? `<button class="mzi-mini" data-vprint="${v.id}" title="Imprimer l'étiquette"><i data-lucide="printer"></i></button>`
      : `<button class="mzi-mini" data-vgen="${v.id}" title="Générer un EAN-13"><i data-lucide="scan-line"></i></button>`;
    const shown = variantColor(v);
    return `<tr>
      <td>${catalogueAdminEnabled() ? `<button class="mzi-cbtn" data-vcolor="${v.id}">${colorDot(shown)} ${esc(shown.label)}</button>` : `<span class="mzi-cbtn is-locked" aria-disabled="true">${colorDot(shown)} ${esc(shown.label)}</span>`}${v.colorSource ? `<em class="mzi-csrc">${esc(v.colorSource)}</em>` : ''} · <b>${esc(v.size)}</b></td>
      <td><span class="mzi-stk-val" style="font-weight:700;padding:4px 8px;border-radius:6px;background:var(--n-100);">${v.stock}</span></td>
      <td>${bc}</td>
      <td class="mzi-vact">${genOrPrint}<button class="mzi-mini" data-vreg="${v.id}" title="Enregistrer un code existant"><i data-lucide="link"></i></button><button class="mzi-mini" data-vmove="${v.id}" title="Déclarer un mouvement de stock"><i data-lucide="arrow-left-right"></i></button>${catalogueAdminEnabled() ? `<button class="mzi-mini danger" data-vdelete="${v.id}" title="Supprimer la variante"><i data-lucide="trash-2"></i></button>` : '<span class="mzi-mini is-locked danger" aria-disabled="true"><i data-lucide="trash-2"></i></span>'}</td>
    </tr>`;
  }

  /* ─── new product ─── */
  function catSelectOptions(sel) {
    const cats = catDB().listCategories();
    return `<option value="">Sans catégorie</option>` + cats.map((c) => `<option value="${c.id}" ${c.id === sel ? 'selected' : ''}>${esc(c.name)}</option>`).join('');
  }
  function kindSelectOptions(sel) {
    const opts = [['tu', 'Pièce unique (sans taille)'], ['taille', 'Formats (S · M · L)']];
    if (sel === 'pointure') opts.push(['pointure', 'Pointure']);
    return opts.map(([v, l]) => `<option value="${v}" ${v === sel ? 'selected' : ''}>${l}</option>`).join('');
  }
  function ownershipField(product, prefix) {
    if (!depotOn()) return '';
    const value = product ? (product.ownership === 'consignment' ? 'consignment' : 'outright') : '';
    const consignor = product ? (product.consignor || '') : '';
    return `<div class="mzi-fg">
      <label>Catégorie A / B</label>
      <div class="mzi-ab">
        <label><input type="radio" name="${prefix}-ownership" value="outright" ${value === 'outright' ? 'checked' : ''}><div><b>Catégorie A</b><span>Marchandise achetée par le magasin</span></div></label>
        <label><input type="radio" name="${prefix}-ownership" value="consignment" ${value === 'consignment' ? 'checked' : ''}><div><b>Catégorie B</b><span>Marchandise confiée par un déposant</span></div></label>
      </div>
    </div>
    <div class="mzi-fg" data-mzi-consignor style="${value === 'consignment' ? '' : 'display:none'}">
      <label>Propriétaire de la marchandise (option)</label>
      <input data-mzi-consignor-input value="${esc(consignor)}" placeholder="Ex. Baobab Collection" maxlength="60">
    </div>`;
  }
  function wireOwnershipField(el, prefix) {
    const radios = $$(`input[name="${prefix}-ownership"]`, el);
    const who = $('[data-mzi-consignor]', el);
    radios.forEach((radio) => { radio.onchange = () => { if (who) who.style.display = radio.checked && radio.value === 'consignment' ? '' : 'none'; }; });
  }
  function readOwnershipField(el, prefix) {
    if (!depotOn()) return { ownership: 'outright', consignor: '' };
    const selected = $(`input[name="${prefix}-ownership"]:checked`, el);
    if (!selected) return null;
    return {
      ownership: selected.value === 'consignment' ? 'consignment' : 'outright',
      consignor: selected.value === 'consignment' ? ($('[data-mzi-consignor-input]', el)?.value.trim() || '') : '',
    };
  }
  function productPhotoField(photo) {
    return `<div class="mzi-fg">
      <label>Photo du produit (option)</label>
      <div class="mzi-photo">
        <div class="mzi-photo-preview" data-mzi-photo-preview>${photo ? `<img src="${esc(photo)}" alt="">` : '<i data-lucide="image-plus"></i>'}</div>
        <div class="mzi-photo-copy">
          <b>Image de l’article</b>
          <div class="mzi-photo-status" data-mzi-photo-status>JPG, PNG, WebP, AVIF ou GIF · 16 Mo maximum.</div>
          <div class="mzi-photo-actions">
            <button class="mz-btn secondary" type="button" data-mzi-photo-pick><i data-lucide="upload"></i>${photo ? 'Remplacer' : 'Ajouter une photo'}</button>
            ${photo ? '<button class="mz-btn secondary" type="button" data-mzi-photo-remove>Retirer</button>' : ''}
          </div>
          <input type="file" accept="image/jpeg,image/png,image/webp,image/avif,image/gif" data-mzi-photo-input hidden>
        </div>
      </div>
    </div>`;
  }
  function photoUploadMessage(error) {
    const detail = error && error.detail;
    const code = (error && (error.code || error.message)) || 'upload-failed';
    if (code === 'too-large') return `Photo trop lourde : ${Math.round(((detail && detail.size) || 0) / 104857.6) / 10} Mo · maximum 16 Mo.`;
    if (code === 'bad-type') return 'Format non pris en charge · utilisez JPG, PNG, WebP, AVIF ou GIF.';
    if (code === 'offline') return 'Réseau indisponible · reconnectez la caisse puis réessayez.';
    if (code === 'unauthorized' || code === 'http-401') return 'Ajout de photo non autorisé pour cette caisse.';
    if (code === 'no-media' || code === 'not-configured') return 'Stockage des photos indisponible sur ce compte.';
    return `Envoi impossible (${code}) · réessayez.`;
  }
  function wireProductPhoto(el, initialPhoto, saveButton) {
    const state = { photo: initialPhoto || '', busy: false };
    const input = $('[data-mzi-photo-input]', el);
    const preview = $('[data-mzi-photo-preview]', el);
    const status = $('[data-mzi-photo-status]', el);
    const actions = $('.mzi-photo-actions', el);
    const paint = () => {
      preview.innerHTML = state.photo ? `<img src="${esc(state.photo)}" alt="">` : '<i data-lucide="image-plus"></i>';
      actions.innerHTML = `<button class="mz-btn secondary" type="button" data-mzi-photo-pick><i data-lucide="upload"></i>${state.photo ? 'Remplacer' : 'Ajouter une photo'}</button>${state.photo ? '<button class="mz-btn secondary" type="button" data-mzi-photo-remove>Retirer</button>' : ''}`;
      icons();
    };
    actions.onclick = (event) => {
      if (event.target.closest('[data-mzi-photo-pick]')) { input.click(); return; }
      if (event.target.closest('[data-mzi-photo-remove]')) { state.photo = ''; status.textContent = 'Photo retirée · enregistrez pour confirmer.'; paint(); }
    };
    input.onchange = async () => {
      const file = input.files && input.files[0];
      if (!file || state.busy) return;
      const uploader = window.KiwiPlatformOps && window.KiwiPlatformOps.uploads;
      if (!uploader || typeof uploader.upload !== 'function') { status.textContent = 'Stockage des photos indisponible.'; return; }
      state.busy = true; if (saveButton) saveButton.disabled = true; status.textContent = 'Envoi de la photo…';
      try {
        const uploaded = await uploader.upload(file, { merchant: merchantSlug(), progress: (pct) => { status.textContent = `Envoi de la photo… ${pct} %`; } });
        if (!uploaded || !uploaded.url) throw new Error('upload-failed');
        state.photo = uploaded.url; status.textContent = 'Photo prête · elle sera liée au produit à l’enregistrement.'; paint();
      } catch (error) { status.textContent = photoUploadMessage(error); }
      finally { state.busy = false; if (saveButton) saveButton.disabled = false; input.value = ''; }
    };
    return state;
  }
  function openNewProduct() {
    if (!catalogueAdminEnabled()) { catalogDashboardOnly(); return; }
    const cat = catDB(); if (!cat) return;
    const html = `<button class="mz-modal-x" data-inv-x aria-label="Fermer"><i data-icon="close"></i></button><div class="mzi-modh"><div><h3>Nouvel article</h3><span>Produit, prix, coût et première variante.</span></div></div><div class="mzi-form mzi-new-form">
      <div class="mzi-fg"><label>Photo</label><div class="mzi-photo mzi-auto"><div class="mzi-photo-preview" data-mzi-auto>${artOf({ name: '', art: 'tshirt' })}</div><div class="mzi-photo-copy"><b>Choisie automatiquement</b><div class="mzi-photo-status">Kiwi choisit l’image d’après le nom de l’article. Votre propre photo s’ajoute ensuite depuis Modifier.</div></div></div></div><div class="mzi-fg"><label for="mzi-n-name">Nom</label><input id="mzi-n-name" placeholder="Ex. Assiette plate en faïence 27 cm" autocomplete="off"></div><div class="mzi-frow"><div class="mzi-fg"><label for="mzi-n-cat">Catégorie</label><select id="mzi-n-cat">${catSelectOptions(state.invFilter !== 'all' ? state.invFilter : '')}</select></div><div class="mzi-fg"><label for="mzi-n-kind">Type</label><select id="mzi-n-kind">${kindSelectOptions('tu')}</select></div></div><div class="mzi-frow"><div class="mzi-fg"><label for="mzi-n-price">Prix de vente (MAD)</label><input id="mzi-n-price" type="number" min="0" step="0.01" inputmode="decimal" placeholder="0,00"></div><div class="mzi-fg"><label for="mzi-n-cost">Coût d'achat (MAD)</label><input id="mzi-n-cost" type="number" min="0" step="0.01" inputmode="decimal" placeholder="0,00"></div></div><div class="mzi-frow mzi-frow3"><div class="mzi-fg"><label for="mzi-n-stock">Stock initial</label><input id="mzi-n-stock" type="number" min="0" value="0" inputmode="numeric"></div><div class="mzi-fg"><label for="mzi-n-size">Format / taille</label><input id="mzi-n-size" value="TU"></div><div class="mzi-fg"><label for="mzi-n-barcode">Code-barres existant (facultatif)</label><input id="mzi-n-barcode" autocomplete="off" spellcheck="false" placeholder="Scannez ou tapez le code"></div></div><div class="mzi-fg"><label for="mzi-n-brand">Marque / fournisseur</label><input id="mzi-n-brand"></div>${ownershipField(null, 'mzi-n')}</div><div class="mzi-modfoot"><button class="mz-btn secondary" data-inv-x>Annuler</button><button class="mz-btn primary" id="mzi-n-save">Créer l'article</button></div>`;
    invSetModal(html, (el) => { const save=$('#mzi-n-save',el); const media={ busy: false, photo: '' }; armScanCapture((c)=>{ const bi=$('#mzi-n-barcode',el); if(bi) bi.value=normScan(c); });   /* un article déjà étiqueté : la douchette écrit son code ici, pas sur le ticket */ wireOwnershipField(el, 'mzi-n'); $('#mzi-n-name',el).oninput=(e)=>{ $('[data-mzi-auto]',el).innerHTML=artOf({ name: e.target.value, art: 'tshirt' }); }; save.onclick = () => { if(media.busy)return; const name=$('#mzi-n-name',el).value.trim(); if(!name){toast('Le nom est requis');return;} const owner=readOwnershipField(el,'mzi-n'); if(!owner){toast('Choisissez la catégorie A ou B');return;} let p,v,bcRes=null; cat.batch(()=>{p=cat.addProduct({name,categoryId:$('#mzi-n-cat',el).value||null,kind:$('#mzi-n-kind',el).value,priceMAD:bqMoney($('#mzi-n-price',el).value),cost:bqMoney($('#mzi-n-cost',el).value),marque:$('#mzi-n-brand',el).value.trim(),art:'tshirt',ownership:owner.ownership,consignor:owner.consignor,photo:media.photo});v=cat.addVariant({productId:p.id,colorId:'noir',size:$('#mzi-n-size',el).value.trim()||'TU',stock:Math.max(0,parseInt($('#mzi-n-stock',el).value,10)||0)});const code=$('#mzi-n-barcode',el).value.trim();if(code)bcRes=cat.attachBarcode(v.id,code);}); disarmScanCapture(); rebuildCatalog(); if(bcRes&&!bcRes.ok) toast(tr(bcRes.reason==='doublon'&&bcRes.owner?`Article créé · code déjà porté par ${bcRes.owner.product.name}, non enregistré`:'Article créé · code-barres illisible, non enregistré')); else toast(tr(bcRes?'Article créé · code fournisseur conservé':'Article créé')); openInvProduct(p.id); renderInventaire(); }; });
  }

  function openCategories() {
    if (!catalogueAdminEnabled()) { catalogDashboardOnly(); return; }
    const cat=catDB(), cats=cat.listCategories();
    const html=`<button class="mz-modal-x" data-inv-x aria-label="Fermer"><i data-lucide="x"></i></button>
      <div class="mzi-modh"><div><h3>Catégories</h3><span>Rayons partagés avec le dashboard et la grille de vente. Touchez un nom pour le modifier.</span></div></div>
      <div class="mzi-form mzi-cat-form">
        <div class="mzi-cat-create">
          <div class="mzi-fg"><label for="mzi-cat-name">Nouvelle catégorie</label><input id="mzi-cat-name" placeholder="Ex. Bougies, Vaisselle, Linge de maison" autocomplete="off"></div>
          <button class="mz-btn primary" id="mzi-cat-add"><i data-lucide="plus"></i>Ajouter</button>
        </div>
        <div class="mzi-cat-list">
          ${cats.length ? cats.map((c)=>{ const n=cat.categoryCount(c.id); return `<div class="mzi-cat-row">
            <div class="mzi-cat-main"><input data-mzi-cat-name="${c.id}" value="${esc(c.name)}" aria-label="Nom de la catégorie ${esc(c.name)}" enterkeyhint="done"><span class="mzi-cat-count">${n} article${n>1?'s':''}</span></div>
            <div class="mzi-cat-actions"><button class="mz-btn danger" data-mzi-cat-delete="${c.id}" aria-label="Supprimer ${esc(c.name)}" title="${n?'Videz d’abord la catégorie':'Supprimer'}"><i data-icon="delete"></i></button></div>
          </div>`; }).join('') : '<div class="mzi-cat-empty">Aucune catégorie pour le moment.</div>'}
        </div>
      </div>`;
    invSetModal(html,(el)=>{ const add=()=>{const name=$('#mzi-cat-name',el).value.trim();if(!name){$('#mzi-cat-name',el).focus();return;}cat.addCategory(name);openCategories();renderInventaire();}; $('#mzi-cat-add',el).onclick=add; $('#mzi-cat-name',el).onkeydown=(event)=>{if(event.key==='Enter'){event.preventDefault();add();}};
      /* Le nom s'enregistre en quittant le champ ou sur Entrée : plus un bouton « Enregistrer » par rayon. */
      el.querySelectorAll('[data-mzi-cat-name]').forEach((inp)=>{ inp.onkeydown=(e)=>{if(e.key==='Enter'){e.preventDefault();inp.blur();}}; inp.onchange=()=>{const v=inp.value.trim();if(!v){openCategories();return;}cat.renameCategory(inp.dataset.mziCatName,v);toast('Catégorie renommée');openCategories();renderInventaire();}; });
      el.querySelectorAll('[data-mzi-cat-delete]').forEach((b)=>b.onclick=()=>{const res=cat.deleteCategory(b.dataset.mziCatDelete,{moveTo:null});if(res?.ok===false){toast('Déplacez d’abord les articles de cette catégorie');return;}openCategories();renderInventaire();});});
  }

  function openEditProduct(pid) {
    if (!catalogueAdminEnabled()) { catalogDashboardOnly(); return; }
    const cat = catDB(); const d = cat.getProduct(pid); if (!d) return; const p = d.product;
    const html = `
      <button class="mz-modal-x" data-inv-x aria-label="Fermer"><i data-lucide="x"></i></button>
      <div class="mzi-modh"><div><h3>Modifier le produit</h3><span>${esc(p.name)}</span></div></div>
      <div class="mzi-form">
        <div class="mzi-fg"><label>Nom</label><input id="mzi-e-name" value="${esc(p.name)}" /></div>
        <div class="mzi-frow">
          <div class="mzi-fg"><label>Catégorie</label><select id="mzi-e-cat">${catSelectOptions(p.categoryId)}</select></div>
          <div class="mzi-fg"><label>Type</label><select id="mzi-e-kind">${kindSelectOptions(p.kind)}</select></div>
        </div>
        <div class="mzi-frow">
          <div class="mzi-fg"><label>Prix de vente (MAD)</label><input id="mzi-e-price" type="number" min="0" value="${p.priceMAD}" /></div>
          <div class="mzi-fg"><label>Coût d'achat (MAD)</label><input id="mzi-e-cost" type="number" min="0" value="${p.cost || 0}" /></div>
        </div>
        <div class="mzi-frow">
          <div class="mzi-fg"><label>Marque</label><input id="mzi-e-marque" value="${esc(p.marque || '')}" placeholder="Baobab Collection" /></div>
          <div class="mzi-fg"><label>Motif / collection</label><input id="mzi-e-motif" value="${esc(p.motif || '')}" placeholder="Fès Bleu" /></div>
        </div>
        ${productPhotoField(p.photo || '')}
        <div class="mzi-fg"><label>Icône du produit</label>${iconPickerHtml(p.art || 'tshirt')}</div>
        ${ownershipField(p, 'mzi-e')}
      </div>
      <div class="mzi-modfoot"><button class="mz-btn secondary" data-inv-back>Retour</button><button class="mz-btn" id="mzi-e-save">Enregistrer</button></div>`;
    invSetModal(html, (el) => {
      let icon = p.art || 'tshirt';
      const save = $('#mzi-e-save', el);
      const media = wireProductPhoto(el, p.photo || '', save);
      wireIconPicker(el, (k) => { icon = k; });
      wireOwnershipField(el, 'mzi-e');
      $('[data-inv-back]', el).addEventListener('click', () => openInvProduct(pid));
      save.addEventListener('click', () => {
        if (media.busy) return;
        cat.updateProduct(pid, { name: $('#mzi-e-name', el).value.trim() || undefined, categoryId: $('#mzi-e-cat', el).value || null, kind: $('#mzi-e-kind', el).value, art: icon, priceMAD: bqMoney($('#mzi-e-price', el).value), cost: bqMoney($('#mzi-e-cost', el).value), photo: media.photo });
        /* Écrit après le patch principal pour ne pas allonger une ligne déjà
           dense — même transaction côté catalogue (updateProduct commit à chaque
           appel), et les deux champs voyagent ensemble. */
        const owner = readOwnershipField(el, 'mzi-e');
        cat.updateProduct(pid, {
          marque: $('#mzi-e-marque', el).value.trim(),
          motif: $('#mzi-e-motif', el).value.trim(),
          ownership: owner ? owner.ownership : undefined,
          consignor: owner ? owner.consignor : undefined,
        });
        rebuildCatalog();
        toast('Produit mis à jour');
        openInvProduct(pid);
      });
    });
  }

  function confirmDeleteProduct(pid) {
    if (!catalogueAdminEnabled()) { catalogDashboardOnly(); return; }
    const cat = catDB(); const d = cat.getProduct(pid); if (!d) return;
    const html = `
      <button class="mz-modal-x" data-inv-x aria-label="Fermer"><i data-lucide="x"></i></button>
      <div class="mzi-modh"><div><h3>Supprimer « ${esc(d.product.name)} » ?</h3><span>${d.variants.length} variantes et leurs codes-barres seront supprimés.</span></div></div>
      <div class="mzi-modfoot"><button class="mz-btn secondary" data-inv-back>Annuler</button><button class="mz-btn danger" id="mzi-del-ok"><i data-lucide="trash-2"></i>Supprimer définitivement</button></div>`;
    invSetModal(html, (el) => {
      $('[data-inv-back]', el).addEventListener('click', () => openInvProduct(pid));
      $('#mzi-del-ok', el).addEventListener('click', () => { cat.deleteProduct(pid); toast('Produit supprimé'); closeVeil('#mz-inv-veil'); renderInventaire(); });
    });
  }

  /* Supprimer une DÉCLINAISON demande la même confirmation que supprimer le
     produit. La corbeille de la ligne partait sur un seul appui, sans retour
     possible : le stock compté, le code-barres imprimé sur les étiquettes du
     rayon et l'historique de mouvements de cette déclinaison disparaissaient
     ensemble, et la ligne d'à côté est le bouton « −1 ». On nomme ce qui part. */
  function confirmDeleteVariant(vid, pid) {
    if (!catalogueAdminEnabled()) { catalogDashboardOnly(); return; }
    const cat = catDB(); const d = cat.getProduct(pid); if (!d) return;
    const v = d.variants.find((x) => x.id === vid); if (!v) return;
    const codes = (v.barcodes || []).length;
    const perte = [
      v.stock > 0 ? `${v.stock} en stock` : 'aucun stock',
      codes ? `${codes} code${codes > 1 ? 's' : ''}-barres` : 'aucun code-barres',
    ].join(' · ');
    const html = `
      <button class="mz-modal-x" data-inv-x aria-label="Fermer"><i data-lucide="x"></i></button>
      <div class="mzi-modh"><div><h3>Supprimer ${esc(variantColor(v).label)} · ${esc(v.size)} ?</h3><span>${esc(d.product.name)} · ${perte}. La suppression est définitive.</span></div></div>
      <div class="mzi-modfoot"><button class="mz-btn secondary" data-inv-back>Annuler</button><button class="mz-btn danger" id="mzi-vdel-ok"><i data-lucide="trash-2"></i>Supprimer la variante</button></div>`;
    invSetModal(html, (el) => {
      $('[data-inv-back]', el).addEventListener('click', () => openInvProduct(pid));
      $('#mzi-vdel-ok', el).addEventListener('click', () => { cat.deleteVariant(vid); toast('Variante supprimée'); openInvProduct(pid); });
    });
  }

  /* ─── add variant (colour × size × stock + optional EAN-13) ───
     Le sélecteur est celui du tableau de bord, en taille tactile : mêmes
     pastilles, même état sélectionné, même comportement clavier. */
  function colorPicker(sel) {
    const k = KC();
    if (!k) return '';
    return k.picker('variant-color', sel || 'noir', {
      size: 'lg', optional: true, label: 'Couleur',
      hint: 'Touchez une pastille pour lire son nom',
    });
  }

  /* Changer la couleur d'une variante existante. La variante garde son stock,
     ses codes-barres et son identité : seule la famille affichée change. */
  function openVariantColor(vid, pid) {
    if (!catalogueAdminEnabled()) { catalogDashboardOnly(); return; }
    const cat = catDB(); const d = cat.getProduct(pid); if (!d) return;
    const v = d.variants.find((x) => x.id === vid); if (!v) return;
    const html = `
      <button class="mz-modal-x" data-inv-x aria-label="Fermer"><i data-lucide="x"></i></button>
      <div class="mzi-modh"><div><h3>Couleur de la variante</h3><span>${esc(d.product.name)} · taille ${esc(v.size)}${v.colorSource ? ` · saisie à l'origine « ${esc(v.colorSource)} »` : ''}</span></div></div>
      <div class="mzi-form">
        <div class="mzi-fg"><label>Couleur</label>${colorPicker(variantColor(v))}</div>
        <div class="mzi-fg"><label>Précision (facultatif)</label><input id="mzi-vc-note" maxlength="60" value="${esc(v.note || '')}" placeholder="Ex. rayé, délavé, motif · pour distinguer deux variantes de même couleur" /></div>
      </div>
      <div class="mzi-modfoot"><button class="mz-btn secondary" data-inv-back>Retour</button><button class="mz-btn" id="mzi-vc-save">Enregistrer</button></div>`;
    invSetModal(html, (el) => {
      $('[data-inv-back]', el).addEventListener('click', () => openInvProduct(pid));
      $('#mzi-vc-save', el).addEventListener('click', () => {
        const k = KC();
        const colorId = k ? k.value(el) : '';
        cat.updateVariant(vid, {
          colorId: colorId || undefined,
          note: $('#mzi-vc-note', el).value.trim(),
        });
        toast('Couleur mise à jour');
        openInvProduct(pid);
      });
    });
  }
  function openAddVariant(pid) {
    if (!catalogueAdminEnabled()) { catalogDashboardOnly(); return; }
    const cat = catDB(); const d = cat.getProduct(pid); if (!d) return;
    const presets = cat.sizePresets(d.product.kind);
    const html = `
      <button class="mz-modal-x" data-inv-x aria-label="Fermer"><i data-lucide="x"></i></button>
      <div class="mzi-modh"><div><h3>Ajouter une variante</h3><span>${esc(d.product.name)}, couleur × taille</span></div></div>
      <div class="mzi-form">
        <div class="mzi-fg"><label>Couleur</label><div id="mzi-av-sw">${colorPicker('noir')}</div></div>
        <div class="mzi-frow">
          <div class="mzi-fg"><label>Taille</label><input id="mzi-av-size" list="mzi-av-sizes" value="${esc(presets[0] || 'TU')}" /><datalist id="mzi-av-sizes">${presets.map((s) => `<option value="${esc(s)}">`).join('')}</datalist></div>
          <div class="mzi-fg"><label>Stock initial</label><input id="mzi-av-stock" type="number" min="0" value="0" /></div>
        </div>
        <div class="mzi-fg"><label>Code-barres</label><select id="mzi-av-bc"><option value="gen">Générer un EAN-13 (imprimable)</option><option value="none">Aucun pour l'instant</option></select></div>
      </div>
      <div class="mzi-modfoot"><button class="mz-btn secondary" data-inv-back>Retour</button><button class="mz-btn" id="mzi-av-save">Ajouter la variante</button></div>`;
    invSetModal(html, (el) => {
      $('[data-inv-back]', el).addEventListener('click', () => openInvProduct(pid));
      $('#mzi-av-save', el).addEventListener('click', () => {
        const k = KC();
        const colorId = (k && k.value($('#mzi-av-sw', el))) || 'noir';
        const size = $('#mzi-av-size', el).value.trim() || 'TU';
        const stock = parseInt($('#mzi-av-stock', el).value, 10) || 0;
        const v = cat.addVariant({ productId: pid, colorId, size, stock });
        if (v && $('#mzi-av-bc', el).value === 'gen') cat.generateBarcode(v.id);
        toast('Variante ajoutée');
        openInvProduct(pid);
      });
    });
  }

  /* ─── register an EXISTING barcode on a variant (old POS code, no reprint) ─── */
  function openRegisterOnVariant(vid, pid) {
    const html = `
      <button class="mz-modal-x" data-inv-x aria-label="Fermer"><i data-lucide="x"></i></button>
      <div class="mzi-modh"><div><h3>Enregistrer un code existant</h3><span>Scannez ou tapez le code déjà présent sur l'article, conservé tel quel.</span></div></div>
      <div class="mzi-form">
        <div class="mzi-fg"><label>Code-barres</label><input id="mzi-reg-code" placeholder="Scannez ou tapez le code…" autocomplete="off" /></div>
        <div class="mzi-help">EAN-13, UPC ou tout code de l'ancien système. Aucune réimpression, le code est rattaché à cette variante.</div>
      </div>
      <div class="mzi-modfoot"><button class="mz-btn secondary" data-inv-back>Retour</button><button class="mz-btn" id="mzi-reg-save">Enregistrer le code</button></div>`;
    invSetModal(html, (el) => {
      $('[data-inv-back]', el).addEventListener('click', () => openInvProduct(pid));
      const inp = $('#mzi-reg-code', el);
      const save = () => {
        const raw = inp.value.trim(); if (!raw) { toast('Code vide'); return; }
        const res = catDB().attachBarcode(vid, raw);
        if (res.ok) { toast(res.already ? 'Code déjà rattaché' : `Code ${raw} enregistré`); openInvProduct(pid); }
        else if (res.reason === 'doublon') toast(`Déjà utilisé par ${res.owner.product.name} (${res.owner.variant.colorLabel} ${res.owner.variant.size})`);
        else toast('Enregistrement impossible');
      };
      inp.onkeydown = (e) => { if (e.key === 'Enter') save(); };
      $('#mzi-reg-save', el).addEventListener('click', save);
      setTimeout(() => inp.focus(), 40);
    });
  }

  /* ─── register an unknown scanned code onto a product (pick / create) ─── */
  function offerRegister(code) {
    const cat = catDB(); if (!cat) return;
    if (state.view !== 'inventaire') switchView('inventaire');
    const products = cat.listProducts({});
    // Une liste déroulante ne peut pas montrer de pastille : c'est le seul
    // endroit où la couleur reste écrite. Quand deux variantes portent la même
    // famille, la nuance d'origine ou la précision les départage.
    const varOptions = (pid) => cat.listVariants(pid).map((v) => {
      const extra = v.note || v.colorSource || '';
      return `<option value="${v.id}">${esc(v.colorLabel)}${extra ? ` (${esc(extra)})` : ''} · ${esc(v.size)}</option>`;
    }).join('');
    const html = `
      <button class="mz-modal-x" data-inv-x aria-label="Fermer"><i data-lucide="x"></i></button>
      <div class="mzi-modh"><div><h3>Code existant à enregistrer</h3><span>Code scanné : <b>${esc(code)}</b>, rattachez-le à un article (sans réimprimer).</span></div></div>
      <div class="mzi-form">
        <div class="mzi-fg"><label>Article</label><select id="mzi-or-prod">${products.map((p) => `<option value="${p.id}">${esc(p.name)}</option>`).join('')}</select></div>
        <div class="mzi-fg"><label>Variante (couleur · taille)</label><select id="mzi-or-var">${products.length ? varOptions(products[0].id) : ''}</select></div>
      </div>
      <div class="mzi-modfoot"><span class="mzi-dashboard-only">Créer l’article dans le tableau de bord</span><button class="mz-btn" id="mzi-or-save">Rattacher le code</button></div>`;
    invSetModal(html, (el) => {
      const prodSel = $('#mzi-or-prod', el), varSel = $('#mzi-or-var', el);
      if (prodSel) prodSel.addEventListener('change', () => { varSel.innerHTML = varOptions(prodSel.value); });
      $('#mzi-or-save', el).addEventListener('click', () => {
        const vid = varSel && varSel.value;
        if (!vid) { toast('Choisissez une variante (ajoutez-en une d\'abord)'); return; }
        const res = cat.attachBarcode(vid, code);
        if (res.ok) { toast(`Code ${code} enregistré`); openInvProduct(prodSel.value); }
        else if (res.reason === 'doublon') toast(`Déjà utilisé par ${res.owner.product.name}`);
        else toast('Enregistrement impossible');
      });
    });
  }

  /* ═══════════════════════════════════════════════════════════════════════════
   * REPRISE DE STOCK — onboarder une boutique déjà étiquetée
   * ---------------------------------------------------------------------------
   * Le cas que ceci résout : un commerçant a des milliers d'articles qui portent
   * DÉJÀ un code-barres fournisseur ou fabricant. Lui faire générer et imprimer
   * une étiquette Kiwi par pièce, c'est des jours de travail et des milliers
   * d'étiquettes pour rien. Le code du carton est un identifiant parfaitement
   * valable : on le lit, on le garde tel quel, on ne réimprime rien.
   *
   * Trois gestes vivent ici, et l'écran ne les confond JAMAIS (c'est la règle
   * la plus importante de cet écran, parce qu'à la douchette ils se ressemblent) :
   *   · CRÉER un article au catalogue           — le code est inconnu
   *   · AJOUTER une déclinaison à un article    — même modèle, autre taille/couleur
   *   · RECEVOIR du stock                       — l'article existe déjà, il en arrive
   *
   * Ce que scanner ici ne fait jamais : mettre au panier, encaisser, bouger le
   * stock avant confirmation, imprimer une étiquette, écraser un article existant.
   * Garanti par armScanCapture() (voir handleWedge) plus le mode `pending` : rien
   * n'est écrit avant que l'employé n'ait touché « Enregistrer ».
   * ─────────────────────────────────────────────────────────────────────────── */

  /* Session de reprise : vit le temps de l'écran, sert le compteur et le journal.
   * `log` est borné — une session d'import peut faire des milliers d'articles et
   * la caisse doit rester aussi vive au 2000e scan qu'au premier. */
  const intake = { open: false, count: 0, pieces: 0, log: [], mode: 'scan', draft: null, lastProduct: null, hint: null };
  const INTAKE_LOG_MAX = 8;

  function intakeReset() {
    intake.count = 0; intake.pieces = 0; intake.log = []; intake.mode = 'scan';
    intake.draft = null; intake.lastProduct = null; intake.hint = null;
  }
  function intakeNote(kind, text) {
    intake.log.unshift({ kind, text, at: new Date() });
    if (intake.log.length > INTAKE_LOG_MAX) intake.log.length = INTAKE_LOG_MAX;
  }

  /* ─── le juge : que faire de ce code ? ───────────────────────────────────────
   * Un seul endroit décide, pour que le scan répété, la saisie manuelle et la
   * caméra donnent exactement le même verdict. */
  function intakeJudge(raw) {
    const code = normScan(raw);
    const KB = window.KiwiBarcode;
    const val = KB && KB.validate ? KB.validate(code) : { ok: !!code, code, sym: '', check: 'na' };
    if (!val.ok) return { kind: 'invalide', code, reason: val.reason };
    const cat = catDB();
    const hit = cat ? cat.findByBarcode(val.code) : null;
    if (hit) return { kind: 'connu', code: val.code, sym: val.sym, check: val.check, hit };
    return { kind: 'nouveau', code: val.code, sym: val.sym, check: val.check };
  }

  const INVALID_MSG = {
    vide: 'Rien n\'a été lu. Rapprochez la douchette de l\'étiquette, ou tapez le code.',
    illisible: 'Lecture incomplète · la douchette a envoyé des caractères parasites. Rescannez, ou tapez le code à la main.',
    'trop-court': 'Lecture partielle : trop peu de caractères pour être un code-barres. Rescannez plus lentement, ou tapez-le.',
    'trop-long': 'Ce code est anormalement long. Vérifiez qu\'un seul article est passé devant la douchette.',
  };

  function symBadge(j) {
    if (!j || !j.sym) return '';
    const KB = window.KiwiBarcode;
    const label = KB && KB.symLabel ? KB.symLabel(j.sym) : j.sym;
    if (j.check === 'bad') return `<span class="bqx-sym warn" title="La clé de contrôle ne correspond pas. C'est fréquent sur un code interne · Kiwi l'accepte tel quel.">${esc(label)} · clé inhabituelle</span>`;
    return `<span class="bqx-sym">${esc(label)}${j.check === 'ok' ? ' ✓' : ''}</span>`;
  }

  /* ─── l'écran ─── */
  function openIntake() {
    if (!catDB()) { toast('Base d\'inventaire indisponible'); return; }
    if (state.view !== 'inventaire') switchView('inventaire');
    intake.open = true;
    intakeReset();
    paintIntake();
  }

  function intakeClose() {
    intake.open = false;
    disarmScanCapture();
    closeVeil('#mz-inv-veil');
    /* La projection de vente a été mise en pause pendant la saisie : on la
       reconstruit maintenant, avant que quiconque scanne pour vendre. */
    rebuildCatalog();
    pruneTicket();
    renderInventaire();
    if (intake.count) toast(`Reprise terminée · ${intake.count} article${intake.count > 1 ? 's' : ''}, ${intake.pieces} pièce${intake.pieces > 1 ? 's' : ''}`);
  }

  function intakeHeader() {
    return `
      <div class="bqx-head">
        <div class="bqx-head-t">
          <h3>Reprise de stock</h3>
          <span>Scannez le code déjà présent sur l'article. Kiwi le garde tel quel · aucune étiquette à réimprimer.</span>
        </div>
        <div class="bqx-tally" aria-live="polite">
          <b>${intake.count}</b><span>article${intake.count > 1 ? 's' : ''}</span>
          <i></i>
          <b>${intake.pieces}</b><span>pièce${intake.pieces > 1 ? 's' : ''}</span>
        </div>
      </div>`;
  }

  function intakeLogHtml() {
    if (!intake.log.length) {
      return `<div class="bqx-log-empty">Rien encore. La douchette écrit directement dans le champ ci-dessus · pas besoin de cliquer.</div>`;
    }
    return `<div class="bqx-log">${intake.log.map((l) => `
      <div class="bqx-log-row is-${l.kind}">
        <i data-lucide="${l.kind === 'cree' ? 'plus-circle' : l.kind === 'variante' ? 'git-branch' : l.kind === 'recu' ? 'package-plus' : 'alert-circle'}"></i>
        <span>${esc(l.text)}</span>
        <em>${fmtHM(l.at)}</em>
      </div>`).join('')}</div>`;
  }

  /* ═══ état 1 · en attente d'un scan ═══ */
  function paintIntake() {
    if (!intake.open) return;
    intake.mode = 'scan';
    const canCam = camSupported();
    invSetModal(`
      <button class="mz-modal-x" data-inv-x aria-label="Fermer"><i data-lucide="x"></i></button>
      ${intakeHeader()}
      <div class="bqx-body">
        <div class="bqx-scanbox" id="bqx-box">
          <i data-lucide="scan-line"></i>
          <input id="bqx-code" placeholder="Scannez un article…" autocomplete="off" autocapitalize="off" spellcheck="false" />
          <button class="bqx-mini" id="bqx-go" title="Valider le code saisi"><i data-lucide="arrow-right"></i></button>
        </div>
        <div class="bqx-hint${intake.hint ? ' is-' + intake.hint.tone : ''}" id="bqx-hint">${esc(intake.hint ? intake.hint.msg : 'Douchette prête. Pas de douchette ? Tapez le code puis Entrée.')}</div>
        <div class="bqx-alt">
          ${canCam ? `<button class="mz-btn secondary" id="bqx-cam"><i data-lucide="camera"></i>Scanner avec la caméra</button>` : ''}
          <button class="mz-btn secondary" id="bqx-diag"><i data-lucide="activity"></i>La douchette ne répond pas ?</button>
        </div>
        ${intakeLogHtml()}
      </div>
      <div class="mzi-modfoot">
        <button class="mz-btn secondary" id="bqx-done">Terminer la reprise</button>
      </div>`, (el) => {
      const inp = $('#bqx-code', el);
      const submit = () => {
        const v = inp.value; inp.value = '';
        if (!String(v).trim()) { intakeHint('Tapez ou scannez un code.', 'warn', el); return; }
        intakeTake(v, { manual: true });
      };
      inp.onkeydown = (e) => { if (e.key === 'Enter') { e.preventDefault(); submit(); } };
      $('#bqx-go', el).onclick = submit;
      $('#bqx-done', el).onclick = intakeClose;
      const cam = $('#bqx-cam', el);
      if (cam) cam.onclick = () => openCamScan((c) => intakeTake(c));
      $('#bqx-diag', el).onclick = () => { disarmScanCapture(); openScannerTest(); };
      /* Le scan appartient à cet écran, et à rien d'autre. */
      armScanCapture((code) => intakeTake(code));
      intakeFocus(el);
    });
  }

  /* La douchette tape dans le champ : il doit avoir le curseur, tout le temps, y
     compris après un enregistrement — c'est ce qui permet d'enchaîner sans souris. */
  function intakeFocus(el) {
    setTimeout(() => { const i = $('#bqx-code', el || root); if (i) { i.focus(); i.select(); } }, 30);
  }
  /* Le message est MÉMORISÉ avant d'être écrit : paintIntake() reconstruit tout
     l'écran, et un texte posé juste avant le repaint disparaissait aussitôt —
     l'employé voyait « Douchette prête » alors que son scan venait d'être refusé. */
  function intakeHint(msg, tone, el) {
    intake.hint = msg ? { msg, tone: tone || '' } : null;
    const h = $('#bqx-hint', el || root);
    if (!h) return;
    h.textContent = msg;
    h.className = 'bqx-hint' + (tone ? ' is-' + tone : '');
  }

  /* ═══ le geste central : un code arrive ═══ */
  function intakeTake(raw, opts) {
    opts = opts || {};
    const j = intakeJudge(raw);
    if (j.kind === 'invalide') {
      intakeNote('erreur', `Lecture refusée · ${INVALID_MSG[j.reason] ? j.reason : 'illisible'}`);
      intakeHint(INVALID_MSG[j.reason] || 'Code illisible, rescannez.', 'bad');
      toast('Scan incomplet, rien n\'a été enregistré');
      paintIntake();
      return;
    }
    intake.hint = null;   // un code lisible efface l'avertissement du scan précédent
    if (j.kind === 'connu') { intakeKnown(j); return; }
    intakeNew(j, opts);
  }

  /* ═══ état 2 · code INCONNU → créer l'article (ou l'ajouter au précédent) ═══ */
  function intakeNew(j, opts) {
    intake.mode = 'nouveau';
    const cat = catDB();
    const cats = cat.listCategories();
    const prev = intake.lastProduct ? cat.getProduct(intake.lastProduct) : null;
    const manual = !!(opts && opts.manual);
    // Combien de fiches attendent leur code-barres (typiquement : ce que le
    // fichier fournisseur a fait entrer au tableau de bord).
    const bare = cat.countCodeless ? cat.countCodeless() : 0;
    invSetModal(`
      <button class="mz-modal-x" data-inv-x aria-label="Fermer"><i data-lucide="x"></i></button>
      ${intakeHeader()}
      <div class="bqx-found is-new">
        <i data-lucide="badge-check"></i>
        <div>
          <b>Code lu${manual ? ' (saisi à la main)' : ''} · nouveau</b>
          <span class="bqx-codeline">${esc(j.code)} ${symBadge(j)}</span>
        </div>
      </div>
      ${prev ? `
      <div class="bqx-chain">
        <div>
          <b>Même modèle que « ${esc(prev.product.name)} » ?</b>
          <span>Une autre taille ou couleur du même article : le nom, la catégorie et les prix sont repris, vous ne changez que la déclinaison.</span>
        </div>
        <button class="mz-btn" id="bqx-chain">Ajouter une déclinaison</button>
      </div>` : ''}
      ${bare ? `
      <div class="bqx-chain is-link">
        <div>
          <b>Cet article est déjà au catalogue, sans code-barres ?</b>
          <span>${bare} déclinaison${bare > 1 ? 's' : ''} attend${bare > 1 ? 'ent' : ''} son code · celles qui viennent du fichier fournisseur. Rattachez ce code au lieu de tout ressaisir.</span>
        </div>
        <button class="mz-btn" id="bqx-link">Chercher l'article</button>
      </div>` : ''}
      <div class="mzi-form bqx-form">
        <div class="mzi-fg"><label>Nom du produit</label><input id="bqx-name" placeholder="Ex. Vase en céramique" autocomplete="off" /></div>
        <div class="mzi-frow">
          <div class="mzi-fg"><label>Catégorie</label><select id="bqx-cat">${catSelectOptions(state.invFilter && state.invFilter !== 'all' ? state.invFilter : (prev ? prev.product.categoryId : ''))}</select></div>
          <div class="mzi-fg"><label>Type</label><select id="bqx-kind">${kindSelectOptions(prev ? prev.product.kind : 'tu')}</select></div>
        </div>
        <div class="mzi-fg"><label>Ou nouvelle catégorie</label><input id="bqx-newcat" placeholder="Laisser vide pour garder celle ci-dessus" autocomplete="off" /></div>
        <div class="mzi-frow">
          <div class="mzi-fg"><label>Prix de vente (MAD)</label><input id="bqx-price" type="number" min="0" step="0.01" inputmode="decimal" placeholder="349" /></div>
          <div class="mzi-fg"><label>Coût d'achat (MAD)</label><input id="bqx-cost" type="number" min="0" step="0.01" inputmode="decimal" placeholder="optionnel" /></div>
        </div>
        <div class="mzi-frow">
          <div class="mzi-fg"><label>Couleur</label><div id="bqx-sw">${colorPicker('noir')}</div></div>
        </div>
        <div class="mzi-frow">
          <div class="mzi-fg"><label>Format</label><input id="bqx-size" list="bqx-sizes" placeholder="TU" autocomplete="off" /><datalist id="bqx-sizes"></datalist></div>
          <div class="mzi-fg"><label>Quantité reçue</label><input id="bqx-qty" type="number" min="0" step="1" inputmode="numeric" value="1" /></div>
        </div>
        <div class="mzi-fg"><label>Autre précision (optionnel)</label><input id="bqx-flag" placeholder="Ex. coupe droite, lot été" autocomplete="off" /></div>
      </div>
      <div class="mzi-modfoot bqx-foot">
        <button class="mz-btn secondary" id="bqx-skip">Ignorer ce code</button>
        <button class="mz-btn" id="bqx-save"><i data-lucide="check"></i>Enregistrer et scanner le suivant</button>
      </div>`, (el) => {
      /* Le sélecteur de couleurs partagé (assets/color-palette.js) porte son propre
         état et sa navigation clavier : on lui DEMANDE sa valeur au moment
         d'enregistrer, plutôt que de suivre les clics à la main. */
      const pickedColor = () => { const k = KC(); return (k && k.value($('#bqx-sw', el))) || 'noir'; };
      const kindSel = $('#bqx-kind', el), sizeList = $('#bqx-sizes', el);
      const fillSizes = () => { sizeList.innerHTML = cat.sizePresets(kindSel.value).map((s) => `<option value="${esc(s)}">`).join(''); };
      kindSel.onchange = fillSizes; fillSizes();

      if (prev) $('#bqx-chain', el).onclick = () => intakeVariant(j, intake.lastProduct);
      const linkBtn = $('#bqx-link', el);
      if (linkBtn) linkBtn.onclick = () => intakeLink(j);
      $('#bqx-skip', el).onclick = () => { intakeNote('erreur', `Code ${j.code} ignoré`); paintIntake(); };

      const save = () => {
        const name = $('#bqx-name', el).value.trim();
        if (!name) { toast('Le nom du produit est requis'); $('#bqx-name', el).focus(); return; }
        const size = $('#bqx-size', el).value.trim() || 'TU';
        const qty = Math.max(0, parseInt($('#bqx-qty', el).value, 10) || 0);
        let catId = $('#bqx-cat', el).value || null;
        const newCat = $('#bqx-newcat', el).value.trim();
        if (newCat) catId = cat.addCategory(newCat).id;
        /* Créer le produit, sa déclinaison et rattacher le code, c'est UN geste :
           une seule écriture du catalogue au lieu de trois (voir batch()). */
        let p = null, ev = null, res = null;
        cat.batch(() => {
          p = cat.addProduct({
            name, categoryId: catId, kind: kindSel.value,
            priceMAD: bqMoney($('#bqx-price', el).value), cost: bqMoney($('#bqx-cost', el).value),
            art: prev ? prev.product.art : 'tshirt', flag: $('#bqx-flag', el).value.trim(),
          });
          ev = cat.ensureVariant({ productId: p.id, colorId: pickedColor(), size, stock: qty });
          res = cat.attachBarcode(ev.variant.id, j.code);
          if (!res.ok) cat.deleteProduct(p.id);   // jamais d'article orphelin
        });
        if (!res.ok) {
          /* Course rarissime : le code a été pris entre le scan et l'enregistrement
             (l'autre caisse, ou l'autre appareil). L'article vient d'être défait
             dans le batch ci-dessus, rien d'orphelin ne reste. */
          toast(res.reason === 'doublon' ? `Ce code vient d'être attribué à ${res.owner.product.name}` : 'Code refusé, rien n\'a été créé');
          paintIntake();
          return;
        }
        intake.count++; intake.pieces += qty;
        intake.lastProduct = p.id;
        intakeNote('cree', `${name} · ${size} · ${qty} pièce${qty > 1 ? 's' : ''}, code conservé`);
        toast(`${name} enregistré · code ${j.code} conservé`);
        intakeHint(`${name} · ${size} enregistré. Scannez l'article suivant.`, 'good');
        paintIntake();
      };
      $('#bqx-save', el).onclick = save;
      /* Entrée depuis n'importe quel champ enregistre : la reprise se fait au
         clavier, la souris ne devrait jamais être nécessaire. */
      el.querySelectorAll('.bqx-form input').forEach((i) => {
        i.addEventListener('keydown', (e) => { if (e.key === 'Enter') { e.preventDefault(); save(); } });
      });
      setTimeout(() => { const n = $('#bqx-name', el); if (n) n.focus(); }, 40);
    });
  }

  /* ═══ état 3 · enchaîner une déclinaison du MÊME produit ═══
     Le cas « Jean Noir » du cahier des charges : noir/S = code A, noir/M = code B,
     bleu/M = code C. On ne recrée pas le produit, on ne retape pas le prix. */
  function intakeVariant(j, pid) {
    intake.mode = 'variante';
    const cat = catDB();
    const d = cat.getProduct(pid);
    if (!d) { intakeNew(j, {}); return; }
    const presets = cat.sizePresets(d.product.kind);
    invSetModal(`
      <button class="mz-modal-x" data-inv-x aria-label="Fermer"><i data-lucide="x"></i></button>
      ${intakeHeader()}
      <div class="bqx-found is-new">
        <i data-lucide="git-branch"></i>
        <div>
          <b>Nouvelle déclinaison · ${esc(d.product.name)}</b>
          <span class="bqx-codeline">${esc(j.code)} ${symBadge(j)}</span>
        </div>
      </div>
      <div class="bqx-common">
        <span>Repris du produit</span>
        <b>${esc(d.category ? d.category.name : 'Divers')} · ${fmtMAD(shelf(d.product.priceMAD))}${d.product.cost ? ' · coût ' + fmtMAD(d.product.cost) : ''}</b>
      </div>
      <div class="mzi-form bqx-form">
        <div class="mzi-fg"><label>Couleur</label><div id="bqx-sw">${colorPicker('noir')}</div></div>
        <div class="mzi-frow">
          <div class="mzi-fg"><label>Taille</label><input id="bqx-size" list="bqx-sizes2" value="" placeholder="${esc(presets[0] || 'TU')}" autocomplete="off" /><datalist id="bqx-sizes2">${presets.map((s) => `<option value="${esc(s)}">`).join('')}</datalist></div>
          <div class="mzi-fg"><label>Quantité reçue</label><input id="bqx-qty" type="number" min="0" step="1" inputmode="numeric" value="1" /></div>
        </div>
      </div>
      <div class="bqx-existing">
        <span>Déjà au catalogue</span>
        <div class="bqx-chips">${d.variants.map((v) => `<span class="bqx-chip"><i style="background:${v.colorHex}"></i>${esc(v.colorLabel)} · ${esc(v.size)} <b>${v.stock}</b></span>`).join('') || '<em>aucune déclinaison</em>'}</div>
      </div>
      <div class="mzi-modfoot bqx-foot">
        <button class="mz-btn secondary" id="bqx-back">Créer un autre produit</button>
        <button class="mz-btn" id="bqx-save"><i data-lucide="check"></i>Enregistrer et scanner le suivant</button>
      </div>`, (el) => {
      /* Le sélecteur de couleurs partagé (assets/color-palette.js) porte son propre
         état et sa navigation clavier : on lui DEMANDE sa valeur au moment
         d'enregistrer, plutôt que de suivre les clics à la main. */
      const pickedColor = () => { const k = KC(); return (k && k.value($('#bqx-sw', el))) || 'noir'; };
      $('#bqx-back', el).onclick = () => intakeNew(j, {});
      const save = () => {
        const size = $('#bqx-size', el).value.trim() || presets[0] || 'TU';
        const qty = Math.max(0, parseInt($('#bqx-qty', el).value, 10) || 0);
        let ev = null, res = null;
        cat.batch(() => {
          ev = cat.ensureVariant({ productId: pid, colorId: pickedColor(), size, stock: 0 });
          if (!ev.variant) return;
          res = cat.attachBarcode(ev.variant.id, j.code);
          if (!res.ok) { if (ev.created) cat.deleteVariant(ev.variant.id); return; }
          /* Une déclinaison qui existait déjà REÇOIT du stock — elle n'est pas
             remise à la quantité du carton. */
          if (qty > 0) cat.receiveStock(ev.variant.id, qty);
        });
        if (!ev || !ev.variant) { toast('Déclinaison impossible'); return; }
        const existed = !ev.created;
        if (!res || !res.ok) {
          if (res && res.reason === 'doublon') toast(`Ce code est déjà sur ${res.owner.product.name} · ${res.owner.variant.colorLabel} ${res.owner.variant.size}`);
          else toast('Code refusé');
          return;
        }
        intake.count++; intake.pieces += qty;
        intake.lastProduct = pid;
        intakeNote('variante', `${d.product.name} · ${size} · ${existed ? 'code ajouté' : 'déclinaison créée'}, ${qty} pièce${qty > 1 ? 's' : ''}`);
        toast(`${d.product.name} · ${size} enregistré`);
        intakeHint(`${d.product.name} · ${size} enregistré. Scannez l'article suivant.`, 'good');
        paintIntake();
      };
      $('#bqx-save', el).onclick = save;
      el.querySelectorAll('.bqx-form input').forEach((i) => {
        i.addEventListener('keydown', (e) => { if (e.key === 'Enter') { e.preventDefault(); save(); } });
      });
      setTimeout(() => { const s = $('#bqx-size', el); if (s) s.focus(); }, 40);
    });
  }

  /* ═══ état 3 bis · RATTACHER le code à une fiche déjà importée ═══
     La seconde moitié d'une reprise : le fichier du fournisseur est entré au
     tableau de bord avec les noms, les prix et les coûts, mais sans code — un
     tarif Excel n'en porte pas. L'employé parcourt le magasin, scanne, et
     retrouve ici la fiche qui attend son code. Rien à ressaisir. */
  function intakeLink(j) {
    intake.mode = 'rattacher';
    const cat = catDB();
    const draw = (q) => {
      const hits = cat.listCodeless({ q, limit: 40 });
      if (!hits.length) {
        return `<div class="bqx-log-empty">${q ? 'Aucune fiche sans code-barres ne porte ce nom.' : 'Toutes les fiches ont déjà un code-barres.'}</div>`;
      }
      return `<div class="bqx-linklist">${hits.map((h) => `
        <div class="bqx-linkprod">
          <div class="bqx-linkhead">
            <span class="mzi-art">${artOf(h.product)}</span>
            <div><b>${esc(h.product.name)}</b><span>${fmtMAD(shelf(h.product.priceMAD))}${h.product.cost ? ' · coût ' + fmtMAD(h.product.cost) : ''} · ${h.variants.length}/${h.total} sans code</span></div>
          </div>
          <div class="bqx-chips">${h.variants.map((v) => `
            <button type="button" class="bqx-chip is-pick" data-link-v="${v.id}" data-link-p="${h.product.id}">
              <i style="background:${v.colorHex}"></i>${esc(v.colorLabel)} · ${esc(v.size)} <b>${v.stock}</b>
            </button>`).join('')}</div>
        </div>`).join('')}</div>`;
    };
    invSetModal(`
      <button class="mz-modal-x" data-inv-x aria-label="Fermer"><i data-lucide="x"></i></button>
      ${intakeHeader()}
      <div class="bqx-found is-new">
        <i data-lucide="link"></i>
        <div>
          <b>Rattacher ce code à une fiche existante</b>
          <span class="bqx-codeline">${esc(j.code)} ${symBadge(j)}</span>
        </div>
      </div>
      <div class="bqx-body">
        <div class="bqx-scanbox slim"><i data-lucide="search"></i>
          <input id="bqx-lq" placeholder="Nom de l'article…" autocomplete="off" />
        </div>
        <div class="mzi-help">Touchez la déclinaison correspondante : le code y sera rattaché tel quel, sans réimpression.</div>
        <div id="bqx-lres">${draw('')}</div>
      </div>
      <div class="mzi-modfoot bqx-foot">
        <button class="mz-btn secondary" id="bqx-lback">Retour</button>
      </div>`, (el) => {
      const res = $('#bqx-lres', el), q = $('#bqx-lq', el);
      const wire = () => {
        res.querySelectorAll('[data-link-v]').forEach((b) => b.addEventListener('click', () => {
          const vid = b.getAttribute('data-link-v'), pid = b.getAttribute('data-link-p');
          const r = cat.attachBarcode(vid, j.code);
          if (!r.ok) {
            toast(r.reason === 'doublon' ? `Ce code vient d'être attribué à ${r.owner.product.name}` : 'Rattachement impossible');
            return;
          }
          const d = cat.getProduct(pid);
          intake.count++;
          intake.lastProduct = pid;
          intakeNote('variante', `${d.product.name} · code rattaché à une fiche importée`);
          toast(`Code ${j.code} rattaché à ${d.product.name}`);
          intakeHint(`${d.product.name} a maintenant son code. Scannez l'article suivant.`, 'good');
          paintIntake();
        }));
      };
      /* Le champ de recherche se tape à la main ; la douchette, elle, doit
         pouvoir scanner l'article SUIVANT sans quitter cet écran. */
      armScanCapture((c) => intakeTake(c));
      let t = null;
      q.addEventListener('input', () => {
        clearTimeout(t);
        t = setTimeout(() => { res.innerHTML = draw(q.value); wire(); icons(); }, 120);
      });
      $('#bqx-lback', el).onclick = () => intakeNew(j, {});
      wire();
      setTimeout(() => q.focus(), 40);
    });
  }

  /* ═══ état 4 · code DÉJÀ CONNU ═══
     Jamais de doublon silencieux. On montre ce que la boutique a déjà, et on
     propose les seules suites qui aient un sens : recevoir, compléter, corriger. */
  function intakeKnown(j) {
    intake.mode = 'connu';
    const cat = catDB();
    const pid = j.hit.product.id;
    const d = cat.getProduct(pid);
    const v = j.hit.variant;
    invSetModal(`
      <button class="mz-modal-x" data-inv-x aria-label="Fermer"><i data-lucide="x"></i></button>
      ${intakeHeader()}
      <div class="bqx-found is-known">
        <i data-lucide="package-check"></i>
        <div>
          <b>Article déjà au catalogue</b>
          <span class="bqx-codeline">${esc(j.code)} ${symBadge(j)}</span>
        </div>
      </div>
      <div class="bqx-known-card">
        <span class="mzi-art">${artOf(d.product)}</span>
        <div>
          <b>${esc(d.product.name)}</b>
          <span>${esc(d.category ? d.category.name : 'Divers')} · ${fmtMAD(shelf(d.product.priceMAD))} · ${d.stock} en stock au total</span>
          <span class="bqx-thisvar"><i style="background:${v.colorHex}"></i>Ce code désigne <b>${esc(v.colorLabel)} · ${esc(v.size)}</b> · ${v.stock} en stock</span>
        </div>
      </div>
      <div class="bqx-existing">
        <span>Toutes ses déclinaisons</span>
        <div class="bqx-chips">${d.variants.map((x) => `<span class="bqx-chip${x.id === v.id ? ' on' : ''}"><i style="background:${x.colorHex}"></i>${esc(x.colorLabel)} · ${esc(x.size)} <b>${x.stock}</b></span>`).join('')}</div>
      </div>
      <div class="bqx-acts">
        <div class="bqx-act">
          <div class="bqx-act-h"><i data-lucide="package-plus"></i><b>Recevoir du stock</b></div>
          <p>Plusieurs pièces du même article : indiquez la quantité, sans scanner chaque pièce.</p>
          <div class="bqx-qtyrow">
            <button class="mzi-mini" id="bqx-qminus" aria-label="Moins">−</button>
            <input id="bqx-rqty" type="number" min="1" step="1" inputmode="numeric" value="1" />
            <button class="mzi-mini" id="bqx-qplus" aria-label="Plus">+</button>
            <button class="mz-btn" id="bqx-receive">Ajouter au stock</button>
          </div>
        </div>
        <div class="bqx-act">
          <div class="bqx-act-h"><i data-lucide="git-branch"></i><b>Une taille ou couleur manque</b></div>
          <p>Le fournisseur donne un code par déclinaison : ajoutez-la sans recréer le produit.</p>
          <button class="mz-btn secondary" id="bqx-addvar">Ajouter une déclinaison</button>
        </div>
        <div class="bqx-act">
          <div class="bqx-act-h"><i data-lucide="pencil"></i><b>La fiche est fausse</b></div>
          <p>Nom, prix ou catégorie saisis de travers : corrigez l'article existant.</p>
          <button class="mz-btn secondary" id="bqx-fix">Corriger la fiche</button>
        </div>
      </div>
      <div class="mzi-modfoot bqx-foot">
        <button class="mz-btn secondary" id="bqx-next">Passer au suivant</button>
      </div>`, (el) => {
      const qty = $('#bqx-rqty', el);
      const nudge = (dz) => { qty.value = Math.max(1, (parseInt(qty.value, 10) || 1) + dz); };
      $('#bqx-qminus', el).onclick = () => nudge(-1);
      $('#bqx-qplus', el).onclick = () => nudge(1);
      const receive = () => {
        const n = parseInt(qty.value, 10) || 0;
        /* Une réception EST un mouvement d'entrée : elle passe par le registre
           quand il est actif (maison), et retombe sur receiveStock partout
           ailleurs — les autres boutiques ne changent pas de comportement. */
        const MZ = window.KiwiMaisonStock;
        if (MZ && MZ.isMaison()) {
          MZ.requestManual({ productId: pid, variantId: v.id, type: 'reception', qty: n, source: 'caisse' })
            .then((out) => {
              if (!out || !out.ok) {
                toast(out && out.reason === 'quantite' ? 'Indiquez une quantité d\'au moins 1'
                  : out && out.reason === 'non-autorise' ? 'Réception non autorisée · code responsable requis'
                    : 'Réception impossible');
                return;
              }
              afterReceive({ added: n, before: out.before, stock: out.after });
            });
          return;
        }
        const res = cat.receiveStock(v.id, n);
        if (!res.ok) { toast(res.reason === 'quantite' ? 'Indiquez une quantité d\'au moins 1' : 'Réception impossible'); return; }
        afterReceive(res);
      };
      const afterReceive = (res) => {
        /* Un réassort compte comme un article repris : sans ce `count++`, une
           session passée entièrement à remettre du stock sur des tailles déjà
           connues affichait « 0 article · 12 pièces » — un compteur qui se
           contredit lui-même et fait douter la vendeuse de tout l'écran. */
        intake.count++;
        intake.pieces += res.added;
        intakeNote('recu', `${d.product.name} · ${v.size} · ${res.added} reçue${res.added > 1 ? 's' : ''} (${res.before} → ${res.stock})`);
        toast(`${d.product.name} · ${v.size} : ${res.before} → ${res.stock}`);
        intakeHint(`${res.added} pièce${res.added > 1 ? 's' : ''} ajoutée${res.added > 1 ? 's' : ''} · ${d.product.name} ${v.size} passe à ${res.stock}. Scannez le suivant.`, 'good');
        paintIntake();
      };
      $('#bqx-receive', el).onclick = receive;
      qty.onkeydown = (e) => { if (e.key === 'Enter') { e.preventDefault(); receive(); } };
      $('#bqx-addvar', el).onclick = () => intakeAddVariantHere(pid);
      $('#bqx-fix', el).onclick = () => intakeFix(pid);
      $('#bqx-next', el).onclick = () => { intake.lastProduct = pid; paintIntake(); };
      setTimeout(() => { if (qty) { qty.focus(); qty.select(); } }, 40);
    });
  }

  /* Ajouter une déclinaison MANQUANTE à un article connu, avec son propre code
     fournisseur — on redemande le code puisque celui qu'on vient de scanner
     appartient déjà à une autre déclinaison. */
  function intakeAddVariantHere(pid) {
    const cat = catDB();
    const d = cat.getProduct(pid); if (!d) return;
    const presets = cat.sizePresets(d.product.kind);
    invSetModal(`
      <button class="mz-modal-x" data-inv-x aria-label="Fermer"><i data-lucide="x"></i></button>
      ${intakeHeader()}
      <div class="bqx-found is-new"><i data-lucide="git-branch"></i>
        <div><b>Déclinaison manquante · ${esc(d.product.name)}</b><span>Scannez le code de CETTE taille/couleur, ou laissez vide pour l'ajouter sans code.</span></div>
      </div>
      <div class="mzi-form bqx-form">
        <div class="mzi-fg"><label>Code-barres de la déclinaison</label>
          <div class="bqx-scanbox slim"><i data-lucide="scan-line"></i><input id="bqx-vcode" placeholder="Scannez ou tapez…" autocomplete="off" spellcheck="false" /></div>
          <div class="mzi-help" id="bqx-vhint">Chaque déclinaison peut porter son propre code fournisseur.</div>
        </div>
        <div class="mzi-fg"><label>Couleur</label><div id="bqx-sw">${colorPicker('noir')}</div></div>
        <div class="mzi-frow">
          <div class="mzi-fg"><label>Taille</label><input id="bqx-size" list="bqx-sizes3" placeholder="${esc(presets[0] || 'TU')}" autocomplete="off" /><datalist id="bqx-sizes3">${presets.map((s) => `<option value="${esc(s)}">`).join('')}</datalist></div>
          <div class="mzi-fg"><label>Quantité reçue</label><input id="bqx-qty" type="number" min="0" step="1" inputmode="numeric" value="1" /></div>
        </div>
      </div>
      <div class="bqx-existing">
        <span>Déjà au catalogue</span>
        <div class="bqx-chips">${d.variants.map((x) => `<span class="bqx-chip"><i style="background:${x.colorHex}"></i>${esc(x.colorLabel)} · ${esc(x.size)} <b>${x.stock}</b></span>`).join('')}</div>
      </div>
      <div class="mzi-modfoot bqx-foot">
        <button class="mz-btn secondary" id="bqx-back">Retour</button>
        <button class="mz-btn" id="bqx-save"><i data-lucide="check"></i>Ajouter la déclinaison</button>
      </div>`, (el) => {
      /* Le sélecteur de couleurs partagé (assets/color-palette.js) porte son propre
         état et sa navigation clavier : on lui DEMANDE sa valeur au moment
         d'enregistrer, plutôt que de suivre les clics à la main. */
      const pickedColor = () => { const k = KC(); return (k && k.value($('#bqx-sw', el))) || 'noir'; };
      const codeIn = $('#bqx-vcode', el);
      /* Le verdict s'affiche sous le champ, et il est le MÊME que le code arrive
         de la douchette ou des doigts : sans le second câblage, un employé qui
         tape un code déjà pris ne l'apprenait qu'au moment d'enregistrer. */
      const judgeV = (raw) => {
        const jj = intakeJudge(raw);
        const hint = $('#bqx-vhint', el);
        if (!hint) return jj;
        if (jj.kind === 'invalide') { hint.textContent = INVALID_MSG[jj.reason] || 'Code illisible.'; hint.className = 'mzi-help is-bad'; }
        else if (jj.kind === 'connu') { hint.textContent = `Déjà utilisé par ${jj.hit.product.name} · ${jj.hit.variant.colorLabel} ${jj.hit.variant.size}. Un code ne peut désigner qu'un seul article.`; hint.className = 'mzi-help is-bad'; }
        else { hint.textContent = `Code lu · ${(window.KiwiBarcode && window.KiwiBarcode.symLabel) ? window.KiwiBarcode.symLabel(jj.sym) : ''}${jj.check === 'bad' ? ' (clé de contrôle inhabituelle, accepté tel quel)' : ''}`; hint.className = 'mzi-help is-good'; }
        return jj;
      };
      armScanCapture((c) => { codeIn.value = normScan(c); judgeV(c); });   /* le scan vient ici, pas sur le ticket */
      const liveJudge = () => { const v = codeIn.value.trim(); if (v) judgeV(v); };
      codeIn.addEventListener('input', liveJudge);
      codeIn.addEventListener('change', liveJudge);
      $('#bqx-back', el).onclick = () => paintIntake();
      const save = () => {
        const size = $('#bqx-size', el).value.trim() || presets[0] || 'TU';
        const qty = Math.max(0, parseInt($('#bqx-qty', el).value, 10) || 0);
        const raw = codeIn.value.trim();
        if (raw) {
          const jj = judgeV(raw);   // refuse ET explique, sous le champ concerné
          if (jj.kind === 'invalide') { toast(INVALID_MSG[jj.reason] || 'Code illisible'); return; }
          if (jj.kind === 'connu') { toast(`Code déjà porté par ${jj.hit.product.name} · ${jj.hit.variant.size}`); return; }
        }
        let ev = null, res = null;
        cat.batch(() => {
          ev = cat.ensureVariant({ productId: pid, colorId: pickedColor(), size, stock: 0 });
          if (!ev.variant) return;
          if (raw) {
            res = cat.attachBarcode(ev.variant.id, raw);
            if (!res.ok) { if (ev.created) cat.deleteVariant(ev.variant.id); return; }
          }
          if (qty > 0) cat.receiveStock(ev.variant.id, qty);
        });
        if (!ev || !ev.variant) { toast('Déclinaison impossible'); return; }
        if (res && !res.ok) {
          toast(res.reason === 'doublon' ? `Code déjà utilisé par ${res.owner.product.name}` : 'Code refusé');
          return;
        }
        intake.count++; intake.pieces += qty;
        intake.lastProduct = pid;
        intakeNote('variante', `${d.product.name} · ${size} · ${ev.created ? 'déclinaison créée' : 'déjà présente'}, ${qty} pièce${qty > 1 ? 's' : ''}`);
        toast(`${d.product.name} · ${size} ajouté`);
        intakeHint(`${d.product.name} · ${size} ajouté. Scannez l'article suivant.`, 'good');
        paintIntake();
      };
      $('#bqx-save', el).onclick = save;
      el.querySelectorAll('.bqx-form input').forEach((i) => {
        i.addEventListener('keydown', (e) => { if (e.key === 'Enter') { e.preventDefault(); save(); } });
      });
      setTimeout(() => codeIn.focus(), 40);
    });
  }

  /* Corriger une fiche saisie de travers. Geste sensible (le prix part en caisse
     et le coût en compta) : passe par l'autorisation responsable, comme une remise. */
  function intakeFix(pid) {
    const cat = catDB();
    const d = cat.getProduct(pid); if (!d) return;
    const p = d.product;
    invSetModal(`
      <button class="mz-modal-x" data-inv-x aria-label="Fermer"><i data-lucide="x"></i></button>
      ${intakeHeader()}
      <div class="bqx-found is-fix"><i data-lucide="pencil"></i>
        <div><b>Corriger « ${esc(p.name)} »</b><span>Le code-barres et le stock ne changent pas · seule la fiche est corrigée.</span></div>
      </div>
      <div class="mzi-form bqx-form">
        <div class="mzi-fg"><label>Nom</label><input id="bqx-fname" value="${esc(p.name)}" /></div>
        <div class="mzi-frow">
          <div class="mzi-fg"><label>Catégorie</label><select id="bqx-fcat">${catSelectOptions(p.categoryId)}</select></div>
          <div class="mzi-fg"><label>Type</label><select id="bqx-fkind">${kindSelectOptions(p.kind)}</select></div>
        </div>
        <div class="mzi-frow">
          <div class="mzi-fg"><label>Prix de vente (MAD)</label><input id="bqx-fprice" type="number" min="0" step="0.01" value="${p.priceMAD}" /></div>
          <div class="mzi-fg"><label>Coût d'achat (MAD)</label><input id="bqx-fcost" type="number" min="0" step="0.01" value="${p.cost || 0}" /></div>
        </div>
      </div>
      <div class="mzi-modfoot bqx-foot">
        <button class="mz-btn secondary" id="bqx-back">Retour</button>
        <button class="mz-btn" id="bqx-fsave"><i data-lucide="check"></i>Enregistrer la correction</button>
      </div>`, (el) => {
      $('#bqx-back', el).onclick = () => paintIntake();
      $('#bqx-fsave', el).onclick = () => {
        const name = $('#bqx-fname', el).value.trim();
        if (!name) { toast('Le nom est requis'); return; }
        const patch = {
          name, categoryId: $('#bqx-fcat', el).value || null, kind: $('#bqx-fkind', el).value,
          priceMAD: bqMoney($('#bqx-fprice', el).value), cost: bqMoney($('#bqx-fcost', el).value),
        };
        const apply = () => {
          cat.updateProduct(pid, patch);
          intakeNote('recu', `${name} · fiche corrigée`);
          toast('Fiche corrigée');
          paintIntake();
        };
        /* Changer le prix change ce que la caisse encaissera, et l'ancien prix
           est peut-être le bon : on fait confirmer l'écart explicitement plutôt
           que de l'appliquer au passage. (openApprove() ne convient pas ici —
           il parle d'une remise et lit state.ticket, qui n'existe pas pendant
           une reprise de stock.) */
        if (patch.priceMAD !== p.priceMAD) intakeConfirmPrice(p, patch.priceMAD, apply);
        else apply();
      };
      setTimeout(() => { const n = $('#bqx-fname', el); if (n) { n.focus(); n.select(); } }, 40);
    });
  }

  /* Un prix corrigé se répercute sur tous les encaissements suivants : l'écart est
     montré en clair, avec le nom de qui est à la caisse, avant d'être appliqué. */
  function intakeConfirmPrice(p, next, onOk) {
    const who = (STAFF.caissiere && STAFF.caissiere.name) || '';
    invSetModal(`
      <button class="mz-modal-x" data-inv-x aria-label="Fermer"><i data-lucide="x"></i></button>
      <div class="bqx-found is-fix"><i data-lucide="alert-triangle"></i>
        <div><b>Confirmer le changement de prix</b><span>${esc(p.name)} sera encaissé à ce nouveau prix dès la prochaine vente.</span></div>
      </div>
      <div class="bqx-pricediff">
        <div><span>Prix actuel</span><b>${fmtMAD(p.priceMAD)}</b></div>
        <i data-lucide="arrow-right"></i>
        <div class="next"><span>Nouveau prix</span><b>${fmtMAD(next)}</b></div>
      </div>
      <div class="mzi-modfoot bqx-foot">
        <button class="mz-btn secondary" id="bqx-pno">Garder ${fmtMAD(p.priceMAD)}</button>
        <button class="mz-btn" id="bqx-pyes"><i data-lucide="check"></i>Appliquer${who ? ' · ' + esc(who) : ''}</button>
      </div>`, (el) => {
      $('#bqx-pno', el).onclick = () => intakeFix(p.id);
      $('#bqx-pyes', el).onclick = () => onOk();
    });
  }

  /* ─── label printing (printer wired to the caisse) ─── */
  /* L'étiquette de rayon porte le prix QU'ON ENCAISSE, pas le prix catalogue.
     Sans ça, lancer une promotion obligeait à réimprimer tout un rayon à la
     main — ou, pire, laissait les étagères annoncer l'ancien prix pendant que
     la caisse en encaisse un autre : c'est le commerçant qui se retrouve à
     devoir expliquer l'écart à la cliente, au comptoir, sans savoir d'où il
     vient. `was` fait ressortir l'ancien prix barré, comme une vraie affiche de
     soldes. Quand la promotion s'arrête, réimprimer redonne le prix plein. */
  function labelForVariant(pid, v) {
    const cat = catDB(); const p = cat.getProduct(pid).product;
    const code = cat.primaryBarcode(v);
    if (!code) return null;
    const extra = v.note || v.colorSource || '';
    const pr = promoFor(pid);
    return {
      title: p.name, sub: `${v.colorLabel}${extra ? ` (${extra})` : ''} · ${v.size}`,
      price: fmtNum(pr ? pr.price : shelf(p.priceMAD)),
      was: pr ? fmtNum(pr.was) : null,
      code, format: window.KiwiBarcode.isValidEan13(code) ? 'ean13' : 'code128',
    };
  }
  function printVariantLabel(vid) {
    const cat = catDB();
    let pid = null, v = null;
    for (const p of cat.listProducts({ includeArchived: true })) { const found = cat.listVariants(p.id).find((x) => x.id === vid); if (found) { pid = p.id; v = found; break; } }
    if (!v) return;
    const label = labelForVariant(pid, v);
    if (!label) { toast('Générez d\'abord un EAN-13'); return; }
    labelToast(window.KiwiBarcode.printLabels([label], { copies: 1 }), 'Étiquette');
  }
  function printProductLabels(pid) {
    const cat = catDB(); const d = cat.getProduct(pid); if (!d) return;
    const labels = [];
    d.variants.forEach((v) => {
      const label = labelForVariant(pid, v);
      if (!label) return;
      const stock = Math.max(0, Math.floor(Number(v.stock) || 0));
      for (let i = 0; i < stock; i++) labels.push(label);
    });
    if (!labels.length) { toast('Aucune unité en stock avec un code-barres à imprimer'); return; }
    labelToast(window.KiwiBarcode.printLabels(labels, { copies: 1 }), `${labels.length} étiquette(s)`);
  }
  // Toast the true outcome of a print (thermal / browser / connect-a-printer),
  // never a blanket "sent" — printLabels resolves with { ok, browser?, reason? }.
  function labelToast(p, what) {
    if (!p || !p.then) return;
    p.then((res) => {
      // Only announce a real send to a connected printer (res.via = bluetooth/bridge).
      // For the chooser (Imprimer / Enregistrer en PDF), the modal speaks for itself.
      if (res && res.ok && res.via) toast(`${what} envoyée à l'imprimante`);
    });
  }