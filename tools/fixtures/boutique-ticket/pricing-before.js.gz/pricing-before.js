  function lineDeal(ln) {
    const stamp = (ln && ln.promo && Number.isFinite(+ln.promo.price)) ? { ...ln.promo, price: shelf(ln.promo.price) } : null;
    const live = promoFor(ln.pid);
    const full = shelf(P[ln.pid].price);
    let best = { price: full, promo: null };
    if (stamp && stamp.price < best.price) best = { price: stamp.price, promo: stamp };
    if (live && live.price < best.price) best = { price: live.price, promo: { price: live.price, badge: live.badge, name: live.promo.name, id: live.promo.id } };
    return best;
  }
  const linePromo = (ln) => lineDeal(ln).promo;
  const lineBase  = (ln) => lineDeal(ln).price;
  const lineUnit  = (ln) => shelf(lineBase(ln) * (100 - ln.remise) / 100);
  const lineTotal = (ln) => lineUnit(ln) * ln.qty;
  /* Remise fidélité au niveau du TICKET (distincte de la remise gérante par ligne).
     Attachée au client via clientId : si on détache/change la cliente, elle cesse
     de s'appliquer d'elle-même, sans avoir à la retirer partout à la main. */
  function rewardDiscount(t, base) {
    const r = t.reward;
    if (!r || r.clientId !== t.client) return 0;
    /* la remise est ce qui reste quand le total est arrondi vers le bas :
       arrondir la remise au plus proche refaisait payer jusqu'à 0,50 de trop */
    if (r.kind === 'percent') return base - shelf(base * (100 - (r.value || 0)) / 100);
    if (r.kind === 'free' && t.lines.length) return Math.min.apply(null, t.lines.map(lineUnit));
    return 0;
  }
  /* Trois baisses, trois lignes séparées, jamais une seule « remise » fourre-tout :
     la promotion est une décision du magasin, la remise un geste de la gérante,
     la récompense un dû de la cliente. Les confondre au total, c'est rendre le
     rapport de clôture incapable de dire ce que les promotions ont coûté. */
  function ticketTotals(t) {
    const sub = t.lines.reduce((s, ln) => s + shelf(P[ln.pid].price) * ln.qty, 0);
    const afterPromo = t.lines.reduce((s, ln) => s + lineBase(ln) * ln.qty, 0);
    const afterLines = t.lines.reduce((s, ln) => s + lineTotal(ln), 0);
    const reward = rewardDiscount(t, afterLines);
    const total = Math.max(0, afterLines - reward);
    return { sub, promo: sub - afterPromo, remise: afterPromo - afterLines, reward, total };
  }
