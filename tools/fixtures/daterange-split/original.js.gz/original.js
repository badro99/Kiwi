/* ═══════════════════════════════════════════════════════════════════════════
 * Kiwi · Global dashboard date-range selector
 *
 * Holds the selected range ('aujourdhui' | 'hier' | 'septJours' |
 * 'trenteJours' | 'personnalise'), persists to localStorage, lets sections
 * subscribe to changes, and renders every data-bearing block on the dashboard.
 * ─────────────────────────────────────────────────────────────────────────── */
(() => {
  'use strict';

  const STORAGE_KEY = 'kiwiDateRange';
  const CMP_KEY = 'kiwiRevCompare';
  const DEFAULT_RANGE = 'aujourdhui';
  /* 'personnalise' is a first-class range again: the "Personnalisé" pill
   * opens a calendar popover (openCustomPicker) that commits a { start,
   * end } pair. The custom range carries no data table of its own —
   * effRange() buckets it onto an existing range by span, so every
   * dashboard block stays internally consistent. */
  const VALID = ['aujourdhui', 'hier', 'septJours', 'trenteJours', 'moisDernier', 'trimestre', 'annee', 'personnalise'];
  const subscribers = new Set();
  let currentRange = DEFAULT_RANGE;
  let showComparison = false;

  /* ─── Custom range state · the picked { start, end } Date pair ───────
   * Persisted to localStorage as "YYYY-MM-DD|YYYY-MM-DD". */
  const CUSTOM_KEY = 'kiwiCustomRange';
  let customRange = null;

  const z2 = (n) => String(n).padStart(2, '0');
  const dateToIso = (d) => `${d.getFullYear()}-${z2(d.getMonth() + 1)}-${z2(d.getDate())}`;
  function isoToDate(s) {
    const m = /^(\d{4})-(\d{2})-(\d{2})$/.exec(String(s || ''));
    if (!m) return null;
    const d = new Date(+m[1], +m[2] - 1, +m[3]);
    return isNaN(d.getTime()) ? null : d;
  }
  function parseCustom(str) {
    const p = String(str || '').split('|');
    const a = isoToDate(p[0]), b = isoToDate(p[1]);
    if (!a || !b) return null;
    return a <= b ? { start: a, end: b } : { start: b, end: a };
  }
  // Inclusive whole-day span between two Dates (same day → 1).
  function spanDays(a, b) {
    const d0 = Date.UTC(a.getFullYear(), a.getMonth(), a.getDate());
    const d1 = Date.UTC(b.getFullYear(), b.getMonth(), b.getDate());
    return Math.round(Math.abs(d1 - d0) / 864e5) + 1;
  }
  /* Borrow the shape of a real data-bearing range, picked by how many
   * days the custom range spans — hier / septJours / trenteJours are the
   * buckets every venue-keyed table is guaranteed to carry. */
  function customBucket() {
    if (!customRange) return 'trenteJours';
    const n = spanDays(customRange.start, customRange.end);
    if (n <= 1) return 'hier';
    if (n <= 10) return 'septJours';
    return 'trenteJours';
  }
  // Resolve currentRange to a range key that actually carries data.
  function effRange() {
    return currentRange === 'personnalise' ? customBucket() : currentRange;
  }

  const getLang = () => (window.KiwiI18n?.getLang?.() || 'fr');
  /* La devise se lit comme ailleurs dans le tableau de bord : « درهم » sous
   * l'arabe (inventaire, fiche produit, insights, répartition des paiements),
   * « MAD » sinon. L'accueil seul écrivait « 0 MAD » sous l'arabe, à côté
   * d'un inventaire en « 4 500 درهم ». */
  const curUnit = () => (getLang() === 'ar' ? 'درهم' : 'MAD');
  // Translate a captured-FR string through a { frString: {en,ar} } map.
  // FR locale or an unmapped string falls through to the original — the
  // same graceful pattern used by the [lang]?.[key] || .fr[key] lookups.
  function trStr(fr, map) {
    const lang = getLang();
    if (lang === 'fr' || !fr) return fr;
    return (map[fr] && map[fr][lang]) || trTemplate(fr, map, lang) || fr;
  }
  /* Les libellés à nombre (« 31 DERNIERS JOURS », « Total 92 jours ») : la clé
   * exacte d'abord, puis le gabarit « # ». Sans lui, la plage réelle d'un
   * commerçant retombait en français dès qu'elle ne faisait pas 7 ou 30 jours. */
  function trTemplate(fr, map, lang) {
    const m = /\d+/.exec(fr);
    if (!m) return null;
    const e = map[fr.replace(m[0], '#')];
    const f = e && e[lang];
    return typeof f === 'function' ? f(+m[0]) : null;
  }
  function arDays(n) {
    if (n === 1) return 'يوم واحد';
    if (n === 2) return 'يومين';
    return (n % 100 >= 3 && n % 100 <= 10) ? n + ' أيام' : n + ' يومًا';
  }
  // Translate "PREFIX · rest" — only the prefix is localized, the rest
  // (usually a formatted amount) is kept verbatim.
  function trLegend(fr, map) {
    const lang = getLang();
    if (lang === 'fr' || !fr) return fr;
    const i = fr.indexOf(' · ');
    if (i < 0) return (map[fr] && map[fr][lang]) || trTemplate(fr, map, lang) || fr;
    const pre = fr.slice(0, i);
    return ((map[pre] && map[pre][lang]) || trTemplate(pre, map, lang) || pre) + fr.slice(i);
  }
  const getDateRange = () => currentRange;
  const getShowComparison = () => showComparison;
  const getCurrentVenue = () => (window.KiwiVenue?.getVenue?.() || 'cafeAtlas');

  /* ─── WHOSE DATA IS THIS? ────────────────────────────────────────────────
   * Every card below picks between the merchant's OWN store and the demo
   * model, and every one of them used to ask isCustom() — "did the user
   * create this venue?". That misses the state a real merchant is actually
   * in for their first minutes, and after any venue-resolution hiccup: a
   * hosted, signed-in session sitting on a venue id that is not flagged
   * custom. In that state the hero, the payment mix, the KPI band and the
   * revenue chart all fell through to the demo model and painted somebody
   * else's day, while the assistant — which asks isReal() || isCustom() —
   * correctly answered that there were no sales yet.
   *
   * That disagreement is the single worst thing this product can do: the
   * merchant reads two Kiwi surfaces, they contradict each other about
   * whether their own money exists, and neither is obviously the liar. So
   * the question is asked ONCE, here, and it is the assistant's question.
   * A real session shows its own data or an empty state — never a demo's.
   * Local demo: isReal() is false, so nothing about it changes. */
  const ownData = (id) => {
    const KV = window.KiwiVenue;
    if (KV && KV.isCustom && KV.isCustom(id)) return true;
    return !!(window.KiwiEnv?.isReal?.());
  };

  /* ─── Fusion-mode aggregator ───────────────────────────────────────────
   * When the merchant has activated "Fusionner les 3 emplacements", every
   * venue-keyed table is summed across cafeAtlas + maisonMansour + spaBahia.
   *
   * Strategy: recursive merge that sums numerics and arrays of numerics,
   * deep-merges objects, and falls back to cafeAtlas for non-aggregable
   * shapes (strings, booleans, null). Keys flagged as "rate-like" (delta*,
   * pct, taux, rate, success, ratio) are averaged instead of summed so
   * percentages don't blow past 100. */
  const FUSION_AVG_KEYS = /(^delta|^pct$|^percent$|^rate$|^success$|^ratio$|^taux|^score$|^health$|^panier$|^basket$|^avg|^moy)/i;
  function isPlainObj(o) {
    return o && typeof o === 'object' && !Array.isArray(o);
  }
  function aggFusion(values, parentKey, rateCtx) {
    const defined = values.filter(v => v !== undefined && v !== null);
    if (defined.length === 0) return values[0] ?? null;
    const first = defined[0];
    // Rate context: once an ancestor key is "rate-like" (success/ratio/taux/
    // delta…) every numeric descendant averages instead of sums. This keeps
    // a fused success of 95% × 92% × 88% reading as ~91%, not 275%.
    const myRateCtx = rateCtx || FUSION_AVG_KEYS.test(String(parentKey || ''));
    if (typeof first === 'number') {
      const sum = defined.reduce((a, v) => a + (typeof v === 'number' ? v : 0), 0);
      return myRateCtx ? sum / defined.length : sum;
    }
    if (typeof first === 'string' || typeof first === 'boolean') {
      // Take cafeAtlas (index 0 in source order) — labels/copy don't aggregate.
      return values[0] ?? first;
    }
    if (Array.isArray(first)) {
      const maxLen = Math.max(...defined.map(a => Array.isArray(a) ? a.length : 0));
      const out = [];
      for (let i = 0; i < maxLen; i++) {
        const slice = defined.map(a => Array.isArray(a) ? a[i] : undefined);
        out.push(aggFusion(slice, parentKey, myRateCtx));
      }
      return out;
    }
    if (isPlainObj(first)) {
      const keys = new Set();
      defined.forEach(o => isPlainObj(o) && Object.keys(o).forEach(k => keys.add(k)));
      const out = {};
      keys.forEach(k => {
        const slice = defined.map(o => isPlainObj(o) ? o[k] : undefined);
        out[k] = aggFusion(slice, k, myRateCtx);
      });
      return out;
    }
    return first;
  }
  // Deep clone of a data slice with every number zeroed and every array kept
  // at the same length — used to give a brand-new user-created venue a
  // structurally-valid but empty dataset, so every renderer paints its real
  // "no data yet" state instead of crashing or falling back to demo numbers.
  function zeroClone(x) {
    if (typeof x === 'number') return 0;
    if (Array.isArray(x)) return x.map(zeroClone);
    if (x && typeof x === 'object') {
      const o = {};
      for (const k in x) o[k] = zeroClone(x[k]);
      return o;
    }
    return x; // strings (labels), booleans, null — preserved
  }

  // Resolve a venue-keyed table for the active venue + range, with cafeAtlas fallback.
  function vData(table, range) {
    const v = getCurrentVenue();
    const knownRanges = ['aujourdhui', 'hier', 'septJours', 'trenteJours', 'personnalise'];
    const requested = range === 'personnalise' ? effRange() : range;
    const hasRequested = !!(table?.[v]?.[requested] ?? table?.cafeAtlas?.[requested]);
    const eff = knownRanges.includes(range) || hasRequested ? requested : 'trenteJours';
    // A user-created venue has no demo data — hand back a zeroed clone of its
    // base type's demo sibling so the dashboard renders empty rather than
    // borrowing live numbers via the fallback below. The shape must match the
    // vertical (a boutique-based venue needs tauxRetour, a spa needs tips…),
    // otherwise vertical-specific KPI tiles silently drop.
    if (ownData(v)) {
      const baseIds = { restaurant: 'cafeAtlas', boutique: 'maisonMansour', spa: 'spaBahia' };
      const baseId = baseIds[window.KiwiVenue?.getVenueType?.() || 'restaurant'] || 'cafeAtlas';
      const shape = table?.[baseId]?.[eff] ?? table?.[baseId]?.trenteJours
                 ?? table?.cafeAtlas?.[eff] ?? table?.cafeAtlas?.trenteJours;
      return shape == null ? shape : zeroClone(shape);
    }
    if (v === 'fusion') {
      const slices = [
        table?.cafeAtlas?.[eff],
        table?.maisonMansour?.[eff],
        table?.spaBahia?.[eff],
      ];
      const merged = aggFusion(slices, '');
      // If every slice was null/undefined fallback gracefully.
      return merged ?? table?.cafeAtlas?.[eff] ?? table?.cafeAtlas?.trenteJours;
    }
    const shape = table?.[v]?.[eff] ?? table?.cafeAtlas?.[eff] ?? table?.[v]?.trenteJours ?? table?.cafeAtlas?.trenteJours;
    return demoLedgerProjection(table, eff, shape);

  }
  const ledgerSum = rows => rows.reduce((s,r)=>s+Math.round(r.amount*100),0)/100;
  /* The same-length window before the selected one: yesterday up to the same
     point of its business day for Today, the day before for Yesterday, the
     previous 7 or 30 days otherwise. */
  function priorLedgerRows(range, selected, days, day) {
    const clock = window.KiwiDemoClock, dr = window.KiwiDayReport;
    if (days === 1) {
      const before = dr.shiftDay(selected,-1), b = dr.dayBounds(selected), o = dr.dayBounds(before);
      const cut = range === 'aujourdhui' ? o.from + (Date.now() - b.from) : o.to;
      return clock.getDaySales(before).filter(r=>r.ts<=cut);
    }
    let prior = [];
    for (let i = days; i < days * 2; i++) prior = prior.concat(clock.getDaySales(dr.shiftDay(day,-i)));
    return prior;
  }
  /* Today against yesterday at the same time, from the same ledger, for Kiwi
     AI's Today card on the kit (§18.6); null where that ledger is not running. */
  function todayPace() {
    const clock = window.KiwiDemoClock, dr = window.KiwiDayReport;
    if (!dr || !clock?.getSimState?.()) return null;
    const day = dr.today(), rows = clock.getDaySales(day) || [];
    return { total:ledgerSum(rows), count:rows.length, priorTotal:ledgerSum(priorLedgerRows('aujourdhui', day, 1, day)), at:Date.now() };
  }
  function demoLedgerProjection(table, range, shape) {
    const clock = window.KiwiDemoClock, dr = window.KiwiDayReport;
    if (!shape || !dr || !['aujourdhui','hier','septJours','trenteJours'].includes(range)
      || ![heroDataByVenue,goalByVenue,kpiByVenue,revChartByVenue,mixByVenue].includes(table) || !clock?.getSimState?.()) return shape;
    const day = dr.today(), days = range === 'septJours' ? 7 : range === 'trenteJours' ? 30 : 1;
    const selected = range === 'hier' ? dr.shiftDay(day,-1) : day;
    const rows = days === 1 ? clock.getDaySales(selected) : clock.getSales(days);
    const sum = ledgerSum;
    const total = sum(rows), count = rows.length;
    if (table === heroDataByVenue) return {...shape,amount:total,netAfterKiwi:total,deltaHier:null,deltaSemaine:null,deltaMois:null};
    if (table === goalByVenue) return {...shape,current:total};
    // One ledger, one tender definition across the donut and card/cash KPI.
    const tenders = entries => {
      const by = {};
      entries.forEach(entry => tenderAmounts(entry).forEach(part => {
        if (part.key) by[part.key] = (by[part.key] || 0) + Math.round(part.amount * 100);
      }));
      return by;
    };
    const by = tenders(rows);
    if (table === mixByVenue) {
      const collectedCents = Object.values(by).reduce((s, value) => s + value, 0);
      const lang = getLang();
      return {...shape, _demoLedger:true, centerMad:collectedCents / 100,
        mixRows:REAL_MIX.filter(m => by[m.key] > 0).map(m => ({
          color:m.color, label:m[lang] || m.fr, pct:by[m.key] / collectedCents * 100}))};
    }
    if (table === kpiByVenue) {
      // Same-length previous window (priorLedgerRows). Deltas come from the
      // ledger, never a constant.
      const prior = priorLedgerRows(range, selected, days, day);
      const pct = (now, then) => then ? Math.round((now - then) / then * 1000) / 10 : 0;
      const priorTotal = sum(prior), priorCount = prior.length;
      const cardShare = tender => {
        const card = (tender.card || 0) + (tender.tap || 0), cash = tender.cash || 0;
        return card + cash ? card / (card + cash) * 100 : null;
      };
      const share = cardShare(by), oldShare = cardShare(tenders(prior));
      const roundedShare = Math.round(share || 0);
      return {...shape,
        ratio:shape.ratio && {...shape.ratio,
          text:share == null ? '·' : `${roundedShare} / ${100 - roundedShare}`,
          unit:share == null ? '' : '%', delta:share == null || oldShare == null ? null : pct(share, oldShare)},
        tx:shape.tx && {...shape.tx,value:count,delta:pct(count,priorCount)},
        panier:shape.panier && {...shape.panier,value:count ? total/count : 0,
          delta:pct(count ? total/count : 0, priorCount ? priorTotal/priorCount : 0)}};
    }
    let rev, revPrev, xLabels, visibleXIdx, cursor = {};
    if (days > 1) {
      const keys = Array.from({length:days},(_,i)=>dr.shiftDay(day,i-days+1));
      rev = keys.map(key=>sum(clock.getDaySales(key)));
      revPrev = keys.map(key=>sum(clock.getDaySales(dr.shiftDay(key,-days))));
      xLabels = keys.map(key=>new Date(key+'T12:00:00').toLocaleDateString(getLang()==='ar'?'ar-MA':getLang()==='en'?'en-GB':'fr-FR',{weekday:'short',day:'numeric'}));
      visibleXIdx = keys.map((_,i)=>i).filter(i=>days===7 || i%5===0 || i===days-1);
    } else {
      const bounds=dr.dayBounds(selected), before=dr.shiftDay(selected,-1), prior=clock.getDaySales(before), old=dr.dayBounds(before);
      const progress = range==='aujourdhui' ? Math.min(24,(Date.now()-bounds.from)/(bounds.to-bounds.from)*24) : 24;
      const index=Math.min(23,Math.floor(progress));
      rev = Array.from({length:25},(_,i)=>i>Math.ceil(progress)?null:sum(rows.filter(r=>r.ts<=bounds.from+Math.min(i,progress)/24*(bounds.to-bounds.from))));
      revPrev = Array.from({length:25},(_,i)=>sum(prior.filter(r=>r.ts<=old.from+i/24*(old.to-old.from))));
      xLabels=Array.from({length:25},(_,i)=>String((5+i)%24).padStart(2,'0')+'h');
      visibleXIdx=xLabels.map((_,i)=>i);
      if(range==='aujourdhui') cursor={_simIdx:index,_simWithin:progress-index};
    }
    const maximum=Math.max(1,...rev.filter(v=>v!=null),...revPrev);
    const ceiling=Math.ceil(maximum/4000)*4000;
    return {...shape,...cursor,_demoLedger:true,rev,revPrev,xLabels,visibleXIdx,total,
      yTicks:[0,.25,.5,.75,1].map(n=>Math.round(n*ceiling)),
      legendPrimary:shape.legendPrimary.split(' · ')[0]+' · '+frInt(total)+' MAD',
      legendCompare:shape.legendCompare.split(' · ')[0]+' · '+frInt(days>1?sum(revPrev.map(amount=>({amount}))):revPrev.at(-1))+' MAD'};
  }

  // True only on the live "today" range, with the demo clock active.
  function isLiveDemo() {
    const eff = effRange();
    // A user-created venue has no synthetic demo clock — it stays at zero
    // until the merchant records real sales.
    if (ownData(getCurrentVenue())) return false;
    return eff === 'aujourdhui' && !!window.KiwiDemoClock?.isActive?.();
  }
  let demoRenderSim = null, demoHeroSim = null;
  function getSim() { return demoRenderSim || window.KiwiDemoClock?.getSimState?.() || null; }
  // One same-time yesterday comparator for both demo cards. The old goal
  // breakdown kept a fixed +3.2% while the chart used a future hour boundary.
  // Called only from the demo branch; merchant sales/reconciliation stay intact.
  function demoPreviousAt(sim) {
    const dr=window.KiwiDayReport, clock=window.KiwiDemoClock;
    if (sim && dr && clock?.getDaySales) {
      const day=dr.shiftDay(dr.today(),-1), bounds=dr.dayBounds(day);
      const before=bounds.from+sim.fraction*(bounds.to-bounds.from);
      return clock.getDaySales(day).filter(r=>r.ts<=before).reduce((s,r)=>s+Math.round(r.amount*100),0)/100;
    }
    const series = vData(revChartByVenue, currentRange)?.revPrev;
    if (!sim || !series?.length) return null;
    const index = Math.min(series.length - 1, Math.max(0, sim.simIdx));
    const next = Math.min(series.length - 1, index + 1);
    return series[index] + (series[next] - series[index]) * sim.simWithin;
  }
  // Set true while a demoClock tick is fanning out renders — used to suppress
  // entrance animations on the chart (would otherwise replay every 3s).
  let liveTickInProgress = false;

  /* ═══════════════ STRINGS ═══════════════ */

  const RANGE_STR = {
    fr: { aujourdhui: "Aujourd'hui", hier: 'Hier', septJours: '7 derniers jours', trenteJours: '30 derniers jours', moisDernier: 'Mois dernier', trimestre: 'Ce trimestre', annee: 'Cette année', personnalise: 'Période personnalisée' },
    en: { aujourdhui: 'Today', hier: 'Yesterday', septJours: 'Last 7 days', trenteJours: 'Last 30 days', moisDernier: 'Last month', trimestre: 'This quarter', annee: 'This year', personnalise: 'Custom period' },
    ar: { aujourdhui: 'اليوم', hier: 'أمس', septJours: 'آخر 7 أيام', trenteJours: 'آخر 30 يوما', moisDernier: 'الشهر الماضي', trimestre: 'هذا الربع', annee: 'هذه السنة', personnalise: 'فترة مخصصة' },
  };

  const HERO_LABEL = {
    fr: { aujourdhui: "ENCAISSÉ AUJOURD'HUI", hier: 'ENCAISSÉ HIER', septJours: 'ENCAISSÉ 7 JOURS', trenteJours: 'ENCAISSÉ 30 JOURS', moisDernier: 'ENCAISSÉ, MOIS DERNIER', trimestre: 'ENCAISSÉ, TRIMESTRE', annee: 'ENCAISSÉ, ANNÉE', personnalise: 'ENCAISSÉ, PÉRIODE' },
    en: { aujourdhui: 'CASHED TODAY', hier: 'CASHED YESTERDAY', septJours: 'CASHED 7 DAYS', trenteJours: 'CASHED 30 DAYS', moisDernier: 'CASHED, LAST MONTH', trimestre: 'CASHED, QUARTER', annee: 'CASHED, YEAR', personnalise: 'CASHED, PERIOD' },
    ar: { aujourdhui: 'المقبوض اليوم', hier: 'المقبوض أمس', septJours: 'المقبوض في 7 أيام', trenteJours: 'المقبوض في 30 يومًا', moisDernier: 'المقبوض، الشهر الماضي', trimestre: 'المقبوض، الربع', annee: 'المقبوض، السنة', personnalise: 'المقبوض، الفترة' },
  };

  /* §9.4: with the 2027 dashboard on, the shipped capitals below read in
     sentence case; with it off they stay as shipped. Currency codes and the
     Z of a Z report keep their capitals. A comparison ("vs hier") follows a
     figure, so it starts in lower case. */
  function kitCase(s, lead) {
    s = String(s == null ? '' : s);
    const de = typeof document !== 'undefined' && document.documentElement;
    if (!de || !de.getAttribute || de.getAttribute('data-skin-2027') !== 'dashboard' || s !== s.toUpperCase()) return s;
    const low = s.toLowerCase().replace(/\b(mad|eur|usd|aed|gbp|z|tva|ice)\b/g, (m) => m.toUpperCase());
    return lead === false ? low : low.charAt(0).toUpperCase() + low.slice(1);
  }
  function deltaLabels(lang, range) {
    const src = DELTA_LABELS[lang]?.[range] || DELTA_LABELS.fr[range];
    if (!src) return src;
    const out = {};
    for (const k in src) out[k] = kitCase(src[k], false);
    return out;
  }

  const DELTA_LABELS = {
    fr: {
      aujourdhui:   { hier: 'VS HIER', semaine: 'VS SEMAINE', mois: 'VS MOIS DERNIER' },
      hier:         { hier: 'VS AVANT-HIER', semaine: 'VS SEMAINE', mois: 'VS MOIS' },
      septJours:    { semaine: 'VS 7 JOURS PRÉCÉDENTS', mois: 'VS MOIS' },
      trenteJours:  { mois: 'VS 30 JOURS PRÉCÉDENTS' },
      moisDernier:  { mois: 'VS MOIS PRÉC.' },
      trimestre:    { mois: 'VS TRIMESTRE PRÉC.' },
      annee:        { mois: 'VS ANNÉE PRÉC.' },
      personnalise: { hier: 'VS HIER', semaine: 'VS SEMAINE', mois: 'VS MOIS DERNIER' },
    },
    en: {
      aujourdhui:   { hier: 'VS YESTERDAY', semaine: 'VS WEEK', mois: 'VS LAST MONTH' },
      hier:         { hier: 'VS DAY BEFORE', semaine: 'VS WEEK', mois: 'VS MONTH' },
      septJours:    { semaine: 'VS PREVIOUS 7 DAYS', mois: 'VS MONTH' },
      trenteJours:  { mois: 'VS PREVIOUS 30 DAYS' },
      moisDernier:  { mois: 'VS PREV. MONTH' },
      trimestre:    { mois: 'VS PREV. QUARTER' },
      annee:        { mois: 'VS PREV. YEAR' },
      personnalise: { hier: 'VS YESTERDAY', semaine: 'VS WEEK', mois: 'VS LAST MONTH' },
    },
    ar: {
      aujourdhui:   { hier: 'مقابل أمس', semaine: 'مقابل الأسبوع', mois: 'مقابل الشهر الماضي' },
      hier:         { hier: 'مقابل أول أمس', semaine: 'مقابل الأسبوع', mois: 'مقابل الشهر' },
      septJours:    { semaine: 'مقابل 7 أيام السابقة', mois: 'مقابل الشهر' },
      trenteJours:  { mois: 'مقابل 30 يومًا السابقة' },
      moisDernier:  { mois: 'مقابل الشهر السابق' },
      trimestre:    { mois: 'مقابل الربع السابق' },
      annee:        { mois: 'مقابل السنة السابقة' },
      personnalise: { hier: 'مقابل أمس', semaine: 'مقابل الأسبوع', mois: 'مقابل الشهر الماضي' },
    },
  };

  const KPI_DELTA_SUFFIX = {
    fr: { aujourdhui: 'vs hier', hier: 'vs avant-hier', septJours: 'vs 7 jours préc.', trenteJours: 'vs 30 jours préc.', moisDernier: 'vs mois préc.', trimestre: 'vs trimestre préc.', annee: 'vs année préc.', personnalise: 'vs hier' },
    en: { aujourdhui: 'vs yesterday', hier: 'vs day before', septJours: 'vs previous 7 days', trenteJours: 'vs previous 30 days', moisDernier: 'vs previous month', trimestre: 'vs previous quarter', annee: 'vs previous year', personnalise: 'vs previous period' },
    ar: { aujourdhui: 'مقابل أمس', hier: 'مقابل أول أمس', septJours: 'مقابل 7 أيام السابقة', trenteJours: 'مقابل 30 يومًا السابقة', moisDernier: 'مقابل الشهر السابق', trimestre: 'مقابل الربع السابق', annee: 'مقابل السنة السابقة', personnalise: 'مقابل أمس' },
  };

  // Caption shown under the chart title when "Comparer" is on, by selected range.
  const COMPARE_CAPTION = {
    fr: { aujourdhui: 'vs. Hier', hier: 'vs. Avant-hier', septJours: 'vs. 7 jours précédents', trenteJours: 'vs. 30 jours précédents', moisDernier: 'vs. Mois précédent', trimestre: 'vs. Trimestre précédent', annee: 'vs. Année précédente', personnalise: 'vs. Période précédente' },
    en: { aujourdhui: 'vs. Yesterday', hier: 'vs. Day before', septJours: 'vs. Previous 7 days', trenteJours: 'vs. Previous 30 days', moisDernier: 'vs. Previous month', trimestre: 'vs. Previous quarter', annee: 'vs. Previous year', personnalise: 'vs. Previous period' },
    ar: { aujourdhui: 'مقابل أمس', hier: 'مقابل أول أمس', septJours: 'مقابل 7 أيام السابقة', trenteJours: 'مقابل 30 يومًا السابقة', moisDernier: 'مقابل الشهر السابق', trimestre: 'مقابل الربع السابق', annee: 'مقابل السنة السابقة', personnalise: 'مقابل الفترة السابقة' },
  };
  // Short label used inside the on-chart tooltip — must fit in ~210px.
  const COMPARE_SHORT = {
    fr: { aujourdhui: 'vs hier', hier: 'vs avant-hier', septJours: 'vs 7j préc.', trenteJours: 'vs 30j préc.', moisDernier: 'vs mois préc.', trimestre: 'vs trim. préc.', annee: 'vs année préc.', personnalise: 'vs préc.' },
    en: { aujourdhui: 'vs yest.', hier: 'vs day before', septJours: 'vs prev. 7d', trenteJours: 'vs prev. 30d', moisDernier: 'vs prev. mo.', trimestre: 'vs prev. qtr.', annee: 'vs prev. yr.', personnalise: 'vs prev.' },
    ar: { aujourdhui: 'مقابل أمس', hier: 'مقابل أول أمس', septJours: 'مقابل 7 أيام', trenteJours: 'مقابل 30 يومًا', moisDernier: 'مقابل الشهر', trimestre: 'مقابل الربع', annee: 'مقابل السنة', personnalise: 'مقابل السابق' },
  };

  // Why « Comparer » is greyed out: this merchant has no takings in the window
  // before the one on screen, so there is no second line to draw.
  const CMP_EMPTY_TITLE = {
    'Aucune période précédente à comparer': {
      en: 'No previous period to compare against',
      ar: 'لا توجد فترة سابقة للمقارنة',
    },
  };

  const HH_SUB = {
    // moisDernier/trimestre/annee reuse the 30-day hourly profile (buildHeatmap
    // maps them onto trenteJours), so their labels say "typical profile" rather
    // than claim period-exact data.
    fr: { aujourdhui: "Intensité horaire aujourd'hui", hier: 'Intensité horaire hier', septJours: 'Intensité horaire moyenne, 7 derniers jours', trenteJours: 'Intensité horaire moyenne, 30 derniers jours', moisDernier: 'Profil horaire type, moyenne longue période', trimestre: 'Profil horaire type, moyenne longue période', annee: 'Profil horaire type, moyenne longue période', personnalise: 'Intensité horaire, période personnalisée' },
    en: { aujourdhui: 'Hourly intensity today', hier: 'Hourly intensity yesterday', septJours: 'Average hourly intensity, last 7 days', trenteJours: 'Average hourly intensity, last 30 days', moisDernier: 'Typical hourly profile, long-run average', trimestre: 'Typical hourly profile, long-run average', annee: 'Typical hourly profile, long-run average', personnalise: 'Hourly intensity, custom period' },
    ar: { aujourdhui: 'كثافة الساعات اليوم', hier: 'كثافة الساعات أمس', septJours: 'متوسط الكثافة الساعية، آخر 7 أيام', trenteJours: 'متوسط الكثافة الساعية، آخر 30 يومًا', moisDernier: 'النمط الساعي النموذجي، متوسط طويل المدى', trimestre: 'النمط الساعي النموذجي، متوسط طويل المدى', annee: 'النمط الساعي النموذجي، متوسط طويل المدى', personnalise: 'كثافة الساعات، فترة مخصصة' },
  };
  const COVERS_LABEL = { fr: 'couverts', en: 'guests', ar: 'زبون' };
  /* Une vente ne porte pas de nombre de couverts : la carte réelle compte des
   * tickets. « 4 couverts » pour une table de quatre et trois cafés au comptoir
   * aurait dit 4 dans les deux cas. */
  const ORDERS_LABEL = {
    fr: (n) => (n > 1 ? 'commandes' : 'commande'),
    en: (n) => (n === 1 ? 'order' : 'orders'),
    ar: () => 'طلب',
  };

  const FEED_TITLE = { fr: { aujourdhui: 'Commandes en direct', hier: 'Commandes · hier', septJours: 'Commandes · 7 derniers jours', trenteJours: 'Commandes · 30 derniers jours', moisDernier: 'Commandes · mois dernier', trimestre: 'Commandes · trimestre', annee: 'Commandes · année', personnalise: 'Commandes en direct' },
                       en: { aujourdhui: 'Live orders', hier: 'Yesterday\'s orders', septJours: 'Orders · last 7 days', trenteJours: 'Orders · last 30 days', moisDernier: 'Orders · last month', trimestre: 'Orders · quarter', annee: 'Orders · year', personnalise: 'Live orders' },
                       ar: { aujourdhui: 'الطلبات المباشرة', hier: 'طلبات أمس', septJours: 'طلبات · آخر 7 أيام', trenteJours: 'طلبات · آخر 30 يومًا', moisDernier: 'طلبات · الشهر الماضي', trimestre: 'طلبات · الربع', annee: 'طلبات · السنة', personnalise: 'الطلبات المباشرة' } };
  const FEED_SUB =   { fr: { aujourdhui: '6 dernières · flux temps réel', hier: 'Dernières du service de hier', septJours: 'Échantillon · 7 derniers jours', trenteJours: 'Échantillon · 30 derniers jours', moisDernier: 'Échantillon · mois dernier', trimestre: 'Échantillon · trimestre', annee: 'Échantillon · année', personnalise: '6 dernières · flux temps réel' },
                       en: { aujourdhui: 'Last 6 · real-time feed', hier: 'Last 6 from yesterday', septJours: 'Sample · last 7 days', trenteJours: 'Sample · last 30 days', moisDernier: 'Sample · last month', trimestre: 'Sample · quarter', annee: 'Sample · year', personnalise: 'Last 6 · real-time feed' },
                       ar: { aujourdhui: 'آخر 6 · تدفّق لحظي', hier: 'آخر 6 من أمس', septJours: 'عيّنة · آخر 7 أيام', trenteJours: 'عيّنة · آخر 30 يومًا', moisDernier: 'عيّنة · الشهر الماضي', trimestre: 'عيّنة · الربع', annee: 'عيّنة · السنة', personnalise: 'آخر 6 · تدفّق لحظي' } };

  const FEED_EMPTY = {
    fr: { badge: 'SERVICE OUVERT', title: 'Première commande à venir', sub: "Le flux s'active dès la première vente saisie sur la caisse." },
    en: { badge: 'SERVICE OPEN',  title: 'First order coming up',     sub: 'The feed starts as soon as the first sale is rung up.' },
    ar: { badge: 'الخدمة مفتوحة',  title: 'أول طلب قادم',              sub: 'يبدأ التدفّق فور تسجيل أول عملية بيع على الصندوق.' },
  };

  const PRODUCTS_SUB = { fr: { aujourdhui: "Aujourd'hui · tous les items", hier: 'Hier · tous les items', septJours: '7 derniers jours · tous les items', trenteJours: '30 derniers jours · tous les items', moisDernier: 'Mois dernier · tous les items', trimestre: 'Trimestre · tous les items', annee: 'Année · tous les items', personnalise: 'Période personnalisée · tous les items' },
                         en: { aujourdhui: 'Today · all items', hier: 'Yesterday · all items', septJours: 'Last 7 days · all items', trenteJours: 'Last 30 days · all items', moisDernier: 'Last month · all items', trimestre: 'Quarter · all items', annee: 'Year · all items', personnalise: 'Custom period · all items' },
                         ar: { aujourdhui: 'اليوم · جميع العناصر', hier: 'أمس · جميع العناصر', septJours: 'آخر 7 أيام · جميع العناصر', trenteJours: 'آخر 30 يومًا · جميع العناصر', moisDernier: 'الشهر الماضي · جميع العناصر', trimestre: 'الربع · جميع العناصر', annee: 'السنة · جميع العناصر', personnalise: 'فترة مخصصة · جميع العناصر' } };
  const STAFF_SUB =    { fr: { aujourdhui: 'Service en cours · PIN connecté', hier: 'Service de hier · clos', septJours: 'Cumul 7 jours · par employé', trenteJours: 'Cumul 30 jours · par employé', moisDernier: 'Cumul mois dernier · par employé', trimestre: 'Cumul trimestre · par employé', annee: 'Cumul année · par employé', personnalise: 'Période personnalisée · par employé' },
                         en: { aujourdhui: 'Service in progress · PIN connected', hier: 'Yesterday\'s service · closed', septJours: '7-day total · per employee', trenteJours: '30-day total · per employee', moisDernier: 'Last month total · per employee', trimestre: 'Quarter total · per employee', annee: 'Year total · per employee', personnalise: 'Custom period · per employee' },
                         ar: { aujourdhui: 'الخدمة جارية · رموز PIN متّصلة', hier: 'خدمة أمس · مغلقة', septJours: 'إجمالي 7 أيام · لكل موظف', trenteJours: 'إجمالي 30 يومًا · لكل موظف', moisDernier: 'إجمالي الشهر الماضي · لكل موظف', trimestre: 'إجمالي الربع · لكل موظف', annee: 'إجمالي السنة · لكل موظف', personnalise: 'فترة مخصصة · لكل موظف' } };
  const HEALTH_SUB =   { fr: { aujourdhui: 'Mesuré sur 90 jours · facteurs activés', hier: 'Mesuré au close de hier', septJours: 'Mesuré sur les 7 derniers jours', trenteJours: 'Mesuré sur les 30 derniers jours', moisDernier: 'Mesuré sur le mois dernier', trimestre: 'Mesuré sur le trimestre', annee: "Mesuré sur l'année", personnalise: 'Période personnalisée · facteurs activés' },
                         en: { aujourdhui: 'Measured over 90 days · active factors', hier: 'Measured at yesterday\'s close', septJours: 'Measured over the last 7 days', trenteJours: 'Measured over the last 30 days', moisDernier: 'Measured over last month', trimestre: 'Measured over the quarter', annee: 'Measured over the year', personnalise: 'Custom period · active factors' },
                         ar: { aujourdhui: 'محسوب على 90 يومًا · عوامل مُفعَّلة', hier: 'محسوب عند إقفال أمس', septJours: 'محسوب على آخر 7 أيام', trenteJours: 'محسوب على آخر 30 يومًا', moisDernier: 'محسوب على الشهر الماضي', trimestre: 'محسوب على الربع', annee: 'محسوب على السنة', personnalise: 'فترة مخصصة · عوامل مُفعَّلة' } };
  const BENCH_SUB =    { fr: { aujourdhui: '147 cafés casablancais · même gamme de ticket moyen', hier: 'Snapshot du close de hier · 147 cafés', septJours: 'Moyennes sur 7 jours · 147 cafés', trenteJours: 'Moyennes sur 30 jours · 147 cafés', moisDernier: 'Moyennes du mois dernier · 147 cafés', trimestre: 'Moyennes du trimestre · 147 cafés', annee: "Moyennes de l'année · 147 cafés", personnalise: '147 cafés · période personnalisée' },
                         en: { aujourdhui: '147 Casablanca cafés · same avg ticket range', hier: 'Yesterday\'s close · 147 cafés', septJours: '7-day averages · 147 cafés', trenteJours: '30-day averages · 147 cafés', moisDernier: 'Last month averages · 147 cafés', trimestre: 'Quarter averages · 147 cafés', annee: 'Year averages · 147 cafés', personnalise: '147 cafés · custom period' },
                         ar: { aujourdhui: '147 مقهى بالدار البيضاء · نفس متوسّط التذكرة', hier: 'إقفال أمس · 147 مقهى', septJours: 'متوسّطات على 7 أيام · 147 مقهى', trenteJours: 'متوسّطات على 30 يومًا · 147 مقهى', moisDernier: 'متوسّطات الشهر الماضي · 147 مقهى', trimestre: 'متوسّطات الربع · 147 مقهى', annee: 'متوسّطات السنة · 147 مقهى', personnalise: '147 مقهى · فترة مخصصة' } };

  /* ─── Revenue chart · range badge / sub-line / legend (FR captured in data) ─── */
  const REV_BADGE = {
    "AUJOURD'HUI · LIVE": { en: 'TODAY · LIVE',          ar: 'اليوم · مباشر' },
    'HIER · COMPLET':     { en: 'YESTERDAY · COMPLETE',  ar: 'أمس · مكتمل' },
    '7 DERNIERS JOURS':   { en: 'LAST 7 DAYS',           ar: 'آخر 7 أيام' },
    '30 DERNIERS JOURS':  { en: 'LAST 30 DAYS',          ar: 'آخر 30 يومًا' },
    /* Ce que dit la carte d'un commerçant réel (realRevSeries) : ces clés
     * manquaient, et la carte restait en français sous EN et AR. */
    "AUJOURD'HUI":           { en: 'TODAY',          ar: 'اليوم' },
    'HIER':                  { en: 'YESTERDAY',      ar: 'أمس' },
    'PÉRIODE PERSONNALISÉE': { en: 'CUSTOM PERIOD',  ar: 'فترة مخصّصة' },
    'MOIS DERNIER':          { en: 'LAST MONTH',     ar: 'الشهر الماضي' },
    'CE TRIMESTRE':          { en: 'THIS QUARTER',   ar: 'هذا الربع' },
    'CETTE ANNÉE':           { en: 'THIS YEAR',      ar: 'هذه السنة' },
    '# DERNIERS JOURS':      { en: (n) => `LAST ${n} DAYS`, ar: (n) => `آخر ${arDays(n)}` },
  };
  const REV_SUB = {
    'Cumul horaire · service en cours':      { en: 'Hourly cumulative · service in progress', ar: 'تراكم بالساعة · الخدمة جارية' },
    "Cumul horaire · journée d'hier":        { en: "Hourly cumulative · yesterday",           ar: 'تراكم بالساعة · يوم أمس' },
    'Cumul horaire · boutique ouverte':      { en: 'Hourly cumulative · shop open',           ar: 'تراكم بالساعة · المتجر مفتوح' },
    'Cumul horaire · réservations en cours': { en: 'Hourly cumulative · bookings in progress',ar: 'تراكم بالساعة · الحجوزات جارية' },
    'Total journalier · 7 derniers jours':   { en: 'Daily total · last 7 days',               ar: 'الإجمالي اليومي · آخر 7 أيام' },
    'Total journalier · 30 derniers jours':  { en: 'Daily total · last 30 days',              ar: 'الإجمالي اليومي · آخر 30 يومًا' },
    "Cumul horaire · aujourd'hui":            { en: 'Hourly cumulative · today',               ar: 'تراكم بالساعة · اليوم' },
    'Cumul horaire · hier':                   { en: 'Hourly cumulative · yesterday',           ar: 'تراكم بالساعة · أمس' },
    'Total journalier · période sélectionnée': { en: 'Daily total · selected period',          ar: 'الإجمالي اليومي · الفترة المحدّدة' },
    'Total journalier · mois dernier':        { en: 'Daily total · last month',                ar: 'الإجمالي اليومي · الشهر الماضي' },
    'Total journalier · ce trimestre':        { en: 'Daily total · this quarter',              ar: 'الإجمالي اليومي · هذا الربع' },
    'Total journalier · cette année':         { en: 'Daily total · this year',                 ar: 'الإجمالي اليومي · هذه السنة' },
    'Total journalier · # derniers jours':    { en: (n) => `Daily total · last ${n} days`,     ar: (n) => `الإجمالي اليومي · آخر ${arDays(n)}` },
  };
  // Legend prefix (the part before the " · NN MAD" amount).
  const LEGEND_PREFIX = {
    "Cumul aujourd'hui":   { en: 'Today cumulative',      ar: 'تراكم اليوم' },
    'Cumul hier':          { en: 'Yesterday cumulative',  ar: 'تراكم أمس' },
    'Cumul avant-hier':    { en: 'Day-before cumulative', ar: 'تراكم أول أمس' },
    'Total 7 jours':       { en: '7-day total',           ar: 'إجمالي 7 أيام' },
    '7 jours précédents':  { en: 'Previous 7 days',       ar: '7 أيام السابقة' },
    'Total 30 jours':      { en: '30-day total',          ar: 'إجمالي 30 يومًا' },
    '30 jours précédents': { en: 'Previous 30 days',      ar: '30 يومًا السابقة' },
    'Cumul':               { en: 'Cumulative',            ar: 'التراكم' },
    'Total # jours':       { en: (n) => `${n}-day total`,  ar: (n) => `إجمالي ${arDays(n)}` },
    '# jours précédents':  { en: (n) => `Previous ${n} days`, ar: (n) => `${arDays(n)} السابقة` },
  };

  /* ─── Benchmark · row metric labels + peer/city wording (FR captured in data) ─── */
  const BENCH_LBL = {
    'Ticket moyen':        { en: 'Average ticket',       ar: 'متوسّط التذكرة' },
    'Pourboire moyen':     { en: 'Average tip',          ar: 'متوسّط الإكرامية' },
    '% clients réguliers': { en: '% regular customers',  ar: '% الزبائن الدائمون' },
    'Marge brute %':       { en: 'Gross margin %',       ar: 'الهامش الإجمالي %' },
    'Rétention 90j':       { en: '90-day retention',     ar: 'الاحتفاظ على 90 يومًا' },
    'Tx / jour':           { en: 'Tx / day',             ar: 'معاملات / يوم' },
    'Transactions / jour': { en: 'Transactions / day',   ar: 'المعاملات / اليوم' },
    'Conversion visite':   { en: 'Visit conversion',     ar: 'تحويل الزيارة' },
    'Tx tax-free':         { en: 'Tax-free tx',          ar: 'معاملات معفاة' },
    'RDV / jour':          { en: 'Appts / day',          ar: 'مواعيد / يوم' },
    'Taux remplissage':    { en: 'Fill rate',            ar: 'نسبة الإشغال' },
    'Vélocité table':      { en: 'Table velocity',       ar: 'سرعة الطاولة' },
  };
  const BENCH_PEER = {
    fr: { restaurant: 'cafés', boutique: 'boutiques', spa: 'spas' },
    en: { restaurant: 'cafés', boutique: 'boutiques', spa: 'spas' },
    ar: { restaurant: 'مقهى',  boutique: 'متجرًا',    spa: 'منتجعًا' },
  };
  const BENCH_CITY = {
    fr: { default: 'Casablanca', spa: 'Casa / Marrakech' },
    en: { default: 'Casablanca', spa: 'Casa / Marrakech' },
    ar: { default: 'الدار البيضاء', spa: 'الدار البيضاء / مراكش' },
  };
  const BENCH_RANK_SUB = {
    fr: (total, peer, city, top) => `sur <b>${total} ${peer}</b> à ${city} · top <b>${top} %</b>`,
    en: (total, peer, city, top) => `out of <b>${total} ${peer}</b> in ${city} · top <b>${top} %</b>`,
    ar: (total, peer, city, top) => `من <b>${total} ${peer}</b> في ${city} · ضمن أفضل <b>${top} %</b>`,
  };
  const BENCH_TITLE_FALLBACK = { fr: 'Vous vs cafés similaires', en: 'You vs similar cafés', ar: 'أنتم مقابل المقاهي المماثلة' };

  /* ─── KPI customizer drawer strings ─── */
  const KC_STR = {
    fr: {
      intro: 'Choisissez les 6 indicateurs affichés en haut de votre tableau de bord. Ils s’adaptent automatiquement à la période sélectionnée.',
      counter: 'indicateurs sélectionnés',
      title: 'Personnaliser les indicateurs',
      subtitle: 'Votre tableau de bord, vos priorités',
      reset: 'Réinitialiser',
      save: 'Enregistrer la sélection',
      maxT: '6 indicateurs maximum', maxD: 'Désélectionnez-en un pour en ajouter un autre.',
      savedT: 'Indicateurs mis à jour', savedD: 'Votre sélection est enregistrée pour ce type d’établissement.',
      resetT: 'Indicateurs réinitialisés', resetD: 'Retour à la sélection par défaut.',
    },
    en: {
      intro: 'Choose the 6 indicators shown at the top of your dashboard. They adapt automatically to the selected period.',
      counter: 'indicators selected',
      title: 'Customize indicators',
      subtitle: 'Your dashboard, your priorities',
      reset: 'Reset',
      save: 'Save selection',
      maxT: '6 indicators maximum', maxD: 'Deselect one to add another.',
      savedT: 'Indicators updated', savedD: 'Your selection is saved for this venue type.',
      resetT: 'Indicators reset', resetD: 'Back to the default selection.',
    },
    ar: {
      intro: 'اختر المؤشرات الستة المعروضة أعلى لوحة التحكم. تتكيّف تلقائيًا مع الفترة المحدّدة.',
      counter: 'مؤشرات محدّدة',
      title: 'تخصيص المؤشرات',
      subtitle: 'لوحة تحكّمك، أولوياتك',
      reset: 'إعادة تعيين',
      save: 'حفظ الاختيار',
      maxT: '6 مؤشرات كحد أقصى', maxD: 'ألغِ تحديد واحد لإضافة آخر.',
      savedT: 'تم تحديث المؤشرات', savedD: 'تم حفظ اختيارك لهذا النوع من المحلات.',
      resetT: 'تمت إعادة تعيين المؤشرات', resetD: 'العودة إلى الاختيار الافتراضي.',
    },
  };
  // Heatmap-AI "set up Glovo combo" toast.
  const GLOVO_TOAST = {
    fr: { t: 'Combo Glovo · bientôt disponible', d: "Disponible quand l'intégration Glovo passe en live (Phase 2 · Kiwi Pay)." },
    en: { t: 'Glovo combo · coming soon',        d: 'Available once the Glovo integration goes live (Phase 2 · Kiwi Pay).' },
    ar: { t: 'كومبو Glovo · قريبًا',             d: 'متاح عندما يصبح تكامل Glovo مباشرًا (المرحلة 2 · Kiwi Pay).' },
  };

  /* ═══════════════ DATA TABLES ═══════════════ */

  const heroDataByVenue = {
    cafeAtlas: {
      aujourdhui:  { amount: 27512.50, deltaHier: 3.2,  deltaSemaine: 18,   deltaMois: 9,  netAfterKiwi: 23091  },
      hier:        { amount: 24820.00, deltaHier: -1.8, deltaSemaine: 12,   deltaMois: 6,  netAfterKiwi: 20640  },
      septJours:   { amount: 198400.00,deltaHier: null, deltaSemaine: 22,   deltaMois: 11, netAfterKiwi: 165280 },
      trenteJours: { amount: 842300.00,deltaHier: null, deltaSemaine: null, deltaMois: 15, netAfterKiwi: 702800 },
      moisDernier: { amount: 783339.00,deltaHier: null, deltaSemaine: null, deltaMois: 11, netAfterKiwi: 653604 },
      trimestre:   { amount: 2526900.00,deltaHier: null, deltaSemaine: null, deltaMois: 12, netAfterKiwi: 2108400 },
      annee:       { amount: 10107600.00,deltaHier: null, deltaSemaine: null, deltaMois: 18, netAfterKiwi: 8433600 },
      personnalise: null,
    },
    maisonMansour: {
      aujourdhui:  { amount: 11820.00, deltaHier: -2.4, deltaSemaine: 11,   deltaMois: 7,  netAfterKiwi: 9920   },
      hier:        { amount: 12110.00, deltaHier: 1.8,  deltaSemaine: 8,    deltaMois: 5,  netAfterKiwi: 10170  },
      septJours:   { amount: 84800.00, deltaHier: null, deltaSemaine: 14,   deltaMois: 8,  netAfterKiwi: 71200  },
      trenteJours: { amount: 358200.00,deltaHier: null, deltaSemaine: null, deltaMois: 12, netAfterKiwi: 300700 },
      moisDernier: { amount: 333126.00,deltaHier: null, deltaSemaine: null, deltaMois: 9,  netAfterKiwi: 279651 },
      trimestre:   { amount: 1074600.00,deltaHier: null, deltaSemaine: null, deltaMois: 11, netAfterKiwi: 902100 },
      annee:       { amount: 4298400.00,deltaHier: null, deltaSemaine: null, deltaMois: 16, netAfterKiwi: 3608400 },
      personnalise: null,
    },
    spaBahia: {
      aujourdhui:  { amount: 8950.00,  deltaHier: 6.8,  deltaSemaine: 22,   deltaMois: 14, netAfterKiwi: 7510   },
      hier:        { amount: 8380.00,  deltaHier: -3.1, deltaSemaine: 16,   deltaMois: 9,  netAfterKiwi: 7035   },
      septJours:   { amount: 64200.00, deltaHier: null, deltaSemaine: 19,   deltaMois: 11, netAfterKiwi: 53890  },
      trenteJours: { amount: 269400.00,deltaHier: null, deltaSemaine: null, deltaMois: 16, netAfterKiwi: 226300 },
      moisDernier: { amount: 250542.00,deltaHier: null, deltaSemaine: null, deltaMois: 12, netAfterKiwi: 210459 },
      trimestre:   { amount: 808200.00,deltaHier: null, deltaSemaine: null, deltaMois: 13, netAfterKiwi: 678900 },
      annee:       { amount: 3232800.00,deltaHier: null, deltaSemaine: null, deltaMois: 19, netAfterKiwi: 2715600 },
      personnalise: null,
    },
  };

  // Goal bar — current revenue vs target for the selected venue + range.
  const goalByVenue = {
    cafeAtlas: {
      aujourdhui:  { goal: 28000,  current: 27512.50 },
      hier:        { goal: 28000,  current: 24820   },
      septJours:   { goal: 196000, current: 198400  },
      trenteJours: { goal: 840000, current: 842300  },
      moisDernier: { goal: 781200, current: 783339  },
      trimestre:   { goal: 2520000, current: 2526900 },
      annee:       { goal: 10080000, current: 10107600 },
    },
    maisonMansour: {
      aujourdhui:  { goal: 12000,  current: 11820   },
      hier:        { goal: 12000,  current: 12110   },
      septJours:   { goal: 84000,  current: 84800   },
      trenteJours: { goal: 360000, current: 358200  },
      moisDernier: { goal: 334800, current: 333126  },
      trimestre:   { goal: 1080000, current: 1074600 },
      annee:       { goal: 4320000, current: 4298400 },
    },
    spaBahia: {
      aujourdhui:  { goal: 9000,   current: 8950    },
      hier:        { goal: 9000,   current: 8380    },
      septJours:   { goal: 63000,  current: 64200   },
      trenteJours: { goal: 270000, current: 269400  },
      moisDernier: { goal: 251100, current: 250542  },
      trimestre:   { goal: 810000, current: 808200  },
      annee:       { goal: 3240000, current: 3232800 },
    },
  };
  const GOAL_LABEL = {
    fr: { aujourdhui: 'OBJECTIF JOUR', hier: 'OBJECTIF JOUR', septJours: 'OBJECTIF SEMAINE', trenteJours: 'OBJECTIF MOIS', moisDernier: 'OBJECTIF MOIS DERNIER', trimestre: 'OBJECTIF TRIMESTRE', annee: 'OBJECTIF ANNÉE', personnalise: 'OBJECTIF PÉRIODE' },
    en: { aujourdhui: 'DAILY GOAL', hier: 'DAILY GOAL', septJours: 'WEEKLY GOAL', trenteJours: 'MONTHLY GOAL', moisDernier: 'LAST MONTH GOAL', trimestre: 'QUARTERLY GOAL', annee: 'YEARLY GOAL', personnalise: 'PERIOD GOAL' },
    ar: { aujourdhui: 'هدف اليوم', hier: 'هدف اليوم', septJours: 'هدف الأسبوع', trenteJours: 'هدف الشهر', moisDernier: 'هدف الشهر الماضي', trimestre: 'هدف الربع', annee: 'هدف السنة', personnalise: 'هدف الفترة' },
  };
  // Objectif non saisi : on le dit, on n'écrit pas « 0 MAD ».
  const GOAL_UNSET = { fr: 'à définir', en: 'not set', ar: 'غير محدد' };

  const HH_HOURS = ['11h','12h','13h','14h','15h','16h','17h','18h','19h','20h','21h','22h','23h','00h','01h','02h'];
  const HH_RAW_BY_VENUE = {
    cafeAtlas: {
      aujourdhui:  [480,1240,1880,1340,620,480,540,920,1620,2040,1880,1480,980,620,380,220],
      hier:        [440,1160,1780,1240,580,440,500,860,1520,1840,1720,1360,920,580,340,200],
      septJours:   [380, 880,1140, 920,480,380,440,740,1320,1700,1640,1240,820,500,300,180],
      trenteJours: [360, 820,1080, 880,460,360,420,720,1280,1620,1560,1180,780,480,280,160],
    },
    // Boutique pattern: morning peak 11h-13h (tourist arrivals), midday lull,
    // evening peak 17h-20h (after-work shoppers). Closes around 20h.
    maisonMansour: {
      aujourdhui:  [1100,1380,1100, 540, 380, 540,1180,1480,1620,1380, 720, 280, 100,  20,  0,  0],
      hier:        [1140,1420,1100, 560, 400, 560,1200,1500,1640,1400, 760, 300, 120,  30,  0,  0],
      septJours:   [1080,1360,1080, 540, 380, 540,1160,1440,1580,1360, 720, 280, 110,  30,  0,  0],
      trenteJours: [1060,1340,1060, 530, 370, 530,1140,1420,1560,1340, 700, 270, 100,  20,  0,  0],
    },
    // Spa pattern: scheduled appointments throughout the day. Peaks 11-13h
    // and 15-17h. Evening tapering, closes ~22h.
    spaBahia: {
      aujourdhui:  [ 600,1100,1300, 800,1000,1300,1100, 800, 500, 300, 150,  50,  0,  0,  0,  0],
      hier:        [ 560,1040,1220, 750, 940,1220,1040, 750, 480, 280, 140,  50,  0,  0,  0,  0],
      septJours:   [ 620,1140,1340, 820,1020,1340,1140, 820, 510, 310, 160,  60,  0,  0,  0,  0],
      trenteJours: [ 600,1100,1300, 800,1000,1300,1100, 800, 500, 300, 150,  60,  0,  0,  0,  0],
    },
  };
  const HH_COVERS_BY_VENUE = {
    cafeAtlas: {
      aujourdhui:  [4,11,16,12,6,4,5,8,14,18,16,13,9,6,4,2],
      hier:        [4,10,15,11,5,4,4,7,13,16,15,12,8,5,3,2],
      septJours:   [3, 8,10, 8,5,3,4,7,12,15,14,11,7,4,3,2],
      trenteJours: [3, 7,10, 8,4,3,4,7,11,14,14,11,7,4,2,1],
    },
    maisonMansour: {
      aujourdhui:  [4, 5, 4, 2, 1, 2, 4, 5, 6, 5, 3, 1, 0, 0, 0, 0],
      hier:        [4, 5, 4, 2, 1, 2, 4, 5, 6, 6, 3, 1, 0, 0, 0, 0],
      septJours:   [3, 5, 4, 2, 1, 2, 4, 5, 6, 5, 3, 1, 0, 0, 0, 0],
      trenteJours: [3, 5, 4, 2, 1, 2, 4, 5, 6, 5, 3, 1, 0, 0, 0, 0],
    },
    spaBahia: {
      aujourdhui:  [1, 2, 3, 2, 2, 3, 2, 2, 1, 1, 1, 0, 0, 0, 0, 0],
      hier:        [1, 2, 3, 2, 2, 3, 2, 1, 1, 0, 1, 0, 0, 0, 0, 0],
      septJours:   [1, 2, 3, 2, 2, 3, 2, 2, 1, 1, 1, 0, 0, 0, 0, 0],
      trenteJours: [1, 2, 3, 2, 2, 3, 2, 2, 1, 1, 0, 0, 0, 0, 0, 0],
    },
  };

  const kpiByVenue = {
    cafeAtlas: {
      aujourdhui: {
        tx:       { value: 182,    unit: '',     fmt: 'int',  delta: 15.2 },
        panier:   { value: 134,    unit: 'MAD',  fmt: 'int',  delta: 1.5 },
        marge:    { value: 71.4,   unit: '%',    fmt: 'pct1', delta: 1.8 },
        success:  { value: 99.34,  unit: '%',    fmt: 'pct2', delta: 0.2 },
        ratio:    { text: '68 / 32', unit: '%',                delta: 4 },
        regulars: { value: 47,     unit: '/ 182',fmt: 'int',  delta: 26 },
      },
      hier: {
        tx:       { value: 168,    unit: '',     fmt: 'int',  delta: 8.4 },
        panier:   { value: 132,    unit: 'MAD',  fmt: 'int',  delta: 0.8 },
        marge:    { value: 69.6,   unit: '%',    fmt: 'pct1', delta: 0.4 },
        success:  { value: 99.18,  unit: '%',    fmt: 'pct2', delta: 0.1 },
        ratio:    { text: '64 / 36', unit: '%',                delta: 2 },
        regulars: { value: 42,     unit: '/ 168',fmt: 'int',  delta: 25 },
      },
      septJours: {
        tx:       { value: 1240,   unit: '',     fmt: 'int',  delta: 18 },
        panier:   { value: 138,    unit: 'MAD',  fmt: 'int',  delta: 3 },
        marge:    { value: 70.8,   unit: '%',    fmt: 'pct1', delta: 2.1 },
        success:  { value: 99.28,  unit: '%',    fmt: 'pct2', delta: 0.3 },
        ratio:    { text: '66 / 34', unit: '%',                delta: 5 },
        regulars: { value: 286,    unit: '/ 1240',fmt:'int',  delta: 23 },
      },
      trenteJours: {
        tx:       { value: 5320,   unit: '',     fmt: 'int',  delta: 21 },
        panier:   { value: 142,    unit: 'MAD',  fmt: 'int',  delta: 5 },
        marge:    { value: 70.2,   unit: '%',    fmt: 'pct1', delta: 1.5 },
        success:  { value: 99.32,  unit: '%',    fmt: 'pct2', delta: 0.5 },
        ratio:    { text: '68 / 32', unit: '%',                delta: 6 },
        regulars: { value: 1240,   unit: '/ 5320',fmt:'int',  delta: 24 },
      },
      moisDernier: {
        tx:       { value: 4948,   unit: '',     fmt: 'int',  delta: 17 },
        panier:   { value: 140,    unit: 'MAD',  fmt: 'int',  delta: 3 },
        marge:    { value: 69.4,   unit: '%',    fmt: 'pct1', delta: 0.9 },
        success:  { value: 99.26,  unit: '%',    fmt: 'pct2', delta: 0.3 },
        ratio:    { text: '67 / 33', unit: '%',                delta: 4 },
        regulars: { value: 1153,   unit: '/ 4948',fmt:'int',  delta: 19 },
      },
      trimestre: {
        tx:       { value: 15960,  unit: '',     fmt: 'int',  delta: 12 },
        panier:   { value: 143,    unit: 'MAD',  fmt: 'int',  delta: 4 },
        marge:    { value: 70.0,   unit: '%',    fmt: 'pct1', delta: 1.2 },
        success:  { value: 99.30,  unit: '%',    fmt: 'pct2', delta: 0.4 },
        ratio:    { text: '68 / 32', unit: '%',                delta: 5 },
        regulars: { value: 3720,   unit: '/ 15960',fmt:'int', delta: 16 },
      },
      annee: {
        tx:       { value: 63840,  unit: '',     fmt: 'int',  delta: 18 },
        panier:   { value: 145,    unit: 'MAD',  fmt: 'int',  delta: 6 },
        marge:    { value: 70.6,   unit: '%',    fmt: 'pct1', delta: 2.4 },
        success:  { value: 99.35,  unit: '%',    fmt: 'pct2', delta: 0.6 },
        ratio:    { text: '69 / 31', unit: '%',                delta: 6 },
        regulars: { value: 14880,  unit: '/ 63840',fmt:'int', delta: 21 },
      },
      personnalise: null,
    },
    maisonMansour: {
      aujourdhui: {
        tx:         { value: 42,    unit: '',     fmt: 'int',  delta: 12 },
        panier:     { value: 282,   unit: 'MAD',  fmt: 'int',  delta: 4.5 },
        tauxRetour: { value: 6.2,   unit: '%',    fmt: 'pct1', delta: -1.3 },
        success:    { value: 99.6,  unit: '%',    fmt: 'pct2', delta: 0.1 },
        ratio:      { text: '85 / 15', unit: '%',               delta: 3 },
        regulars:   { value: 11,    unit: '/ 42', fmt: 'int',  delta: 18 },
      },
      hier: {
        tx:         { value: 43,    unit: '',     fmt: 'int',  delta: 8 },
        panier:     { value: 282,   unit: 'MAD',  fmt: 'int',  delta: 1.2 },
        tauxRetour: { value: 5.8,   unit: '%',    fmt: 'pct1', delta: -1.8 },
        success:    { value: 99.5,  unit: '%',    fmt: 'pct2', delta: 0.0 },
        ratio:      { text: '83 / 17', unit: '%',               delta: 2 },
        regulars:   { value: 12,    unit: '/ 43', fmt: 'int',  delta: 20 },
      },
      septJours: {
        tx:         { value: 295,   unit: '',     fmt: 'int',  delta: 14 },
        panier:     { value: 287,   unit: 'MAD',  fmt: 'int',  delta: 3 },
        tauxRetour: { value: 6.4,   unit: '%',    fmt: 'pct1', delta: -0.8 },
        success:    { value: 99.4,  unit: '%',    fmt: 'pct2', delta: 0.2 },
        ratio:      { text: '84 / 16', unit: '%',               delta: 4 },
        regulars:   { value: 78,    unit: '/ 295',fmt: 'int',  delta: 16 },
      },
      trenteJours: {
        tx:         { value: 1240,  unit: '',     fmt: 'int',  delta: 18 },
        panier:     { value: 289,   unit: 'MAD',  fmt: 'int',  delta: 5 },
        tauxRetour: { value: 6.1,   unit: '%',    fmt: 'pct1', delta: -1.4 },
        success:    { value: 99.5,  unit: '%',    fmt: 'pct2', delta: 0.3 },
        ratio:      { text: '85 / 15', unit: '%',               delta: 5 },
        regulars:   { value: 320,   unit: '/ 1240',fmt:'int',  delta: 21 },
      },
      moisDernier: {
        tx:         { value: 1153,  unit: '',     fmt: 'int',  delta: 14 },
        panier:     { value: 286,   unit: 'MAD',  fmt: 'int',  delta: 3 },
        tauxRetour: { value: 6.3,   unit: '%',    fmt: 'pct1', delta: -1.1 },
        success:    { value: 99.4,  unit: '%',    fmt: 'pct2', delta: 0.2 },
        ratio:      { text: '84 / 16', unit: '%',               delta: 4 },
        regulars:   { value: 298,   unit: '/ 1153',fmt:'int',  delta: 17 },
      },
      trimestre: {
        tx:         { value: 3720,  unit: '',     fmt: 'int',  delta: 11 },
        panier:     { value: 291,   unit: 'MAD',  fmt: 'int',  delta: 4 },
        tauxRetour: { value: 5.9,   unit: '%',    fmt: 'pct1', delta: -0.9 },
        success:    { value: 99.5,  unit: '%',    fmt: 'pct2', delta: 0.3 },
        ratio:      { text: '85 / 15', unit: '%',               delta: 4 },
        regulars:   { value: 960,   unit: '/ 3720',fmt:'int',  delta: 15 },
      },
      annee: {
        tx:         { value: 14880, unit: '',     fmt: 'int',  delta: 16 },
        panier:     { value: 294,   unit: 'MAD',  fmt: 'int',  delta: 6 },
        tauxRetour: { value: 5.7,   unit: '%',    fmt: 'pct1', delta: -1.2 },
        success:    { value: 99.6,  unit: '%',    fmt: 'pct2', delta: 0.4 },
        ratio:      { text: '86 / 14', unit: '%',               delta: 5 },
        regulars:   { value: 3840,  unit: '/ 14880',fmt:'int', delta: 19 },
      },
      personnalise: null,
    },
    spaBahia: {
      aujourdhui: {
        tx:       { value: 20,    unit: '',     fmt: 'int',  delta: 14 },
        panier:   { value: 447,   unit: 'MAD',  fmt: 'int',  delta: 6.5 },
        marge:    { value: 78.2,  unit: '%',    fmt: 'pct1', delta: 2.1 },
        success:  { value: 92.5,  unit: '%',    fmt: 'pct1', delta: 3.2 },
        ratio:    { text: '92 / 8', unit: '%',                 delta: 2 },
        regulars: { value: 14,    unit: '/ 20', fmt: 'int',  delta: 12 },
      },
      hier: {
        tx:       { value: 18,    unit: '',     fmt: 'int',  delta: 5 },
        panier:   { value: 466,   unit: 'MAD',  fmt: 'int',  delta: 2 },
        marge:    { value: 76.5,  unit: '%',    fmt: 'pct1', delta: -0.8 },
        success:  { value: 89.3,  unit: '%',    fmt: 'pct1', delta: -1.5 },
        ratio:    { text: '90 / 10', unit: '%',                 delta: -2 },
        regulars: { value: 13,    unit: '/ 18', fmt: 'int',  delta: 14 },
      },
      septJours: {
        tx:       { value: 142,   unit: '',     fmt: 'int',  delta: 19 },
        panier:   { value: 452,   unit: 'MAD',  fmt: 'int',  delta: 4 },
        marge:    { value: 77.8,  unit: '%',    fmt: 'pct1', delta: 1.6 },
        success:  { value: 91.8,  unit: '%',    fmt: 'pct1', delta: 2.7 },
        ratio:    { text: '91 / 9', unit: '%',                 delta: 3 },
        regulars: { value: 92,    unit: '/ 142',fmt: 'int',  delta: 18 },
      },
      trenteJours: {
        tx:       { value: 580,   unit: '',     fmt: 'int',  delta: 22 },
        panier:   { value: 464,   unit: 'MAD',  fmt: 'int',  delta: 6 },
        marge:    { value: 78.0,  unit: '%',    fmt: 'pct1', delta: 2.4 },
        success:  { value: 92.1,  unit: '%',    fmt: 'pct1', delta: 4.5 },
        ratio:    { text: '92 / 8', unit: '%',                 delta: 5 },
        regulars: { value: 412,   unit: '/ 580',fmt: 'int',  delta: 20 },
      },
      moisDernier: {
        tx:       { value: 539,   unit: '',     fmt: 'int',  delta: 18 },
        panier:   { value: 458,   unit: 'MAD',  fmt: 'int',  delta: 4 },
        marge:    { value: 77.2,  unit: '%',    fmt: 'pct1', delta: 1.1 },
        success:  { value: 91.6,  unit: '%',    fmt: 'pct1', delta: 3.6 },
        ratio:    { text: '91 / 9', unit: '%',                 delta: 4 },
        regulars: { value: 383,   unit: '/ 539',fmt: 'int',  delta: 16 },
      },
      trimestre: {
        tx:       { value: 1740,  unit: '',     fmt: 'int',  delta: 13 },
        panier:   { value: 466,   unit: 'MAD',  fmt: 'int',  delta: 5 },
        marge:    { value: 77.6,  unit: '%',    fmt: 'pct1', delta: 1.8 },
        success:  { value: 92.3,  unit: '%',    fmt: 'pct1', delta: 4.0 },
        ratio:    { text: '92 / 8', unit: '%',                 delta: 5 },
        regulars: { value: 1236,  unit: '/ 1740',fmt:'int',   delta: 17 },
      },
      annee: {
        tx:       { value: 6960,  unit: '',     fmt: 'int',  delta: 19 },
        panier:   { value: 472,   unit: 'MAD',  fmt: 'int',  delta: 7 },
        marge:    { value: 78.4,  unit: '%',    fmt: 'pct1', delta: 3.0 },
        success:  { value: 92.8,  unit: '%',    fmt: 'pct1', delta: 4.8 },
        ratio:    { text: '93 / 7', unit: '%',                 delta: 6 },
        regulars: { value: 4944,  unit: '/ 6960',fmt:'int',   delta: 21 },
      },
      personnalise: null,
    },
  };

  /* tempsTable seed — average time a covert occupies a table (restaurant)
   * or a cabin (spa). Lower is better for restaurants (faster turnover ⇒
   * more sittings per service); higher is better for spas (longer treatment
   * ⇒ higher revenue per booking). Delta convention: negative = went down.
   * Boutique has no tables → key absent → KPI excluded from its catalog. */
  const TEMPS_TABLE_SEED = {
    cafeAtlas: {
      aujourdhui:  { value: 47, unit: 'min', fmt: 'int', delta: -2.1 },
      hier:        { value: 49, unit: 'min', fmt: 'int', delta:  1.2 },
      septJours:   { value: 46, unit: 'min', fmt: 'int', delta: -3.4 },
      trenteJours: { value: 47, unit: 'min', fmt: 'int', delta: -1.8 },
      moisDernier: { value: 48, unit: 'min', fmt: 'int', delta:  0.4 },
      trimestre:   { value: 47, unit: 'min', fmt: 'int', delta: -2.3 },
      annee:       { value: 46, unit: 'min', fmt: 'int', delta: -4.1 },
    },
    spaBahia: {
      aujourdhui:  { value: 62, unit: 'min', fmt: 'int', delta:  3.8 },
      hier:        { value: 58, unit: 'min', fmt: 'int', delta:  1.4 },
      septJours:   { value: 60, unit: 'min', fmt: 'int', delta:  4.2 },
      trenteJours: { value: 59, unit: 'min', fmt: 'int', delta:  2.6 },
      moisDernier: { value: 57, unit: 'min', fmt: 'int', delta:  1.1 },
      trimestre:   { value: 58, unit: 'min', fmt: 'int', delta:  3.0 },
      annee:       { value: 56, unit: 'min', fmt: 'int', delta:  2.2 },
    },
  };
  Object.keys(TEMPS_TABLE_SEED).forEach((v) => {
    const venueData = kpiByVenue[v]; if (!venueData) return;
    Object.keys(TEMPS_TABLE_SEED[v]).forEach((period) => {
      if (venueData[period]) venueData[period].tempsTable = TEMPS_TABLE_SEED[v][period];
    });
  });

  const revChartByVenue = {
    cafeAtlas: {
    // Today: hourly cumulative across the full opening band (11h → 02h).
    // Past hours (≤14h) are real cumul; post-14h are projected forward to end of service.
    // Compare line is yesterday's full-day cumul at the same hours.
    aujourdhui: {
      rangeBadge: "AUJOURD'HUI · LIVE",
      sub: 'Cumul horaire · service en cours',
      xLabels: ['11h','12h','13h','14h','15h','16h','17h','18h','19h','20h','21h','22h','23h','00h','01h','02h'],
      visibleXIdx: [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15], // every 2h: 12h, 14h, 16h, 18h, 20h, 22h, 00h, 02h
      rev:    [0, 4800, 12200, 27512.50, 29400, 30600, 31800, 35200, 39400, 43000, 45200, 47000, 48200, 49000, 49600, 50000],
      revPrev:[0,  600,  2200,  4400,    5400,  6000,  6800,  9400, 13800, 18200, 21400, 23200, 24200, 24600, 24800, 24820],
      yTicks: [0, 12500, 25000, 37500, 50000],
      legendPrimary: "Cumul aujourd'hui · 27 512,50 MAD",
      legendCompare: 'Cumul hier · 24 820 MAD',
    },
    hier: {
      rangeBadge: 'HIER · COMPLET',
      sub: "Cumul horaire · journée d'hier",
      xLabels: ['11h','12h','13h','14h','15h','16h','17h','18h','19h','20h','21h','22h','23h','00h','01h','02h'],
      visibleXIdx: [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15],
      rev:    [0,  600,  2200,  4400,  5400,  6000,  6800,  9400, 13800, 18200, 21400, 23200, 24200, 24600, 24800, 24820],
      revPrev:[0,  500,  1900,  3800,  4700,  5300,  6000,  8400, 12500, 16400, 19400, 21000, 21800, 22200, 22600, 22800],
      yTicks: [0, 6500, 13000, 19500, 26000],
      legendPrimary: 'Cumul hier · 24 820 MAD',
      legendCompare: 'Cumul avant-hier · 22 800 MAD',
    },
    septJours: {
      rangeBadge: '7 DERNIERS JOURS',
      sub: 'Total journalier · 7 derniers jours',
      xLabels: ['Sam 18','Dim 19','Lun 20','Mar 21','Mer 22','Jeu 23','Ven 24'],
      visibleXIdx: [0, 1, 2, 3, 4, 5, 6],
      rev:    [18200, 22500, 17800, 19200, 21300, 25600, 27512],
      revPrev:[15400, 19200, 15600, 17400, 17800, 21000, 21800],
      yTicks: [0, 8000, 16000, 24000, 32000],
      legendPrimary: 'Total 7 jours · 198 400 MAD',
      legendCompare: '7 jours précédents · 126 200 MAD',
    },
    trenteJours: {
      rangeBadge: '30 DERNIERS JOURS',
      sub: 'Total journalier · 30 derniers jours',
      // 30 daily totals; labels visible every 5 days (idx 0,5,10,15,20,25,29).
      xLabels: [
        '26 mar','27 mar','28 mar','29 mar','30 mar',
        '31 mar','1 avr','2 avr','3 avr','4 avr',
        '5 avr','6 avr','7 avr','8 avr','9 avr',
        '10 avr','11 avr','12 avr','13 avr','14 avr',
        '15 avr','16 avr','17 avr','18 avr','19 avr',
        '20 avr','21 avr','22 avr','23 avr','24 avr',
      ],
      visibleXIdx: [0, 5, 10, 15, 20, 25, 29],
      rev: [
        22400, 23600, 24100, 24400, 24800,
        25200, 25800, 26000, 26100, 26200,
        26500, 26800, 27000, 27200, 27800,
        28000, 28200, 28000, 28100, 28400,
        28600, 28900, 29100, 29200, 29600,
        29400, 28800, 28200, 28000, 27512,
      ],
      revPrev: [
        19200, 20100, 20400, 20800, 21400,
        21800, 22200, 22500, 22600, 22800,
        23200, 23600, 23900, 24200, 24600,
        24900, 25200, 25400, 25600, 25800,
        26100, 26400, 26500, 26700, 26900,
        26800, 26200, 25600, 25200, 24800,
      ],
      yTicks: [0, 8000, 16000, 24000, 32000],
      legendPrimary: 'Total 30 jours · 842 300 MAD',
      legendCompare: '30 jours précédents · 731 200 MAD',
    },
    personnalise: null,
    },
    maisonMansour: {
      aujourdhui: {
        rangeBadge: "AUJOURD'HUI · LIVE",
        sub: 'Cumul horaire · boutique ouverte',
        xLabels: ['11h','12h','13h','14h','15h','16h','17h','18h','19h','20h','21h','22h','23h','00h','01h','02h'],
        visibleXIdx: [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15],
        rev:    [0, 2400, 6400, 11820, 11900, 12000, 12200, 12500, 12900, 13400, 13800, 14000, 14100, 14200, 14200, 14200],
        revPrev:[0, 1100, 2400,  3400,  3800,  4100,  4500,  5800,  7400,  9100, 11000, 11800, 12000, 12080, 12100, 12110],
        yTicks: [0, 4000, 8000, 12000, 16000],
        legendPrimary: "Cumul aujourd'hui · 11 820 MAD",
        legendCompare: 'Cumul hier · 12 110 MAD',
      },
      hier: {
        rangeBadge: 'HIER · COMPLET',
        sub: "Cumul horaire · journée d'hier",
        xLabels: ['11h','12h','13h','14h','15h','16h','17h','18h','19h','20h','21h','22h','23h','00h','01h','02h'],
        visibleXIdx: [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15],
        rev:    [0, 1100, 2400, 3400, 3800, 4100, 4500, 5800, 7400, 9100, 11000, 11800, 12000, 12080, 12100, 12110],
        revPrev:[0, 1080, 2380, 3380, 3780, 4080, 4480, 5780, 7380, 9080, 10940, 11700, 11800, 11800, 11800, 11800],
        yTicks: [0, 3500, 7000, 10500, 14000],
        legendPrimary: 'Cumul hier · 12 110 MAD',
        legendCompare: 'Cumul avant-hier · 11 800 MAD',
      },
      septJours: {
        rangeBadge: '7 DERNIERS JOURS',
        sub: 'Total journalier · 7 derniers jours',
        xLabels: ['Sam 18','Dim 19','Lun 20','Mar 21','Mer 22','Jeu 23','Ven 24'],
        visibleXIdx: [0, 1, 2, 3, 4, 5, 6],
        rev:    [10800, 13200, 11400, 12100, 12400, 13100, 11800],
        revPrev:[ 9100, 11400,  9700, 10300, 10500, 11100, 10000],
        yTicks: [0, 4000, 8000, 12000, 16000],
        legendPrimary: 'Total 7 jours · 84 800 MAD',
        legendCompare: '7 jours précédents · 72 100 MAD',
      },
      trenteJours: {
        rangeBadge: '30 DERNIERS JOURS',
        sub: 'Total journalier · 30 derniers jours',
        xLabels: [
          '26 mar','27 mar','28 mar','29 mar','30 mar','31 mar','1 avr','2 avr','3 avr','4 avr',
          '5 avr','6 avr','7 avr','8 avr','9 avr','10 avr','11 avr','12 avr','13 avr','14 avr',
          '15 avr','16 avr','17 avr','18 avr','19 avr','20 avr','21 avr','22 avr','23 avr','24 avr',
        ],
        visibleXIdx: [0, 5, 10, 15, 20, 25, 29],
        rev: [
          10800, 11200, 11400, 11600, 11800, 12000, 12200, 12000, 11800, 11900,
          12100, 12300, 12400, 12200, 12000, 11900, 12000, 12200, 12400, 12600,
          12400, 12200, 12000, 11800, 11600, 11400, 11600, 11800, 12000, 12110,
        ],
        revPrev: [
          9700, 10100, 10300, 10500, 10700, 10900, 11000, 10900, 10700, 10800,
          11000, 11200, 11200, 11000, 10800, 10700, 10800, 11000, 11200, 11400,
          11200, 11000, 10800, 10600, 10400, 10300, 10500, 10700, 10800, 10900,
        ],
        yTicks: [0, 4000, 8000, 12000, 16000],
        legendPrimary: 'Total 30 jours · 358 200 MAD',
        legendCompare: '30 jours précédents · 322 100 MAD',
      },
      personnalise: null,
    },
    spaBahia: {
      aujourdhui: {
        rangeBadge: "AUJOURD'HUI · LIVE",
        sub: 'Cumul horaire · réservations en cours',
        xLabels: ['11h','12h','13h','14h','15h','16h','17h','18h','19h','20h','21h','22h','23h','00h','01h','02h'],
        visibleXIdx: [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15],
        rev:    [0, 1500, 4200, 8950, 9050, 9300, 9700, 10100, 10500, 10800, 10950, 11000, 11000, 11000, 11000, 11000],
        revPrev:[0,  600, 1900, 3200, 3700, 4500, 5300,  6100,  7100,  7900,  8200,  8350,  8380,  8380,  8380,  8380],
        yTicks: [0, 3000, 6000, 9000, 12000],
        legendPrimary: "Cumul aujourd'hui · 8 950 MAD",
        legendCompare: 'Cumul hier · 8 380 MAD',
      },
      hier: {
        rangeBadge: 'HIER · COMPLET',
        sub: "Cumul horaire · journée d'hier",
        xLabels: ['11h','12h','13h','14h','15h','16h','17h','18h','19h','20h','21h','22h','23h','00h','01h','02h'],
        visibleXIdx: [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15],
        rev:    [0, 600, 1900, 3200, 3700, 4500, 5300, 6100, 7100, 7900, 8200, 8350, 8380, 8380, 8380, 8380],
        revPrev:[0, 580, 1850, 3100, 3600, 4400, 5200, 5950, 6900, 7700, 8000, 8100, 8100, 8100, 8100, 8100],
        yTicks: [0, 2500, 5000, 7500, 10000],
        legendPrimary: 'Cumul hier · 8 380 MAD',
        legendCompare: 'Cumul avant-hier · 8 100 MAD',
      },
      septJours: {
        rangeBadge: '7 DERNIERS JOURS',
        sub: 'Total journalier · 7 derniers jours',
        xLabels: ['Sam 18','Dim 19','Lun 20','Mar 21','Mer 22','Jeu 23','Ven 24'],
        visibleXIdx: [0, 1, 2, 3, 4, 5, 6],
        rev:    [8200, 9400, 8800, 9100, 9300, 10100, 9300],
        revPrev:[7000, 8000, 7500, 7800, 7900,  8600, 7900],
        yTicks: [0, 3000, 6000, 9000, 12000],
        legendPrimary: 'Total 7 jours · 64 200 MAD',
        legendCompare: '7 jours précédents · 54 700 MAD',
      },
      trenteJours: {
        rangeBadge: '30 DERNIERS JOURS',
        sub: 'Total journalier · 30 derniers jours',
        xLabels: [
          '26 mar','27 mar','28 mar','29 mar','30 mar','31 mar','1 avr','2 avr','3 avr','4 avr',
          '5 avr','6 avr','7 avr','8 avr','9 avr','10 avr','11 avr','12 avr','13 avr','14 avr',
          '15 avr','16 avr','17 avr','18 avr','19 avr','20 avr','21 avr','22 avr','23 avr','24 avr',
        ],
        visibleXIdx: [0, 5, 10, 15, 20, 25, 29],
        rev: [
          7800, 8100, 8400, 8600, 8800, 9000, 9200, 9000, 8800, 8900,
          9100, 9300, 9400, 9200, 9000, 8900, 9000, 9200, 9400, 9600,
          9400, 9200, 9000, 8800, 8600, 8400, 8600, 8800, 9000, 9100,
        ],
        revPrev: [
          6700, 7000, 7200, 7400, 7500, 7700, 7900, 7700, 7500, 7600,
          7800, 8000, 8000, 7900, 7700, 7600, 7700, 7900, 8100, 8200,
          8100, 7900, 7700, 7500, 7300, 7200, 7300, 7500, 7700, 7800,
        ],
        yTicks: [0, 3000, 6000, 9000, 12000],
        legendPrimary: 'Total 30 jours · 269 400 MAD',
        legendCompare: '30 jours précédents · 232 100 MAD',
      },
      personnalise: null,
    },
  };

  const mixByVenue = {
    cafeAtlas: {
      aujourdhui:  { visa: 48, mc: 24, tap: 18, qr: 10, centerMad: 16590,  fee: '288,50 MAD · 1,19 %' },
      hier:        { visa: 50, mc: 23, tap: 17, qr: 10, centerMad: 14920,  fee: '264,80 MAD · 1,19 %' },
      septJours:   { visa: 47, mc: 25, tap: 19, qr:  9, centerMad: 134700, fee: '2 230 MAD · 1,19 %' },
      trenteJours: { visa: 46, mc: 26, tap: 19, qr:  9, centerMad: 568200, fee: '9 480 MAD · 1,19 %' },
      personnalise: null,
    },
    maisonMansour: {
      aujourdhui:  { visa: 52, mc: 28, tap: 12, qr: 8, centerMad: 6150,   fee: '141 MAD · 1,19 %' },
      hier:        { visa: 51, mc: 29, tap: 12, qr: 8, centerMad: 6175,   fee: '144 MAD · 1,19 %' },
      septJours:   { visa: 53, mc: 27, tap: 12, qr: 8, centerMad: 44944,  fee: '1 010 MAD · 1,19 %' },
      trenteJours: { visa: 52, mc: 28, tap: 12, qr: 8, centerMad: 186264, fee: '4 260 MAD · 1,19 %' },
      personnalise: null,
    },
    spaBahia: {
      aujourdhui:  { visa: 58, mc: 30, tap: 8, qr: 4, centerMad: 5191,   fee: '107 MAD · 1,19 %' },
      hier:        { visa: 57, mc: 31, tap: 8, qr: 4, centerMad: 4777,   fee: '100 MAD · 1,19 %' },
      septJours:   { visa: 59, mc: 29, tap: 8, qr: 4, centerMad: 37878,  fee: '764 MAD · 1,19 %' },
      trenteJours: { visa: 58, mc: 30, tap: 8, qr: 4, centerMad: 156252, fee: '3 206 MAD · 1,19 %' },
      personnalise: null,
    },
  };

  // Live feed: 6 transactions per venue per range
  const FEED_BY_VENUE = {
    cafeAtlas: {
    aujourdhui: [
      { t: '14:37', method: 'visa', primary: 'Visa •• 4291',   sub: 'Carte marocaine · Attijariwafa', flag: 'ma', ctx: 'Karim B. · T4',     amt: '240,00',  tip: '+24,00', neg: false, isNew: true },
      { t: '14:32', method: 'tap',  primary: 'Kiwi Tap',        sub: 'Client #3412 · Kiwi Wallet',     flag: 'ma', ctx: 'Client #3412 · T7',amt: '180,00',  tip: '·',       neg: false },
      { t: '14:18', method: 'mc',   primary: 'Mastercard •• 7820', sub: 'Carte française · BNP Paribas', flag: 'fr', ctx: 'Sara L. · T2',  amt: '85,50',   tip: '+8,55',  neg: false },
      { t: '14:03', method: 'qr',   primary: 'Kiwi Wallet QR',  sub: 'Nawal K. · abonnée',             flag: 'ma', ctx: 'Nawal K. · T6',    amt: '62,00',   tip: '·',       neg: false },
      { t: '13:57', method: 'visa', primary: 'Visa •• 0043',   sub: 'Carte espagnole · CaixaBank',    flag: 'es', ctx: 'Youssef A. · T1',  amt: '312,00',  tip: '+30,00', neg: false },
      { t: '13:41', method: 'mc',   primary: 'Mastercard •• 1209', sub: 'Remboursement · CMI',         flag: 'ma', ctx: 'Hassan J. · T3',   amt: '−155,00', tip: '·',       neg: true },
    ],
    hier: [
      { t: '22:48', method: 'visa', primary: 'Visa •• 8841',   sub: 'Carte marocaine · BMCE',         flag: 'ma', ctx: 'Imane S. · T5',    amt: '276,00',  tip: '+27,60', neg: false },
      { t: '22:14', method: 'tap',  primary: 'Kiwi Tap',        sub: 'Client #3287 · contactless',     flag: 'ma', ctx: 'Client #3287 · T8',amt: '142,00',  tip: '·',       neg: false },
      { t: '21:52', method: 'mc',   primary: 'Mastercard •• 4509', sub: 'Carte française · LCL',      flag: 'fr', ctx: 'Pierre D. · T2',   amt: '198,50',  tip: '+19,85', neg: false },
      { t: '21:18', method: 'qr',   primary: 'Kiwi Wallet QR',  sub: 'Mehdi C. · régulier',            flag: 'ma', ctx: 'Mehdi C. · T6',    amt: '88,00',   tip: '·',       neg: false },
      { t: '20:42', method: 'visa', primary: 'Visa •• 6612',   sub: 'Carte américaine · Chase',       flag: 'us', ctx: 'Diana K. · T1',    amt: '384,00',  tip: '+38,40', neg: false },
      { t: '20:09', method: 'mc',   primary: 'Mastercard •• 8830', sub: 'Carte marocaine · CIH',      flag: 'ma', ctx: 'Anas L. · T3',     amt: '124,00',  tip: '+12,40', neg: false },
    ],
    septJours: [
      { t: 'Ven 23', method: 'visa', primary: 'Visa •• 2914',  sub: 'Top transaction de la semaine', flag: 'fr', ctx: 'Nicolas R. · T4', amt: '1 240,00', tip: '+124,00', neg: false },
      { t: 'Jeu 22', method: 'qr',   primary: 'Kiwi Wallet QR', sub: 'Soirée d\'anniversaire',        flag: 'ma', ctx: 'Hicham B. · T8', amt: '684,00',   tip: '+50,00',  neg: false },
      { t: 'Mer 21', method: 'mc',   primary: 'Mastercard •• 1456', sub: 'Carte espagnole · Sabadell', flag: 'es', ctx: 'Lucia G. · T2', amt: '420,00',   tip: '+42,00',  neg: false },
      { t: 'Mar 20', method: 'tap',  primary: 'Kiwi Tap',       sub: 'Service midi · Tap',            flag: 'ma', ctx: 'Client #2945 · T6', amt: '208,00', tip: '·',       neg: false },
      { t: 'Lun 19', method: 'visa', primary: 'Visa •• 7740',  sub: 'Carte marocaine · BMCE',        flag: 'ma', ctx: 'Salma F. · T1',  amt: '162,00',   tip: '+16,20',  neg: false },
      { t: 'Dim 18', method: 'mc',   primary: 'Mastercard •• 3308', sub: 'Annulation client',         flag: 'ma', ctx: 'Khalid A. · T3', amt: '−240,00',  tip: '·',       neg: true },
    ],
    trenteJours: [
      { t: 'S22 J1', method: 'visa', primary: 'Visa •• 0921',  sub: 'Réservation groupe · 12 couverts', flag: 'ma', ctx: 'Mariage Bensouda · T1-T4', amt: '4 280,00', tip: '+428,00', neg: false },
      { t: 'S21 J3', method: 'qr',   primary: 'Kiwi Wallet QR', sub: 'Soirée privée',                   flag: 'ma', ctx: 'Wissam · T7', amt: '1 920,00', tip: '+150,00', neg: false },
      { t: 'S20 J5', method: 'mc',   primary: 'Mastercard •• 6612', sub: 'Carte française · BNP',     flag: 'fr', ctx: 'Sophie M. · T2', amt: '780,00', tip: '+78,00', neg: false },
      { t: 'S19 J6', method: 'visa', primary: 'Visa •• 5544',  sub: 'Carte espagnole · La Caixa',    flag: 'es', ctx: 'Manuel V. · T5', amt: '512,00', tip: '+50,00', neg: false },
      { t: 'S18 J2', method: 'tap',  primary: 'Kiwi Tap',       sub: 'Pic samedi · service du soir',  flag: 'ma', ctx: 'Client #1882 · T8', amt: '342,00', tip: '·',     neg: false },
      { t: 'S17 J4', method: 'mc',   primary: 'Mastercard •• 9982', sub: 'Reversement Glovo',         flag: 'ma', ctx: 'Réconciliation', amt: '−380,00', tip: '·', neg: true },
    ],
    },
    maisonMansour: {
      aujourdhui: [
        { t: '14:38', method: 'visa', primary: 'Visa •• 5821',     sub: 'Carte allemande · Sparkasse', flag: 'fr', ctx: 'Anna M. · Caftan brodé',   amt: '1 890,00', tip: '·', neg: false, isNew: true },
        { t: '14:14', method: 'mc',   primary: 'Mastercard •• 7714', sub: 'Carte française · LCL',     flag: 'fr', ctx: 'Sophie L. · Babouches',    amt: '450,00',   tip: '·', neg: false },
        { t: '13:42', method: 'tap',  primary: 'Kiwi Tap',          sub: 'Client #4521 · Kiwi Wallet', flag: 'ma', ctx: 'Client #4521 · Coussin',   amt: '240,00',   tip: '·', neg: false },
        { t: '13:18', method: 'visa', primary: 'Visa •• 0987',     sub: 'Carte espagnole · BBVA',     flag: 'es', ctx: 'Carmen R. · Théière',      amt: '680,00',   tip: '·', neg: false },
        { t: '12:54', method: 'mc',   primary: 'Mastercard •• 3344', sub: 'Carte américaine · Chase',  flag: 'us', ctx: 'Karen B. · Tapis berbère', amt: '3 200,00', tip: '·', neg: false },
        { t: '12:21', method: 'mc',   primary: 'Mastercard •• 8830', sub: 'Retour boutique · CIH',    flag: 'ma', ctx: 'Hassan J. · Babouches',    amt: '−450,00',  tip: '·', neg: true },
      ],
      hier: [
        { t: '19:52', method: 'visa', primary: 'Visa •• 4421',     sub: 'Carte française · BNP',      flag: 'fr', ctx: 'Camille D. · Caftan',      amt: '1 890,00', tip: '·', neg: false },
        { t: '19:18', method: 'tap',  primary: 'Kiwi Tap',          sub: 'Client #4488 · contactless', flag: 'ma', ctx: 'Client #4488 · Théière',   amt: '680,00',   tip: '·', neg: false },
        { t: '18:46', method: 'mc',   primary: 'Mastercard •• 2298', sub: 'Carte espagnole · Sabadell',flag: 'es', ctx: 'Marta G. · Coussin',       amt: '240,00',   tip: '·', neg: false },
        { t: '18:14', method: 'visa', primary: 'Visa •• 6643',     sub: 'Carte américaine · Citi',    flag: 'us', ctx: 'David W. · Tapis',          amt: '3 200,00', tip: '·', neg: false },
        { t: '17:32', method: 'mc',   primary: 'Mastercard •• 5512', sub: 'Carte marocaine · BMCE',    flag: 'ma', ctx: 'Yasmine F. · Lampe',       amt: '920,00',   tip: '·', neg: false },
        { t: '16:48', method: 'visa', primary: 'Visa •• 8801',     sub: 'Carte française · Crédit Agricole', flag: 'fr', ctx: 'Léa M. · Babouches', amt: '450,00',   tip: '·', neg: false },
      ],
      septJours: [
        { t: 'Ven 23', method: 'mc',   primary: 'Mastercard •• 1144', sub: 'Top transaction de la semaine', flag: 'us', ctx: 'Karen B. · Tapis berbère', amt: '3 200,00', tip: '·', neg: false },
        { t: 'Jeu 22', method: 'visa', primary: 'Visa •• 5821',      sub: 'Tax-free · Allemagne',          flag: 'fr', ctx: 'Anna M. · Caftan brodé',   amt: '1 890,00', tip: '·', neg: false },
        { t: 'Mer 21', method: 'visa', primary: 'Visa •• 0987',      sub: 'Carte espagnole · BBVA',        flag: 'es', ctx: 'Carmen R. · Théière',      amt: '680,00',   tip: '·', neg: false },
        { t: 'Mar 20', method: 'mc',   primary: 'Mastercard •• 7714', sub: 'Carte française · LCL',         flag: 'fr', ctx: 'Sophie L. · Babouches',    amt: '450,00',   tip: '·', neg: false },
        { t: 'Lun 19', method: 'tap',  primary: 'Kiwi Tap',           sub: 'Client #4521 · contactless',    flag: 'ma', ctx: 'Client #4521 · Coussin',   amt: '240,00',   tip: '·', neg: false },
        { t: 'Dim 18', method: 'mc',   primary: 'Mastercard •• 8830', sub: 'Retour boutique · CIH',         flag: 'ma', ctx: 'Hassan J. · Babouches',    amt: '−450,00',  tip: '·', neg: true },
      ],
      trenteJours: [
        { t: 'S22 J3', method: 'visa', primary: 'Visa •• 9912',     sub: 'Caftans haut de gamme · paire',   flag: 'fr', ctx: 'Marion K. · 2 caftans',    amt: '3 780,00', tip: '·', neg: false },
        { t: 'S20 J5', method: 'mc',   primary: 'Mastercard •• 1144', sub: 'Tapis premium · Berbère',       flag: 'us', ctx: 'Karen B. · Tapis',          amt: '3 200,00', tip: '·', neg: false },
        { t: 'S19 J2', method: 'visa', primary: 'Visa •• 5821',     sub: 'Caftan brodé Tax-free',          flag: 'fr', ctx: 'Anna M.',                   amt: '1 890,00', tip: '·', neg: false },
        { t: 'S18 J6', method: 'tap',  primary: 'Kiwi Tap',          sub: 'Lampe artisanale · cliente VIP', flag: 'ma', ctx: 'Salma O. · Lampe',          amt: '920,00',   tip: '·', neg: false },
        { t: 'S17 J4', method: 'visa', primary: 'Visa •• 0987',     sub: 'Théière argentée',               flag: 'es', ctx: 'Carmen R.',                 amt: '680,00',   tip: '·', neg: false },
        { t: 'S16 J1', method: 'mc',   primary: 'Mastercard •• 4477', sub: 'Échange · taille différente',   flag: 'ma', ctx: 'Hicham B. · Caftan',        amt: '−1 890,00',tip: '·', neg: true },
      ],
    },
    spaBahia: {
      aujourdhui: [
        { t: '14:30', method: 'visa', primary: 'Visa •• 7741',     sub: 'Carte marocaine · Attijariwafa', flag: 'ma', ctx: 'Fatima B. · Forfait Argan',       amt: '850,00', tip: '+85,00', neg: false, isNew: true },
        { t: '14:00', method: 'mc',   primary: 'Mastercard •• 3329', sub: 'Carte française · BNP',         flag: 'fr', ctx: 'Sara K. · Massage 60min',         amt: '550,00', tip: '+55,00', neg: false },
        { t: '13:30', method: 'visa', primary: 'Visa •• 1102',     sub: 'Carte marocaine · BMCE',         flag: 'ma', ctx: 'Karim L. · Hammam',                amt: '350,00', tip: '+35,00', neg: false },
        { t: '13:00', method: 'visa', primary: 'Visa •• 8826',     sub: 'Carte espagnole · La Caixa',     flag: 'es', ctx: 'Imane S. · Soin du visage',        amt: '650,00', tip: '+65,00', neg: false },
        { t: '12:30', method: 'mc',   primary: 'Mastercard •• 5530', sub: 'Carte marocaine · CIH',          flag: 'ma', ctx: 'Nadia M. · Gommage corps',         amt: '400,00', tip: '+40,00', neg: false },
        { t: '12:00', method: 'visa', primary: 'Visa •• 4408',     sub: 'Carte marocaine · CFG',          flag: 'ma', ctx: 'Yasmine T. · Forfait Argan',       amt: '850,00', tip: '+90,00', neg: false },
      ],
      hier: [
        { t: '18:42', method: 'visa', primary: 'Visa •• 9912',     sub: 'Carte américaine · Wells Fargo', flag: 'us', ctx: 'Lisa P. · Forfait Argan',         amt: '850,00', tip: '+100,00', neg: false },
        { t: '17:50', method: 'mc',   primary: 'Mastercard •• 6611', sub: 'Carte française · LCL',         flag: 'fr', ctx: 'Camille R. · Massage 60min',       amt: '550,00', tip: '+50,00',  neg: false },
        { t: '16:24', method: 'visa', primary: 'Visa •• 2230',     sub: 'Carte marocaine · BCP',          flag: 'ma', ctx: 'Lina C. · Soin du visage',         amt: '650,00', tip: '+65,00',  neg: false },
        { t: '15:08', method: 'visa', primary: 'Visa •• 7720',     sub: 'Carte marocaine · Attijari',     flag: 'ma', ctx: 'Khadija R. · Hammam',              amt: '350,00', tip: '+35,00',  neg: false },
        { t: '14:32', method: 'mc',   primary: 'Mastercard •• 1145', sub: 'Carte espagnole · Santander',   flag: 'es', ctx: 'Lucia M. · Gommage corps',         amt: '400,00', tip: '+40,00',  neg: false },
        { t: '11:46', method: 'visa', primary: 'Visa •• 9933',     sub: 'Carte marocaine · BMCE',         flag: 'ma', ctx: 'Sofia A. · Modelage pieds',        amt: '280,00', tip: '+30,00',  neg: false },
      ],
      septJours: [
        { t: 'Ven 23', method: 'visa', primary: 'Visa •• 4408',     sub: 'Top forfait de la semaine',       flag: 'ma', ctx: 'Yasmine T. · Forfait Argan',       amt: '850,00', tip: '+100,00', neg: false },
        { t: 'Jeu 22', method: 'mc',   primary: 'Mastercard •• 1145', sub: 'Carte espagnole · Santander',   flag: 'es', ctx: 'Lucia M. · Massage 60min + Hammam', amt: '900,00', tip: '+90,00',  neg: false },
        { t: 'Mer 21', method: 'visa', primary: 'Visa •• 9912',     sub: 'Cliente VIP · 3e visite',         flag: 'us', ctx: 'Lisa P. · Forfait Argan',         amt: '850,00', tip: '+100,00', neg: false },
        { t: 'Mar 20', method: 'visa', primary: 'Visa •• 8826',     sub: 'Soin du visage premium',          flag: 'es', ctx: 'Imane S.',                        amt: '650,00', tip: '+65,00',  neg: false },
        { t: 'Lun 19', method: 'mc',   primary: 'Mastercard •• 5530', sub: 'Gommage corps complet',         flag: 'ma', ctx: 'Nadia M.',                        amt: '400,00', tip: '+40,00',  neg: false },
        { t: 'Dim 18', method: 'visa', primary: 'Visa •• 1102',     sub: 'Hammam traditionnel',             flag: 'ma', ctx: 'Karim L.',                        amt: '350,00', tip: '+35,00',  neg: false },
      ],
      trenteJours: [
        { t: 'S22 J6', method: 'visa', primary: 'Visa •• 9912',     sub: 'Forfait premium · cliente fidèle', flag: 'us', ctx: 'Lisa P. · Forfait Argan x2',     amt: '1 700,00', tip: '+200,00', neg: false },
        { t: 'S21 J3', method: 'mc',   primary: 'Mastercard •• 1145', sub: 'Carte espagnole · Santander',    flag: 'es', ctx: 'Lucia M. · Soirée détente',      amt: '1 200,00', tip: '+120,00', neg: false },
        { t: 'S20 J1', method: 'visa', primary: 'Visa •• 4408',     sub: 'Forfait Argan · cliente VIP',     flag: 'ma', ctx: 'Yasmine T.',                     amt: '850,00',   tip: '+100,00', neg: false },
        { t: 'S19 J5', method: 'mc',   primary: 'Mastercard •• 3329', sub: 'Massage couple',                 flag: 'fr', ctx: 'Camille & Pierre R.',           amt: '1 100,00', tip: '+110,00', neg: false },
        { t: 'S18 J2', method: 'visa', primary: 'Visa •• 8826',     sub: 'Soin visage premium',             flag: 'es', ctx: 'Imane S.',                       amt: '650,00',   tip: '+65,00',  neg: false },
        { t: 'S17 J4', method: 'mc',   primary: 'Mastercard •• 8821', sub: 'Annulation rendez-vous',         flag: 'ma', ctx: 'Anonyme',                        amt: '−550,00',  tip: '·',       neg: true },
      ],
    },
  };

  const settleByVenue = {
    cafeAtlas: {
      aujourdhui:  { lbl: 'PROCHAIN RÈGLEMENT',    amt: 23091,  sub: 'Arrive demain matin à 9 h 00 sur votre IBAN Bank of Africa •• 3291.', detailVal: '−289 MAD' },
      hier:        { lbl: 'RÈGLEMENT REÇU',         amt: 20640,  sub: 'Crédité ce matin à 9 h 02 sur votre IBAN Bank of Africa •• 3291.',     detailVal: '−248 MAD' },
      septJours:   { lbl: 'RÉGLÉ SUR 7 JOURS',      amt: 165280, sub: '7 règlements T+1 cumulés sur la semaine.',                    detailVal: '−2 230 MAD' },
      trenteJours: { lbl: 'RÉGLÉ SUR 30 JOURS',     amt: 702800, sub: '30 règlements T+1 cumulés sur le mois.',                       detailVal: '−9 480 MAD' },
    },
    maisonMansour: {
      aujourdhui:  { lbl: 'PROCHAIN RÈGLEMENT',    amt: 9920,   sub: 'Arrive demain matin à 9 h 00 sur votre IBAN Bank of Africa •• 8842.', detailVal: '−146 MAD' },
      hier:        { lbl: 'RÈGLEMENT REÇU',         amt: 10170,  sub: 'Crédité ce matin à 9 h 02 sur votre IBAN Bank of Africa •• 8842.',     detailVal: '−149 MAD' },
      septJours:   { lbl: 'RÉGLÉ SUR 7 JOURS',      amt: 71200,  sub: '7 règlements T+1 cumulés sur la semaine.',                    detailVal: '−1 020 MAD' },
      trenteJours: { lbl: 'RÉGLÉ SUR 30 JOURS',     amt: 300700, sub: '30 règlements T+1 cumulés sur le mois.',                       detailVal: '−4 280 MAD' },
    },
    spaBahia: {
      aujourdhui:  { lbl: 'PROCHAIN RÈGLEMENT',    amt: 7510,   sub: 'Arrive demain matin à 9 h 00 sur votre IBAN Bank of Africa •• 4416.', detailVal: '−108 MAD' },
      hier:        { lbl: 'RÈGLEMENT REÇU',         amt: 7035,   sub: 'Crédité ce matin à 9 h 02 sur votre IBAN Bank of Africa •• 4416.',     detailVal: '−105 MAD' },
      septJours:   { lbl: 'RÉGLÉ SUR 7 JOURS',      amt: 53890,  sub: '7 règlements T+1 cumulés sur la semaine.',                    detailVal: '−770 MAD' },
      trenteJours: { lbl: 'RÉGLÉ SUR 30 JOURS',     amt: 226300, sub: '30 règlements T+1 cumulés sur le mois.',                       detailVal: '−3 240 MAD' },
    },
  };
  const SETTLE_LBL = {
    fr: { aujourdhui: 'PROCHAIN RÈGLEMENT', hier: 'RÈGLEMENT REÇU', septJours: 'RÉGLÉ SUR 7 JOURS', trenteJours: 'RÉGLÉ SUR 30 JOURS', moisDernier: 'RÉGLÉ LE MOIS DERNIER', trimestre: 'RÉGLÉ SUR LE TRIMESTRE', annee: "RÉGLÉ SUR L'ANNÉE", personnalise: 'PROCHAIN RÈGLEMENT' },
    en: { aujourdhui: 'NEXT SETTLEMENT', hier: 'SETTLEMENT RECEIVED', septJours: 'SETTLED OVER 7 DAYS', trenteJours: 'SETTLED OVER 30 DAYS', moisDernier: 'SETTLED LAST MONTH', trimestre: 'SETTLED OVER QUARTER', annee: 'SETTLED OVER YEAR', personnalise: 'NEXT SETTLEMENT' },
    ar: { aujourdhui: 'التسوية القادمة', hier: 'تسوية مستلمة', septJours: 'مسوّى على 7 أيام', trenteJours: 'مسوّى على 30 يومًا', moisDernier: 'مسوّى في الشهر الماضي', trimestre: 'مسوّى خلال الربع', annee: 'مسوّى خلال السنة', personnalise: 'التسوية القادمة' },
  };
  const SETTLE_DETAIL_LBL = { fr: 'Commission Kiwi déduite', en: 'Kiwi commission deducted', ar: 'عمولة كيوي مخصومة' };

  const timelineWeekTotalByVenue = {
    cafeAtlas: {
      aujourdhui:  '~ 172 100 MAD',
      hier:        '~ 165 800 MAD',
      septJours:   '~ 198 400 MAD',
      trenteJours: '~ 842 300 MAD',
    },
    maisonMansour: {
      aujourdhui:  '~ 78 600 MAD',
      hier:        '~ 76 200 MAD',
      septJours:   '~ 84 800 MAD',
      trenteJours: '~ 358 200 MAD',
    },
    spaBahia: {
      aujourdhui:  '~ 60 800 MAD',
      hier:        '~ 58 200 MAD',
      septJours:   '~ 64 200 MAD',
      trenteJours: '~ 269 400 MAD',
    },
  };

  const healthByVenue = {
    cafeAtlas: {
      aujourdhui:  { score: 91, chip: 'EXCELLENT', chipKey: 'excellent' },
      hier:        { score: 90, chip: 'EXCELLENT', chipKey: 'excellent' },
      septJours:   { score: 89, chip: 'TRÈS BON',  chipKey: 'verygood' },
      trenteJours: { score: 88, chip: 'TRÈS BON',  chipKey: 'verygood' },
    },
    maisonMansour: {
      aujourdhui:  { score: 88, chip: 'TRÈS BON',  chipKey: 'verygood' },
      hier:        { score: 87, chip: 'TRÈS BON',  chipKey: 'verygood' },
      septJours:   { score: 86, chip: 'TRÈS BON',  chipKey: 'verygood' },
      trenteJours: { score: 85, chip: 'TRÈS BON',  chipKey: 'verygood' },
    },
    spaBahia: {
      aujourdhui:  { score: 93, chip: 'EXCELLENT', chipKey: 'excellent' },
      hier:        { score: 92, chip: 'EXCELLENT', chipKey: 'excellent' },
      septJours:   { score: 91, chip: 'EXCELLENT', chipKey: 'excellent' },
      trenteJours: { score: 90, chip: 'EXCELLENT', chipKey: 'excellent' },
    },
  };
  const HEALTH_CHIP = {
    fr: { excellent: 'EXCELLENT', verygood: 'TRÈS BON' },
    en: { excellent: 'EXCELLENT', verygood: 'VERY GOOD' },
    ar: { excellent: 'ممتاز', verygood: 'جيّد جدًا' },
  };

  const benchByVenue = {
    cafeAtlas: {
      aujourdhui: {
        rank: 12, total: 147, top: 8,
        rows: [
          { lbl: 'Ticket moyen',       you: 74, peer: 58, v: '+16 MAD',   pos: true },
          { lbl: 'Transactions / jour',you: 82, peer: 62, v: '+34',       pos: true },
          { lbl: '% clients réguliers',you: 68, peer: 55, v: '+7 pts',    pos: true },
          { lbl: 'Pourboire moyen',    you: 55, peer: 58, v: '−0,4 pts',  pos: false, warn: true },
          { lbl: 'Vélocité table',     you: 71, peer: 60, v: '+12 %',     pos: true },
        ],
      },
      hier: {
        rank: 14, total: 147, top: 9,
        rows: [
          { lbl: 'Ticket moyen',       you: 71, peer: 58, v: '+13 MAD',   pos: true },
          { lbl: 'Transactions / jour',you: 78, peer: 62, v: '+28',       pos: true },
          { lbl: '% clients réguliers',you: 66, peer: 55, v: '+6 pts',    pos: true },
          { lbl: 'Pourboire moyen',    you: 53, peer: 58, v: '−0,6 pts',  pos: false, warn: true },
          { lbl: 'Vélocité table',     you: 69, peer: 60, v: '+9 %',      pos: true },
        ],
      },
      septJours: {
        rank: 11, total: 147, top: 7,
        rows: [
          { lbl: 'Ticket moyen',       you: 76, peer: 58, v: '+18 MAD',   pos: true },
          { lbl: 'Transactions / jour',you: 84, peer: 62, v: '+42',       pos: true },
          { lbl: '% clients réguliers',you: 70, peer: 55, v: '+9 pts',    pos: true },
          { lbl: 'Pourboire moyen',    you: 56, peer: 58, v: '−0,3 pts',  pos: false, warn: true },
          { lbl: 'Vélocité table',     you: 73, peer: 60, v: '+14 %',     pos: true },
        ],
      },
      trenteJours: {
        rank: 9, total: 147, top: 6,
        rows: [
          { lbl: 'Ticket moyen',       you: 78, peer: 58, v: '+22 MAD',   pos: true },
          { lbl: 'Transactions / jour',you: 86, peer: 62, v: '+58',       pos: true },
          { lbl: '% clients réguliers',you: 72, peer: 55, v: '+11 pts',   pos: true },
          { lbl: 'Pourboire moyen',    you: 58, peer: 58, v: '0 pt',      pos: true },
          { lbl: 'Vélocité table',     you: 75, peer: 60, v: '+18 %',     pos: true },
        ],
      },
    },
    maisonMansour: {
      aujourdhui: {
        rank: 8, total: 89, top: 9,
        rows: [
          { lbl: 'Ticket moyen',         you: 76, peer: 60, v: '+34 MAD', pos: true },
          { lbl: 'Tx / jour',            you: 64, peer: 50, v: '+8',      pos: true },
          { lbl: 'Conversion visite',    you: 71, peer: 58, v: '+8 pts',  pos: true },
          { lbl: 'Tx tax-free',          you: 48, peer: 60, v: '−12 pts', pos: false, warn: true },
          { lbl: 'Marge brute %',        you: 78, peer: 64, v: '+10 pts', pos: true },
        ],
      },
      hier: {
        rank: 9, total: 89, top: 10,
        rows: [
          { lbl: 'Ticket moyen',         you: 75, peer: 60, v: '+32 MAD', pos: true },
          { lbl: 'Tx / jour',            you: 65, peer: 50, v: '+10',     pos: true },
          { lbl: 'Conversion visite',    you: 70, peer: 58, v: '+7 pts',  pos: true },
          { lbl: 'Tx tax-free',          you: 47, peer: 60, v: '−13 pts', pos: false, warn: true },
          { lbl: 'Marge brute %',        you: 77, peer: 64, v: '+9 pts',  pos: true },
        ],
      },
      septJours: {
        rank: 7, total: 89, top: 8,
        rows: [
          { lbl: 'Ticket moyen',         you: 77, peer: 60, v: '+36 MAD', pos: true },
          { lbl: 'Tx / jour',            you: 66, peer: 50, v: '+12',     pos: true },
          { lbl: 'Conversion visite',    you: 73, peer: 58, v: '+10 pts', pos: true },
          { lbl: 'Tx tax-free',          you: 49, peer: 60, v: '−11 pts', pos: false, warn: true },
          { lbl: 'Marge brute %',        you: 79, peer: 64, v: '+11 pts', pos: true },
        ],
      },
      trenteJours: {
        rank: 6, total: 89, top: 7,
        rows: [
          { lbl: 'Ticket moyen',         you: 80, peer: 60, v: '+40 MAD', pos: true },
          { lbl: 'Tx / jour',            you: 68, peer: 50, v: '+15',     pos: true },
          { lbl: 'Conversion visite',    you: 74, peer: 58, v: '+11 pts', pos: true },
          { lbl: 'Tx tax-free',          you: 51, peer: 60, v: '−9 pts',  pos: false, warn: true },
          { lbl: 'Marge brute %',        you: 81, peer: 64, v: '+13 pts', pos: true },
        ],
      },
    },
    spaBahia: {
      aujourdhui: {
        rank: 4, total: 42, top: 9,
        rows: [
          { lbl: 'Ticket moyen',         you: 82, peer: 65, v: '+58 MAD', pos: true },
          { lbl: 'Taux remplissage',     you: 78, peer: 64, v: '+12 pts', pos: true },
          { lbl: 'RDV / jour',           you: 68, peer: 56, v: '+5',      pos: true },
          { lbl: 'Pourboire moyen',      you: 62, peer: 50, v: '+3 pts',  pos: true },
          { lbl: 'Rétention 90j',        you: 71, peer: 58, v: '+13 pts', pos: true },
        ],
      },
      hier: {
        rank: 5, total: 42, top: 11,
        rows: [
          { lbl: 'Ticket moyen',         you: 83, peer: 65, v: '+62 MAD', pos: true },
          { lbl: 'Taux remplissage',     you: 75, peer: 64, v: '+9 pts',  pos: true },
          { lbl: 'RDV / jour',           you: 64, peer: 56, v: '+3',      pos: true },
          { lbl: 'Pourboire moyen',      you: 60, peer: 50, v: '+2 pts',  pos: true },
          { lbl: 'Rétention 90j',        you: 70, peer: 58, v: '+12 pts', pos: true },
        ],
      },
      septJours: {
        rank: 3, total: 42, top: 7,
        rows: [
          { lbl: 'Ticket moyen',         you: 84, peer: 65, v: '+64 MAD', pos: true },
          { lbl: 'Taux remplissage',     you: 80, peer: 64, v: '+14 pts', pos: true },
          { lbl: 'RDV / jour',           you: 70, peer: 56, v: '+6',      pos: true },
          { lbl: 'Pourboire moyen',      you: 64, peer: 50, v: '+4 pts',  pos: true },
          { lbl: 'Rétention 90j',        you: 73, peer: 58, v: '+15 pts', pos: true },
        ],
      },
      trenteJours: {
        rank: 2, total: 42, top: 5,
        rows: [
          { lbl: 'Ticket moyen',         you: 86, peer: 65, v: '+68 MAD', pos: true },
          { lbl: 'Taux remplissage',     you: 82, peer: 64, v: '+16 pts', pos: true },
          { lbl: 'RDV / jour',           you: 72, peer: 56, v: '+8',      pos: true },
          { lbl: 'Pourboire moyen',      you: 66, peer: 50, v: '+5 pts',  pos: true },
          { lbl: 'Rétention 90j',        you: 75, peer: 58, v: '+17 pts', pos: true },
        ],
      },
    },
  };

  const productsByVenue = {
    cafeAtlas: {
      aujourdhui: [
        { rank: '#1', name: 'Tajine kefta œuf',    sub: '28 portions · 85 MAD chacune', bar: 100, sales: '2 380' },
        { rank: '#2', name: 'Thé à la menthe',     sub: '94 verres · 12 MAD',           bar: 68,  sales: '1 128' },
        { rank: '#3', name: 'Msemen beurre & miel',sub: '62 · 12 MAD',                   bar: 44,  sales: '744' },
        { rank: '#4', name: 'Orange pressée',      sub: '34 · 18 MAD',                   bar: 36,  sales: '612' },
        { rank: '#5', name: 'Couscous végétarien', sub: '11 · 45 MAD',                   bar: 29,  sales: '495' },
        { rank: '#6', name: 'Salade marocaine',    sub: '13 · 32 MAD',                   bar: 25,  sales: '416' },
      ],
      hier: [
        { rank: '#1', name: 'Tajine kefta œuf',    sub: '24 portions · 85 MAD',          bar: 100, sales: '2 040' },
        { rank: '#2', name: 'Thé à la menthe',     sub: '88 verres · 12 MAD',            bar: 70,  sales: '1 056' },
        { rank: '#3', name: 'Msemen beurre & miel',sub: '54 · 12 MAD',                   bar: 41,  sales: '648' },
        { rank: '#4', name: 'Orange pressée',      sub: '32 · 18 MAD',                   bar: 36,  sales: '576' },
        { rank: '#5', name: 'Couscous végétarien', sub: '9 · 45 MAD',                    bar: 25,  sales: '405' },
        { rank: '#6', name: 'Salade marocaine',    sub: '11 · 32 MAD',                   bar: 22,  sales: '352' },
      ],
      septJours: [
        { rank: '#1', name: 'Tajine kefta œuf',     sub: '198 portions · 85 MAD',         bar: 100, sales: '16 830' },
        { rank: '#2', name: 'Thé à la menthe',      sub: '648 verres · 12 MAD',           bar: 71,  sales: '7 776' },
        { rank: '#3', name: 'Msemen beurre & miel', sub: '432 · 12 MAD',                  bar: 47,  sales: '5 184' },
        { rank: '#4', name: 'Couscous végétarien',  sub: '78 · 45 MAD',                   bar: 38,  sales: '3 510' },
        { rank: '#5', name: 'Orange pressée',       sub: '218 · 18 MAD',                  bar: 35,  sales: '3 924' },
        { rank: '#6', name: 'Salade marocaine',     sub: '92 · 32 MAD',                   bar: 27,  sales: '2 944' },
      ],
      trenteJours: [
        { rank: '#1', name: 'Tajine kefta œuf',     sub: '820 portions · 85 MAD',         bar: 100, sales: '69 700' },
        { rank: '#2', name: 'Thé à la menthe',      sub: '2 760 verres · 12 MAD',         bar: 73,  sales: '33 120' },
        { rank: '#3', name: 'Msemen beurre & miel', sub: '1 840 · 12 MAD',                bar: 47,  sales: '22 080' },
        { rank: '#4', name: 'Couscous végétarien',  sub: '348 · 45 MAD',                  bar: 41,  sales: '15 660' },
        { rank: '#5', name: 'Orange pressée',       sub: '900 · 18 MAD',                  bar: 35,  sales: '16 200' },
        { rank: '#6', name: 'Salade marocaine',     sub: '420 · 32 MAD',                  bar: 30,  sales: '13 440' },
      ],
    },
    maisonMansour: {
      aujourdhui: [
        { rank: '#1', name: 'Caftan brodé',         sub: '2 pièces · 1 890 MAD',          bar: 100, sales: '3 780' },
        { rank: '#2', name: 'Tapis berbère',        sub: '1 · 3 200 MAD',                  bar: 85,  sales: '3 200' },
        { rank: '#3', name: 'Théière argentée',     sub: '3 · 680 MAD',                    bar: 54,  sales: '2 040' },
        { rank: '#4', name: 'Babouches en cuir',    sub: '3 paires · 450 MAD',             bar: 36,  sales: '1 350' },
        { rank: '#5', name: 'Coussin tissé',        sub: '4 · 240 MAD',                    bar: 26,  sales: '960' },
        { rank: '#6', name: 'Lampe artisanale',     sub: '1 · 920 MAD',                    bar: 24,  sales: '920' },
      ],
      hier: [
        { rank: '#1', name: 'Caftan brodé',         sub: '2 pièces · 1 890 MAD',          bar: 100, sales: '3 780' },
        { rank: '#2', name: 'Tapis berbère',        sub: '1 · 3 200 MAD',                  bar: 85,  sales: '3 200' },
        { rank: '#3', name: 'Théière argentée',     sub: '3 · 680 MAD',                    bar: 54,  sales: '2 040' },
        { rank: '#4', name: 'Babouches en cuir',    sub: '4 paires · 450 MAD',             bar: 48,  sales: '1 800' },
        { rank: '#5', name: 'Coussin tissé',        sub: '4 · 240 MAD',                    bar: 26,  sales: '960' },
        { rank: '#6', name: 'Lampe artisanale',     sub: '1 · 920 MAD',                    bar: 24,  sales: '920' },
      ],
      septJours: [
        { rank: '#1', name: 'Caftan brodé',         sub: '12 pièces · 1 890 MAD',         bar: 100, sales: '22 680' },
        { rank: '#2', name: 'Tapis berbère',        sub: '6 · 3 200 MAD',                  bar: 85,  sales: '19 200' },
        { rank: '#3', name: 'Babouches en cuir',    sub: '28 paires · 450 MAD',            bar: 56,  sales: '12 600' },
        { rank: '#4', name: 'Théière argentée',     sub: '18 · 680 MAD',                   bar: 54,  sales: '12 240' },
        { rank: '#5', name: 'Coussin tissé',        sub: '32 · 240 MAD',                   bar: 34,  sales: '7 680' },
        { rank: '#6', name: 'Lampe artisanale',     sub: '8 · 920 MAD',                    bar: 32,  sales: '7 360' },
      ],
      trenteJours: [
        { rank: '#1', name: 'Caftan brodé',         sub: '52 pièces · 1 890 MAD',         bar: 100, sales: '98 280' },
        { rank: '#2', name: 'Tapis berbère',        sub: '26 · 3 200 MAD',                 bar: 85,  sales: '83 200' },
        { rank: '#3', name: 'Babouches en cuir',    sub: '118 paires · 450 MAD',           bar: 54,  sales: '53 100' },
        { rank: '#4', name: 'Théière argentée',     sub: '74 · 680 MAD',                   bar: 51,  sales: '50 320' },
        { rank: '#5', name: 'Coussin tissé',        sub: '140 · 240 MAD',                  bar: 34,  sales: '33 600' },
        { rank: '#6', name: 'Lampe artisanale',     sub: '32 · 920 MAD',                   bar: 30,  sales: '29 440' },
      ],
    },
    spaBahia: {
      aujourdhui: [
        { rank: '#1', name: 'Forfait Argan',        sub: '3 forfaits · 850 MAD',          bar: 100, sales: '2 550' },
        { rank: '#2', name: 'Massage relaxant 60min',sub: '3 · 550 MAD',                   bar: 65,  sales: '1 650' },
        { rank: '#3', name: 'Soin du visage',       sub: '2 · 650 MAD',                    bar: 51,  sales: '1 300' },
        { rank: '#4', name: 'Hammam traditionnel',  sub: '3 · 350 MAD',                    bar: 41,  sales: '1 050' },
        { rank: '#5', name: 'Gommage corps',        sub: '2 · 400 MAD',                    bar: 31,  sales: '800' },
        { rank: '#6', name: 'Modelage pieds',       sub: '2 · 280 MAD',                    bar: 22,  sales: '560' },
      ],
      hier: [
        { rank: '#1', name: 'Forfait Argan',        sub: '3 forfaits · 850 MAD',          bar: 100, sales: '2 550' },
        { rank: '#2', name: 'Soin du visage',       sub: '2 · 650 MAD',                    bar: 51,  sales: '1 300' },
        { rank: '#3', name: 'Massage relaxant 60min',sub: '2 · 550 MAD',                   bar: 43,  sales: '1 100' },
        { rank: '#4', name: 'Hammam traditionnel',  sub: '3 · 350 MAD',                    bar: 41,  sales: '1 050' },
        { rank: '#5', name: 'Gommage corps',        sub: '2 · 400 MAD',                    bar: 31,  sales: '800' },
        { rank: '#6', name: 'Modelage pieds',       sub: '2 · 280 MAD',                    bar: 22,  sales: '560' },
      ],
      septJours: [
        { rank: '#1', name: 'Forfait Argan',        sub: '22 forfaits · 850 MAD',         bar: 100, sales: '18 700' },
        { rank: '#2', name: 'Massage relaxant 60min',sub: '24 · 550 MAD',                  bar: 71,  sales: '13 200' },
        { rank: '#3', name: 'Soin du visage',       sub: '16 · 650 MAD',                   bar: 56,  sales: '10 400' },
        { rank: '#4', name: 'Hammam traditionnel',  sub: '28 · 350 MAD',                   bar: 53,  sales: '9 800' },
        { rank: '#5', name: 'Gommage corps',        sub: '18 · 400 MAD',                   bar: 38,  sales: '7 200' },
        { rank: '#6', name: 'Modelage pieds',       sub: '16 · 280 MAD',                   bar: 24,  sales: '4 480' },
      ],
      trenteJours: [
        { rank: '#1', name: 'Forfait Argan',        sub: '90 forfaits · 850 MAD',         bar: 100, sales: '76 500' },
        { rank: '#2', name: 'Massage relaxant 60min',sub: '98 · 550 MAD',                  bar: 70,  sales: '53 900' },
        { rank: '#3', name: 'Soin du visage',       sub: '66 · 650 MAD',                   bar: 56,  sales: '42 900' },
        { rank: '#4', name: 'Hammam traditionnel',  sub: '114 · 350 MAD',                  bar: 52,  sales: '39 900' },
        { rank: '#5', name: 'Gommage corps',        sub: '74 · 400 MAD',                   bar: 39,  sales: '29 600' },
        { rank: '#6', name: 'Modelage pieds',       sub: '66 · 280 MAD',                   bar: 24,  sales: '18 480' },
      ],
    },
  };

  /* The demo rosters below are written in French. Each line is « role · status »;
   * under English and Arabic both halves are translated here, from a closed
   * list, so a demo never shows « Serveur · pause depuis 14:12 » in English. */
  const DEMO_ROLE = {
    'Serveuse senior': { en: 'Senior waitress', ar: 'نادلة أولى' }, 'Serveur': { en: 'Waiter', ar: 'نادل' },
    'Barista': { en: 'Barista', ar: 'باريستا' }, 'Cuisine': { en: 'Kitchen', ar: 'المطبخ' },
    'Vendeuse principale': { en: 'Head sales associate', ar: 'بائعة رئيسية' }, 'Vendeuse': { en: 'Sales associate', ar: 'بائعة' },
    'Praticienne senior': { en: 'Senior therapist', ar: 'معالجة أولى' }, 'Praticienne': { en: 'Therapist', ar: 'معالجة' },
    'service en salle': { en: 'dining room', ar: 'القاعة' }, 'terrasse': { en: 'terrace', ar: 'التراس' },
    'comptoir': { en: 'counter', ar: 'الكونطوار' }, 'service de hier': { en: "yesterday's shift", ar: 'وردية الأمس' },
    'service du soir': { en: 'evening shift', ar: 'الوردية المسائية' }, 'service en cours': { en: 'on shift', ar: 'في الخدمة' },
    'vitrine': { en: 'window display', ar: 'الواجهة' }, 'journée complète': { en: 'full day', ar: 'يوم كامل' },
    'soins du visage': { en: 'facials', ar: 'العناية بالوجه' }, 'hammam & gommage': { en: 'hammam & scrub', ar: 'حمام وتقشير' },
    'hammam': { en: 'hammam', ar: 'حمام' }, 'massages': { en: 'massages', ar: 'تدليك' },
  };
  function demoRole(text, lang) {
    if (!text || lang === 'fr' || (lang !== 'en' && lang !== 'ar')) return text;
    return String(text).split(' · ').map((part) => {
      const hit = DEMO_ROLE[part]; if (hit) return hit[lang];
      let m;
      if ((m = /^(\d+) jours?( de service)?$/.exec(part))) return lang === 'en' ? `${m[1]} days` : `${m[1]} أيام`;
      if ((m = /^pause depuis (\d\d:\d\d)$/.exec(part))) return lang === 'en' ? `on break since ${m[1]}` : `في استراحة منذ ${m[1]}`;
      if ((m = /^fini(?: son service)? (\d\d:\d\d)$/.exec(part))) return lang === 'en' ? `shift ended ${m[1]}` : `انتهت ورديته ${m[1]}`;
      return part;
    }).join(' · ');
  }

  const staffByVenue = {
    cafeAtlas: {
      aujourdhui: [
        { av: 'FK', cls: '',         name: 'Fatima Khalki',  role: 'Serveuse senior · service en salle', shift: '5h 32', amt: '5 240 MAD', tx: '42 tx' },
        { av: 'HJ', cls: 'b',        name: 'Hamid Jelloul',  role: 'Serveur · terrasse',                   shift: '5h 10', amt: '4 680 MAD', tx: '38 tx' },
        { av: 'SB', cls: 'c',        name: 'Sofia Belkadi',  role: 'Barista · comptoir',                   shift: '4h 48', amt: '3 920 MAD', tx: '54 tx' },
        { av: 'YA', cls: 'd',        name: 'Youssef Amrani', role: 'Serveur · pause depuis 14:12',          shift: '3h 22', amt: '2 110 MAD', tx: '25 tx' },
        { av: 'MM', cls: 'offline',  name: 'Mehdi Mansouri', role: 'Cuisine · fini son service 14:00',      shift: '·',     amt: '·',         tx: '' },
      ],
      hier: [
        { av: 'FK', cls: 'offline', name: 'Fatima Khalki',  role: 'Serveuse senior · service de hier',   shift: '8h 12', amt: '7 420 MAD', tx: '58 tx' },
        { av: 'HJ', cls: 'offline', name: 'Hamid Jelloul',  role: 'Serveur · terrasse',                   shift: '7h 48', amt: '6 980 MAD', tx: '52 tx' },
        { av: 'SB', cls: 'offline', name: 'Sofia Belkadi',  role: 'Barista · comptoir',                   shift: '6h 30', amt: '5 240 MAD', tx: '64 tx' },
        { av: 'YA', cls: 'offline', name: 'Youssef Amrani', role: 'Serveur · service du soir',            shift: '5h 50', amt: '3 240 MAD', tx: '38 tx' },
        { av: 'MM', cls: 'offline', name: 'Mehdi Mansouri', role: 'Cuisine · fini 23:00',                  shift: '7h 00', amt: '·',         tx: '' },
      ],
      septJours: [
        { av: 'FK', cls: '', name: 'Fatima Khalki',  role: 'Serveuse senior · 6 jours de service',   shift: '48h 20', amt: '36 800 MAD', tx: '298 tx' },
        { av: 'HJ', cls: 'b',name: 'Hamid Jelloul',  role: 'Serveur · 6 jours',                       shift: '46h 10', amt: '32 400 MAD', tx: '256 tx' },
        { av: 'SB', cls: 'c',name: 'Sofia Belkadi',  role: 'Barista · 7 jours',                       shift: '42h 00', amt: '28 700 MAD', tx: '342 tx' },
        { av: 'YA', cls: 'd',name: 'Youssef Amrani', role: 'Serveur · 5 jours',                       shift: '34h 40', amt: '18 200 MAD', tx: '184 tx' },
        { av: 'MM', cls: 'd',name: 'Mehdi Mansouri', role: 'Cuisine · 6 jours',                       shift: '44h 30', amt: '·',          tx: '' },
      ],
      trenteJours: [
        { av: 'FK', cls: '', name: 'Fatima Khalki',  role: 'Serveuse senior · 26 jours',              shift: '208h 40', amt: '152 600 MAD', tx: '1 240 tx' },
        { av: 'HJ', cls: 'b',name: 'Hamid Jelloul',  role: 'Serveur · 25 jours',                      shift: '198h 20', amt: '138 800 MAD', tx: '1 086 tx' },
        { av: 'SB', cls: 'c',name: 'Sofia Belkadi',  role: 'Barista · 28 jours',                      shift: '174h 00', amt: '118 400 MAD', tx: '1 458 tx' },
        { av: 'YA', cls: 'd',name: 'Youssef Amrani', role: 'Serveur · 21 jours',                      shift: '146h 20', amt: '76 400 MAD',  tx: '784 tx' },
        { av: 'MM', cls: 'd',name: 'Mehdi Mansouri', role: 'Cuisine · 24 jours',                      shift: '184h 00', amt: '·',           tx: '' },
      ],
    },
    maisonMansour: {
      aujourdhui: [
        { av: 'KI', cls: '',  name: 'Karima Idrissi', role: 'Vendeuse principale · service en cours', shift: '5h 30', amt: '6 200 MAD', tx: '18 tx' },
        { av: 'AB', cls: 'b', name: 'Aicha Benali',   role: 'Vendeuse · pause depuis 14:30',          shift: '4h 12', amt: '3 100 MAD', tx: '14 tx' },
        { av: 'RT', cls: 'c', name: 'Rania Tazi',     role: 'Vendeuse · vitrine',                     shift: '4h 48', amt: '2 520 MAD', tx: '10 tx' },
      ],
      hier: [
        { av: 'KI', cls: 'offline', name: 'Karima Idrissi', role: 'Vendeuse principale · service de hier', shift: '8h 30', amt: '6 850 MAD', tx: '20 tx' },
        { av: 'AB', cls: 'offline', name: 'Aicha Benali',   role: 'Vendeuse · journée complète',           shift: '7h 50', amt: '3 280 MAD', tx: '15 tx' },
        { av: 'RT', cls: 'offline', name: 'Rania Tazi',     role: 'Vendeuse · vitrine',                    shift: '7h 30', amt: '1 980 MAD', tx: '8 tx' },
      ],
      septJours: [
        { av: 'KI', cls: '',  name: 'Karima Idrissi', role: 'Vendeuse principale · 6 jours', shift: '48h 30', amt: '38 200 MAD', tx: '128 tx' },
        { av: 'AB', cls: 'b', name: 'Aicha Benali',   role: 'Vendeuse · 6 jours',            shift: '44h 10', amt: '24 800 MAD', tx: '102 tx' },
        { av: 'RT', cls: 'c', name: 'Rania Tazi',     role: 'Vendeuse · 5 jours',            shift: '36h 50', amt: '15 400 MAD', tx: '65 tx' },
      ],
      trenteJours: [
        { av: 'KI', cls: '',  name: 'Karima Idrissi', role: 'Vendeuse principale · 26 jours', shift: '210h 30', amt: '162 800 MAD', tx: '548 tx' },
        { av: 'AB', cls: 'b', name: 'Aicha Benali',   role: 'Vendeuse · 25 jours',             shift: '194h 50', amt: '105 200 MAD', tx: '432 tx' },
        { av: 'RT', cls: 'c', name: 'Rania Tazi',     role: 'Vendeuse · 22 jours',             shift: '162h 30', amt: '64 800 MAD',  tx: '260 tx' },
      ],
    },
    spaBahia: {
      aujourdhui: [
        { av: 'NH', cls: '',  name: 'Nour El Hassan',     role: 'Praticienne senior · soins du visage',   shift: '6h 30', amt: '3 850 MAD', tx: '8 RDV' },
        { av: 'SB', cls: 'b', name: 'Salma Benkirane',    role: 'Praticienne · massages',                 shift: '5h 50', amt: '3 200 MAD', tx: '7 RDV' },
        { av: 'YB', cls: 'c', name: 'Yasmine Bouchikhi',  role: 'Praticienne · hammam & gommage',         shift: '4h 30', amt: '1 900 MAD', tx: '5 RDV' },
      ],
      hier: [
        { av: 'NH', cls: 'offline', name: 'Nour El Hassan',     role: 'Praticienne senior · journée complète', shift: '8h 00', amt: '3 600 MAD', tx: '7 RDV' },
        { av: 'SB', cls: 'offline', name: 'Salma Benkirane',    role: 'Praticienne · massages',                shift: '7h 30', amt: '3 050 MAD', tx: '6 RDV' },
        { av: 'YB', cls: 'offline', name: 'Yasmine Bouchikhi',  role: 'Praticienne · hammam',                  shift: '6h 30', amt: '1 730 MAD', tx: '5 RDV' },
      ],
      septJours: [
        { av: 'NH', cls: '',  name: 'Nour El Hassan',     role: 'Praticienne senior · 6 jours', shift: '46h 00', amt: '26 800 MAD', tx: '54 RDV' },
        { av: 'SB', cls: 'b', name: 'Salma Benkirane',    role: 'Praticienne · 6 jours',        shift: '42h 30', amt: '22 400 MAD', tx: '48 RDV' },
        { av: 'YB', cls: 'c', name: 'Yasmine Bouchikhi',  role: 'Praticienne · 5 jours',        shift: '32h 00', amt: '15 000 MAD', tx: '40 RDV' },
      ],
      trenteJours: [
        { av: 'NH', cls: '',  name: 'Nour El Hassan',     role: 'Praticienne senior · 27 jours', shift: '198h 00', amt: '112 800 MAD', tx: '224 RDV' },
        { av: 'SB', cls: 'b', name: 'Salma Benkirane',    role: 'Praticienne · 26 jours',        shift: '184h 30', amt: '94 200 MAD',  tx: '198 RDV' },
        { av: 'YB', cls: 'c', name: 'Yasmine Bouchikhi',  role: 'Praticienne · 23 jours',        shift: '142h 00', amt: '62 400 MAD',  tx: '158 RDV' },
      ],
    },
  };

  /* ═══════════════ STATE + EVENTS ═══════════════ */

  function setDateRange(id) {
    if (!VALID.includes(id)) id = DEFAULT_RANGE;
    // 'personnalise' is only meaningful with a date pair behind it.
    if (id === 'personnalise' && !customRange) id = DEFAULT_RANGE;
    currentRange = id;
    try { localStorage.setItem(STORAGE_KEY, id); } catch (_) {}
    renderSelector();
    subscribers.forEach(fn => { try { fn(id); } catch (_) {} });
  }
  /* Commit a calendar-picked pair and switch the dashboard onto it —
   * called by the custom-range popover's "Appliquer" button. */
  function commitCustomRange(start, end) {
    if (!start || !end) return;
    customRange = start <= end ? { start, end } : { start: end, end: start };
    try {
      localStorage.setItem(CUSTOM_KEY,
        dateToIso(customRange.start) + '|' + dateToIso(customRange.end));
    } catch (_) {}
    setDateRange('personnalise');
  }
  function setShowComparison(v) {
    showComparison = !!v;
    try { localStorage.setItem(CMP_KEY, showComparison ? '1' : '0'); } catch (_) {}
    const btn = document.querySelector('[data-rev-compare-btn]');
    if (btn) {
      btn.classList.toggle('on', showComparison);
      btn.setAttribute('aria-pressed', String(showComparison));
    }
    renderRevChart();
  }
  function subscribe(fn) { subscribers.add(fn); return () => subscribers.delete(fn); }

  /* ═══════════════ DATE / NUMBER HELPERS ═══════════════ */

  const pad = n => String(n).padStart(2, '0');
  const fmtDate = d => `${pad(d.getDate())}.${pad(d.getMonth()+1)}.${d.getFullYear()}`;
  const fmtShort = d => `${pad(d.getDate())}.${pad(d.getMonth()+1)}`;
  const offsetDays = n => { const d = new Date(); d.setDate(d.getDate() + n); return d; };

  function computeSubLine(id) {
    const today = new Date();
    if (id === 'aujourdhui')  return fmtDate(today);
    if (id === 'hier')        return fmtDate(offsetDays(-1));
    if (id === 'septJours')   return `${fmtShort(offsetDays(-6))}, ${fmtDate(today)}`;
    if (id === 'trenteJours') return `${fmtShort(offsetDays(-30))}, ${fmtDate(today)}`;
    return '·';
  }

  const frInt = n => window.KiwiNumber?.number(Math.round(n)) || Math.round(n).toLocaleString('fr-FR');
  /* Money as the till prints it (KiwiNumber.amount): 404,10 stays 404,10. The
   * band, the hero and the payment ring used frInt and showed 404 for a day
   * the till, the day report and Commandes all closed at 404,10. Counts and
   * percentages keep frInt. */
  const frMoney = n => window.KiwiNumber?.amount?.(n) || (Math.round((+n || 0) * 100) % 100
    ? (Math.round((+n || 0) * 100) / 100).toLocaleString('fr-FR', { minimumFractionDigits: 2, maximumFractionDigits: 2 })
    : frInt(n));

  function fmtHeroAmount(v) {
    const int = Math.floor(v);
    const cents = Math.round((v - int) * 100);
    const separator = getLang() === 'en' ? '.' : ',';
    return `${frInt(int)}<span class="cents">${separator}${String(cents).padStart(2,'0')}</span><span class="currency">${curUnit()}</span>`;
  }
  const fmtSettleAmount = v => `${frInt(v)} <span style="font-size:0.42em; opacity: 0.7;">${curUnit()}</span>`;
  /* Design 2027, étape 5 (kiwiSkin2027:dashboard) : l'accueil du kit dessine
   * les chiffres que CES rendus calculent, et aucun autre. Chaque rendu dépose
   * ici ce qu'il vient d'écrire dans le DOM livré ; un évènement par image
   * (kiwi:home-model) prévient le kit. Drapeau éteint : personne n'écoute. */
  function homeStore() { return homeStore.m || (homeStore.m = {}); }
  function homeSet(key, value) {
    homeStore()[key] = value;
    if (homeSet.q) return;
    homeSet.q = true;
    Promise.resolve().then(() => {
      homeSet.q = false;
      try { window.dispatchEvent(new CustomEvent('kiwi:home-model')); } catch (_) {}
    });
  }
  const fmtPct = v => {
    const sign = v > 0 ? '+' : v < 0 ? '−' : '';
    const abs = Math.abs(v);
    const digits = Math.abs(abs - Math.round(abs)) < 0.001 ? 0 : 1;
    const formatted = window.KiwiNumber?.number(abs, digits)
      ?? new Intl.NumberFormat(document.documentElement?.lang === 'en' ? 'en-GB' : 'fr-FR', {minimumFractionDigits:digits,maximumFractionDigits:digits}).format(abs);
    return `${sign}${formatted} %`;
  };

  /* One frame of a count-up. When the markup keeps its shape and only the
   * digits move, the text is updated in place: rebuilding the spans every
   * frame made each counter add new elements sixty times a second, and in
   * dark mode every new element is re-checked for contrast (dark-fixes.js),
   * about 0.9 s of a dashboard start on its own. */
  const numberShape = (html) => html.replace(/>[^<]*</g, '><').replace(/^[^<]*|[^>]*$/g, '');
  function textNodesOf(root) {
    const out = [], w = document.createTreeWalker(root, NodeFilter.SHOW_TEXT);
    while (w.nextNode()) out.push(w.currentNode);
    return out;
  }
  function paintNumber(el, html) {
    const shape = numberShape(html);
    const mine = el.__kiwiNumText;
    /* Reuse only what this function wrote and nobody has replaced since: any
     * other write (a plain re-render, the '…' placeholder) detaches these. */
    if (mine && el.__kiwiNumShape === shape) {
      const live = textNodesOf(el);
      if (live.length === mine.length && live.every((t, i) => t === mine[i])) {
        const tpl = document.createElement('template');
        tpl.innerHTML = html;
        const next = textNodesOf(tpl.content);
        if (next.length === live.length) {
          next.forEach((t, i) => { if (live[i].data !== t.data) live[i].data = t.data; });
          return;
        }
      }
    }
    el.innerHTML = html;
    el.__kiwiNumShape = shape;
    el.__kiwiNumText = textNodesOf(el);
  }

  function animateNumber(el, from, to, { duration = 800, format } = {}) {
    if (!el) return;
    if (operatorLedgerPending()) { el.textContent = '…'; return; }
    // Hidden tabs freeze requestAnimationFrame — set the final value at once
    // so a background re-render never leaves a tile blank.
    if (document.hidden || duration === 0 || window.matchMedia?.('(prefers-reduced-motion: reduce)').matches) { el['inner' + 'HTML'] = format(to); return; }
    const start = performance.now();
    const ease = t => 1 - Math.pow(1 - t, 3);
    function tick(now) {
      if (operatorLedgerPending()) { el.textContent = '…'; return; }
      const p = Math.min(1, (now - start) / duration);
      const v = from + (to - from) * ease(p);
      paintNumber(el, format(v));
      if (p < 1) requestAnimationFrame(tick);
      else paintNumber(el, format(to));
    }
    requestAnimationFrame(tick);
  }

  /* Auto-size the hero amount so it always sits on a single line.
   * Renders the target value in a hidden mirror (same fonts/letter-spacing),
   * measures, and shrinks font-size if it would overflow the column. */
  function fitHeroAmount(el, targetValue) {
    if (!el) return;
    el.style.fontSize = '';
    const parent = el.parentElement;
    if (!parent) return;
    const cs = getComputedStyle(el);
    const probe = document.createElement('span');
    probe.style.cssText = `position: absolute; left: -9999px; top: -9999px; visibility: hidden; white-space: nowrap; pointer-events: none;`;
    probe.style.fontFamily = cs.fontFamily;
    probe.style.fontWeight = cs.fontWeight;
    probe.style.fontSize = cs.fontSize;
    probe.style.letterSpacing = cs.letterSpacing;
    probe.style.fontFeatureSettings = cs.fontFeatureSettings;
    probe.innerHTML = fmtHeroAmount(targetValue);
    document.body.appendChild(probe);
    const naturalW = probe.scrollWidth;
    document.body.removeChild(probe);
    const availW = parent.clientWidth;
    if (availW > 0 && naturalW > availW) {
      const baseSize = parseFloat(cs.fontSize);
      el.style.fontSize = `${Math.floor(baseSize * (availW / naturalW) * 0.97)}px`;
    }
  }

  function parseAmountFromEl(el) {
    if (!el) return 0;
    const m = el.textContent.replace('−', '-').match(/-?\d+(?:[\s ]\d{3})*(?:[.,]\d+)?/);
    if (!m) return 0;
    return parseFloat(m[0].replace(/[\s ]/g, '').replace(',', '.')) || 0;
  }
  function parseIntFromEl(el) {
    if (!el) return 0;
    const txt = el.textContent.replace(/\s/g, '').replace('−', '-');
    const m = txt.match(/-?\d+/);
    return m ? parseInt(m[0], 10) : 0;
  }
  function parsePctFromEl(el) {
    if (!el) return 0;
    const txt = el.textContent.replace('−', '-').replace(',', '.');
    const m = txt.match(/-?\d+(\.\d+)?/);
    return m ? parseFloat(m[0]) : 0;
  }

  /* ═══════════════ RENDER: SELECTOR ═══════════════ */

  function revealDayPill(pill) {
    const track = pill.parentElement;
    if (!track) return;
    const p = pill.getBoundingClientRect(), r = track.getBoundingClientRect();
    const delta = p.left < r.left ? p.left - r.left : p.right > r.right ? p.right - r.right : 0;
    // Only this horizontal track moves. scrollIntoView also pulled the entire
    // page vertically on each live re-render, sometimes during a user's swipe.
    if (delta) track.scrollBy({left: delta, behavior: 'instant'});
  }

  function renderSelector() {
    const lang = getLang();
    const labelEl = document.querySelector('[data-dr-label]');
    const subEl = document.querySelector('[data-dr-sub]');
    if (currentRange === 'personnalise' && customRange) {
      // The custom range owns the headline: show its human date span, with
      // the day count standing in for the usual single-date sub-line.
      const ps = PICKER_STR[lang] || PICKER_STR.fr;
      const n = spanDays(customRange.start, customRange.end);
      if (labelEl) labelEl.textContent = fmtHumanRange(customRange.start, customRange.end, lang);
      if (subEl) subEl.textContent =
        `${RANGE_STR[lang]?.personnalise || RANGE_STR.fr.personnalise} · ${n} ${n > 1 ? ps.days : ps.day}`;
    } else {
      if (labelEl) labelEl.textContent = RANGE_STR[lang]?.[currentRange] || RANGE_STR.fr[currentRange];
      if (subEl)   subEl.textContent = computeSubLine(currentRange);
    }
    // A period without a pill of its own (Mois dernier, Ce trimestre, Cette
    // année, kept from the old range menu) is chosen from the calendar, so the
    // calendar pill is the one lit. Lighting none left the lens on
    // « Aujourd'hui » under a « Mois dernier » title.
    const pills = [...document.querySelectorAll('.dash-date-range .dr-pill')];
    const lit = pills.some(p => p.dataset.range === currentRange) ? currentRange : 'personnalise';
    pills.forEach(p => {
      const on = p.dataset.range === lit;
      p.classList.toggle('on', on);
      p.setAttribute('aria-pressed', String(on));
      if (on) requestAnimationFrame(() => p.isConnected && revealDayPill(p));
    });
  }

  /* ═══════════════ REAL SALES · time-windowed (user-created venues) ═══════════════
   * KiwiSales entries carry a real `ts` (millis). The hero, KPI band, goal bar
   * and revenue chart all derive from the SAME window here — so a single sale
   * moves every surface and the figures can never disagree with each other.
   * Placed before renderHero but hoisted as function declarations, so every
   * renderer below can call them. */
  /* ── Où commence « aujourd'hui » ────────────────────────────────────────
   * À la même heure que sur le rapport Z, et pas à minuit.
   *
   * Le tableau de bord coupait la journée à minuit. Le rapport de clôture, lui,
   * la coupe à la bascule commerciale du commerçant — 5 h par défaut, ou
   * l'heure déduite de ses horaires (assets/day-report.js · cutoff). Pour un
   * restaurant qui ferme à 1 h du matin, les deux surfaces ne pouvaient donc
   * pas tomber d'accord : le Z du soir rangeait les ventes de 00 h–01 h dans la
   * recette de la soirée, la tuile « Aujourd'hui » les comptait dans le
   * lendemain. Le patron voyait un Z à 8 400 MAD et un tableau de bord qui
   * n'en montrait que 7 900, sans qu'aucun des deux ne soit faux ni réparable :
   * ils répondaient à deux questions différentes en prétendant répondre à la
   * même. Et le décalage frappe précisément les commerces de service du soir,
   * c'est-à-dire ceux dont la soirée EST le chiffre d'affaires.
   *
   * Une seule définition, donc, et c'est celle du rapport — parce que c'est
   * celle que le commerçant imprime, signe et compare à sa caisse.
   *
   * Repli à minuit quand le module de rapport n'est pas chargé : c'est
   * exactement le comportement d'avant, donc rien ne peut se dégrader. */
  const DEFAULT_MERCHANT_TZ = 'Africa/Casablanca';
  function activeMerchantSlug() {
    try { return getCurrentVenue(); } catch (_) { return ''; }
  }
  function merchantTimeZone(slug) {
    try {
      const R = window.KiwiDayReport;
      if (R?.timezone) return R.timezone(slug);
    } catch (_) {}
    try {
      const vd = window.KiwiVenue?.getCurrentVenueData?.();
      const zone = vd?.timezone || vd?.timeZone || vd?.tz || window.KiwiConfig?.timezone || window.KiwiConfig?.timeZone;
      if (zone) { new (globalThis.KiwiZoneLaw?.DateTimeFormat || Intl.DateTimeFormat)('en-CA', { timeZone: zone }).format(); return zone; }
    } catch (_) {}
    try { return Intl.DateTimeFormat().resolvedOptions().timeZone || DEFAULT_MERCHANT_TZ; } catch (_) { return DEFAULT_MERCHANT_TZ; }
  }
  function merchantParts(ts, slug) {
    const f = new (globalThis.KiwiZoneLaw?.DateTimeFormat || Intl.DateTimeFormat)('en-CA', {
      timeZone: merchantTimeZone(slug), year: 'numeric', month: '2-digit', day: '2-digit',
      hour: '2-digit', minute: '2-digit', second: '2-digit', hourCycle: 'h23'
    });
    const out = {};
    f.formatToParts(new Date(ts)).forEach(p => { if (p.type !== 'literal') out[p.type] = p.value; });
    return out;
  }
  function addMerchantDays(day, delta) {
    const p = String(day || '').split('-');
    return new Date(Date.UTC(+p[0], (+p[1] || 1) - 1, +p[2] || 1) + delta * 864e5).toISOString().slice(0, 10);
  }
  function merchantBoundary(day, hour, slug) {
    const zone = merchantTimeZone(slug);
    const target = Date.parse(String(day) + 'T00:00:00Z') + hour * 3600000;
    let guess = target;
    for (let i = 0; i < 6; i++) {
      const p = merchantParts(guess, slug);
      const observed = Date.parse(`${p.year}-${p.month}-${p.day}T${p.hour}:${p.minute}:${p.second}Z`);
      if (observed === target) return guess;
      guess += target - observed;
    }
    return guess;
  }
  function merchantDayKey(ts, slug) {
    try {
      const R = window.KiwiDayReport;
      if (R?.businessDay) return R.businessDay(ts, slug);
    } catch (_) {}
    const p = merchantParts(ts, slug);
    const day = `${p.year}-${p.month}-${p.day}`;
    return +p.hour < dayCutoffH(slug) ? addMerchantDays(day, -1) : day;
  }
  function merchantDayBounds(day, slug) {
    try {
      const R = window.KiwiDayReport;
      if (R?.dayBounds) return R.dayBounds(day, slug);
    } catch (_) {}
    const h = dayCutoffH(slug);
    return { from: merchantBoundary(day, h, slug), to: merchantBoundary(addMerchantDays(day, 1), h, slug) };
  }
  function dayCutoffH(slug) { /* repli = 05:00 comme la caisse, jamais minuit */
    try {
      const h = window.KiwiDayReport?.cutoff?.(slug);
      return (typeof h === 'number' && isFinite(h) && h >= 0 && h <= 12) ? h : 5;
    } catch (_) { return 5; }
  }
  function dayStartMs(t) {
    const slug = activeMerchantSlug();
    return merchantDayBounds(merchantDayKey(t, slug), slug).from;
  }
  function realSalesList() {
    try { return (window.KiwiSales?.list?.(getCurrentVenue()) || []); } catch (_) { return []; }
  }
  function realRefundList() {
    try { return (window.KiwiRefunds?.list?.(getCurrentVenue()) || []); } catch (_) { return []; }
  }
  function realMoneyList() {
    return realSalesList().concat(realRefundList().map((r) => ({ ...r, amount: -Math.abs(+r.amount || 0), kind: 'refund' })));
  }
  // Window bounds [from, to) in ms for a range, relative to now.
  /* « Mois dernier », « Ce trimestre », « Cette année » sont des périodes du
   * CALENDRIER. Le sélecteur les affiche ainsi (« Septembre 2026 »,
   * « 1 Jul – 12 Oct 2026 », « 2026 ») et les tuiles disent « vs mois préc. » ;
   * les bornes, elles, étaient les 30, 90 et 365 derniers jours. Le 12
   * octobre, « Septembre 2026 » totalisait du 13 septembre au 12 octobre, et
   * « 2026 » remontait au 13 octobre 2025. Clés de journée en texte : pas de
   * fuseau, la journée de caisse reste celle de merchantDayBounds. */
  function calendarStartKey(dayKey, unit, back) {
    let y = +dayKey.slice(0, 4), m = +dayKey.slice(5, 7) - 1;
    if (unit === 'year') { y -= back; m = 0; }
    else {
      m = (unit === 'quarter' ? Math.floor(m / 3) * 3 : m) - (unit === 'quarter' ? 3 : 1) * back;
      while (m < 0) { m += 12; y--; }
      while (m > 11) { m -= 12; y++; }
    }
    return y + '-' + String(m + 1).padStart(2, '0') + '-01';
  }
  /* [début, fin) de la période, `back` périodes en arrière. « Mois dernier »
   * est le mois précédent ENTIER ; trimestre et année courent depuis leur
   * premier jour, ouverts jusqu'à maintenant. null hors calendrier. */
  function calendarBounds(range, back) {
    const unit = range === 'moisDernier' ? 'month' : range === 'trimestre' ? 'quarter' : range === 'annee' ? 'year' : '';
    if (!unit) return null;
    const slug = activeMerchantSlug();
    const todayDay = merchantDayKey(Date.now(), slug);
    const shift = (range === 'moisDernier' ? 1 : 0) + (back || 0);
    const from = merchantDayBounds(calendarStartKey(todayDay, unit, shift), slug).from;
    if (range !== 'moisDernier' && !back) return [from, Infinity];
    return [from, merchantDayBounds(calendarStartKey(todayDay, unit, shift - 1), slug).from];
  }
  function rangeBounds(range) {
    /* A merchant-picked range is exact. Demo tables may use a presentation
     * bucket, but live ledgers must never turn "3–5 August" into "last 7
     * days" while keeping the precise dates on screen. */
    if ((range === 'personnalise' || (range == null && currentRange === 'personnalise')) && customRange) {
      const slug = activeMerchantSlug();
      const start = merchantDayBounds(dateToIso(customRange.start), slug).from;
      const end = merchantDayBounds(dateToIso(customRange.end), slug).to;
      return [start, end];
    }
    const slug = activeMerchantSlug();
    const todayDay = merchantDayKey(Date.now(), slug);
    const today = merchantDayBounds(todayDay, slug).from;
    if (range === 'aujourdhui') return [today, Infinity];
    if (range === 'hier') {
      const yesterday = merchantDayBounds(addMerchantDays(todayDay, -1), slug);
      return [yesterday.from, yesterday.to];
    }
    const calendar = calendarBounds(range, 0);
    if (calendar) return calendar;
    const days = RANGE_DAYS[range] || 1;
    return [merchantDayBounds(addMerchantDays(todayDay, -(days - 1)), slug).from, Infinity];
  }
  /* Les livraisons pas encore payées par le transporteur. Une vente partie en
   * livraison est enregistrée à 0 MAD, et le magasin des ventes ne garde que
   * l'argent : elle n'était donc dans aucune créance. Le montant dû vient de
   * /api/receivables (assets/delivery-receivables.js), daté du jour de la
   * vente ; une livraison reçue en sort et entre comme une vente ordinaire. */
  const deliveryDue = (from, to) => {
    try { return Math.max(0, +(window.KiwiDeliveries && window.KiwiDeliveries.dueIn(from, to)) || 0); } catch (_) { return 0; }
  };
  /* assets/sales-history.js loads just before this file. Read it on use, so a
     page that loads dateRange.js alone still boots and only the totals wait. */
  const salesMath = () => window.KiwiSalesMath;
  const tenderBucket = (m) => salesMath().tenderBucket(m);
  const tenderAmounts = (e) => salesMath().tenderAmounts(e);
  function realSalesTotals(range) {
    const [from, to] = rangeBounds(range == null ? currentRange : range);
    const { card, cash, ...totals } = realWindowStats(from, to);
    return totals;
  }
  function realWindowStats(from, to) {
    const summary = window.KiwiSalesSummary;
    const totals = summary ? summary.stats(realSalesList(), realRefundList(), from, to, getCurrentVenue())
      : window.KiwiSalesMath.statsFromSales(realSalesList(), realRefundList(), from, to);
    totals.receivable += deliveryDue(from, to);
    return totals;
  }

  /* One read model for every headline and insight sentence. Nothing falls back
   * to older rows when the selected period is empty: zero today means zero
   * today, even when the venue sold yesterday. */
  /* L'heure d'une vente dans le fuseau du COMMERCE (day-report.js), pas celui de
     l'appareil : un patron qui ouvre le tableau de bord depuis l'étranger voyait
     une « heure de pointe » décalée. Repli sur l'appareil si le module du rapport
     du jour n'est pas chargé. */
  function saleHour(ts) {
    try {
      const R = window.KiwiDayReport;
      if (R && typeof R.hourOf === 'function') { const h = R.hourOf(ts); if (isFinite(h) && h >= 0 && h < 24) return h; }
    } catch (_) {}
    return new Date(ts).getHours();
  }
  function realInsightSummary(range) {
    const [from, to] = rangeBounds(range == null ? currentRange : range);
    const rows = realSalesList().filter((e) => {
      const ts = +e.ts || 0;
      return ts >= from && ts < to;
    });
    let revenue = 0, gross = 0, refunds = 0, collected = 0, receivable = 0;
    const byHour = window.KiwiSalesMath.hoursFromSales(rows, from, to, saleHour), byTender = {};
    rows.forEach((e) => {
      const amount = Math.max(0, +e.amount || 0);
      revenue += amount; gross += amount;
      const tender = tenderBucket(e && e.method);
      if (tender && amount) {
        tenderAmounts(e).forEach(part => {
          if (part.key) byTender[part.key] = (byTender[part.key] || 0) + part.amount;
        });
        collected += amount;
      } else if (salesMath().RECEIVABLE_METHODS.includes(String(e && e.method || '').trim().toLowerCase())) {
        receivable += amount;
      }
    });
    realRefundList().forEach((e) => {
      const ts = +e.ts || 0;
      if (ts < from || ts >= to) return;
      const amount = Math.abs(+e.amount || 0);
      revenue -= Math.abs(+e.amount || 0); refunds += amount;
      const hour = saleHour(ts);
      byHour[hour] = (byHour[hour] || 0) - amount;
      const tender = tenderBucket(e && e.method);
      if (tender) { byTender[tender] = (byTender[tender] || 0) - amount; collected -= amount; }
      else if (salesMath().RECEIVABLE_METHODS.includes(String(e && e.method || '').trim().toLowerCase())) receivable -= amount;
    });
    receivable += deliveryDue(from, to);
    const topKey = (obj) => Object.keys(obj).reduce((best, key) =>
      best == null || obj[key] > obj[best] ? key : best, null);
    const peakHour = topKey(byHour);
    const topTender = topKey(byTender);
    return {
      from, to, count: rows.length, revenue, gross, refunds, collected, receivable,
      basket: rows.length ? revenue / rows.length : 0,
      peakHour: peakHour == null ? null : +peakHour,
      peakRevenue: peakHour == null ? 0 : byHour[peakHour],
      activeHours: Object.keys(byHour).length,
      topTender,
      tenderAmount: topTender == null ? 0 : byTender[topTender],
      collected,
    };
  }

  const TENDER_NAME = {
    fr: { cash: 'espèces', card: 'carte bancaire', tap: 'Kiwi Tap', qr: 'QR / wallet', link: 'lien de paiement', transfer: 'virement', cheque: 'chèque', split: 'paiement partagé', other: 'autre mode' },
    en: { cash: 'cash', card: 'bank card', tap: 'Kiwi Tap', qr: 'QR / wallet', link: 'payment link', transfer: 'bank transfer', cheque: 'cheque', split: 'split payment', other: 'other tender' },
    ar: { cash: 'نقدًا', card: 'بطاقة بنكية', tap: 'Kiwi Tap', qr: 'QR / محفظة', link: 'رابط دفع', transfer: 'تحويل بنكي', cheque: 'شيك', split: 'دفع مقسّم', other: 'طريقة أخرى' },
  };
  function buildRealHeroRec() {
    const s = realInsightSummary();
    if (!s.count || !s.revenue) return null;
    const lang = getLang();
    const today = currentRange === 'aujourdhui';
    const num = (n) => frInt(Math.round(n));
    const tender = s.topTender && s.collected ? Math.round((s.tenderAmount / s.collected) * 100) : null;
    const tenderName = s.topTender ? (TENDER_NAME[lang] || TENDER_NAME.fr)[s.topTender] : '';
    const peakFr = s.peakHour == null ? '' : ` Votre meilleure heure : ${s.peakHour}h.`;
    const payFr = tender == null ? '' : ` ${tender} % des encaissements identifiés sont en ${tenderName}.`;
    const peakEn = s.peakHour == null ? '' : ` Your best hour: ${s.peakHour}:00.`;
    const payEn = tender == null ? '' : ` ${tender}% of identified payments are ${tenderName}.`;
    const peakAr = s.peakHour == null ? '' : ` أفضل ساعة: ${s.peakHour}.`;
    const payAr = tender == null ? '' : ` ${tender}٪ من المدفوعات المحددة عبر ${tenderName}.`;
    const W = {
      fr: { title: today ? 'Votre journée en cours' : 'La période sélectionnée', obs: `${s.count} vente${s.count > 1 ? 's' : ''} ${today ? "aujourd'hui" : 'sur la période'} pour ${num(s.revenue)} MAD, panier moyen ${num(s.basket)} MAD.${peakFr}${payFr}`, act: '→ Calculé à partir des ventes affichées sur cette période.', basisLabel: 'mesuré' },
      en: { title: today ? 'Your day so far' : 'Selected period', obs: `${s.count} sale${s.count > 1 ? 's' : ''} ${today ? 'today' : 'in this period'} for ${num(s.revenue)} MAD, average basket ${num(s.basket)} MAD.${peakEn}${payEn}`, act: '→ Calculated from the sales shown for this period.', basisLabel: 'measured' },
      ar: { title: today ? 'يومك حتى الآن' : 'الفترة المحددة', obs: `${s.count} عملية بيع ${today ? 'اليوم' : 'خلال هذه الفترة'} بقيمة ${num(s.revenue)} درهم، ومتوسط السلة ${num(s.basket)} درهم.${peakAr}${payAr}`, act: '← محسوب من المبيعات المعروضة لهذه الفترة.', basisLabel: 'مقاس' },
    };
    return W[lang] || W.fr;
  }
  function buildRealHeatmapRec() {
    const s = realInsightSummary();
    if (!s.count || !s.revenue || s.peakHour == null) return null;
    const lang = getLang();
    const share = Math.round((s.peakRevenue / s.revenue) * 100);
    const num = (n) => frInt(Math.round(n));
    const W = {
      fr: { title: `Votre pic : ${s.peakHour}h`, obs: `${num(s.peakRevenue)} MAD de ventes nettes à ${s.peakHour}h, soit ${share} % de la période, réparties sur ${s.activeHours} heure${s.activeHours > 1 ? 's' : ''} d’activité.`, cta: '' },
      en: { title: `Your peak: ${s.peakHour}:00`, obs: `${num(s.peakRevenue)} MAD in net sales at ${s.peakHour}:00, ${share}% of the period across ${s.activeHours} active hour${s.activeHours > 1 ? 's' : ''}.`, cta: '' },
      ar: { title: `ذروتك: ${s.peakHour}`, obs: `${num(s.peakRevenue)} درهم من صافي المبيعات عند الساعة ${s.peakHour}، أي ${share}٪ من الفترة موزعة على ${s.activeHours} ساعة نشاط.`, cta: '' },
    };
    return W[lang] || W.fr;
  }
  /* Coût matière RÉEL — délégué à window.KiwiCost (assets/cost.js), qui est
   * désormais le seul endroit de l'application qui sache répondre « combien me
   * coûte ce produit ».
   *
   * ── CE QUE FAISAIT CETTE FONCTION, ET POURQUOI C'ÉTAIT FAUX ───────────────
   * Elle rapprochait le LIBELLÉ du ticket du nom d'un produit du catalogue. Or
   * le libellé est un RÉSUMÉ de panier — « Pain complet +3 art. », « Table 4 »
   * (voir schema.sql, colonne `lines`, qui existe précisément parce que le
   * libellé ne désigne pas un produit). Trois conséquences mesurées :
   *
   *   · un panier de plusieurs articles ne se résolvait jamais ;
   *   · quand il se résolvait, on retranchait UN coût unitaire du montant du
   *     ticket ENTIER : quatre pains à 5 MAD donnaient 18 MAD de bénéfice au
   *     lieu de 12 ;
   *   · tout le reste retombait sur DEFAULT_MARGIN. Pour un café, dont aucune
   *     vente ne se résolvait jamais, la tuile « Marge brute » affichait donc
   *     exactement 69,0 % tous les jours, à vie. Une constante présentée comme
   *     une mesure — et « Bénéfice brut » et « Coût matière » en dérivant, les
   *     trois tuiles se confirmaient mutuellement.
   *
   * ── CE QU'ELLE FAIT MAINTENANT ────────────────────────────────────────────
   * Elle lit `e.lines[]` — le panier réel, avec ses quantités, qui remonte déjà
   * de la caisse jusqu'ici — multiplie le coût par la quantité, et n'invente
   * RIEN : une ligne dont le coût est inconnu sort du calcul de marge et entre
   * dans un compteur de couverture. Mieux vaut « marge calculée sur 62 % de vos
   * ventes » qu'un pourcentage complet en apparence et faux en réalité.
   *
   * `revenueCosted`/`pctCosted` remontent jusqu'aux tuiles : sans eux la marge
   * ne s'affiche pas du tout (un tiret), au lieu de se déguiser en mesure. */
  function realGrossProfit(from, to) {
    const C = window.KiwiCost;
    if (!C || !C.coverage) return null;
    try { return C.coverage(realSalesList(), from, to); } catch (_) { return null; }
  }
  /* rangeBounds leaves `to` open at Infinity for live ranges; a comparison
   * needs a closed window it can shift backwards, so pin the open end to now. */
  function closedBounds(range) {
    const [from, to] = rangeBounds(range == null ? currentRange : range);
    return [from, to === Infinity ? Date.now() + 1 : to];
  }
  function shiftedBusinessBounds(from, to, deltaDays) {
    const slug = activeMerchantSlug();
    const startDay = merchantDayKey(from + 1, slug);
    const endDay = merchantDayKey((to === Infinity ? Date.now() : to - 1), slug);
    const shiftedStart = addMerchantDays(startDay, -deltaDays);
    const shiftedEnd = addMerchantDays(endDay, -deltaDays);
    return [merchantDayBounds(shiftedStart, slug).from, merchantDayBounds(shiftedEnd, slug).to];
  }
  /* A percentage change needs something to change FROM. A merchant on their
   * first day has no yesterday, and printing « 0 % vs hier » beside their
   * opening sales claims the day was flat when it was in fact their first.
   * null means "no baseline" — every caller hides the comparison rather than
   * inventing one. Without `backDays` the baseline is the window immediately
   * before this one; with it, the SAME slice N days earlier — so at 14h « vs
   * semaine » weighs today-so-far against last week up to 14h, not against a
   * full day it hasn't finished yet. */
  /* Le nombre de journées de caisse que couvre la fenêtre, aujourd'hui
   * compris : le dénominateur honnête de « CA moyen par jour ». RANGE_DAYS
   * divisait une période personnalisée par 1 (la moyenne valait le total) et
   * l'année en cours par 365. */
  /* Le carnet (clôtures, clients) de l'établissement À L'ÉCRAN, et de lui
   * seul. KiwiDayReport et KiwiClients savent retrouver un carnet par défaut,
   * mais leur repli passe par kiwiLiveMerchant ou l'appairage, un réglage
   * global au navigateur : sur une session réelle dont l'établissement n'est
   * pas (encore) identifié, ou après qu'un opérateur a consulté un autre
   * commerce, ce repli désigne un AUTRE commerce. Ces tuiles s'affichent à
   * côté des ventes de l'établissement à l'écran ; elles lisent donc le même
   * établissement, par son slug gravé (le même calcul que ces deux carnets en
   * mode tableau de bord), ou rien du tout. */
  function screenBook() {
    try {
      const KV = window.KiwiVenue;
      if (!KV || !KV.isCustom || !KV.isCustom() || !KV.getCurrentVenueData) return '';
      const vd = KV.getCurrentVenueData();
      if (!vd) return '';
      if (vd.slug) return String(vd.slug);
      return String(vd.name || '').normalize('NFD').replace(/[\u0300-\u036f]/g, '')
        .toLowerCase().trim().replace(/[^a-z0-9]+/g, '-').replace(/^-+|-+$/g, '');
    } catch (_) { return ''; }
  }
  /* Les pourboires déclarés par les journées CLOSES de la fenêtre, et, pour une
   * journée encore ouverte, ceux que la caisse a saisis à l'encaissement
   * (sales.tip_cents, porté par le flux). Une journée close garde son chiffre
   * déclaré, jamais additionné aux saisies : c'est le Z qui fait foi. Une
   * journée ouverte sans aucun pourboire saisi n'est pas comptée : rien à dire,
   * plutôt qu'un 0 qu'une caisse plus ancienne n'aurait simplement pas envoyé.
   * null quand le classeur n'est pas chargé (rien à dire). */
  function realClosedTips(range) {
    const DR = window.KiwiDayReport;
    if (!DR || typeof DR.list !== 'function') return null;
    const book = screenBook();
    if (!book) return null;
    const [from, to] = rangeBounds(range == null ? currentRange : range);
    const slug = activeMerchantSlug();
    const coverage = window.KiwiSalesReconcile?.coverage();
    const first = merchantDayKey(from + 1, slug);
    const last = to === Infinity ? merchantDayKey(Date.now(), slug) : merchantDayKey(to - 1, slug);
    /* Tout en centimes entiers : des dirhams flottants (le Z) et des centimes
       (la caisse, le résumé) s'additionnaient en flottants et s'arrondissaient
       une fois à la fin. */
    let cents = 0, days = 0;
    let reports = [];
    try { reports = DR.list(book) || []; } catch (_) { return null; }
    const closed = new Set();
    reports.forEach((r) => {
      if (!r || !r.closed || !r.day || r.day < first || r.day > last) return;
      const t = Number(r.tips);
      days++; closed.add(r.day);
      if (Number.isFinite(t) && t > 0) cents += Math.round(t * 100);
    });
    const live = new Set();
    let sales = [];
    try { sales = typeof realSalesList === 'function' ? realSalesList() : []; } catch (_) { sales = []; }
    (sales || []).forEach((e) => {
      const tipCents = Math.round(Number(e && e.tipCents));
      if (!(tipCents > 0)) return;
      const ts = +e.ts || 0;
      if (ts < from || ts >= to || (coverage != null && ts < coverage)) return;
      const day = merchantDayKey(ts, slug);
      if (closed.has(day)) return;
      live.add(day);
      cents += tipCents;
    });
    const old = window.KiwiSalesHistory?.oldTips(from, to, closed);
    /* L'historique ancien (avant la couverture des ventes locales) vient du
       résumé serveur, qui peut tarder ou échouer. Les pourboires déjà connus
       (Z clos et caisse) restent comptés et la tuile le DIT (partial), au lieu
       de les taire. */
    if (!old?.partial) { cents += Math.round((old?.sum || 0) * 100); days += old?.days || 0; }
    days += live.size;
    const out = { sum: cents / 100, days, liveDays: live.size };
    if (old?.partial) out.partial = true;
    return out;
  }
  /* Les clients du carnet (KiwiClients) venus sur [from, to) : ceux qu'on a
   * déjà vus avant `from` sont des réguliers, les autres des nouveaux. Seuls
   * comptent les passages DATÉS, c'est-à-dire l'historique d'achats que la
   * caisse écrit à chaque vente rattachée (les 50 derniers par client, aussi
   * côté serveur). Un client créé sans achat n'est pas venu ; une fiche
   * ancienne sans historique ne peut pas être placée dans le temps, elle ne
   * compte pas. Un compteur de passages plus grand que l'historique veut dire
   * que des passages plus anciens existent : le client était déjà venu.
   * Un client anonyme n'est pas dans le carnet : ces chiffres portent sur les
   * clients identifiés, jamais sur toutes les ventes. */
  function realClientMix(from, to) {
    const KC = window.KiwiClients;
    const book = screenBook();
    let list = [];
    try { list = (book && KC && typeof KC.list === 'function' && KC.list(book)) || []; } catch (_) { list = []; }
    /* Un client régulier est un client revenu : au moins deux passages à la fin
       de la période. Il fallait un passage AVANT la période, si bien qu'une
       cliente arrivée ce mois-ci et revenue cinq fois comptait zéro, et qu'une
       boutique récente lisait « aucun régulier » pendant des semaines. Les
       nouveaux clients restent ceux dont le tout premier passage tombe dans la
       période. */
    let visitors = 0, regulars = 0, newcomers = 0;
    list.forEach((c) => {
      const stamps = (Array.isArray(c && c.history) ? c.history : [])
        .map((h) => Number(h && h.ts)).filter((t) => Number.isFinite(t) && t > 0);
      if (!stamps.some((t) => t >= from && t < to)) return;
      visitors++;
      const older = stamps.some((t) => t < from) || Number(c.visits || 0) > stamps.length;
      if (older || stamps.filter((t) => t < to).length >= 2) regulars++;
      if (!older) newcomers++;
    });
    return { visitors, regulars, newcomers };
  }
  function windowDays(range) {
    const [from, to] = closedBounds(range);
    const slug = activeMerchantSlug();
    const a = merchantDayKey(from + 1, slug), b = merchantDayKey(to - 1, slug);
    return Math.max(1, Math.round((Date.parse(b + 'T00:00:00Z') - Date.parse(a + 'T00:00:00Z')) / 864e5) + 1);
  }
  /* Les journées d'ouverture de la fenêtre : celles où la caisse a enregistré
   * au moins une vente (journée de caisse, coupure à 5 h). « CA par jour » et
   * « Ventes par jour » divisaient par la longueur de la période : un commerce
   * fermé le dimanche voyait sa moyenne amputée d'un septième, une semaine de
   * congés la divisait encore. Une période sans aucune vente vaut 1 (la
   * moyenne est alors 0, pas une division par zéro). */
  function openDays(range) {
    const [from, to] = closedBounds(range);
    const slug = activeMerchantSlug();
    const days = new Set();
    realSalesList().forEach((e) => {
      const ts = +e.ts || 0;
      if (ts >= from && ts < to) days.add(merchantDayKey(ts, slug));
    });
    return Math.max(1, days.size);
  }
  function realDeltaPct(range, pick, backDays, stats = realWindowStats) {
    const [from, to] = closedBounds(range);
    const startDay = merchantDayKey(from + 1, activeMerchantSlug());
    const endDay = merchantDayKey(to - 1, activeMerchantSlug());
    const spanDays = Math.max(1, Math.round((Date.parse(endDay + 'T00:00:00Z') - Date.parse(startDay + 'T00:00:00Z')) / 864e5) + 1);
    /* « vs mois préc. », « vs trimestre préc. », « vs année préc. » : la période
       du calendrier d'avant, pas les N jours qui précèdent. */
    const calendarBase = backDays ? null : calendarBounds(range == null ? currentRange : range, 1);
    const baseBounds = calendarBase || shiftedBusinessBounds(from, to, backDays || spanDays);
    /* The promise above, kept. shiftedBusinessBounds returns WHOLE business
       days, so a live range (« Aujourd'hui », « 7 jours » ending now) was
       weighed against complete days: at 11h42, six hours of trading against
       all of yesterday, and every morning tile read −80 % to −100 %. A live
       window's baseline stops at the same point of its own day. */
    if (rangeBounds(range == null ? currentRange : range)[1] === Infinity) {
      baseBounds[1] = Math.min(baseBounds[1], baseBounds[0] + (to - from));
    }
    const base = pick(stats(baseBounds[0], baseBounds[1]));
    if (!base) return null;
    const cur = pick(stats(from, to));
    return deltaTenths(cur, base);
  }
  /* round(num / den), une demie vers le haut, en entiers : 2,01 MAD sur deux
     tickets fait 1,005, que le flottant range sous 1,005 et arrondit à 1,00. */
  function halfUpDiv(num, den) {
    if (den < 0) { num = -num; den = -den; }
    const n = 2 * num + den, d = 2 * den;
    let q = Math.floor(n / d);
    if (q * d > n) q--; else if ((q + 1) * d <= n) q++;
    return q;
  }
  /* L'écart en dixièmes de pour cent. Deux montants au centime se comparent en
     centimes entiers : 0,80 → 0,79 fait −1,25 %, que (0,79 − 0,80) / 0,80 en
     flottant poussait à −1,3. Un taux (part carte, fidèles…) garde le calcul
     flottant, il n'a pas de centime. */
  function deltaTenths(cur, base) {
    const c = Math.round(cur * 100), b = Math.round(base * 100);
    const onCents = (v, k) => Math.abs(v * 100 - k) <= 1e-6 * Math.max(1, Math.abs(k));
    const num = (c - b) * 1000;
    if (b && onCents(cur, c) && onCents(base, b) && Number.isSafeInteger(2 * num + 2 * Math.abs(b))) {
      return halfUpDiv(num, b) / 10;
    }
    return Math.round(((cur - base) / base) * 1000) / 10;
  }
  // Le panier moyen au centime, une demie vers le haut, depuis la somme en centimes.
  function basketCents(s) {
    const n = s && s.count > 0 ? s.count : 0;
    return n ? halfUpDiv(Math.round(s.basket * n * 100), n) : Math.round(((s && s.basket) || 0) * 100);
  }
  // Round a max value up to a clean axis ceiling (1/2/5 × 10ⁿ).
  function niceCeil(v) {
    if (!(v > 0)) return 1;
    const mag = Math.pow(10, Math.floor(Math.log10(v)));
    const n = v / mag;
    const step = n <= 1 ? 1 : n <= 2 ? 2 : n <= 5 ? 5 : 10;
    return step * mag;
  }
  const DAY_ABBR = ['Dim', 'Lun', 'Mar', 'Mer', 'Jeu', 'Ven', 'Sam'];
  /* Day ticks are built in French ("Sam 18"), including the demo series.
   * Translate the weekday at paint time so an English or Arabic dashboard
   * does not show "Sam 18 … Ven 24". */
  const DAY_ABBR_BY_LANG = {
    en: ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'],
    ar: ['الأحد', 'الإثنين', 'الثلاثاء', 'الأربعاء', 'الخميس', 'الجمعة', 'السبت'],
  };
  function localDayTick(label) {
    const table = DAY_ABBR_BY_LANG[getLang()];
    if (!table || typeof label !== 'string') return label;
    const m = /^(Dim|Lun|Mar|Mer|Jeu|Ven|Sam)(\s.*)$/.exec(label);
    return m ? table[DAY_ABBR.indexOf(m[1])] + m[2] : label;
  }
  /* One day, bucketed by hour and accumulated — 24 running totals. Shared by
   * the plotted day and the day it is compared against so both curves are
   * built by the same code and are readable point-for-point.
   * Bucketing is relative to `base` (the business day start, e.g. 5:00 AM)
   * so late-night sales after midnight are attributed to their service. */
  function hourlyCumul(list, base, end) {
    const hours = Math.max(1, Math.ceil((end - base) / 3600000));
    const per = new Array(hours).fill(0);
    list.forEach(e => {
      const ts = +e.ts || 0;
      if (ts >= base && ts < end) {
        const idx = Math.floor((ts - base) / 3600000);
        if (idx >= 0 && idx < hours) per[idx] += (+e.amount || 0);
      }
    });
    const out = [];
    let acc = 0;
    for (let h = 0; h < hours; h++) { acc += per[h]; out.push(acc); }
    return out;
  }
  // Same idea over N whole days: one total per day from `start`.
  function dailyTotals(list, start, days) {
    const out = new Array(days).fill(0);
    const startDay = merchantDayKey(start, activeMerchantSlug());
    list.forEach(e => {
      const ts = +e.ts || 0;
      if (ts >= start) {
        const day = merchantDayKey(ts, activeMerchantSlug());
        const idx = Math.round((Date.parse(day + 'T00:00:00Z') - Date.parse(startDay + 'T00:00:00Z')) / 864e5);
        if (idx >= 0 && idx < days) out[idx] += (+e.amount || 0);
      }
    });
    return out;
  }
  // Build a REAL revenue-chart series for the active range from KiwiSales — the
  // custom-venue replacement for the zeroed demo clone (which plots a flat line
  // and leaks the demo legend total). Hourly-cumulative on day ranges, daily
  // totals on 7/30-day ranges; axis + legend computed from the real numbers.
  //
  // `revPrev` is the window immediately before this one, bucketed identically —
  // this is what « Comparer » draws. It used to be `rev.map(() => 0)`, so on a
  // real merchant the button faded in a flat line pinned to the axis with an
  // empty legend: indistinguishable from a dead control. A window with no sale
  // at all returns null, not zeros — same rule realDeltaPct states above: a
  // fabricated baseline claims a comparison that was never possible.
  function realRevSeries(range) {
    range = range == null ? currentRange : range;
    const list = realMoneyList();
    const hourly = (range === 'aujourdhui' || range === 'hier');
    let rev = [], prev = [], xLabels = [], visibleXIdx = [], dayKeys = null, sub = '', rangeBadge = '', cmpPrefix = '', total = 0, prevTotal = 0;

    if (hourly) {
      const slug = activeMerchantSlug();
      const todayDay = merchantDayKey(Date.now(), slug);
      const day = addMerchantDays(todayDay, range === 'hier' ? -1 : 0);
      const previousDay = addMerchantDays(day, -1);
      const currentWindow = merchantDayBounds(day, slug);
      const previousWindow = merchantDayBounds(previousDay, slug);
      const base = currentWindow.from;
      rev = hourlyCumul(list, currentWindow.from, currentWindow.to);
      prev = hourlyCumul(list, previousWindow.from, previousWindow.to);
      total = rev[rev.length - 1];
      prevTotal = prev[prev.length - 1];
      for (let h = 0; h < rev.length; h++) {
        const hr = +merchantParts(base + h * 3600000, slug).hour;
        xLabels.push((hr < 10 ? '0' : '') + hr + 'h');
      }
      visibleXIdx = Array.from({ length: rev.length }, (_, i) => i).filter(i => i % Math.max(1, Math.floor(rev.length / 8)) === 0);
      // Today is unfinished. Truncate at current hour elapsed in this business window.
      if (range === 'aujourdhui') {
        const nowIdx = Math.min(rev.length - 1, Math.max(0, Math.floor((Date.now() - base) / 3600000)));
        for (let i = nowIdx + 1; i < rev.length; i++) rev[i] = null;
      }
      rangeBadge = (range === 'hier') ? 'HIER' : "AUJOURD'HUI";
      sub = (range === 'hier') ? 'Cumul horaire · hier' : 'Cumul horaire · aujourd\'hui';
      cmpPrefix = (range === 'hier') ? 'Cumul avant-hier' : 'Cumul hier';
    } else {
      const [start, end] = closedBounds(range);
      const startDay = merchantDayKey(start + 1, activeMerchantSlug());
      const endDay = merchantDayKey(end - 1, activeMerchantSlug());
      const days = Math.max(1, Math.round((Date.parse(endDay + 'T00:00:00Z') - Date.parse(startDay + 'T00:00:00Z')) / 864e5) + 1);
      rev = dailyTotals(list, start, days);
      const previousStart = merchantDayBounds(addMerchantDays(startDay, -days), activeMerchantSlug()).from;
      prev = dailyTotals(list, previousStart, days);
      dayKeys = [];
      for (let i = 0; i < days; i++) { dayKeys.push(addMerchantDays(startDay, i)); const d = new Date(Date.parse(dayKeys[i] + 'T12:00:00Z')); xLabels.push(DAY_ABBR[d.getUTCDay()] + ' ' + d.getUTCDate()); }
      const step = Math.max(1, Math.round(days / 6));
      for (let i = 0; i < days; i += step) visibleXIdx.push(i);
      if (visibleXIdx[visibleXIdx.length - 1] !== days - 1) visibleXIdx.push(days - 1);
      total = rev.reduce((s, x) => s + x, 0);
      prevTotal = prev.reduce((s, x) => s + x, 0);
      const named = { moisDernier: ['MOIS DERNIER', 'mois dernier'], trimestre: ['CE TRIMESTRE', 'ce trimestre'], annee: ['CETTE ANNÉE', 'cette année'] }[range];
      rangeBadge = range === 'personnalise' ? 'PÉRIODE PERSONNALISÉE' : named ? named[0] : days + ' DERNIERS JOURS';
      sub = range === 'personnalise' ? 'Total journalier · période sélectionnée' : 'Total journalier · ' + (named ? named[1] : days + ' derniers jours');
      cmpPrefix = days + ' jours précédents';
    }

    const hasPrev = prevTotal > 0;
    // The ceiling has to clear BOTH curves, or a stronger previous period gets
    // clipped off the top of the box the moment the comparison is switched on.
    const top = niceCeil(Math.max(1, ...rev.filter(v => v != null), ...(hasPrev ? prev : [])));
    const yTicks = [0, top * 0.25, top * 0.5, top * 0.75, top].map(Math.round);
    const legendPrimary = (hourly ? 'Cumul' : ('Total ' + rev.length + ' jours')) + ' · ' + frInt(total) + ' MAD';
    return {
      rev, revPrev: hasPrev ? prev : null, total, prevTotal: hasPrev ? prevTotal : null,
      yTicks, xLabels, visibleXIdx, dayKeys, sub, rangeBadge, legendPrimary,
      legendCompare: hasPrev ? (cmpPrefix + ' · ' + frInt(prevTotal) + ' MAD') : '',
    };
  }

  /* ═══════════════ RENDER: HERO ═══════════════ */

  // dateRange loads before live-link. An operator URL starts unverified even
  // before identity/feed initialization; cached or partial totals are not zero.
  function operatorLedgerPending() {
    if (!/[?&]op=1(?:&|$)/.test(location.search)) return false;
    const live = window.KiwiLive;
    const state = live?.snapshotStatus?.();
    const requested = new URLSearchParams(location.search).get('merchant');
    const venue = window.KiwiVenue?.getCurrentVenueData?.();
    return !state || state.phase !== 'complete' || (requested && state.merchant !== requested) ||
      !venue || (venue.slug && venue.slug !== state.merchant) ||
      !state.venue || state.venue !== window.KiwiVenue?.getVenue?.();
  }
  function operatorUnavailableText() {
    const state = window.KiwiLive?.snapshotStatus?.();
    const loading = !state || state.phase === 'loading';
    const lang = getLang();
    return (loading
      ? { fr: 'Chargement du journal…', en: 'Loading ledger…', ar: 'جارٍ تحميل السجل…' }
      : { fr: 'Chiffres indisponibles · actualiser le journal', en: 'Figures unavailable · refresh the ledger', ar: 'الأرقام غير متاحة · حدّث السجل' })[lang] || 'Journal indisponible';
  }
  function guardOperatorFigures(selector) {
    if (!operatorLedgerPending()) return false;
    document.querySelectorAll(selector).forEach(el => { el.textContent = ''; });
    return true;
  }

  function renderHero() {
    demoHeroSim = null;
    if (guardOperatorFigures('.hero-breakdown')) {
      const amount = document.querySelector('[data-hero-amount]');
      if (amount) { amount.textContent = '…'; amount.setAttribute('aria-label', operatorUnavailableText()); }
      const label = document.querySelector('[data-hero-label]');
      if (label) label.textContent = operatorUnavailableText();
      const greet = document.querySelector('.hero-left-today .greet');
      if (greet) greet.style.display = 'none';
      typeof homeSet === 'function' && homeSet('hero', { unavailable: operatorUnavailableText() });
      return;
    }
    const lang = getLang();
    const effective = effRange();
    let data = vData(heroDataByVenue, currentRange);
    if (!data) return;

    // Live-demo override on aujourdhui — hero amount + net come from the clock,
    // deltas remain comparative (vs hier / semaine / mois).
    if (isLiveDemo()) {
      const sim = getSim();
      if (sim) {
        demoHeroSim = sim;
        const previous = demoPreviousAt(sim);
        data = { ...data, amount: sim.cumRevenue, netAfterKiwi: Math.round(sim.cumRevenue * 0.839),
          deltaHier: previous > 0 ? (sim.cumRevenue - previous) / previous * 100 : null };
      }
    }
    // User-created venue — hero figures come from the merchant's real sales,
    // windowed to the active range so the number tracks the selected period.
    if (ownData() && window.KiwiSales) {
      const t = realSalesTotals();
      /* Les trois comparaisons du hero sortent des ventes réelles. Une période
       * de référence vide renvoie null, et le bloc entier disparaît au lieu
       * d'annoncer « 0 % » : le premier jour d'un commerçant n'a pas de veille,
       * et prétendre le contraire est la seule chose que ce chiffre ne doit
       * jamais faire. Les lignes reviennent d'elles-mêmes dès qu'il y a un
       * historique à comparer. */
      const rev = (s) => s.revenue;
      data = {
        ...data,
        amount: t.revenue,
        netAfterKiwi: Math.round(t.revenue * 0.839),
        deltaHier:    realDeltaPct(currentRange, rev),
        deltaSemaine: realDeltaPct(currentRange, rev, 7),
        deltaMois:    realDeltaPct(currentRange, rev, 28),
      };
    }

    const reference = ownData() && window.KiwiZReconciliation?.reference?.();
    if (reference) {
      data = { ...data, amount: reference.referenceCents / 100,
        deltaHier: null, deltaSemaine: null, deltaMois: null };
    }
    const labelEl = document.querySelector('[data-hero-label]');
    if (labelEl) labelEl.textContent = reference ? kitCase(reference.source === 'closed-z' ? 'RAPPORT Z DE LA CAISSE · ' : 'VENTES ENREGISTRÉES · ') + reference.day : kitCase(HERO_LABEL[lang]?.[currentRange] || HERO_LABEL.fr[currentRange]);

    // The live-session row ("LIVE · HH:MM · 24 heures · session continue
    // depuis 08h12") is a today-only concept — a ticking LIVE clock over a
    // 7-day or 30-day aggregate is misleading. Show it only on aujourd'hui.
    const greetEl = document.querySelector('.hero-left-today .greet');
    if (greetEl) greetEl.style.display = (effective === 'aujourdhui' && !/[?&]op=1(?:&|$)/.test(location.search)) ? '' : 'none';

    const amtEl = document.querySelector('[data-hero-amount]');
    if (amtEl) {
      amtEl.removeAttribute('aria-label');
      const fromVal = parseAmountFromEl(amtEl);
      // Resize font to fit the wider of from/to so the number never wraps mid-animation.
      fitHeroAmount(amtEl, Math.max(fromVal, data.amount));
      // Live-tick: shorter duration so the count keeps up with the 3s cadence
      const dur = liveTickInProgress ? 600 : 800;
      animateNumber(amtEl, fromVal, data.amount, { duration: dur, format: fmtHeroAmount });
    }

    const breakdown = document.querySelector('.hero-breakdown');
    if (breakdown) {
      const labels = deltaLabels(lang, currentRange);

      const existing = {};
      breakdown.querySelectorAll('[data-hero-delta]').forEach(el => {
        const k = el.dataset.heroDelta;
        const v = el.querySelector('[data-hero-delta-val]');
        if (v) existing[k] = parsePctFromEl(v);
      });
      const items = [];
      if (data.deltaHier    != null && labels && labels.hier)    items.push({ key: 'hier',    value: data.deltaHier,    label: labels.hier });
      if (data.deltaSemaine != null && labels && labels.semaine) items.push({ key: 'semaine', value: data.deltaSemaine, label: labels.semaine });
      if (data.deltaMois    != null && labels && labels.mois)    items.push({ key: 'mois',    value: data.deltaMois,    label: labels.mois });

      // "Net après Kiwi" removed by product decision — the dashboard is the
      // merchant's own takings; a "what's left after Kiwi's cut" line is an
      // unwanted reminder of the fee and adds no operational value.
      breakdown.innerHTML = items.map(it => `
        <div class="b" data-hero-delta="${it.key}">
          <div class="l">${it.label}</div>
          <div class="v" data-hero-delta-val></div>
        </div>
      `).join('');

      items.forEach(it => {
        const valEl = breakdown.querySelector(`[data-hero-delta="${it.key}"] [data-hero-delta-val]`);
        if (!valEl) return;
        const from = existing[it.key] ?? 0;
        animateNumber(valEl, from, it.value, {
          duration: isLiveDemo() ? 0 : 600,
          format: v => `${fmtPct(v)} <span class="d${v < 0 ? ' dn' : ''}">${arrowSvg(v >= 0)}</span>`,
        });
      });
    }
    if (typeof homeSet === 'function') {
      const dl = deltaLabels(lang, currentRange) || {};
      const deltas = [['hier', data.deltaHier], ['semaine', data.deltaSemaine], ['mois', data.deltaMois]]
        .filter(([k, v]) => v != null && dl[k]).map(([k, v]) => ({ key: k, value: v, text: fmtPct(v), label: dl[k] }));
      const amount = Number(data.amount) || 0;
      typeof homeSet === 'function' && homeSet('hero', { label: labelEl ? labelEl.textContent : '', amount, amountText: fmtHeroAmount(amount).replace(/<[^>]*>/g, '').replace(curUnit(), '').trim(), unit: curUnit(), deltas, reference: !!reference });
    }
  }

  /* ═══════════════ RENDER: HERO AI PANEL (per venue) ═══════════════ */

  function renderHeroAi() {
    /* Ask-bar placeholder follows the trade — a gym owner asks about their
     * salle, not their restaurant. Defaults mirror i18n.js so switching back
     * to a demo venue restores the stock copy without waiting for setLang. */
    const input = document.querySelector('[data-hai-input]');
    if (input) {
      const trade = window.KiwiVenue?.getVocab?.('askPlaceholder');
      const lang = getLang();
      input.placeholder = trade
        || (lang === 'en' ? 'Ask a question about your restaurant...'
          : lang === 'ar' ? 'اطرح سؤالاً حول مطعمك...'
          : 'Posez votre question sur votre restaurant...');
    }
    /* The three starter questions are hard-coded in dashboard.html for a
     * restaurant — a clothing shop was being invited to ask "Quel plat retirer
     * de ma carte ?". Swap them for the trade's own when the venue has one; a
     * demo venue keeps the captured originals so i18n still owns them. */
    const chipEls = document.querySelectorAll('.hai-chips .hai-chip');
    if (chipEls.length) {
      const chipTexts = window.KiwiVenue?.getVocab?.('aiChips');
      chipEls.forEach((btn, i) => {
        // Stash the captured original (and its i18n key) once, so switching back
        // to a demo venue restores the stock question instead of stranding the
        // trade copy. i18n owns the chip again the moment the key is back.
        if (btn.dataset.haiOrig == null) {
          btn.dataset.haiOrig = btn.textContent.trim();
          btn.dataset.haiKey = btn.getAttribute('data-i18n') || '';
        }
        const trade = Array.isArray(chipTexts) ? chipTexts[i] : null;
        if (trade) {
          btn.textContent = trade;
          btn.removeAttribute('data-i18n');   // sinon un changement de langue restaure la question restaurant
        } else {
          btn.textContent = btn.dataset.haiOrig;
          if (btn.dataset.haiKey) btn.setAttribute('data-i18n', btn.dataset.haiKey);
        }
      });
    }

    const rec = ownData() ? buildRealHeroRec() : window.KiwiVenue?.getHeroAiRec?.();
    const titleEl = document.querySelector('.hai-rec-title');
    const obsEl   = document.querySelector('.hai-rec-obs');
    const actEl   = document.querySelector('.hai-rec-act');
    const eyebrow = document.querySelector('.hai-eyebrow');
    /* `return` on a null rec used to leave whatever was in the markup sitting
     * there — which was a finished, hand-written recommendation. Getting no
     * answer has to look like no answer, not like the last one. */
    if (!rec) {
      const empty = { fr: 'Pas encore assez de ventes pour une recommandation.', en: 'Not enough sales yet for a recommendation.', ar: 'لا توجد مبيعات كافية بعد لتقديم توصية.' };
      if (titleEl) titleEl.textContent = '';
      if (obsEl)   obsEl.textContent = empty[getLang()] || empty.fr;
      if (actEl)   actEl.textContent = '';
      if (eyebrow) eyebrow.textContent = 'KIWI INSIGHTS';
      return;
    }
    if (titleEl) titleEl.textContent = rec.title;
    if (obsEl)   obsEl.textContent = rec.obs;
    if (actEl)   actEl.textContent = rec.act;
    /* Measured or estimated, said out loud on the card. A counted best-seller
     * and a constant-volume price projection are not the same kind of claim,
     * and the merchant is the one carrying the risk of the difference. */
    if (eyebrow) {
      eyebrow.textContent = rec.basisLabel ? `KIWI INSIGHTS · ${rec.basisLabel}` : 'KIWI INSIGHTS';
      eyebrow.removeAttribute('data-i18n');
    }
  }

  /* ═══════════════ RENDER: HEATMAP AI HINT (per venue) ═══════════════ */

  function renderHeatmapAi() {
    const rec = ownData() ? buildRealHeatmapRec() : window.KiwiVenue?.getHeatmapAiRec?.();
    const titleEl = document.querySelector('.hh-ai-title');
    const obsEl   = document.querySelector('.hh-ai-obs');
    const ctaEl   = document.querySelector('.hh-ai-cta');
    /* Same rule as renderHeroAi: no hint has to LOOK like no hint. Returning
     * early left the markup's own copy standing, and that copy used to be a
     * finished recommendation quoting a peer benchmark Kiwi cannot measure. */
    if (!rec) {
      const empty = { fr: 'Vos heures creuses apparaîtront ici dès vos premières ventes.', en: 'Your quiet hours will appear here once you record sales.', ar: 'ستظهر ساعاتك الهادئة هنا بمجرد تسجيل مبيعاتك.' };
      if (titleEl) titleEl.textContent = '';
      if (obsEl)   obsEl.textContent = empty[getLang()] || empty.fr;
      // An empty link has no name for a screen reader: hide it with its text.
      if (ctaEl)   { ctaEl.textContent = ''; ctaEl.hidden = true; ctaEl.style.display = 'none'; }
      return;
    }
    if (ctaEl)   { ctaEl.hidden = false; ctaEl.style.display = ''; }
    if (titleEl) titleEl.textContent = rec.title;
    if (obsEl)   obsEl.textContent = rec.obs;
    if (ctaEl)   ctaEl.textContent = rec.cta;
  }

  /* ═══════════════ RENDER: HERO GOAL BAR ═══════════════ */

  function renderGoal() {
    if (guardOperatorFigures('[data-goal-label], [data-goal-pct]')) {
      const fill = document.querySelector('[data-goal-fill]');
      if (fill) fill.style.width = '0%';
      typeof homeSet === 'function' && homeSet('goal', null);
      return;
    }
    const lang = getLang();
    const effective = effRange();
    let data = vData(goalByVenue, currentRange);
    if (!data) return;

    // Live-demo override: goal stays at venue's daily target (matches the
    // demo target), `current` ticks up from 0 → daily total each real hour.
    if (isLiveDemo()) {
      const sim = getSim();
      if (sim) data = { ...data, goal: sim.target.revenue, current: sim.cumRevenue };
    }
    // User-created venue — goal comes from the merchant's setting, progress
    // from their recorded sales.
    if (ownData() && window.KiwiSales) {
      const vd = window.KiwiVenue.getCurrentVenueData?.() || {};
      data = { ...data, goal: +vd.goal || 0, current: realSalesTotals(currentRange).revenue };
    }

    // Settings → "Objectif journalier" override for the default demo venue: the
    // merchant's daily target wins on the day ranges (week/month keep theirs).
    if (!(window.KiwiVenue && window.KiwiVenue.isCustom && window.KiwiVenue.isCustom())) {
      try {
        const ov = localStorage.getItem('kiwiSet:goal');
        if (ov && (currentRange === 'aujourdhui' || currentRange === 'hier')) {
          const n = +String(ov).replace(/[^\d]/g, '');
          if (n > 0) data = { ...data, goal: n };
        }
      } catch (_) {}
    }

    /* Objectif jamais saisi. Un commerçant qui n'a rien fixé lisait
     * « OBJECTIF JOUR · 0 MAD » puis « 0 % atteint » le jour où il avait fait
     * 2 254 MAD : la division par un objectif nul retombait sur 0, ce qui se
     * lit comme un échec au lieu d'une case vide. On dit ce qui est — aucun
     * objectif — et on ne calcule pas un pourcentage qui n'existe pas. Le
     * drapeau sur le libellé sert à la carte Vexel, qui recopie ce DOM. */
    /* Rien de saisi : on propose un objectif tiré des ventes du commerce
     * lui-même (voir suggestedGoal), marqué « suggéré ». Un commerce sans
     * historique garde « à définir » : on n'invente pas un chiffre. */
    let suggested = false;
    if (!(data.goal > 0) && ownData() && window.KiwiSales) {
      const g = suggestedGoal(currentRange);
      if (g > 0) { data = { ...data, goal: g }; suggested = true; }
    }
    const unset = !(data.goal > 0);
    const labelTxt = kitCase(GOAL_LABEL[lang]?.[currentRange] || GOAL_LABEL.fr[currentRange]);
    const labelEl = document.querySelector('[data-goal-label]');
    if (labelEl) {
      labelEl.textContent = unset
        ? `${labelTxt} · ${GOAL_UNSET[lang] || GOAL_UNSET.fr}`
        : `${labelTxt} · ${frInt(data.goal)} ${curUnit()}`;
      if (unset) labelEl.dataset.goalUnset = '1';
      else delete labelEl.dataset.goalUnset;
      if (suggested) labelEl.dataset.goalSuggested = '1';
      else delete labelEl.dataset.goalSuggested;
    }

    const ratio = unset ? 0 : data.current / data.goal;
    const pctRound = Math.round(ratio * 100);
    const widthPct = Math.min(100, ratio * 100);

    const pctEl = document.querySelector('[data-goal-pct]');
    if (pctEl) {
      if (unset) {
        pctEl.textContent = '·';
      } else {
        const from = parseInt((pctEl.textContent || '').replace(/\D/g, ''), 10) || 0;
        animateNumber(pctEl, from, pctRound, { duration: 700, format: v => `${Math.round(v)} %` });
      }
    }
    const fillEl = document.querySelector('[data-goal-fill]');
    if (fillEl) fillEl.style.width = `${widthPct.toFixed(1)}%`;
    typeof homeSet === 'function' && homeSet('goal', { range: currentRange, unset, label: labelEl ? labelEl.textContent : '', goal: unset ? 0 : data.goal, suggested, current: data.current, pct: unset ? null : pctRound, ratio });
    /* Un objectif réaliste pour un commerçant qui n'en a pas fixé.
     * Jour : la médiane des 28 derniers jours ouvrés AVEC ventes (un jour fermé ne
     * tire pas la cible vers zéro, un gros jour isolé ne la gonfle pas). Période
     * plus longue : la moyenne par jour calendaire sur ces 28 jours, fois le nombre
     * de jours de la période. Il faut au moins trois jours de ventes. Arrondi vers
     * le haut à un pas lisible. Mémorisé pour la journée : le tableau de bord se
     * redessine toutes les quelques secondes et le passé ne bouge pas. */
    function suggestedGoal(range) {
      const DAY = 86400000;
      let today;
      try { today = rangeBounds('aujourdhui')[0]; } catch (_) { return 0; }
      if (!(today > 0)) return 0;
      const suggestMemo = renderGoal.suggestMemo || { key: '', daily: 0, perDay: 0 };
      if (suggestMemo.key !== String(today) || !suggestMemo.daily) {
        const days = [];
        let total = 0;
        for (let k = 1; k <= 28; k++) {
          let rev = 0;
          try { rev = +realWindowStats(today - k * DAY, today - (k - 1) * DAY).revenue || 0; } catch (_) { rev = 0; }
          if (rev > 0) { days.push(rev); total += rev; }
        }
        days.sort((a, b) => a - b);
        const median = days.length ? (days.length % 2 ? days[(days.length - 1) / 2] : (days[days.length / 2 - 1] + days[days.length / 2]) / 2) : 0;
        Object.assign(suggestMemo, days.length >= 3 ? { key: String(today), daily: median, perDay: total / 28 } : { key: String(today), daily: 0, perDay: 0 });
        renderGoal.suggestMemo = suggestMemo;
      }
      if (!suggestMemo.daily) return 0;
      const n = RANGE_DAYS?.[range] || 1;
      const raw = n <= 1 ? suggestMemo.daily : suggestMemo.perDay * n;
      const step = raw < 500 ? 10 : raw < 2000 ? 50 : raw < 20000 ? 100 : raw < 200000 ? 1000 : 10000;
      return Math.ceil(raw / step) * step;
    }
  }

  /* ═══════════════ RENDER: HOURLY HEATMAP ═══════════════ */

  function intensityClass(v) {
    if (v < 0.2) return 'i0';
    if (v < 0.4) return 'i1';
    if (v < 0.6) return 'i2';
    if (v < 0.8) return 'i3';
    return 'i4';
  }
  function buildHeatmap(rng) {
    const v = getCurrentVenue();
    /* A real merchant's peak hours come from their OWN tickets: every sale
     * carries a `ts`, so bucket the active window by hour of day. Before the
     * first sale this still draws flat — the honest answer — but it no longer
     * STAYS flat once the till has rung, which is the one thing a merchant
     * opens this card to find out. Never borrows Café Atlas's shape. */
    if (ownData(v)) {
      const [from, to] = closedBounds(rng);
      const span = HH_HOURS.length;                          // 16 créneaux, la largeur de la carte
      /* ── La bande suit le commerce, elle ne lui est plus imposée ───────────
       * Les heures affichées étaient figées de 11 h à 02 h — les heures d'un
       * restaurant. Toute vente en dehors était JETÉE en silence
       * (`if (i >= HH_HOURS.length) return`). Une boulangerie qui ouvre à 6 h,
       * un café qui sert les petits-déjeuners à 8 h : leur matinée entière
       * disparaissait de la carte « Heures de pointe ». Et la carte ne restait
       * pas vide — elle affichait un pic à midi, c'est-à-dire le contraire de
       * la réponse. Un commerçant qui déplace du personnel là-dessus le déplace
       * à l'envers.
       *
       * On garde les seize créneaux (la carte est dessinée pour eux) mais on
       * choisit OÙ ils commencent : la fenêtre de seize heures qui capte le
       * plus de recette. À égalité, celle qui commence le plus près de la
       * première vente, pour ne pas ouvrir sur des créneaux vides. Un
       * restaurant retombe naturellement sur 11 h–02 h ; une boulangerie sur
       * 06 h–21 h. Aucun réglage à saisir, et rien n'est plus jeté tant que le
       * commerce tient dans seize heures d'affilée. */
      const byHour = new Array(24).fill(0);
      const covByHour = new Array(24).fill(0);
      realSalesList().forEach((e) => {
        const ts = +e.ts || 0;
        if (ts < from || ts >= to) return;
        const h = saleHour(ts);
        byHour[h] += Math.max(0, +e.amount || 0);
        covByHour[h] += 1;
      });
      let start = 11, bestSum = -1, bestLead = 99;
      for (let s = 0; s < 24; s++) {
        let sum = 0, lead = 0, counting = true;
        for (let k = 0; k < span; k++) {
          const val = byHour[(s + k) % 24];
          sum += val;
          if (counting) { if (val > 0) counting = false; else lead++; }
        }
        if (sum > bestSum || (sum === bestSum && lead < bestLead)) { bestSum = sum; bestLead = lead; start = s; }
      }
      if (bestSum <= 0) start = 11;                          // rien encore vendu : la bande d'origine
      const rev = [], cov = [], labels = [];
      for (let k = 0; k < span; k++) {
        const h = (start + k) % 24;
        rev.push(byHour[h]);
        cov.push(covByHour[h]);
        labels.push(String(h).padStart(2, '0') + 'h');
      }
      const max = Math.max(...rev);
      return labels.map((h, i) => ({
        hour: h, revenue: rev[i], covers: cov[i], unit: 'orders', intensity: max ? rev[i] / max : 0,
      }));
    }
    // Demo fixtures only carry base ranges; mapping is confined to that path.
    rng = ({ personnalise: 'aujourdhui', moisDernier: 'trenteJours', trimestre: 'trenteJours', annee: 'trenteJours' })[rng] || rng;
    const rev = HH_RAW_BY_VENUE[v]?.[rng] || HH_RAW_BY_VENUE.cafeAtlas[rng]
      || HH_RAW_BY_VENUE.cafeAtlas.trenteJours || HH_RAW_BY_VENUE.cafeAtlas.aujourdhui;
    const cov = HH_COVERS_BY_VENUE[v]?.[rng] || HH_COVERS_BY_VENUE.cafeAtlas[rng]
      || HH_COVERS_BY_VENUE.cafeAtlas.trenteJours || HH_COVERS_BY_VENUE.cafeAtlas.aujourdhui;
    const max = Math.max(...rev);
    return HH_HOURS.map((h, i) => ({
      hour: h, revenue: rev[i], covers: cov[i],
      intensity: max ? rev[i] / max : 0,
    }));
  }
  function renderHeatmap() {
    const lang = getLang();
    const data = buildHeatmap(ownData() ? currentRange : effRange());
    // Determine sim cursor for past/current/future state on aujourdhui
    let simIdx = -1;
    if (isLiveDemo()) {
      const sim = getSim();
      if (sim) simIdx = sim.simIdx;
    }
    const row = document.querySelector('[data-hh-row]');
    if (row) {
      /* Bars rise into place on real data changes; a 3s live tick rebuilds
       * silently (no replay while the demo clock runs). */
      row.classList.toggle('hh-anim', !liveTickInProgress);
      row.innerHTML = data.map((d, i) => {
        let stateCls = '';
        if (simIdx >= 0) {
          if (i < simIdx) stateCls = 'past';
          else if (i === simIdx) stateCls = 'now';
          else stateCls = 'future';
        }
        return `
        <div class="hh-col" style="--i:${i};">
          <div class="hh-cell ${intensityClass(d.intensity)}${stateCls ? ' ' + stateCls : ''}">
            <div class="hh-tooltip">
              <div class="hour">${d.hour}</div>
              <div class="met"><b>${frInt(d.revenue)} MAD</b></div>
              <div class="met">${d.covers} ${d.unit === 'orders' ? (ORDERS_LABEL[lang] || ORDERS_LABEL.fr)(d.covers) : (COVERS_LABEL[lang] || COVERS_LABEL.fr)}</div>
            </div>
          </div>
          <div class="hh-h">${d.hour}</div>
        </div>
      `;
      }).join('');
    }
    const subEl = document.querySelector('[data-hh-sub]');
    if (subEl) subEl.textContent = HH_SUB[lang]?.[currentRange] || HH_SUB.fr[currentRange];
  }

  /* ═══════════════ RENDER: KPI BAND ═══════════════ */

  const arrowSvg = up => `<i data-lucide="${up ? 'arrow-up' : 'arrow-down'}" style="width:11px;height:11px" aria-hidden="true"></i>`;

  function fmtKpiVal(spec, v) {
    /* A "/ 5320" denominator is data too: group it like the value beside it. */
    const unit = spec.unit ? `<span class="u">${String(spec.unit === 'MAD' ? curUnit() : spec.unit).replace(/\d{4,}/g, n => frInt(Number(n)))}</span>` : '';
    if (spec.text) return spec.text + unit;
    if (spec.fmt === 'pct2') return (window.KiwiNumber?.number(v, 2) || v.toFixed(2).replace('.', ',')) + unit;
    if (spec.fmt === 'pct1') return (window.KiwiNumber?.number(v, 1) || v.toFixed(1).replace('.', ',')) + unit;
    return (spec.unit === 'MAD' ? frMoney(v) : frInt(v)) + unit;
  }

  const KPI_MATERIAL_ICONS = {
    tx: 'credit-card', panier: 'shopping-bag', tips: 'hand-coins', marge: 'percent',
    success: 'check-circle-2', ratio: 'pie-chart', regulars: 'users',
    tauxRetour: 'rotate-ccw', revenue: 'banknote', profit: 'trending-up',
    cogs: 'package', retention: 'heart', newClients: 'user-plus',
    revPerDay: 'calendar', txPerDay: 'list', tempsTable: 'clock',
    occupation: 'bed', adr: 'tag', revpar: 'trending-up',
    arrdep: 'swap-vert', menage: 'sparkles', mixRev: 'pie-chart'
  };
  // One sparkline path per key. Colour stays atlas; deltas drive the up/down chip.
  const KPI_SPARKS = {
    tx:         'M0 18 L15 15 L30 16 L45 12 L60 10 L75 7 L90 11 L105 6 L120 4',
    panier:     'M0 11 L15 13 L30 10 L45 14 L60 11 L75 12 L90 10 L105 13 L120 11',
    tips:       'M0 18 L15 16 L30 14 L45 15 L60 10 L75 11 L90 7 L105 4 L120 2',
    marge:      'M0 13 L15 12 L30 13 L45 10 L60 11 L75 9 L90 8 L105 6 L120 5',
    success:    'M0 7 L15 6 L30 8 L45 5 L60 6 L75 4 L90 5 L105 3 L120 2',
    ratio:      'M0 14 L15 13 L30 12 L45 11 L60 10 L75 9 L90 7 L105 6 L120 5',
    regulars:   'M0 15 L15 14 L30 15 L45 13 L60 10 L75 11 L90 9 L105 8 L120 6',
    tauxRetour: 'M0 4 L15 6 L30 5 L45 8 L60 9 L75 11 L90 10 L105 13 L120 14',
    revenue:    'M0 17 L15 15 L30 13 L45 14 L60 10 L75 9 L90 6 L105 5 L120 3',
    profit:     'M0 18 L15 15 L30 14 L45 12 L60 11 L75 8 L90 7 L105 4 L120 2',
    cogs:       'M0 9 L15 10 L30 9 L45 11 L60 10 L75 12 L90 11 L105 12 L120 13',
    retention:  'M0 15 L15 14 L30 13 L45 13 L60 11 L75 10 L90 9 L105 7 L120 6',
    newClients: 'M0 16 L15 14 L30 15 L45 12 L60 13 L75 10 L90 9 L105 7 L120 5',
    revPerDay:  'M0 16 L15 14 L30 15 L45 12 L60 10 L75 11 L90 8 L105 6 L120 4',
    txPerDay:   'M0 15 L15 13 L30 14 L45 11 L60 12 L75 9 L90 10 L105 6 L120 4',
    tempsTable: 'M0 6 L15 8 L30 7 L45 9 L60 11 L75 10 L90 12 L105 14 L120 13',
    occupation: 'M0 14 L15 12 L30 13 L45 10 L60 9 L75 7 L90 8 L105 5 L120 4',
    adr:        'M0 12 L15 11 L30 12 L45 10 L60 11 L75 9 L90 8 L105 7 L120 6',
    revpar:     'M0 16 L15 14 L30 13 L45 12 L60 10 L75 8 L90 9 L105 6 L120 4',
    arrdep:     'M0 12 L15 9 L30 13 L45 8 L60 12 L75 7 L90 11 L105 6 L120 9',
    menage:     'M0 6 L15 9 L30 7 L45 11 L60 8 L75 12 L90 10 L105 13 L120 12',
    mixRev:     'M0 11 L15 11 L30 10 L45 11 L60 10 L75 10 L90 9 L105 10 L120 9',
  };

  /* ═══════════════ KPI CATALOG · personnalisation ═══════════════
   * The owner can pick any 6 of these for the band; the choice persists
   * per vertical in localStorage ('kiwiKpiLayout'). Each entry derives
   * its tile spec from the current range data, so every KPI works across
   * all date ranges without extra datasets. */
  const DEFAULT_MARGIN = { restaurant: 69, spa: 78, boutique: 54, fusion: 69 };
  const TIP_RATE = { restaurant: 0.072, spa: 0.055, boutique: 0, fusion: 0.06 };
  const RANGE_DAYS = { aujourdhui: 1, hier: 1, septJours: 7, trenteJours: 30, moisDernier: 30, trimestre: 90, annee: 365, personnalise: 1 };
  const r1 = (n) => Math.round(n * 10) / 10;
  /* Derived tiles combine the deltas of their inputs. A null input means "no
   * baseline to compare against" — and `null + null` is 0 in JS, which would
   * quietly resurrect the « 0 % » the null exists to suppress. So: any missing
   * component ⇒ the derived tile has no comparison either. With demo data
   * every component is a number, so this behaves exactly like the old r1(sum). */
  const withDelta = (parts, fn) => parts.some((p) => p == null) ? null : r1(fn(...parts));
  /* ── Le chiffre d'affaires ──────────────────────────────────────────────
   * Il se LIT quand on l'a, il ne se reconstitue qu'en dernier recours.
   *
   * Avant, il était toujours reconstitué : nombre de ventes × panier moyen. Or
   * le panier moyen affiché est ARRONDI à l'entier (Math.round, plus bas dans
   * le chemin réel) — 37 ventes pour 4 618 MAD donnent un panier de 124,81 qui
   * s'affiche 125, et le CA reconstitué sort à 4 625. Sept dirhams de trop, nés
   * d'un arrondi d'affichage. Sur trois cents ventes l'écart passe la centaine,
   * et il grandit avec le volume : c'est précisément le commerçant le plus
   * occupé qui voit son tableau de bord s'éloigner le plus de sa caisse.
   *
   * Le total exact existait déjà — realSalesTotals() l'additionne vente par
   * vente et il n'était utilisé nulle part ici. Bénéfice brut, coût matière,
   * pourboires et CA par jour en dérivent tous, donc les cinq tuiles se
   * décalaient ensemble et de façon cohérente : impossible à repérer à l'œil,
   * et faux à chaque fois qu'on rapproche du rouleau de caisse.
   *
   * La démo n'a pas de clé `revenue` : elle continue de passer par le produit,
   * comme avant, avec des paniers déjà entiers — donc rien n'y change. */
  const revOf = (d) => {
    if (d.revenue && d.revenue.value != null) return d.revenue.value;
    return (d.tx && d.panier) ? d.tx.value * d.panier.value : null;
  };
  /* DEFAULT_MARGIN est une marge TYPE DE MÉTIER, bonne pour habiller la démo et
   * rien d'autre. Sur les chiffres d'un vrai commerçant elle n'a aucun droit :
   * appliquée là, elle transformait « je ne connais pas vos coûts » en « votre
   * marge est de 69 % », tous les jours, à l'identique, sur les trois tuiles à
   * la fois. Chez un vrai commerçant, pas de coût saisi ⇒ pas de marge affichée. */
  const margeOf = (d, ctx) => {
    if (d.marge) return d.marge.value;
    if (ownData()) return null;
    return DEFAULT_MARGIN[ctx.venueType] ?? null;
  };
  /* La VARIATION du chiffre d'affaires, même discipline que sa valeur : réelle
   * quand la période la connaît, sinon l'approximation d'origine (la somme des
   * variations du nombre de ventes et du panier moyen). Tout ce qui dérive du
   * CA la reprend, pour que CA, CA/jour, bénéfice, coût matière et pourboires
   * ne puissent pas afficher cinq comparaisons différentes de la même chose. */
  const revDelta = (d) => (d.revenue && d.revenue.delta != null)
    ? d.revenue.delta
    : withDelta([d.tx && d.tx.delta, d.panier && d.panier.delta], (a, b) => a + b);

  /* Une marge mesurée sur une partie des ventes seulement (des articles sans
   * prix d'achat) est étendue au reste : la tuile le dit, avec la part
   * réellement chiffrée, plutôt que de passer une estimation pour un compte. */
  const costedNote = (d) => {
    const p = d.marge && d.marge.costedPct;
    if (p == null || p >= 99.5) return '';
    const n = Math.round(p), lang = getLang();
    if (lang === 'en') return `Estimate · cost known on ${n} % of sales`;
    if (lang === 'ar') return `تقدير · التكلفة معروفة لـ ${n} % من المبيعات`;
    return `Estimation · coût connu sur ${n} % des ventes`;
  };
  const KPI_CATALOG = {
    tx:         { labels: { default: 'Commandes', spa: 'Rendez-vous' }, i18n: 'dash.kpi.tx',
                  desc: 'Nombre de ventes sur la période', derive: (d) => d.tx || null },
    panier:     { labels: { default: 'Panier moyen' }, i18n: 'dash.kpi.basket',
                  desc: 'Montant moyen dépensé par vente', derive: (d) => d.panier || null },
    revenue:    { labels: { default: 'Ventes nettes', en: 'Net sales', ar: 'صافي المبيعات' }, i18n: '',
                  desc: 'Ventes enregistrées moins remboursements; le paiement est ventilé séparément', derive: (d) => { const r = revOf(d); return r == null ? null : { value: r, unit: 'MAD', fmt: 'int', delta: revDelta(d) }; } },
    collected:  { labels: { default: 'Encaissé', en: 'Collected', ar: 'المقبوض' }, i18n: '',
                  desc: 'Paiements identifiés comme encaissés, après remboursements', derive: (d) => d.collected ? { value: d.collected.value, unit: 'MAD', fmt: 'int', delta: d.collected.delta } : null },
    receivable: { labels: { default: 'Créances', en: 'Receivable', ar: 'المستحق' }, i18n: '',
                  desc: 'Ventes à crédit ou livraison non encore encaissées', derive: (d) => d.receivable ? { value: d.receivable.value, unit: 'MAD', fmt: 'int', delta: d.receivable.delta } : null },
    revPerDay:  { labels: { default: 'CA par jour' }, i18n: 'dash.kpi.revPerDay',
                  desc: 'Chiffre d’affaires moyen par jour d’ouverture', derive: (d, ctx) => { const r = revOf(d); return r == null ? null : { value: r / ctx.nbDays, unit: 'MAD', fmt: 'int', delta: revDelta(d) }; } },
    marge:      { labels: { default: 'Marge brute' }, i18n: 'dash.kpi.margin',
                  desc: 'Part du CA conservée après coût matière', derive: (d) => d.marge || null },
    profit:     { labels: { default: 'Bénéfice brut' }, i18n: 'dash.kpi.grossProfit',
                  desc: 'Chiffre d’affaires moins le coût matière', derive: (d, ctx) => { const r = revOf(d), m = margeOf(d, ctx); return (r == null || m == null) ? null : { value: r * m / 100, unit: 'MAD', fmt: 'int', delta: withDelta([revDelta(d), d.marge ? d.marge.delta : 0], (a, b) => a + b), note: costedNote(d) }; } },
    cogs:       { labels: { default: 'Coût matière' }, i18n: 'dash.kpi.cogs',
                  desc: 'Dépense en matières premières', derive: (d, ctx) => { const r = revOf(d), m = margeOf(d, ctx); return (r == null || m == null) ? null : { value: r * (1 - m / 100), unit: 'MAD', fmt: 'int', delta: withDelta([revDelta(d), d.marge ? d.marge.delta : 0], (a, b) => a - b) }; } },
    /* Chez un vrai commerçant, les pourboires sont ceux que la caisse a
       DÉCLARÉS à la clôture des journées de la période (KiwiDayReport, synchro
       store_docs « dayreports »). Ils valaient jusqu'ici CA × 7,2 % : un
       montant inventé, affiché sous « Pourboires » sans qu'un seul dirham de
       pourboire ait été saisi. Aucune journée close sur la période : « · »,
       et la bande par défaut le remplace par un indicateur qui a une valeur.
       La démo garde son estimation : tout y est illustratif. */
    tips:       { labels: { default: 'Pourboires' }, i18n: 'dash.kpi.tips',
                  desc: 'Pourboires déclarés à la clôture, ou saisis à l’encaissement pour une journée ouverte', derive: (d, ctx) => {
                    if (ownData()) {
                      const real = realClosedTips(ctx.range);
                      if (!real) return null;
                      /* Plage à cheval sur l'historique ancien : tant que le résumé n'est pas là, la tuile
                         montre ce que la caisse et les Z connaissent, et le dit (note), plutôt que rien. */
                      if (real.partial) return real.days
                        ? { value: real.sum, unit: 'MAD', fmt: 'int', delta: null, note: 'Partiel · historique ancien en chargement', noteKey: 'dash.kpi.tipsPartial' }
                        : { text: '…', value: 0, unit: '', delta: null };
                      return real.days ? { value: real.sum, unit: 'MAD', fmt: 'int', delta: null } : { text: '·', value: 0, unit: '', fmt: 'int', delta: null };
                    }
                    const r = revOf(d), rate = TIP_RATE[ctx.venueType] || 0;
                    return (r == null || !rate) ? null : { value: r * rate, unit: 'MAD', fmt: 'int', delta: revDelta(d) };
                  } },
    success:    { labels: { default: 'Taux succès', spa: 'Taux remplissage' }, i18n: 'dash.kpi.success',
                  desc: 'Paiements aboutis · créneaux remplis', derive: (d) => d.success || null },
    ratio:      { labels: { default: 'Ratio card / cash' }, i18n: 'dash.kpi.ratio',
                  desc: 'Répartition carte vs espèces', derive: (d) => d.ratio || null },
    regulars:   { labels: { default: 'Clients réguliers', boutique: 'Clients fidèles', spa: 'Clients fidèles' }, i18n: 'dash.kpi.regular',
                  desc: 'Clients déjà venus sur la période', derive: (d) => d.regulars || null },
    retention:  { labels: { default: 'Taux de fidélité' }, i18n: 'dash.kpi.retention',
                  desc: 'Part de clients réguliers parmi les clients venus', derive: (d) => {
                    /* Vrai commerçant : la part des clients identifiés venus sur la
                       période qui étaient déjà venus avant (carnet clients). */
                    if (d.clientMix) return { value: d.clientMix.regulars / d.clientMix.visitors * 100, unit: '%', fmt: 'pct1', delta: d.clientMix.deltaRate };
                    if (!d.tx || !d.regulars) return null; if (d.regulars.text === '·') return { text: '·', value: 0, unit: '', fmt: 'pct1', delta: null }; const pct = d.tx.value ? d.regulars.value / d.tx.value * 100 : 0; return { value: pct, unit: '%', fmt: 'pct1', delta: withDelta([d.regulars.delta, d.tx.delta], (a, b) => a - b) }; } },
    newClients: { labels: { default: 'Nouveaux clients' }, i18n: 'dash.kpi.newClients',
                  desc: 'Premières visites sur la période', derive: (d) => {
                    /* Vrai commerçant : les clients identifiés dont la première
                       visite tombe dans la période (carnet clients). */
                    if (d.clientMix) return { value: d.clientMix.newcomers, unit: '', fmt: 'int', delta: d.clientMix.deltaNew };
                    if (!d.tx || !d.regulars) return null; if (d.regulars.text === '·') return { text: '·', value: 0, unit: '', fmt: 'int', delta: null }; return { value: Math.max(0, d.tx.value - d.regulars.value), unit: '', fmt: 'int', delta: withDelta([d.tx.delta, d.regulars.delta], (a, b) => a - b * 0.3) }; } },
    txPerDay:   { labels: { default: 'Ventes par jour', spa: 'RDV par jour' }, i18n: 'dash.kpi.txPerDay',
                  desc: 'Nombre de ventes moyen par jour d’ouverture', derive: (d, ctx) => d.tx ? { value: d.tx.value / ctx.nbDays, unit: '', fmt: 'int', delta: d.tx.delta } : null },
    occupation: { labels: { default: "Taux d'occupation" }, i18n: 'dash.kpi.occupancy',
                  desc: 'Chambres occupées vs chambres disponibles', derive: (d) => d.occupation || null },
    adr:        { labels: { default: 'ADR · prix moyen / nuit' }, i18n: 'dash.kpi.adr',
                  desc: 'Prix moyen par nuit vendue (Average Daily Rate)', derive: (d) => d.adr || null },
    revpar:     { labels: { default: 'RevPAR' }, i18n: 'dash.kpi.revpar',
                  desc: 'Revenu par chambre disponible · ADR × occupation', derive: (d) => d.revpar || null },
    arrdep:     { labels: { default: 'Arrivées / départs' }, i18n: 'dash.kpi.arrdep',
                  desc: 'Mouvements à la réception sur la période', derive: (d) => d.arrdep || null },
    menage:     { labels: { default: 'Chambres à nettoyer' }, i18n: 'dash.kpi.toClean',
                  desc: 'File ménage · chambres à remettre à blanc', derive: (d) => d.menage || null },
    mixRev:     { labels: { default: 'Mix revenu · ch · resto · spa' }, i18n: 'dash.kpi.revMix',
                  desc: 'Répartition du revenu : chambres / restaurant / hammam', derive: (d) => d.mixRev || null },
    tauxRetour: { labels: { default: 'Taux retour' }, i18n: 'dash.kpi.returnRate',
                  desc: 'Part des ventes remboursée', derive: (d) => d.tauxRetour || null },
    tempsTable: { labels: { default: 'Temps moyen à table', spa: 'Temps moyen en cabine', 'en:spa': 'Average time in treatment room', 'ar:spa': 'متوسط المدة في غرفة العلاج' }, i18n: 'dash.kpi.tableTime',
                  desc: 'Durée moyenne d\'une table, de l\'installation au départ', derive: (d) => d.tempsTable || null },
  };

  function loadKpiLayouts() {
    try { return JSON.parse(localStorage.getItem('kiwiKpiLayout')) || {}; }
    catch (_) { return {}; }
  }
  /* KPI band always shows 6 tiles. Owners can swap any of them via the
   * Personnaliser drawer (e.g. include "Temps moyen à table" instead of
   * one of the defaults). The cap is uniform across all venue types. */
  const KPI_MAX = 6;
  function getKpiLayout(venueType) {
    const L = loadKpiLayouts()[venueType];
    return (Array.isArray(L) && L.length === KPI_MAX && L.every((k) => KPI_CATALOG[k])) ? L : null;
  }
  function saveKpiLayout(venueType, keys) {
    const all = loadKpiLayouts(); all[venueType] = keys;
    try { localStorage.setItem('kiwiKpiLayout', JSON.stringify(all)); } catch (_) {}
  }
  function resetKpiLayout(venueType) {
    const all = loadKpiLayouts(); delete all[venueType];
    try { localStorage.setItem('kiwiKpiLayout', JSON.stringify(all)); } catch (_) {}
  }
  function defaultKpiKeys(venueType) {
    return (window.KiwiVenue?.getKpiSpec?.(venueType) || []).map((s) => s.key);
  }
  function kpiLabel(key, venueType, lang) {
    const c = KPI_CATALOG[key]; if (!c) return key;
    const T = window.KiwiI18n?.T?.[lang] || {};
    return c.labels[lang + ':' + venueType] || T[c.i18n] || c.labels[lang] || c.labels[venueType] || c.labels.default;
  }

  /* ═══════════════ HÔTEL · performance réelle de la bande ═══════════════
   * La bande d'un vrai hôtel affichait « Occupation 0,0 % · ADR 0 MAD · RevPAR
   * 0 MAD · 0 / 0 » codés en dur : deux chambres vendues sur huit se lisaient
   * « 0 % », et un zéro écrit à la main se lit comme une mesure. Les chiffres
   * viennent maintenant de /api/hotel/performance (registre `hotel_reservations`
   * + inventaire du document `rooms`), la même source que la Production mensuelle.
   * Ce qui ne peut pas être calculé honnêtement s'affiche « · », jamais 0. */
  const HOTEL_PERF_TTL = 30000;
  const hotelPerf = new Map();
  function hotelMerchant() {
    try {
      const id = window.KiwiVenue?.getVenue?.();
      return String(window.KiwiStore?.slugFor?.(id) || window.KiwiVenue?.getCurrentVenueData?.()?.slug || window.KiwiMe?.merchant || '').trim();
    } catch (_) { return ''; }
  }
  /* Les nuits d'une plage : la journée d'activité du commerçant, pas minuit de
   * l'appareil. À 02 h, « Aujourd'hui » est encore la nuit d'hier. */
  function hotelRangeNights(range) {
    const [from, to] = closedBounds(range);
    const slug = activeMerchantSlug();
    return { from: merchantDayKey(from + 1, slug), to: merchantDayKey(to - 1, slug) };
  }
  function hotelPreviousNights(w) {
    const span = Math.max(1, Math.round((Date.parse(w.to + 'T00:00:00Z') - Date.parse(w.from + 'T00:00:00Z')) / 864e5) + 1);
    return { from: addMerchantDays(w.from, -span), to: addMerchantDays(w.from, -1) };
  }
  /* Lit (et au besoin recharge) la performance d'une plage. Rend toujours une
   * entrée : { data } quand on sait, { error } quand le serveur ne sait pas,
   * ni l'un ni l'autre tant que la première réponse n'est pas arrivée. */
  function hotelPerfEntry(w) {
    const merchant = hotelMerchant();
    const key = merchant + '|' + w.from + '|' + w.to;
    let e = hotelPerf.get(key);
    if (!e) { e = { data: null, error: '', ts: 0, loading: false }; hotelPerf.set(key, e); }
    if (merchant && !e.loading && Date.now() - e.ts > HOTEL_PERF_TTL) {
      e.loading = true;
      fetch('/api/hotel/performance?' + new URLSearchParams({ merchant, from: w.from, to: w.to }), { cache: 'no-store', credentials: 'same-origin' })
        .then((r) => r.json().then((b) => ({ ok: r.ok, b })))
        .then(({ ok, b }) => {
          const next = ok && b && b.ok ? b : null;
          const before = JSON.stringify([e.data, e.error]);
          e.data = next; e.error = next ? '' : String((b && b.error) || 'unavailable');
          e.changed = before !== JSON.stringify([e.data, e.error]);
        })
        .catch(() => { if (!e.data) { e.error = 'unavailable'; e.changed = true; } })
        .finally(() => {
          e.loading = false; e.ts = Date.now();
          /* Repeindre seulement si quelque chose a bougé : le rafraîchissement
           * périodique ne doit pas rejouer l'animation des tuiles pour rien. */
          if (e.changed) { e.changed = false; try { renderKpiBand(); } catch (_) {} }
        });
    }
    return e;
  }
  const hotelDelta = (cur, prev) => (cur != null && prev != null && prev > 0 ? Math.round(((cur - prev) / prev) * 1000) / 10 : null);
  /* Pure : les six tuiles hôtel à partir de deux lectures (période, période
   * précédente de même durée) et de l'état du ménage. Une valeur inconnue est
   * « · » ; une lecture pas encore arrivée est « … » pour que la bande ne
   * clignote pas entre trois et six tuiles. */
  function hotelTilesFrom(cur, prev, clean) {
    const dash = { text: '·', unit: '', delta: null };
    const wait = { text: '…', unit: '', delta: null };
    const pd = prev && prev.data;
    let out;
    if (cur && cur.data) {
      const d = cur.data;
      const num = (v, unit, fmt, prevV) => (v == null ? { ...dash } : { value: v, unit, fmt, delta: hotelDelta(v, prevV) });
      out = {
        occupation: num(d.occupancyPct, '%', 'pct1', pd && pd.occupancyPct),
        adr: num(d.adr, 'MAD', 'int', pd && pd.adr),
        revpar: num(d.revpar, 'MAD', 'int', pd && pd.revpar),
        /* Mouvements de la période : une arrivée attendue compte. Aucun
         * dossier = « 0 / 0 » est ici une mesure (il n'y a pas de mouvement). */
        arrdep: { text: `${d.arrivals} / ${d.departures}`, unit: '', delta: null },
      };
    } else {
      const blank = cur && cur.error ? dash : wait;
      out = { occupation: { ...blank }, adr: { ...blank }, revpar: { ...blank }, arrdep: { ...blank } };
    }
    out.menage = clean && clean.total > 0
      ? { value: clean.toClean, unit: `/ ${clean.total}`, fmt: 'int', delta: null }
      : { ...(clean && clean.loading ? wait : dash) };
    /* « Mix revenu · ch · resto · spa » : aucune source n'attribue encore le
     * revenu par point de vente. */
    out.mixRev = { ...dash };
    return out;
  }
  function hotelBandTiles(range) {
    const w = hotelRangeNights(range);
    const cur = hotelPerfEntry(w);
    const prev = hotelPerfEntry(hotelPreviousNights(w));
    let clean = null;
    try { clean = window.KiwiHotelRooms?.housekeeping?.() || null; } catch (_) {}
    return hotelTilesFrom(cur, prev, clean);
  }
  /* Une réservation prise (réception, page publique, canal) ou un séjour qui
   * bouge doit atteindre la bande sans recharger la page. */
  function hotelPerfInvalidate() {
    hotelPerf.forEach((e) => { e.ts = 0; });
    if (window.KiwiVenue?.getVenueType?.() === 'hotel') { try { renderKpiBand(); } catch (_) {} }
  }
  window.addEventListener('kiwi-hotel-stays-changed', hotelPerfInvalidate);
  window.addEventListener('kiwi-hotel-stays-loaded', () => {
    if (window.KiwiVenue?.getVenueType?.() === 'hotel') { try { renderKpiBand(); } catch (_) {} }
  });
  /* Un hôtel ouvert toute la journée au comptoir : la bande se relit toute seule.
   * Les harnais qui chargent ce fichier sans minuteur (vm nu) ne la reçoivent pas. */
  if (typeof setInterval === 'function') setInterval(() => {
    if (document.visibilityState === 'hidden') return;
    if (window.KiwiVenue?.getVenueType?.() !== 'hotel' || !document.querySelector('[data-kpi-band]')) return;
    hotelPerf.forEach((e) => { e.ts = Math.min(e.ts, Date.now() - HOTEL_PERF_TTL - 1); });
    try { hotelBandTiles(currentRange); } catch (_) {}
  }, HOTEL_PERF_TTL);

  /* « Temps moyen à table » d'un vrai restaurant : la durée des visites de
   * table fermées sur la période (/api/table-time, qui ne retient que les
   * vrais départs : addition réglée, table libérée par un serveur). Même
   * mécanique que l'hôtel : une entrée par fenêtre, relue toutes les cinq
   * minutes au plus, la bande repeinte seulement quand la réponse change. */
  const TABLE_TIME_TTL = 5 * 60 * 1000;
  const tableTime = new Map();
  function tableTimeEntry(from, to) {
    const merchant = hotelMerchant();
    const key = merchant + '|' + from + '|' + to;
    let e = tableTime.get(key);
    if (!e) { e = { data: null, error: '', ts: 0, loading: false }; tableTime.set(key, e); }
    if (merchant && !e.loading && Date.now() - e.ts > TABLE_TIME_TTL) {
      e.loading = true;
      fetch('/api/table-time?' + new URLSearchParams({ merchant, from: String(from), to: String(to) }), { cache: 'no-store', credentials: 'same-origin' })
        .then((r) => r.json().then((b) => ({ ok: r.ok, b })))
        .then(({ ok, b }) => {
          const next = ok && b && b.ok ? { visits: +b.visits || 0, avgMin: b.avgMin == null ? null : +b.avgMin } : null;
          const before = JSON.stringify([e.data, e.error]);
          e.data = next; e.error = next ? '' : String((b && b.error) || 'unavailable');
          e.changed = before !== JSON.stringify([e.data, e.error]);
        })
        .catch(() => { if (!e.data) { e.error = 'unavailable'; e.changed = true; } })
        .finally(() => {
          e.loading = false; e.ts = Date.now();
          if (e.changed) { e.changed = false; try { renderKpiBand(); } catch (_) {} }
        });
    }
    return e;
  }
  /* Pure : la tuile à partir de la période et de la précédente. Pas encore
   * de réponse : « … ». Pas de source, ou moins de cinq visites : « · ». */
  function tableTimeTileFrom(cur, prev) {
    if (!cur || (!cur.data && !cur.error)) return { text: '…', unit: '', delta: null };
    const d = cur.data;
    if (!d || d.avgMin == null) return { text: '·', unit: '', delta: null };
    const p = prev && prev.data && prev.data.avgMin;
    /* text: null efface le « · » posé plus haut sur le clone remis à zéro. */
    return { text: null, value: d.avgMin, unit: 'min', fmt: 'int', delta: p > 0 ? Math.round(((d.avgMin - p) / p) * 1000) / 10 : null };
  }
  function tableTimeTile(range) {
    const [from, open] = rangeBounds(range);
    /* Une période encore ouverte (aujourd'hui, 7 derniers jours) s'arrête à
     * la fin de la journée commerciale : une clé stable, pas Date.now(). */
    const to = open === Infinity ? merchantDayBounds(merchantDayKey(Date.now(), activeMerchantSlug()), activeMerchantSlug()).to : open;
    const span = Math.max(1, to - from);
    return tableTimeTileFrom(tableTimeEntry(from, to), tableTimeEntry(from - span, from));
  }

  let lastBand = null;
  function renderKpiBand() {
    if (guardOperatorFigures('[data-kpi-band]')) {
      const wrap = document.querySelector('[data-kpi-band]');
      if (wrap) wrap.textContent = operatorUnavailableText();
      typeof homeSet === 'function' && homeSet('tiles', null);
      return;
    }
    const lang = getLang();
    let data = vData(kpiByVenue, currentRange);
    if (!data) return;
    const suffix = KPI_DELTA_SUFFIX[lang]?.[currentRange] || KPI_DELTA_SUFFIX.fr[currentRange];

    const wrap = document.querySelector('[data-kpi-band]');
    if (!wrap) return;
    // A signed-in merchant on a fresh browser has a transient `own` venue
    // until /api/me resolves. No restaurant KPIs may flash for a hotel/shop.
    const activeVenue = window.KiwiVenue?.getCurrentVenueData?.();
    if (activeVenue?.id === 'own' && !activeVenue.type) {
      wrap.replaceChildren();
      return;
    }

    // Live-demo override: tx/panier/regulars all scale with sim time.
    // The ratio is already projected from ledger tenders above.
    if (isLiveDemo()) {
      const sim = getSim();
      if (sim && !(sim.cumTx > 0) && effRange() === 'aujourdhui') {
        /* Before the demo's first sale of the day (05:00 cut to about 07:00)
         * there is no basket, no margin and no rate to show, and nothing to
         * compare with a full yesterday. It said « Marge brute 71,4 % » and
         * « Taux succès 99,34 % » on zero orders; it now says « · », exactly
         * what a real merchant's band says when there is nothing to measure. */
        const dash = { text: '·', unit: '', delta: null };
        const quiet = (tile) => (tile ? { ...tile, ...dash } : tile);
        data = {
          ...data,
          tx:         data.tx       ? { ...data.tx, value: 0, delta: null } : data.tx,
          panier:     quiet(data.panier),
          regulars:   quiet(data.regulars),
          marge:      quiet(data.marge),
          profit:     quiet(data.profit),
          cogs:       quiet(data.cogs),
          success:    quiet(data.success),
          tauxRetour: quiet(data.tauxRetour),
        };
      } else if (sim) {
        data = {
          ...data,
          tx:         data.tx       ? { ...data.tx,       value: sim.cumTx } : data.tx,
          panier:     data.panier   ? { ...data.panier,   value: sim.panierMoyen || data.panier.value } : data.panier,
          regulars:   data.regulars ? { ...data.regulars, value: sim.cumRegulars, unit: `/ ${Math.max(1, sim.cumTx)}` } : data.regulars,
          // success / tauxRetour stay at their static daily values
        };
      }
    }
    // User-created venue — tx / panier (and the revenue derived from them)
    // come from the merchant's recorded sales.
    if (ownData() && window.KiwiSales) {
      const t = realSalesTotals();
      const rng = currentRange;
      const [wFrom, wTo] = closedBounds(rng);
      const w = realWindowStats(wFrom, wTo);
      const mix = realClientMix(wFrom, wTo);
      /* Le ratio se lit « card / cash ». Les deux parts sortent des ventes
       * encaissées — la même source que l'anneau Mix de paiement juste à côté,
       * pour que deux cartes affichant la même donnée ne puissent plus se
       * contredire. La part espèces est le complément à 100, donc l'addition
       * tombe toujours juste. Sans encaissement : le tiret, il n'y a rien à
       * répartir. */
      const tender = w.card + w.cash;
      const cardPct = tender ? Math.round((w.card / tender) * 100) : 0;
      /* Pressing : « Dépôts » et « Bon moyen » comptent les BONS déposés, pas les
       * encaissements. Le journal des ventes enregistre un bon quand il est payé
       * (au retrait pour un « payer au retrait », deux fois pour un acompte puis
       * son solde) : trois bons déposés (226, 64, 90 MAD) s'affichaient
       * « 2 dépôts · bon moyen 57 MAD ». Les bons viennent du document
       * pressing-orders, par date de dépôt, annulés exclus. Tant que ce document
       * n'est pas arrivé, on garde le journal plutôt qu'un zéro faux. */
      const pressingStats = (() => {
        const ops = window.KiwiPressingOps;
        if (!ops?.dropoffStats || (activeVenue?.subtype || activeVenue?.trade) !== 'pressing') return null;
        try { if (!ops.read().length) return null; } catch (_) { return null; }
        return (from, to) => ops.dropoffStats(from, to);
      })();
      const txNow = pressingStats ? pressingStats(wFrom, wTo) : null;
      /* Un retour réglé en AVOIR n'est pas de l'argent sorti : il n'entre pas
       * au journal des remboursements, et « Taux retour » restait à 0,0 % un
       * jour de retours. Les avoirs émis viennent du registre que lit la page
       * « Retours & échanges » (/api/sale/refund, returns-ledger.js), relu au
       * plus une fois par minute ; la bande se repeint s'ils ont changé. */
      const creditStats = (f, to) => {
        let credited = NaN;
        try {
          const d = JSON.parse(localStorage.getItem('kiwi:returnsLedger') || 'null');
          const covered = d && Object.hasOwn(d, 'window') && (d.window === null || (d.window[0] <= f && (d.window[1] == null ? Infinity : d.window[1]) >= to));
          if (covered && d.v === __state.activeMerchantSlug() && Array.isArray(d.list)) { credited = 0; d.list.forEach((r) => { if (r.ts >= f && r.ts < to) credited += Math.round((Number(r.amount) || 0) * 100); }); credited /= 100; }
          else import('../returns-ledger.js').then(m => m.warmCreditReturns([f, to])).then(changed => { if (changed) __state.renderKpiBand(); }, () => {});
        } catch (_) {}
        return { ...realWindowStats(f, to), credited };
      };
      if (data.tauxRetour) import('../returns-ledger.js').then((m) => m.warmCreditReturns([wFrom, wTo])).then((changed) => { if (changed) __state.renderKpiBand(); }, () => {});
      const returned = w.refunds + creditStats(wFrom, wTo).credited;
      data = {
        ...data,
        tx:     { ...(data.tx || {}),     value: txNow ? txNow.count : t.count,
                  delta: txNow ? realDeltaPct(rng, (s) => s.count, undefined, pressingStats) : realDeltaPct(rng, (s) => s.count) },
        /* Au centime, comme le rouleau de la caisse : 424,50 / 5 tickets se lit
                  84,90, pas 85 (la tuile l'écrit par KiwiNumber.amount). */
        panier: { ...(data.panier || {}), value: basketCents(txNow || t) / 100,
                  delta: txNow ? realDeltaPct(rng, (s) => s.basket, undefined, pressingStats) : realDeltaPct(rng, (s) => s.basket) },
        /* Le CA EXACT, additionné vente par vente. Il n'était pas transmis, si
         * bien que revOf() le reconstituait à partir du panier arrondi
         * ci-dessus et que le tableau de bord ne tombait jamais juste face au
         * rouleau de caisse (voir revOf). */
        revenue: { value: t.revenue, unit: 'MAD', fmt: 'int', delta: realDeltaPct(rng, (s) => s.revenue) },
        collected: { value: t.collected, unit: 'MAD', fmt: 'int', delta: realDeltaPct(rng, (s) => s.collected) },
        receivable: { value: t.receivable, unit: 'MAD', fmt: 'int', delta: realDeltaPct(rng, (s) => s.receivable) },
        ratio:    data.ratio    ? { ...data.ratio,    text: tender ? `${cardPct} / ${100 - cardPct}` : '·', unit: tender ? '%' : '', delta: realDeltaPct(rng, (s) => (s.card + s.cash ? (s.card / (s.card + s.cash)) * 100 : 0)) } : data.ratio,
        /* « Réguliers », « Fidélité » et « Nouveaux clients » se lisent au
         * carnet clients (realClientMix) : les clients identifiés à la caisse
         * qui sont venus sur la période, déjà vus avant ou non. Ils valaient
         * « · » faute de source ; avant ça, un 0 faisait dire à « Nouveaux
         * clients » que TOUTES les ventes étaient des premières visites. Sans
         * client identifié sur la période, le tiret reste, et la bande remplace
         * les tuiles mortes. Le dénominateur est le nombre de clients venus,
         * jamais le nombre de ventes : un client et un ticket ne se divisent
         * pas l'un par l'autre. */
        clientMix: mix.visitors ? { ...mix,
          deltaNew: realDeltaPct(rng, (s) => s.newcomers, undefined, realClientMix),
          deltaRate: realDeltaPct(rng, (s) => (s.visitors ? (s.regulars / s.visitors) * 100 : 0), undefined, realClientMix) } : null,
        regulars: data.regulars ? (mix.visitors
          ? { ...data.regulars, text: undefined, value: mix.regulars, unit: `/ ${mix.visitors}`, fmt: 'int', delta: realDeltaPct(rng, (s) => s.regulars, undefined, realClientMix) }
          : { ...data.regulars, text: '·', value: 0, unit: '', delta: null }) : data.regulars,
        /* ── Un tiret, pas un zéro ──────────────────────────────────────────
         * Le taux de succès n'a encore aucune source chez un vrai commerçant :
         * Kiwi ne compte pas les paiements refusés. Le clone de
         * démonstration remis à zéro les affichait donc « Taux succès 0,00 % »
         * — et un taux de succès à zéro ne se lit pas « on ne sait pas », il se
         * lit « AUCUN paiement n'aboutit ». C'est l'alarme la plus grave que
         * puisse afficher une caisse, sur une tuile qui ne mesure rien. Un
         * commerçant qui la croit appelle le support un jour d'ouverture ; un
         * commerçant qui finit par comprendre qu'elle ment cesse de croire les
         * cinq tuiles d'à côté, qui, elles, sont justes.
         *
         * Le tiret est déjà le vocabulaire de la maison pour « rien à
         * montrer » — c'est ce qu'affiche le ratio carte/espèces sans
         * encaissement, deux lignes plus haut. */
        success:    data.success    ? { ...data.success,    text: '·', unit: '', delta: null } : data.success,
        /* « Temps moyen à table / en cabine » part de « · » : le clone remis à
         * zéro affichait « 0 min », une table libérée à l'instant où elle est
         * prise. La vraie mesure (visites de table fermées, /api/table-time)
         * le remplace plus bas quand la tuile est sur la bande ; une cabine de
         * spa n'a pas de visite de table et garde « · ». */
        tempsTable: data.tempsTable ? { ...data.tempsTable, text: '·', unit: '', delta: null } : data.tempsTable,
        /* Le taux de retour, lui, a une source : les remboursements passés à
         * la caisse (/api/sale/refund) arrivent dans le même journal que les
         * ventes, et les avoirs émis sur retour viennent du registre (voir
         * creditStats). C'est la part, en valeur, de ce qui a été vendu sur la
         * période et rendu (remboursé ou crédité) sur la même période. Sans vente sur la
         * période : « · » (rien à rapporter) ; avec des ventes et aucun
         * remboursement : un vrai 0 %. Un remboursement d'une vente plus
         * ancienne compte le jour où il est fait, comme dans le CA. */
        tauxRetour: data.tauxRetour ? (!Number.isFinite(returned) ? { ...data.tauxRetour, text: '·', unit: '', delta: null } : w.gross > 0
          ? { ...data.tauxRetour, text: undefined, value: Math.round((returned / w.gross) * 1000) / 10, unit: '%', fmt: 'pct1',
              delta: realDeltaPct(rng, (s) => (s.gross ? ((s.refunds + s.credited) / s.gross) * 100 : 0), undefined, creditStats) }
          : { ...data.tauxRetour, text: '·', unit: '', delta: null }) : data.tauxRetour,
      };

      /* Bénéfice brut, Coût matière et Marge brute dérivent TOUS de `marge` via
       * margeOf(). En injectant ici la marge réellement constatée, les trois
       * tuiles sortent d'une seule source et ne peuvent plus se contredire —
       * au lieu des 54 % forfaitaires qui ignoraient le coût que le commerçant
       * avait pris la peine de saisir.
       *
       * `marge: null` est un RÉSULTAT, pas une absence de calcul : il dit « ce
       * commerçant n'a chiffré aucun des produits qu'il a vendus sur cette
       * période ». Les trois tuiles affichent alors un tiret. C'est le même
       * vocabulaire que « Taux succès » deux lignes plus haut, et c'est la
       * seule réponse honnête tant que la carte n'est pas chiffrée : un
       * pourcentage inventé ici est celui sur lequel le patron changerait ses
       * prix. `costedPct` accompagne la valeur pour que l'écran puisse dire sur
       * quelle part des ventes elle porte. */
      const gp = w.revenue > 0 ? realGrossProfit(wFrom, wTo) : null;
      if (gp && gp.marginPct != null && gp.revenueCosted > 0) {
        data.marge = { value: gp.marginPct, unit: '%', fmt: 'pct1', delta: null, costedPct: gp.pctCosted };
      } else {
        /* Rien de chiffré ⇒ le tiret, sur les TROIS tuiles. Un zéro se lirait
         * « vous ne gagnez rien », ce qui est une affirmation, et fausse. Le
         * tiret est déjà le mot de la maison pour « rien à montrer » — c'est ce
         * qu'affichent « Taux succès » et le ratio carte/espèces plus haut. */
        const dash = { text: '·', unit: '', delta: null };
        data.marge = { ...dash };
        data.profit = { ...dash };
        data.cogs = { ...dash };
      }
      /* Hôtel : les tuiles viennent du registre des séjours (voir
       * hotelBandTiles), plus des zéros écrits à la main. Le dénominateur du
       * ménage suit les chambres réellement déclarées, pas la réponse
       * facultative de l'étape 2 de l'installation. */
      if (window.KiwiVenue?.getVenueType?.() === 'hotel') {
        data = { ...data, ...hotelBandTiles(rng) };
        try { window.KiwiHotelRooms?.warm?.(); } catch (_) {}
      }
      /* Le temps à table n'est demandé au serveur que si la tuile est sur la
       * bande de ce commerce : pas de requête pour une tuile que personne ne voit. */
      if (data.tempsTable) {
        const vt = window.KiwiVenue?.getVenueType?.() || 'restaurant';
        const shown = getKpiLayout(vt) || defaultKpiKeys(vt);
        if (Array.isArray(shown) && shown.includes('tempsTable')) data = { ...data, tempsTable: { ...data.tempsTable, ...tableTimeTile(rng) } };
      }

      /* Tout le reste de la bande vient du clone démo remis à zéro : la valeur
       * affichée est bien neutre, mais son delta, lui, est resté le chiffre de
       * Café Atlas. « Taux retour 0,0 % · 0 % vs hier » se lisait donc comme un
       * taux stable alors qu'il n'y a jamais eu de retour à comparer. On coupe
       * la comparaison partout où elle n'a PAS été recalculée depuis les ventes
       * réelles, plutôt que d'énumérer les tuiles une à une — une tuile ajoutée
       * demain est couverte sans y penser. */
      const REAL_DELTAS = new Set(['tx', 'panier', 'ratio', 'revenue', 'collected', 'receivable', 'regulars', 'tauxRetour', 'tempsTable', 'occupation', 'adr', 'revpar']);
      Object.keys(data).forEach((k) => {
        const tile = data[k];
        if (tile && typeof tile === 'object' && 'delta' in tile && !REAL_DELTAS.has(k)) {
          data[k] = { ...tile, delta: null };
        }
      });
    }

    /* « Personnaliser » prévisualise exactement ces chiffres-là : ceux de la
     * bande, ventes réelles comprises, et non le tableau de démo. */
    lastBand = { range: currentRange, data };

    // Resolve which 6 KPI keys to render — owner's saved layout, or the
    // vertical default. Derived KPIs are merged into `data` so the tile
    // builder and value loop below keep working unchanged.
    const venueType = window.KiwiVenue?.getVenueType?.() || 'restaurant';
    const savedLayout = getKpiLayout(venueType);
    let layout = savedLayout || defaultKpiKeys(venueType);
    const ctx = { venueType, range: effRange(), nbDays: (ownData() && window.KiwiSales) ? openDays(effRange()) : (RANGE_DAYS[effRange()] || 1) };
    const deriveTile = (k) => {
      const c = KPI_CATALOG[k];
      return c ? c.derive(data, ctx) : (data[k] || null);
    };
    const derived = {};
    layout.forEach((k) => {
      const t = deriveTile(k);
      if (t) derived[k] = t;
    });
    data = { ...data, ...derived };

    /* Une tuile qui ne PEUT rien afficher n'a pas sa place dans la bande.
     *
     * Chez un vrai commerçant, trois indicateurs de la grille par défaut n'ont
     * aucune source : le taux de succès (Kiwi n'enregistre pas les refus de
     * paiement), les clients réguliers (aucun client identifié venu sur la
     * période, voir realClientMix), et la marge tant que le
     * catalogue n'est pas costé. Le tiret reste la bonne réponse — inventer un
     * 0 mentirait — mais trois tirets alignés dans la bande donnent à lire
     * « le tableau de bord est cassé » alors que les ventes, elles, sont là.
     *
     * On remplace donc les cases mortes par un indicateur qui, lui, a une
     * valeur, et à défaut on rétrécit la bande. Deux garde-fous :
     *   · seulement si la grille est celle par défaut (savedLayout === null) —
     *     un commerçant qui a choisi ses six tuiles garde les siennes, tirets
     *     compris, c'est sa décision ;
     *   · le vivier est court. « CA/jour » et « ventes/jour » valent
     *     exactement « CA » et « ventes » sur une journée : on ne les propose
     *     que sur une plage multi-jours, sinon la bande afficherait deux fois
     *     le même nombre sous deux titres. Pourboires (journées closes), marge et
     *     coût (marge inconnue), rétention et nouveaux clients (morts avec
     *     les réguliers, ils lisent le même carnet) sont exclus par construction.
     *
     * Auto-réparateur : le jour où le commerçant saisit ses coûts, `marge` a
     * une valeur, n'est plus morte, et reprend sa place. */
    const isDeadTile = (k) => {
      const t = data[k];
      return !t || (t.text != null && String(t.text).replace(/\s/g, '') === '·');
    };
    if (ownData() && !savedLayout && layout.some(isDeadTile)) {
      const pool = (ctx.nbDays > 1 ? ['revenue', 'revPerDay', 'txPerDay'] : ['revenue'])
        .filter((k) => !layout.includes(k));
      const ready = [];
      pool.forEach((k) => {
        const t = deriveTile(k);
        if (!t) return;
        data[k] = t;
        if (!isDeadTile(k)) ready.push(k);
      });
      const shrunk = layout
        .map((k) => (isDeadTile(k) && ready.length ? ready.shift() : k))
        .filter((k) => !isDeadTile(k));
      if (shrunk.length) layout = shrunk;
    }
    /* De l'argent dehors s'affiche. Une livraison que le transporteur n'a pas
     * encore payée n'est dans aucune tuile par défaut : le commerçant ne la
     * voyait nulle part. Tant qu'il reste quelque chose à recevoir sur la
     * période, « Créances » prend place dans la bande par défaut (en plus si
     * la bande est courte, sinon à la dernière place), et un clic dessus ouvre
     * la liste des livraisons. Une bande choisie par le commerçant ne bouge pas. */
    if (ownData() && !savedLayout && !layout.includes('receivable')) {
      const owed = deriveTile('receivable');
      if (owed && +owed.value > 0) {
        data.receivable = owed;
        layout = layout.length < KPI_MAX ? layout.concat('receivable') : layout.slice(0, KPI_MAX - 1).concat('receivable');
      }
    }
    /* La grille est figée à six colonnes (dashboard.html) : une bande plus
     * courte laisserait des pistes vides à droite. On lui passe le compte
     * réel — repeat() n'accepte pas min(), le clamp se fait donc ici. */
    const nCols = Math.max(1, layout.length);
    wrap.style.setProperty('--kpi-cols', String(nCols));
    wrap.style.setProperty('--kpi-cols-md', String(Math.min(3, nCols)));
    wrap.style.setProperty('--kpi-cols-sm', String(Math.min(2, nCols)));
    // A custom venue with a subtype profile speaks its trade's vocabulary:
    // getKpiSpec returns {key,label} pairs (no i18n field) already resolved
    // for the current language. Those labels win over the generic catalog,
    // and the tile skips data-i18n so i18n.js doesn't overwrite them — the
    // langchange refire re-renders the band with freshly-picked labels.
    const profLabels = {};
    (window.KiwiVenue?.getKpiSpec?.(venueType) || []).forEach((s) => {
      if (s.label && !s.i18n) profLabels[s.key] = s.label;
    });
    const spec = layout.map((k) => ({
      key: k,
      i18n: profLabels[k] ? '' : (KPI_CATALOG[k] || {}).i18n,
      label: profLabels[k] || kpiLabel(k, venueType, lang),
    }));

    // Read previous values (for count-up animation continuity within same venue)
    const prevVals = {};
    wrap.querySelectorAll('.kpi-m').forEach(card => {
      const k = card.dataset.kpi;
      const v = card.querySelector('[data-kpi-val]');
      if (k && v) prevVals[k] = parseAmountFromEl(v);
    });
    const prevVenue = wrap.dataset.venue || '';
    const currentVenue = getCurrentVenue();
    const isVenueSwitch = prevVenue !== currentVenue;

    // Build tiles for each KPI key in the spec, skipping missing data
    const tiles = spec.map(s => {
      const tileData = data[s.key];
      if (!tileData) return ''; // tile hidden for this vertical/range
      // A user-created venue has no trend history yet — show a flat baseline
      // instead of a borrowed demo sparkline.
      const sparkPath = ownData()
        ? 'M0 18 L120 18'
        : (KPI_SPARKS[s.key] || KPI_SPARKS.tx);
      const iconName = KPI_MATERIAL_ICONS[s.key] || 'credit-card';
      const i18nAttr = s.i18n ? ` data-i18n="${s.i18n}"` : '';
      // If a translation exists in T, use it as initial label; otherwise the FR label.
      const T = window.KiwiI18n?.T?.[lang] || {};
      const label = T[s.i18n] || s.label;
      return `
        <div class="kpi-m" data-kpi="${s.key}" tabindex="0" role="button">
          <div class="l"><span${i18nAttr}>${label}</span><div class="ico"><i data-lucide="${iconName}" style="width:13px;height:13px" aria-hidden="true"></i></div></div>
          <div class="v" data-kpi-val></div>
          <div class="d" data-kpi-delta></div>
          <svg class="sp" viewBox="0 0 120 22" preserveAspectRatio="none" aria-hidden="true" focusable="false">
            <path d="${sparkPath}" style="stroke: var(--atlas)" stroke-width="4" stroke-opacity="0.16" fill="none" stroke-linecap="round" stroke-linejoin="round"/>
            <path d="${sparkPath}" style="stroke: var(--atlas)" stroke-width="2" fill="none" stroke-linecap="round" stroke-linejoin="round"/>
          </svg>
        </div>
      `;
    }).join('');
    wrap.innerHTML = tiles;
    wrap.dataset.venue = currentVenue;
    watchKpiFit(wrap);

    // Populate values + deltas (count-up animation only when same venue)
    spec.forEach(s => {
      const tileSpec = data[s.key];
      if (!tileSpec) return;
      const card = wrap.querySelector(`[data-kpi="${s.key}"]`);
      if (!card) return;
      const valEl = card.querySelector('[data-kpi-val]');
      const deltaEl = card.querySelector('[data-kpi-delta]');
      if (valEl) {
        if (tileSpec.text != null) {
          valEl.innerHTML = fmtKpiVal(tileSpec, 0);
        } else if (isVenueSwitch) {
          // Venue change: set value instantly (DOM was rebuilt anyway)
          valEl.innerHTML = fmtKpiVal(tileSpec, tileSpec.value);
        } else {
          const from = prevVals[s.key] ?? 0;
          /* Taille fixée sur la valeur finale, la plus large : le compteur ne
           * change pas de corps en montant. */
          valEl.innerHTML = fmtKpiVal(tileSpec, tileSpec.value);
          fitKpiValue(valEl);
          animateNumber(valEl, from, tileSpec.value, { duration: 700, format: v => fmtKpiVal(tileSpec, v) });
        }
        if (tileSpec.text != null || isVenueSwitch) fitKpiValue(valEl);
      }
      if (deltaEl) {
        const d = tileSpec.delta;
        /* Pas de période précédente = pas de comparaison. Ni « 0 % » (qui
         * affirmerait que rien n'a bougé au premier jour du commerçant), ni
         * flèche (elle pointerait dans une direction inventée) — et pas non
         * plus « — vs hier », qui n'apprend rien et fait lire la tuile comme
         * une panne. On laisse la ligne vide ; le CSS en réserve la hauteur
         * (.kpi-m .d:empty) pour que les tuiles restent alignées. */
        if (d == null) {
          deltaEl.className = 'd neutral';
          /* Une tuile partielle (pourboires d'une plage qui touche l'historique
             ancien) le dit ici, dans la langue de l'écran. */
          const note = tileSpec.note ? ((window.KiwiI18n?.T?.[lang] || {})[tileSpec.noteKey] || tileSpec.note) : '';
          deltaEl.textContent = note;
        } else {
          deltaEl.className = `d${d < 0 ? ' dn' : d === 0 ? ' neutral' : ''}`;
          deltaEl.innerHTML = `${arrowSvg(d >= 0)}${fmtPct(d)} ${suffix}`;
        }
      }
    });
    if (typeof homeSet === 'function') {
      const T = window.KiwiI18n?.T?.[lang] || {};
      typeof homeSet === 'function' && homeSet('tiles', { suffix, items: spec.filter((sp) => data[sp.key]).map((sp) => {
        const tl = data[sp.key];
        const unit = tl.unit ? String(tl.unit === 'MAD' ? curUnit() : tl.unit).replace(/d{4,}/g, n => frInt(Number(n))) : '';
        const value = fmtKpiVal({ ...tl, unit: '' }, tl.text != null ? 0 : tl.value);
        return { key: sp.key, label: T[sp.i18n] || sp.label, value: String(value).replace(/<[^>]*>/g, ''), unit, dash: tl.text != null && String(tl.text).replace(/s/g, '') === '·',
          delta: tl.delta == null ? null : tl.delta, deltaText: tl.delta == null ? '' : fmtPct(tl.delta) };
      }) });
    }
    /* Un grand chiffre (« 3 916,50 MAD », « 125 400 MAD ») sortait de sa tuile et
     * se lisait coupé (« MAI »). La taille de chaque skin reste la règle ; quand la
     * valeur déborde, on réduit CETTE valeur seulement, juste assez, sans descendre
     * sous 16 px. Réévalué quand la bande change de largeur. */
    function kpiMeasure(valEl) {
      /* La place : du début de la valeur au bord intérieur de la tuile. Le besoin :
       * jusqu'au bout du texte rendu. La largeur propre de la valeur ne dit rien,
       * elle grandit avec son contenu dans la plupart des skins. */
      if (typeof valEl.closest !== 'function' || typeof document.createRange !== 'function') return null;
      const card = valEl.closest('.kpi-m') || valEl.parentElement;
      if (!card) return null;
      const left = valEl.getBoundingClientRect().left;
      const cr = card.getBoundingClientRect();
      const limit = cr.right - (parseFloat(getComputedStyle(card).paddingRight) || 0);
      const range = document.createRange();
      range.selectNodeContents(valEl);
      const right = range.getBoundingClientRect().right;
      return { avail: limit - left, need: right - left };
    }
    function fitKpiValue(valEl, measure = kpiMeasure) {
      if (!valEl || !valEl.style) return;
      valEl.style.fontSize = '';
      for (let i = 0; i < 3; i++) {
        const m = measure(valEl);
        if (!m || !(m.avail > 0) || m.need <= m.avail + 1) return;
        const fs = parseFloat(getComputedStyle(valEl).fontSize) || 32;
        const next = Math.max(16, Math.floor(fs * m.avail / m.need));
        if (next >= fs) return;
        valEl.style.fontSize = next + 'px';
      }
    }
    function watchKpiFit(wrap) {
      if (!wrap || typeof ResizeObserver !== 'function') return;
      let kpiFitObserver = renderKpiBand.fitObserver;
      if (!kpiFitObserver) {
        let last = 0;
        kpiFitObserver = new ResizeObserver((entries) => {
          const w = Math.round(entries[0]?.contentRect?.width || 0);
          if (w === last) return;
          last = w;
          entries[0].target.querySelectorAll('[data-kpi-val]').forEach((v) => fitKpiValue(v));
        });
        renderKpiBand.fitObserver = kpiFitObserver;
      }
      kpiFitObserver.disconnect();
      kpiFitObserver.observe(wrap);
    }
  }

  /* ═══════════════ KPI BAND · personnalisation drawer ═══════════════ */
  function openKpiCustomizer() {
    const Kiwi = window.Kiwi;
    if (!Kiwi || !Kiwi.drawer) return;
    const lang = getLang();
    const kc = KC_STR[lang] || KC_STR.fr;
    const venueType = window.KiwiVenue?.getVenueType?.() || 'restaurant';
    /* Les tuiles du sélecteur montrent les chiffres de la bande : un vrai
     * commerçant voyait ici « Café Atlas » (le tableau de démo) en choisissant
     * ses indicateurs. */
    if (!(lastBand && lastBand.range === currentRange)) { try { renderKpiBand(); } catch (_) {} }
    const data = (lastBand && lastBand.range === currentRange && lastBand.data)
      || (ownData() ? {} : vData(kpiByVenue, currentRange)) || {};
    const ctx = { venueType, range: effRange(), nbDays: (ownData() && window.KiwiSales) ? openDays(effRange()) : (RANGE_DAYS[effRange()] || 1) };

    // Only offer KPIs that actually resolve for this venue + range.
    const available = Object.keys(KPI_CATALOG).filter((k) => {
      try { return !!KPI_CATALOG[k].derive(data, ctx); } catch (_) { return false; }
    });
    const maxKpis = KPI_MAX;
    let selected = (getKpiLayout(venueType) || defaultKpiKeys(venueType))
      .filter((k) => available.includes(k)).slice(0, maxKpis);

    const deltaSuffix = KPI_DELTA_SUFFIX[lang]?.[currentRange] || KPI_DELTA_SUFFIX.fr[currentRange];
    // Each picker tile is a faithful preview of the dashboard KPI card —
    // label + icon, the period value, its delta and a sparkline.
    const cardHtml = (k) => {
      const c = KPI_CATALOG[k];
      const iconName = KPI_MATERIAL_ICONS[k] || 'credit-card';
      const sparkPath = KPI_SPARKS[k] || KPI_SPARKS.tx;
      let tile = null;
      try { tile = c.derive(data, ctx); } catch (_) { tile = null; }
      tile = tile || { value: 0, delta: 0 };
      const valHtml = tile.text != null ? fmtKpiVal(tile, 0) : fmtKpiVal(tile, tile.value || 0);
      const dv = tile.delta || 0;
      const dCls = dv < 0 ? ' dn' : dv === 0 ? ' neutral' : '';
      return `
        <button class="kpi-pick" data-kc="${k}" type="button" aria-pressed="false">
          <span class="kc-badge"></span>
          <span class="l"><span>${kpiLabel(k, venueType, lang)}</span><span class="ico"><i data-lucide="${iconName}" style="width:13px;height:13px" aria-hidden="true"></i></span></span>
          <span class="v">${valHtml}</span>
          <span class="d${dCls}">${arrowSvg(dv >= 0)}${fmtPct(dv)} ${deltaSuffix}</span>
          <svg class="sp" viewBox="0 0 120 22" preserveAspectRatio="none" aria-hidden="true" focusable="false"><path d="${sparkPath}" stroke="#0B6E4F" stroke-width="4" stroke-opacity="0.16" fill="none" stroke-linecap="round" stroke-linejoin="round"/><path d="${sparkPath}" stroke="#0B6E4F" stroke-width="2" fill="none" stroke-linecap="round" stroke-linejoin="round"/></svg>
        </button>`;
    };

    const body = `
      <div class="kc">
        <p class="kc-intro">${kc.intro}</p>
        <div class="kc-counter"><b data-kc-count>0 / ${maxKpis}</b> ${kc.counter}</div>
        <div class="kc-grid">${available.map(cardHtml).join('')}</div>
      </div>`;

    const res = Kiwi.drawer({
      title: kc.title,
      subtitle: kc.subtitle,
      width: 520,
      body,
      foot: `<button class="kb ghost" data-kc-reset type="button">${kc.reset}</button>
             <button data-activation=write class="kb atlas" data-kc-save type="button" style="flex:1; justify-content:center;">${kc.save}</button>`,
    });
    const root = res.el;

    function refresh() {
      root.querySelectorAll('.kpi-pick').forEach((card) => {
        const idx = selected.indexOf(card.getAttribute('data-kc'));
        const badge = card.querySelector('.kc-badge');
        card.setAttribute('aria-pressed', idx >= 0 ? 'true' : 'false');
        if (idx >= 0) { card.classList.add('sel'); badge.textContent = String(idx + 1); }
        else { card.classList.remove('sel'); badge.textContent = ''; }
      });
      const count = root.querySelector('[data-kc-count]');
      if (count) count.textContent = `${selected.length} / ${maxKpis}`;
      const cwrap = root.querySelector('.kc-counter');
      if (cwrap) cwrap.classList.toggle('full', selected.length === maxKpis);
      const save = root.querySelector('[data-kc-save]');
      if (save) save.toggleAttribute('disabled', selected.length !== maxKpis);
    }

    root.addEventListener('click', (e) => {
      const card = e.target.closest('.kpi-pick');
      if (card) {
        const k = card.getAttribute('data-kc');
        const idx = selected.indexOf(k);
        if (idx >= 0) selected.splice(idx, 1);
        else if (selected.length < maxKpis) selected.push(k);
        else { Kiwi.toast?.(kc.maxT, { type: 'info', desc: kc.maxD }); return; }
        refresh();
        return;
      }
      if (e.target.closest('[data-kc-save]')) {
        if (selected.length !== maxKpis) return;
        saveKpiLayout(venueType, selected);
        res.close();
        renderKpiBand();
        Kiwi.toast?.(kc.savedT, { type: 'success', desc: kc.savedD });
        return;
      }
      if (e.target.closest('[data-kc-reset]')) {
        resetKpiLayout(venueType);
        res.close();
        renderKpiBand();
        Kiwi.toast?.(kc.resetT, { type: 'info', desc: kc.resetD });
        return;
      }
    });
    refresh();
  }

  /* ═══════════════ RENDER: REVENUE LINE CHART ═══════════════ */

  function renderRevChart() {
    if (guardOperatorFigures('[data-rev-svg], [data-rev-legend], [data-rev-hero-delta], [data-rev-range-badge], [data-rev-compare-caption]')) {
      const value = document.querySelector('[data-rev-hero-val]');
      if (value) value.textContent = '…';
      const sub = document.querySelector('[data-rev-sub]');
      if (sub) sub.textContent = operatorUnavailableText();
      return;
    }
    const lang = getLang();
    const effective = effRange();
    let data = vData(revChartByVenue, currentRange);
    if (!data) return;
    const svg = document.querySelector('[data-rev-svg]');
    if (!svg) return;

    // User-created venue — plot the merchant's REAL sales for the active range
    // (bucketed from KiwiSales), replacing the zeroed demo clone that draws a
    // flat line AND leaks the demo legend total. Matches the hero / KPI window.
    if (ownData() && window.KiwiSales) {
      data = { ...data, ...realRevSeries(currentRange) };
    }

    // ─── Live-demo override on aujourdhui ────────────────────────────────
    // Build a "today so far" curve from the demo clock. Line truncates to
    // the current sim position; pulse + tooltip anchor at that live point.
    let liveSimIdx = -1;     // -1 = no live cursor
    let liveSimWithin = 0;   // 0..1 within liveSimIdx hour
    if (isLiveDemo() && !data._demoLedger) {
      const sim = getSim();
      if (sim) {
        liveSimIdx = sim.simIdx;
        liveSimWithin = sim.simWithin;
        // Y-axis is anchored to the daily target so the chart shape doesn't
        // jump as cumulative grows. yTicks span 0..target with 5 stops.
        const target = sim.target.revenue;
        const yMax = Math.ceil(target / 4000) * 4000 + 4000; // round up + headroom
        const yTicks = [0, yMax * 0.25, yMax * 0.5, yMax * 0.75, yMax].map(v => Math.round(v));

        // Build cumulative point at each hour boundary 0..15, scaled to target.
        // Then truncate to the live cursor position with an interpolated final point.
        const w = sim.weights.rev;
        const fullCum = [];
        let acc = 0;
        for (let i = 0; i < 16; i++) {
          acc += w[i] * target;
          fullCum.push(acc);
        }
        // Truncate: keep [0..simIdx] then interpolate within simIdx
        const partial = [];
        partial.push(0);                              // start at 0 at hour 11
        for (let i = 0; i <= liveSimIdx; i++) {
          if (i < liveSimIdx) {
            partial.push(fullCum[i]);
          } else {
            // Interpolated last point at sim position
            const prev = i === 0 ? 0 : fullCum[i - 1];
            partial.push(prev + (fullCum[i] - prev) * liveSimWithin);
          }
        }
        // Pad with nulls to keep array length 16 so x-axis labels stay positioned.
        // Clip first: late in the service (sim hour ≥ 15) partial can exceed 16,
        // and a negative Array length throws — which killed the whole render
        // chain (incl. setLang subscribers) for any night-time viewer.
        const clipped = partial.slice(0, 16);
        const padded = clipped.concat(new Array(16 - clipped.length).fill(null));

        data = {
          ...data,
          rev: padded,
          yTicks,
          // Update the legend to reflect the live cumulative
          legendPrimary: `Cumul aujourd'hui · ${frInt(sim.cumRevenue)} MAD`,
          // Live cursor markers — used by smoothPath, live-pulse, area path,
          // and hover-clamp logic so the live tip lands at the EXACT sim x
          // (not at the next hour boundary).
          _simIdx: liveSimIdx,
          _simWithin: liveSimWithin,
        };
      }
    }

    // Measure actual rendered width + height so 1 viewBox unit = 1 pixel.
    // Height is flex-driven (the chart fills its column) — measure it live.
    const H = Math.max(150, Math.round(svg.clientHeight || 240));
    const measured = Math.round(svg.clientWidth || svg.parentElement?.clientWidth || 820);
    // Phones draw at their real width: a 620-unit floor scaled a 375px chart
    // down to 60 %, shrinking the hour labels to 7px and letterboxing the curve.
    const W = measured < 620 ? Math.max(300, measured) : measured;
    svg.setAttribute('viewBox', `0 0 ${W} ${H}`);
    svg.setAttribute('preserveAspectRatio', 'xMidYMid meet');

    // Detect why we're re-rendering: full (range change) vs resize vs compare-toggle vs live-tick.
    const lastW = parseInt(svg.dataset.lastW || '0', 10);
    const lastRange = svg.dataset.lastRange || '';
    const lastShowCmp = svg.dataset.lastShowCmp === '1';
    const showCmpFlag = !!showComparison;
    const sameRange = lastRange === effective;
    const sameW = lastW > 0 && Math.abs(W - lastW) <= 2;
    const isResizeOnly = sameRange && lastW > 0 && Math.abs(W - lastW) > 2;
    const isCmpToggle  = sameRange && sameW && (lastShowCmp !== showCmpFlag);
    // On live ticks the line GROWS — no draw-in animation, no halo replay.
    const suppressAnim = isResizeOnly || (sameRange && liveTickInProgress);
    svg.dataset.lastW = String(W);
    svg.dataset.lastRange = effective;
    svg.dataset.lastShowCmp = showCmpFlag ? '1' : '0';
    svg.classList.toggle('no-anim', suppressAnim);
    svg.classList.toggle('cmp-toggle', isCmpToggle);

    // Hourly ranges plot a running total; daily ranges plot one total per
    // business day, and their hover snaps to whole days. It used to read out
    // « Mar 6 · 14h », a value interpolated between two days that nobody sold.
    const isHourly = !!data.xLabels?.[0]?.endsWith('h');
    const N = data.rev.length;
    const daily = !isHourly && N > 1;
    const PAD = { left: 20, right: 26, top: daily ? 34 : 26, bottom: 40 };
    const innerW = W - PAD.left - PAD.right;
    const innerH = H - PAD.top - PAD.bottom;
    const slot = innerW / Math.max(1, N - 1);
    const xAt = i => PAD.left + (N <= 1 ? innerW / 2 : (i * innerW) / (N - 1));
    const xs = data.rev.map((_, i) => xAt(i));

    const yTicks = data.yTicks;
    let yMin = Math.min(...yTicks);
    // Guard the all-zero case (empty user-created venue) — yMax===yMin would
    // make yScale divide by zero.
    let yMax = Math.max(...yTicks) || (yMin + 1);
    // A daily line is read for its shape, and the hero carries the amount: fit
    // the box to the days' own range (both periods, so « Comparer » never
    // rescales), never below zero. From zero, ±15 % days drew a flat rule.
    if (daily) {
      const vals = data.rev.concat(data.revPrev || []).filter(v => v != null).map(Number);
      const lo = Math.min(...vals), hi = Math.max(...vals), span = (hi - lo) || hi || 1;
      yMin = Math.max(0, lo - span * 0.45);
      yMax = hi + span * 0.32;
    }
    const yScale = v => PAD.top + innerH * (1 - (v - yMin) / (yMax - yMin));
    const baseY = yScale(yMin);

    // Live cursor x — when in live demo, the truncated curve's tip should
    // land at the EXACT sim x position (between two hour boundaries), not at
    // the next hour's x. xForIdx() returns sim x for the live-tip entry,
    // canonical xs[i] otherwise.
    const hasSim = (data._simIdx != null && data._simIdx >= 0 && data._simIdx < xs.length - 1);
    const liveTipIdx = hasSim ? data._simIdx + 1 : -1;
    const liveTipX = hasSim
      ? xs[data._simIdx] + (xs[data._simIdx + 1] - xs[data._simIdx]) * data._simWithin
      : 0;
    const xForIdx = i => (i === liveTipIdx) ? liveTipX : xs[i];

    // Monotone cubic Hermite spline (Fritsch–Carlson). Smooth and organic
    // like Apple Stocks / Robinhood, but mathematically guaranteed never to
    // overshoot or wobble between points: a rising run stays rising, a flat
    // run (e.g. yesterday's evening plateau) stays perfectly flat — no kink.
    // Skips null entries — used for the live-truncated curve where the
    // post-cursor section of the array is null.
    function smoothPath(arr) {
      if (!arr || !arr.length) return '';
      const pts = [];
      arr.forEach((v, i) => {
        if (v != null) pts.push([xForIdx(i), yScale(v)]);
      });
      const n = pts.length;
      if (n === 0) return '';
      if (n === 1) return `M${pts[0][0].toFixed(1)} ${pts[0][1].toFixed(1)}`;

      // Secant slopes between consecutive points.
      const dx = [], slope = [];
      for (let i = 0; i < n - 1; i++) {
        const h = pts[i + 1][0] - pts[i][0];
        dx.push(h);
        slope.push(h !== 0 ? (pts[i + 1][1] - pts[i][1]) / h : 0);
      }
      // Initial tangents — average of adjacent secants; 0 at local extrema.
      const m = new Array(n);
      m[0] = slope[0];
      m[n - 1] = slope[n - 2];
      for (let i = 1; i < n - 1; i++) {
        m[i] = (slope[i - 1] * slope[i] <= 0) ? 0 : (slope[i - 1] + slope[i]) / 2;
      }
      // Clamp tangents so each segment stays monotone (no overshoot).
      for (let i = 0; i < n - 1; i++) {
        if (slope[i] === 0) { m[i] = 0; m[i + 1] = 0; continue; }
        const a = m[i] / slope[i], b = m[i + 1] / slope[i];
        const s = a * a + b * b;
        if (s > 9) {
          const tau = 3 / Math.sqrt(s);
          m[i] = tau * a * slope[i];
          m[i + 1] = tau * b * slope[i];
        }
      }
      // Hermite tangents → cubic Bézier control points.
      let p = `M${pts[0][0].toFixed(1)} ${pts[0][1].toFixed(1)}`;
      for (let i = 0; i < n - 1; i++) {
        const h = dx[i];
        const cp1x = pts[i][0] + h / 3;
        const cp1y = pts[i][1] + m[i] * h / 3;
        const cp2x = pts[i + 1][0] - h / 3;
        const cp2y = pts[i + 1][1] - m[i + 1] * h / 3;
        p += ` C${cp1x.toFixed(1)} ${cp1y.toFixed(1)} ${cp2x.toFixed(1)} ${cp2y.toFixed(1)} ${pts[i + 1][0].toFixed(1)} ${pts[i + 1][1].toFixed(1)}`;
      }
      return p;
    }
    // Last non-null index in data.rev — needed for the area path's right edge
    // and for positioning the live pulse on the live-truncated curve.
    let lastIdx = -1;
    for (let i = 0; i < N; i++) { if (data.rev[i] != null) lastIdx = i; }

    // Resting hero readout:
    // - On hourly ranges (aujourdhui / hier), points are cumulative so the last
    //   non-null point is the day's total.
    // - On daily/multi-day ranges (7j, 30j, personnalisé...), points are discrete
    //   daily buckets. The hero number must show the full period's total revenue,
    //   not just the revenue of the last single day.
    let restingVal, restingPrev;
    if (isHourly) {
      restingVal = lastIdx >= 0 ? (data.rev[lastIdx] || 0) : 0;
      restingPrev = (data.revPrev && lastIdx >= 0) ? (data.revPrev[lastIdx] || 0) : null;
      if (isLiveDemo()) {
        // Resize and hydration must reuse the goal card snapshot, not sample
        // a later sub-second demo time and round to a different percentage.
        const sim = demoHeroSim?.venue === getCurrentVenue() ? demoHeroSim : getSim();
        if (sim) { restingVal = sim.cumRevenue; restingPrev = demoPreviousAt(sim); }
      }
    } else {
      if (data.total != null) {
        restingVal = data.total;
      } else {
        restingVal = data.rev.reduce((s, x) => s + (x || 0), 0);
      }
      if (data.prevTotal != null) {
        restingPrev = data.prevTotal;
      } else if (data.revPrev) {
        restingPrev = data.revPrev.reduce((s, x) => s + (x || 0), 0);
      } else {
        restingPrev = null;
      }
    }
    /* Design 2027 (kiwiSkin2027:dashboard) : la même série, pour la courbe du
     * kit sur téléphone ; le point vivant garde sa fraction d'heure. */
    typeof homeSet === 'function' && homeSet('chart', {
      range: effective, hourly: isHourly, labels: (data.xLabels || []).slice(), rev: data.rev.slice(),
      prev: data.revPrev ? data.revPrev.slice() : null, tip: liveTipIdx, within: data._simWithin || 0,
      value: restingVal, prevValue: restingPrev,
    });
    const linePath = smoothPath(data.rev);
    const cmpPath  = smoothPath(data.revPrev);
    // Area's right edge follows the line's actual tip — sim x in live mode.
    const areaTipX = lastIdx >= 0 ? xForIdx(lastIdx) : 0;
    const areaPath = lastIdx >= 0
      ? `${linePath} L${areaTipX.toFixed(1)} ${baseY.toFixed(1)} L${xs[0].toFixed(1)} ${baseY.toFixed(1)} Z`
      : '';

    // Live "you are here" indicator — anchors at the truncated curve's tip
    // when demoClock is active, otherwise stays at the canonical 14h index.
    const showLive = effective === 'aujourdhui' && lastIdx >= 0;
    const liveIdx = isLiveDemo() ? lastIdx : Math.min(3, lastIdx);
    const liveX = showLive ? xForIdx(liveIdx) : 0;
    const liveY = (showLive && data.rev[liveIdx] != null) ? yScale(data.rev[liveIdx]) : 0;

    const AVG_LBL = { fr: 'Moyenne', en: 'Average', ar: 'المتوسط' };
    const SO_FAR = { fr: 'en cours', en: 'so far', ar: 'حتى الآن' };
    const LOCALE = { fr: 'fr-FR', en: 'en-GB', ar: 'ar-MA' };
    const keys = daily ? (data.dayKeys || keysFromLabels(data.xLabels)) : null;
    const sold = daily ? data.rev.filter(v => +v > 0) : [];
    const bestIdx = sold.length >= 2 ? data.rev.reduce((b, v, i) => ((+v || 0) > (+data.rev[b] || 0) ? i : b), 0) : -1;
    const todayIdx = daily && data.dayKeys && data.dayKeys[N - 1] === merchantDayKey(Date.now(), activeMerchantSlug()) ? N - 1 : -1;
    // Demo/partial series can have fewer points than the template's tick list.
    // Ignore stale ticks rather than aborting every language-change subscriber.
    const allIdx = (data.visibleXIdx || data.rev.map((_, i) => i))
      .filter(i => Number.isInteger(i) && i >= 0 && i < xs.length && Number.isFinite(xs[i]));
    // Keep at least ~34px per label so hour ticks never touch on a phone.
    const labelStep = Math.max(1, Math.ceil(allIdx.length / Math.max(1, Math.floor(W / 34))));
    const visibleIdx = labelStep === 1 ? allIdx : allIdx.filter((_, k) => k % labelStep === 0);
    let xLabelsHtml = visibleIdx.map(i =>
      `<text x="${xs[i].toFixed(1)}" y="${(H - 14).toFixed(1)}" text-anchor="middle">${localDayTick(data.xLabels[i] || '')}</text>`
    ).join('');
    // Past ten days the axis is read by the week: a date and a short tick on
    // each Monday (on each first of the month past a hundred days).
    if (daily && keys && N > 10) {
      const monthly = N > 100, by = baseY;
      const fmt = new (globalThis.KiwiZoneLaw?.DateTimeFormat || Intl.DateTimeFormat)(LOCALE[lang] || 'fr-FR', monthly ? { month: 'short', timeZone: 'UTC' } : { day: 'numeric', month: 'short', timeZone: 'UTC' });
      let lastX = -Infinity;
      xLabelsHtml = keys.map((k, i) => {
        const d = new Date(k + 'T12:00:00Z');
        if (i === 0 || (monthly ? d.getUTCDate() !== 1 : d.getUTCDay() !== 1)) return '';
        const x = xs[i], txt = fmt.format(d);
        if (x - lastX < (monthly ? 34 : 52)) return '';
        lastX = x;
        const tx = Math.max(PAD.left + 18, Math.min(W - PAD.right - 18, x));
        return `<line class="rev-week" x1="${x.toFixed(1)}" x2="${x.toFixed(1)}" y1="${(by + 4).toFixed(1)}" y2="${(by + 9).toFixed(1)}" stroke="rgba(247,245,240,0.25)"/>` +
          `<text x="${tx.toFixed(1)}" y="${(H - 14).toFixed(1)}" text-anchor="middle">${txt}</text>`;
      }).join('');
    }
    // Robinhood-clean: no y-axis labels — the hero readout + scrubber carry
    // the exact figures, so the line floats free of gridline clutter.
    const yLabelsHtml = '';

    const showCmp = !!showComparison;
    const captionFull = COMPARE_CAPTION[lang]?.[currentRange] || COMPARE_CAPTION.fr[currentRange] || '';
    const captionShort = COMPARE_SHORT[lang]?.[currentRange] || COMPARE_SHORT.fr[currentRange] || '';

    svg.innerHTML = `
      <defs>
        <!-- 3-stop gradient: punchy near the line, fades fast, Robinhood depth -->
        <linearGradient id="gfill" x1="0" x2="0" y1="0" y2="1">
          <stop offset="0"    stop-color="#7DF2B0" stop-opacity="0.30"/>
          <stop offset="0.6"  stop-color="#7DF2B0" stop-opacity="0.06"/>
          <stop offset="1"    stop-color="#7DF2B0" stop-opacity="0"/>
        </linearGradient>
        <filter id="rev-line-glow" x="-2%" y="-30%" width="104%" height="160%">
          <feGaussianBlur stdDeviation="3"/>
        </filter>
        <!-- Atlas → riad gradient for the tooltip card -->
        <linearGradient id="rev-tip-gradient" x1="0%" y1="0%" x2="100%" y2="100%">
          <stop offset="0%"   stop-color="#0B6E4F"/>
          <stop offset="100%" stop-color="#053B2C"/>
        </linearGradient>
        <!-- Green-tinted soft shadow under the tooltip -->
        <filter id="rev-tip-shadow" x="-50%" y="-50%" width="200%" height="240%">
          <feDropShadow dx="0" dy="2"  stdDeviation="2"  flood-color="#053B2C" flood-opacity="0.18"/>
          <feDropShadow dx="0" dy="10" stdDeviation="16" flood-color="#053B2C" flood-opacity="0.32"/>
        </filter>
      </defs>
      ${yLabelsHtml}
      <g font-family="Inter Tight" font-size="10.5" fill="rgba(247,245,240,0.5)" letter-spacing="0.02em">${xLabelsHtml}</g>
      <line class="rev-cross-line" x1="${PAD.left}" x2="${PAD.left}" y1="${PAD.top}" y2="${(PAD.top + innerH).toFixed(1)}" stroke="rgba(255,255,255,0.32)" stroke-width="1"/>
      ${cmpPath ? `<path class="rev-cmp" d="${cmpPath}" stroke="rgba(247,245,240,0.4)" stroke-width="2" fill="none" stroke-linecap="round" stroke-linejoin="round" pathLength="1" style="opacity:${showCmp ? 1 : 0};"/>` : ''}
      <path class="rev-area" d="${areaPath}" fill="url(#gfill)"/>
      <!-- Halo: wider, blurred sibling of the line, Apple Stocks soft glow -->
      <path class="rev-line-halo" d="${linePath}" stroke="#7DF2B0" stroke-width="5" stroke-opacity="0.20" fill="none" stroke-linecap="round" stroke-linejoin="round" filter="url(#rev-line-glow)" pathLength="1"/>
      <path class="rev-line" d="${linePath}" stroke="#7DF2B0" stroke-width="2.25" fill="none" stroke-linecap="round" stroke-linejoin="round" pathLength="1"/>
      ${daily ? dailyMarks() : ''}
      ${showLive ? `
      <g class="rev-live" transform="translate(${liveX.toFixed(1)} ${liveY.toFixed(1)})">
        <circle class="rev-live-ring" cx="0" cy="0" r="4"/>
        <circle class="rev-live-ring delay" cx="0" cy="0" r="4"/>
        <circle class="rev-live-dot" cx="0" cy="0" r="4"/>
      </g>` : ''}
      <g class="rev-active">
        <circle class="rev-active-cmp" cx="${PAD.left}" cy="${PAD.top}" r="4" fill="rgba(247,245,240,0.55)" stroke="#053B2C" stroke-width="2"/>
        <circle class="rev-active-dot" cx="${PAD.left}" cy="${PAD.top}" r="5.5" fill="#7DF2B0" stroke="#053B2C" stroke-width="2"/>
      </g>
      <g class="rev-tip">
        <rect class="rev-tip-rect" rx="14" ry="14" fill="url(#rev-tip-gradient)" stroke="rgba(125,242,176,0.18)" stroke-width="1" filter="url(#rev-tip-shadow)"/>
        <text class="rev-tip-label" x="0" text-anchor="middle" font-family="Inter Tight" font-weight="500" font-size="12" fill="#7DF2B0" opacity="0.92"></text>
        <text class="rev-tip-value" x="0" text-anchor="middle" font-family="Inter Tight" font-weight="600" font-size="17" fill="#FFFFFF" letter-spacing="-0.01em"></text>
        <text class="rev-tip-cmp"   x="0" text-anchor="middle" font-family="Inter Tight" font-weight="500" font-size="11" letter-spacing="0"></text>
        ${daily ? `<line class="rev-tip-rule" stroke="rgba(247,245,240,0.12)" stroke-width="1"/>
        <line class="rev-tip-swatch" stroke="rgba(247,245,240,0.55)" stroke-width="1.5" stroke-linecap="round"/>
        <rect class="rev-tip-pill" rx="9" ry="9" height="18"/>
        <text class="rev-tip-delta" font-family="Inter Tight" font-weight="600" font-size="11" text-anchor="middle"></text>` : ''}
      </g>
      <rect class="rev-hit" x="${PAD.left}" y="${PAD.top}" width="${innerW}" height="${innerH}" fill="transparent" pointer-events="all"/>
    `;

    // Pointer-driven tooltip + active dots — hover state controlled by .is-hover
    // class on the SVG; element opacity transitions in CSS handle the fade.
    const hit = svg.querySelector('.rev-hit');
    const aDot = svg.querySelector('.rev-active-dot');
    const aCmp = svg.querySelector('.rev-active-cmp');
    const cross = svg.querySelector('.rev-cross-line');
    const tip = svg.querySelector('.rev-tip');
    const tipRect  = svg.querySelector('.rev-tip-rect');
    const tipLabel = svg.querySelector('.rev-tip-label');
    const tipValue = svg.querySelector('.rev-tip-value');
    const tipCmp   = svg.querySelector('.rev-tip-cmp');

    function fmtDeltaPct(now, prev) {
      if (!prev || prev <= 0) return '';
      const pct = ((now - prev) / prev) * 100;
      const sign = pct > 0 ? '+' : pct < 0 ? '−' : '';
      const abs = Math.abs(pct);
      const txt = (Math.abs(abs - Math.round(abs)) < 0.05) ? String(Math.round(abs)) : (window.KiwiNumber?.number(abs, 1) ?? new Intl.NumberFormat(document.documentElement?.lang === 'en' ? 'en-GB' : 'fr-FR', {minimumFractionDigits:1,maximumFractionDigits:1}).format(abs));
      return `${sign}${txt} %`;
    }

    // Robinhood-style hero readout: a big live figure that the scrubber drives.
    function setHero(val, prev, animate) {
      const vEl = document.querySelector('[data-rev-hero-val]');
      const dEl = document.querySelector('[data-rev-hero-delta]');
      if (vEl) {
        // The group space is U+202F; at the hero's tight tracking it closed up
        // and 944 489,70 read as 944489,70. It gets its own untracked span.
        const fmtV = (v) => `${String(frMoney(v)).replace(/[\u202F\u00A0 ]/g, '<span class="rev-hero-sep">\u202F</span>')}<span class="rev-hero-cur">${curUnit()}</span>`;
        if (animate) animateNumber(vEl, parseAmountFromEl(vEl), val, { duration: 720, format: fmtV });
        else vEl['inner' + 'HTML'] = fmtV(val);
      }
      if (dEl) {
        if (prev != null && prev > 0) {
          const diff = Math.round(val - prev);
          const up = diff >= 0;
          dEl.className = 'rev-hero-delta ' + (up ? 'up' : 'down');
          dEl['inner' + 'HTML'] = `${arrowSvg(up)}<span>${up ? '+' : '−'}${frInt(Math.abs(diff))} MAD · ${fmtDeltaPct(val, prev)}</span><span class="lbl">${captionShort || 'vs préc.'}</span>`;
        } else {
          dEl.className = 'rev-hero-delta is-empty';
          dEl['inner' + 'HTML'] = '';
        }
      }
    }

    /* ── Daily columns ──────────────────────────────────────────────────
     * Rest state: every day a quiet column, the best day solid and named,
     * a dashed line at the average of the days that sold. Comparing adds a
     * thin mark per day at the previous period's same day. The pointer
     * snaps to whole days and lights one column. */
    // Demo series carry « Mar 22 » ticks and no dates: walk back from today to
    // the last tick's weekday and day of month, then count backwards.
    function keysFromLabels(labels) {
      const m = /^(dim|lun|mar|mer|jeu|ven|sam)\.?\s+(\d{1,2})$/i.exec(labels?.[labels.length - 1] || '');
      if (!m) return null;
      let t = Date.parse(merchantDayKey(Date.now(), activeMerchantSlug()) + 'T12:00:00Z');
      for (let k = 0; k < 40; k++, t -= 864e5) {
        const d = new Date(t);
        if (d.getUTCDate() === +m[2] && d.getUTCDay() === DAY_ABBR.findIndex(a => a.toLowerCase() === m[1].toLowerCase())) {
          return labels.map((_, i) => new Date(t - (labels.length - 1 - i) * 864e5).toISOString().slice(0, 10));
        }
      }
      return null;
    }
    function dayName(i, shift) {
      if (!keys?.[0]) return shift ? '' : localDayTick(data.xLabels[i] || '');
      const t = Date.parse(keys[0] + 'T12:00:00Z') + (i + shift) * 864e5;
      const s = new (globalThis.KiwiZoneLaw?.DateTimeFormat || Intl.DateTimeFormat)(LOCALE[lang] || 'fr-FR', { weekday: 'long', day: 'numeric', month: shift ? 'short' : 'long', timeZone: 'UTC' }).format(t);
      return s.charAt(0).toUpperCase() + s.slice(1);
    }
    function compact(v) {
      return v >= 10000 ? (window.KiwiNumber?.number?.(v / 1000, 1) ?? (v / 1000).toFixed(1)) + ' k' : frInt(v);
    }
    /* Rest-state reading of a daily line: a dashed average of the days that
     * sold, the best day marked and named, and the last day closed by a dot. */
    function dailyMarks() {
      let out = '';
      if (sold.length >= 2) {
        const mean = sold.reduce((a, v) => a + (+v), 0) / sold.length, ay = yScale(mean).toFixed(1);
        out += `<line class="rev-avg" x1="${PAD.left}" x2="${(W - PAD.right).toFixed(1)}" y1="${ay}" y2="${ay}" stroke="rgba(247,245,240,0.4)" stroke-dasharray="2 5"/>` +
          `<text class="rev-avg-lbl" x="${(W - PAD.right).toFixed(1)}" y="${(+ay - 8).toFixed(1)}" text-anchor="end">${AVG_LBL[lang] || AVG_LBL.fr} · ${frInt(mean)} ${curUnit()}</text>`;
      }
      if (bestIdx >= 0) {
        const bx = xs[bestIdx], by = yScale(+data.rev[bestIdx]);
        const lx = Math.max(PAD.left + 20, Math.min(W - PAD.right - 20, bx));
        out += `<circle class="rev-best-halo" cx="${bx.toFixed(1)}" cy="${by.toFixed(1)}" r="9" fill="#7DF2B0" fill-opacity="0.16"/>` +
          `<circle class="rev-best-dot" cx="${bx.toFixed(1)}" cy="${by.toFixed(1)}" r="4" fill="#7DF2B0" stroke="#053B2C" stroke-width="2"/>` +
          `<text class="rev-best-lbl" x="${lx.toFixed(1)}" y="${(by - 15).toFixed(1)}" text-anchor="middle">${compact(+data.rev[bestIdx])}</text>`;
      }
      if (lastIdx >= 0 && lastIdx !== bestIdx) {
        out += `<circle class="rev-end-dot" cx="${xs[lastIdx].toFixed(1)}" cy="${yScale(+data.rev[lastIdx] || 0).toFixed(1)}" r="3.5" fill="#7DF2B0" stroke="#053B2C" stroke-width="2"/>`;
      }
      return `<g class="rev-marks" font-family="Inter Tight" font-size="10.5" font-weight="600" fill="rgba(247,245,240,0.7)">${out}</g>`;
    }
    function moveDaily(evt) {
      const rect = svg.getBoundingClientRect();
      if (rect.width === 0) return;
      const xVB = ((evt.clientX - rect.left) / rect.width) * W;
      const i = Math.max(0, Math.min(N - 1, Math.round((xVB - PAD.left) / slot)));
      if (data.rev[i] == null) { leave(); return; }
      const v = +data.rev[i] || 0;
      const p = data.revPrev ? (+data.revPrev[i] || 0) : null;
      const cmpOn = !!showComparison && p != null;
      const sx = xs[i], sy = yScale(v);
      aDot.setAttribute('cx', sx.toFixed(1)); aDot.setAttribute('cy', sy.toFixed(1));
      aCmp.style.display = cmpOn ? '' : 'none';
      if (cmpOn) { aCmp.setAttribute('cx', sx.toFixed(1)); aCmp.setAttribute('cy', yScale(p).toFixed(1)); }
      cross?.setAttribute('x1', sx.toFixed(1)); cross?.setAttribute('x2', sx.toFixed(1));
      /* The day's card: date, then the amount with its unit set small. When
       * comparing, a hairline, then the same day of the previous period keyed
       * by a swatch of its line, with the change in a pill. */
      const q = c => svg.querySelector(c);
      const rule = q('.rev-tip-rule'), swatch = q('.rev-tip-swatch'), pill = q('.rev-tip-pill'), delta = q('.rev-tip-delta');
      const d = cmpOn ? fmtDeltaPct(v, p) : '';
      tip.classList.add('is-day');
      tip.classList.toggle('is-cmp', cmpOn);
      [tipLabel, tipValue, tipCmp].forEach(t => t.setAttribute('text-anchor', 'start'));
      tipLabel.textContent = dayName(i, 0) + (i === todayIdx ? ' · ' + (SO_FAR[lang] || SO_FAR.fr) : '');
      tipValue.innerHTML = `${frMoney(v)}<tspan class="rev-tip-cur" dx="5" font-size="11" font-weight="600" fill="rgba(247,245,240,0.55)">${curUnit()}</tspan>`;
      tipCmp.textContent = cmpOn ? `${dayName(i, -N) || captionShort} · ${frInt(p)} ${curUnit()}` : '';
      delta.textContent = d;
      [tipCmp, rule, swatch].forEach(el => { el.style.display = cmpOn ? '' : 'none'; });
      [pill, delta].forEach(el => { el.style.display = cmpOn && d ? '' : 'none'; });
      pill.classList.toggle('down', v < p); delta.classList.toggle('down', v < p);
      pill.setAttribute('fill', v < p ? 'rgba(252,165,151,0.16)' : 'rgba(125,242,176,0.16)');
      delta.setAttribute('fill', v < p ? '#FCA597' : '#7DF2B0');
      const PX = 16, pillW = d ? Math.ceil(delta.getComputedTextLength()) + 14 : 0;
      const cmpW = cmpOn ? 18 + tipCmp.getComputedTextLength() + (pillW ? 12 + pillW : 0) : 0;
      const tipW = Math.ceil(Math.max(150, tipLabel.getComputedTextLength(), tipValue.getComputedTextLength(), cmpW)) + PX * 2;
      const tipH = cmpOn ? 100 : 66, GAP = 14;
      // Beside the day, never over its point: right of it, left near the end.
      const left = sx + GAP + tipW <= W - 4 ? sx + GAP : sx - GAP - tipW;
      const ty = Math.max(4, Math.min(H - PAD.bottom - tipH, sy - tipH / 2));
      tipRect.setAttribute('x', '0'); tipRect.setAttribute('y', '0');
      tipRect.setAttribute('width', tipW); tipRect.setAttribute('height', tipH);
      tipLabel.setAttribute('x', PX); tipLabel.setAttribute('y', '25');
      tipValue.setAttribute('x', PX); tipValue.setAttribute('y', '50');
      if (cmpOn) {
        rule.setAttribute('x1', PX); rule.setAttribute('x2', tipW - PX); rule.setAttribute('y1', '66.5'); rule.setAttribute('y2', '66.5');
        swatch.setAttribute('x1', PX); swatch.setAttribute('x2', PX + 10); swatch.setAttribute('y1', '83'); swatch.setAttribute('y2', '83');
        tipCmp.setAttribute('x', PX + 18); tipCmp.setAttribute('y', '87');
        pill.setAttribute('x', tipW - PX - pillW); pill.setAttribute('y', '74'); pill.setAttribute('width', pillW);
        delta.setAttribute('x', tipW - PX - pillW / 2); delta.setAttribute('y', '87');
      }
      tip.setAttribute('transform', `translate(${Math.max(4, left).toFixed(1)}, ${ty.toFixed(1)})`);
      svg.classList.add('is-hover');
      setHero(v, null, false);
    }
    function move(evt) {
      const rect = svg.getBoundingClientRect();
      if (rect.width === 0) return;
      const xVB = ((evt.clientX - rect.left) / rect.width) * W;

      let sx, sy, cmpY, valueAtCursor, prevAtCursor, timeLabel, refIdx;

      if (isHourly) {
        // ─── PER-MINUTE: linear interpolation between hour boundaries ───
        const fx = Math.max(0, Math.min(1, (xVB - PAD.left) / innerW));
        const TOTAL_MIN = (xs.length - 1) * 60;          // 15h × 60 = 900 min
        let totalMin = Math.round(fx * TOTAL_MIN);

        // Live demo: reject hover positions past the sim cursor (you can't peek
        // at hours that haven't happened yet).
        if (data._simIdx != null) {
          const simTotalMin = data._simIdx * 60 + Math.round(data._simWithin * 60);
          if (totalMin > simTotalMin) { svg.classList.remove('is-hover'); return; }
        }

        let hourIdx = Math.min(xs.length - 1, Math.floor(totalMin / 60));
        let minWithin = totalMin - hourIdx * 60;
        // Handle the rightmost edge
        if (hourIdx >= xs.length - 1) { hourIdx = xs.length - 1; minWithin = 0; }

        const vLow  = data.rev[hourIdx];
        const vHigh = data.rev[hourIdx + 1];

        // If we're past the live cursor (vLow null), don't render the hover.
        if (vLow == null) { svg.classList.remove('is-hover'); return; }

        // Interpolate value (linear) between the two surrounding hour boundaries.
        if (vHigh == null || hourIdx >= xs.length - 1) {
          valueAtCursor = vLow;
        } else {
          valueAtCursor = vLow + (vHigh - vLow) * (minWithin / 60);
        }

        // Interpolate compare line too if active.
        if (data.revPrev) {
          const pLow  = data.revPrev[hourIdx];
          const pHigh = data.revPrev[hourIdx + 1];
          if (pLow != null && pHigh != null && hourIdx < xs.length - 1) {
            prevAtCursor = pLow + (pHigh - pLow) * (minWithin / 60);
          } else if (pLow != null) {
            prevAtCursor = pLow;
          }
        }

        // Snap cursor x to the exact minute (60 minutes per hour-segment).
        const fSnap = totalMin / TOTAL_MIN;
        sx = PAD.left + fSnap * innerW;
        sy = yScale(valueAtCursor);
        cmpY = (prevAtCursor != null) ? yScale(prevAtCursor) : null;

        // Build "11h32" / "14h27" / "01h05" — wraps past 23h to 00h/01h/02h.
        const baseHour = parseInt((data.xLabels[hourIdx] || '11h').replace('h', ''), 10);
        const safeHour = isNaN(baseHour) ? 11 : baseHour;
        timeLabel = `${String(safeHour).padStart(2, '0')}h${String(minWithin).padStart(2, '0')}`;
        refIdx = hourIdx;
      } else {
        // Single-day series (a one-day custom range): no columns to snap to.
        sx = xs[0]; sy = yScale(data.rev[0] || 0);
        valueAtCursor = data.rev[0] || 0; prevAtCursor = data.revPrev ? data.revPrev[0] : null;
        cmpY = prevAtCursor != null ? yScale(prevAtCursor) : null;
        timeLabel = localDayTick(data.xLabels[0] || ''); refIdx = 0;
      }

      const showCmpNow = !!showComparison && cmpY != null;

      // Active dots — CSS transitions on cx/cy smooth-track the cursor
      aDot.setAttribute('cx', sx.toFixed(1));
      aDot.setAttribute('cy', sy.toFixed(1));
      aCmp.style.display = showCmpNow ? '' : 'none';
      if (showCmpNow) {
        aCmp.setAttribute('cx', sx.toFixed(1));
        aCmp.setAttribute('cy', cmpY.toFixed(1));
      }
      // Vertical crosshair — full-height dashed line, smooth-tracking
      if (cross) {
        cross.setAttribute('x1', sx.toFixed(1));
        cross.setAttribute('x2', sx.toFixed(1));
      }

      // Tooltip — two heights: compact (180×54) when no compare, expanded (224×84) with compare
      const tipW = showCmpNow ? 224 : 180;
      const tipH = showCmpNow ? 84  : 54;
      const ANCHOR_GAP = 16;        // gap between tooltip edge and the hovered dot
      const rectX = -tipW / 2;

      // Flip strategy — tooltip ABOVE the dot by default, but if the dot
      // is high (small sy) the tooltip would clip the top edge AND overlap
      // the dot itself. In that case flip BELOW the dot so the dot stays
      // visible. This is the bug the user reported: green box covering
      // the green hover point on high values.
      const tipFitsAbove = sy >= PAD.top + tipH + ANCHOR_GAP + 4;
      const tipBelow = !tipFitsAbove;
      const rectY = tipBelow ? ANCHOR_GAP : -tipH - ANCHOR_GAP;

      tipRect.setAttribute('x', rectX.toFixed(1));
      tipRect.setAttribute('y', rectY.toFixed(1));
      tipRect.setAttribute('width',  tipW);
      tipRect.setAttribute('height', tipH);

      // Vertical layout inside the rect: text positions are relative to
      // rectY, so they flip automatically with the rect.
      if (showCmpNow) {
        tipLabel.setAttribute('y', (rectY + 22).toFixed(1));   // top row
        tipValue.setAttribute('y', (rectY + 48).toFixed(1));   // middle
        tipCmp  .setAttribute('y', (rectY + 70).toFixed(1));   // bottom
      } else {
        tipLabel.setAttribute('y', (rectY + 22).toFixed(1));
        tipValue.setAttribute('y', (rectY + 44).toFixed(1));
      }

      // Anchor at the dot; horizontal clamping keeps it on-canvas.
      const tipDy = sy;
      const halfW = tipW / 2 + 8;
      let tipDx = 0;
      if (sx - halfW < 4)         tipDx = halfW + 8 - sx;          // push right
      else if (sx + halfW > W - 4) tipDx = -((sx + halfW) - (W - 4)); // push left
      tip.setAttribute('transform', `translate(${(sx + tipDx).toFixed(1)}, ${tipDy.toFixed(1)})`);

      // Content — time label + interpolated value
      tipLabel.textContent = timeLabel;
      tipValue.textContent = `${frInt(valueAtCursor)} ${curUnit()}`;
      if (showCmpNow && prevAtCursor != null) {
        const delta = fmtDeltaPct(valueAtCursor, prevAtCursor);
        // Green tooltip bg: positive delta = mint, negative = warm red. Label muted mint.
        const deltaColor = (valueAtCursor >= prevAtCursor) ? '#7DF2B0' : '#FCA597';
        tipCmp.innerHTML =
          `<tspan fill="rgba(199,234,212,0.85)">${captionShort} · ${frInt(prevAtCursor)} MAD&#160;&#160;</tspan>` +
          `<tspan fill="${deltaColor}" font-weight="600">${delta}</tspan>`;
        tipCmp.style.display = '';
      } else {
        tipCmp.style.display = 'none';
      }
      svg.classList.add('is-hover');
      setHero(valueAtCursor, prevAtCursor, false);
    }
    function leave() {
      svg.classList.remove('is-hover');
      setHero(restingVal, restingPrev, false);
    }
    hit.addEventListener('pointermove', daily ? moveDaily : move);
    hit.addEventListener('pointerenter', daily ? moveDaily : move);
    hit.addEventListener('pointerleave', leave);

    // Hero readout — latest cumulative figure + delta vs the comparison.
    setHero(restingVal, restingPrev, !suppressAnim);

    // Header text
    const badge = document.querySelector('[data-rev-range-badge]');
    if (badge) badge.textContent = trStr(data.rangeBadge, REV_BADGE);
    const sub = document.querySelector('[data-rev-sub]');
    if (sub) sub.textContent = trStr(data.sub, REV_SUB);

    /* No previous period, no comparison to make. Left enabled the button reads
     * as broken — you press it and the chart doesn't move. Disabled, with the
     * reason on the tooltip, it reads as what it is: there is nothing yet to
     * compare this period against. */
    const cmpBtn = document.querySelector('[data-rev-compare-btn]');
    if (cmpBtn) {
      const canCompare = Array.isArray(data.revPrev) && data.revPrev.length > 0;
      cmpBtn.disabled = !canCompare;
      if (canCompare) cmpBtn.removeAttribute('title');
      else cmpBtn.setAttribute('title', trStr('Aucune période précédente à comparer', CMP_EMPTY_TITLE));
    }

    // Legend (revenue lines only — transactions count moved to KPI band)
    const legend = document.querySelector('[data-rev-legend]');
    if (legend) {
      legend['inner' + 'HTML'] = `
        <label><i class="leg-line leg-line-primary"></i>${trLegend(data.legendPrimary || '', LEGEND_PREFIX)}</label>
        ${showCmp && data.legendCompare
          ? `<label class="leg-cmp"><i class="leg-line leg-line-compare"></i>${trLegend(data.legendCompare, LEGEND_PREFIX)}</label>`
          : ''}
      `;
    }

    // Caption under the chart title — language-aware
    const cap = document.querySelector('[data-rev-compare-caption]');
    if (cap) {
      if (showCmp && captionFull) {
        cap.textContent = captionFull;
        cap.hidden = false;
      } else {
        cap.hidden = true;
      }
    }
  }

  /* ═══════════════ RENDER: PAYMENT MIX DONUT ═══════════════ */

  /* Ventilation réelle des encaissements (venues créées par le marchand).
   * La caisse enregistre un MODE DE PAIEMENT — espèces, carte, tap, QR, lien —
   * et jamais le réseau de la carte : le partage Visa / Mastercard de la démo ne
   * peut pas exister ici. La carte n'avait aucune branche « venue personnalisée »,
   * donc un vrai magasin voyait un anneau vide et quatre rails figés à 0 % malgré
   * ses ventes, et surtout AUCUNE ligne Espèces — le tender dominant d'une
   * boutique marocaine. */
  const REAL_MIX = [
    { key: 'cash', color: '#0B6E4F', fr: 'Espèces',          en: 'Cash',         ar: 'نقدًا' },
    { key: 'card', color: '#46A878', fr: 'Carte bancaire',   en: 'Bank card',    ar: 'بطاقة بنكية' },
    { key: 'tap',  color: '#7DF2B0', fr: 'Kiwi Tap',         en: 'Kiwi Tap',     ar: 'Kiwi Tap' },
    { key: 'qr',   color: '#D99A2B', fr: 'QR / Wallet',      en: 'QR / Wallet',  ar: 'QR / محفظة' },
    { key: 'link', color: '#B08CC8', fr: 'Lien de paiement', en: 'Payment link', ar: 'رابط الدفع' },
    { key: 'transfer', color: 'var(--n-500)', fr: 'Virement', en: 'Bank transfer', ar: 'تحويل بنكي' },
    { key: 'cheque', color: 'var(--n-300)', fr: 'Chèque', en: 'Cheque', ar: 'شيك' },
    { key: 'split', color: 'var(--n-700)', fr: 'Paiement partagé', en: 'Split payment', ar: 'دفع مقسّم' },
    { key: 'other', color: 'var(--n-300)', fr: 'Autre mode', en: 'Other tender', ar: 'طريقة أخرى' },
  ];
  const MIX_EMPTY = {
    fr: 'Aucun encaissement sur la période',
    en: 'No payments in this period',
    ar: 'لا توجد مدفوعات في هذه الفترة',
  };
  // Rows for the active range: only tenders actually used, so a store that takes
  // cash only is not told it has four dead card rails.
  /* Au centre de l'anneau, la démo affiche le total CARTE — d'où « MAD carte »
   * dans le HTML. Une venue réelle y affiche le total TOUS MODES, donc la même
   * légende ferait lire « 1 350 MAD carte » à un commerçant qui n'a encaissé
   * que 450 MAD par carte. Deux légendes, un seul centre. */
  const MIX_CENTER_ALL = { fr: 'MAD encaissé', en: 'MAD collected', ar: 'درهم محصّل' };

  function realMixRows(lang, range) {
    const [from, to] = rangeBounds(range == null ? currentRange : range);
    const by = {};
    let total = 0;
    realSalesList().forEach((e) => {
      const ts = +e.ts || 0;
      if (ts < from || ts >= to) return;
      const amt = Math.max(0, +e.amount || 0);
      if (!amt) return;
      const k = tenderBucket(e && e.method);
      if (!k) return; // crédit client / créance livraison ≠ argent encaissé
      tenderAmounts(e).forEach(part => {
        if (part.key) by[part.key] = (by[part.key] || 0) + part.amount;
      });
      total += amt;
    });
    /* The ring says « MAD encaissé »: money kept, after refunds, the way the
     * till's « Moyens de paiement · net » and the day report count it. It used
     * to add sales only, so a day with a 20,40 card refund read 425 here and
     * 404,10 everywhere else, on the same screen as the 404,10 band. A refund
     * goes back on the tender it was paid with (realWindowStats does the same
     * for the card/cash tile). */
    realRefundList().forEach((e) => {
      const ts = +e.ts || 0;
      if (ts < from || ts >= to) return;
      const amt = Math.abs(+e.amount || 0);
      const k = tenderBucket(e && e.method);
      if (!amt || !k) return;
      by[k] = (by[k] || 0) - amt;
      total -= amt;
    });
    total = Math.round(total * 100) / 100;
    const kept = REAL_MIX.filter((m) => by[m.key] > 0.004);
    const keptSum = kept.reduce((s, m) => s + by[m.key], 0);
    if (!(total > 0) || !keptSum) return { rows: [], total: 0, cardTotal: 0 };
    return {
      total,
      rows: kept.map((m) => ({
        color: m.color, label: m[lang] || m.fr, pct: (by[m.key] / keptSum) * 100,
      })),
    };
  }

  function renderMix() {
    const effective = effRange();
    const data = vData(mixByVenue, currentRange);
    if (!data) return;
    const lang = getLang();

    // Real and active-demo venues both render tenders actually in their ledger.
    // The static preview is only a fallback when no demo clock is running.
    const custom = !!(ownData() && window.KiwiSales);
    renderMixPlan(custom, lang);
    const real = custom ? realMixRows(lang, currentRange) : null;
    const rows = custom ? real.rows : data._demoLedger ? data.mixRows : [
      { color: '#0B6E4F', label: 'Visa',       pct: data.visa },
      { color: '#46A878', label: 'Mastercard', pct: data.mc   },
      { color: '#7DF2B0', label: 'Kiwi Tap',   pct: data.tap  },
      { color: '#D99A2B', label: 'QR',         pct: data.qr   },
    ];
    const rawCenterMad = custom ? real.total : data.centerMad;
    const centerMad = Number.isFinite(Number(rawCenterMad)) ? Number(rawCenterMad) : 0;

    const donut = document.querySelector('[data-mix-donut]');
    if (donut) {
      // Segments draw clockwise from 12 o'clock. Each segment carries its FINAL
      // dashoffset from the start; only stroke-dasharray animates from "0 100" → "P 100".
      // Clockwise from 12 o'clock. pathLength=100 → dash/offset are exact
      // percentages; a hairline GAP between segments keeps them legible. A
      // light→deep green ramp + amber makes all four methods distinguishable.
      const GAP = 1.6;
      const SW = 2.89;
      let acc = 0;
      const segs = rows.map((r) => {
        const pct = r.pct || 0;
        const seg = { stroke: r.color, pct, dash: Math.max(0, pct - GAP), offset: 25 - acc };
        acc += pct;
        return seg;
      });
      /* The built DOM caches one <circle> per segment, addressed by index. A real
       * store's tender set grows as it takes its first card or QR payment, so the
       * cached ring must be discarded whenever the shape changes — otherwise the
       * new tranche would have no element to draw into. */
      const sig = segs.map((s) => s.stroke).join('|');
      if (donut.dataset.sig !== sig) donut.dataset.built = '';
      donut.dataset.sig = sig;
      const built = donut.dataset.built === '1';
      const STAGGER_MS = 150;
      const FILL_MS = 850; // matches CSS transition duration

      if (!built) {
        donut['inner' + 'HTML'] = `
          <circle class="track" cx="21" cy="21" r="15.9155" fill="transparent" stroke="#EBE8E0" stroke-width="${SW}" pathLength="100"/>
          ${segs.map((s, i) => `
            <circle class="seg" data-seg="${i}"
              cx="21" cy="21" r="15.9155" fill="transparent"
              stroke="${s.stroke}" stroke-width="${SW}" pathLength="100"
              stroke-dasharray="0 100"
              stroke-dashoffset="${s.offset}"
              stroke-linecap="butt"/>
          `).join('')}
        `;
        donut.dataset.built = '1';
        // Initial entrance: segments wipe in clockwise, sequentially from visa → qr.
        segs.forEach((s, i) => {
          setTimeout(() => {
            const el = donut.querySelector(`[data-seg="${i}"]`);
            if (el) el.setAttribute('stroke-dasharray', `${s.dash} ${100 - s.dash}`);
          }, 80 + i * STAGGER_MS);
        });
      } else {
        // Range change: stagger the per-segment update so the user sees the donut
        // redistribute sector by sector rather than morph all 4 at once (too subtle).
        segs.forEach((s, i) => {
          const el = donut.querySelector(`[data-seg="${i}"]`);
          if (!el) return;
          el.setAttribute('stroke', s.stroke);
          setTimeout(() => {
            el.setAttribute('stroke-dasharray', `${s.dash} ${100 - s.dash}`);
            el.setAttribute('stroke-dashoffset', String(s.offset));
          }, i * STAGGER_MS);
        });
      }

      // Center text re-fade on every render (load + range change). Force a reflow
      // between the .in removal and re-add so the transition actually replays.
      const ringCenter = donut.parentElement?.querySelector('.ring-center');
      if (ringCenter) {
        ringCenter.classList.remove('in');
        // eslint-disable-next-line no-unused-expressions
        ringCenter.offsetWidth; // force reflow
        const startOffset = built ? 0 : 80;
        const totalMs = startOffset + (segs.length - 1) * STAGGER_MS + FILL_MS - 280;
        setTimeout(() => ringCenter.classList.add('in'), totalMs);
      }
    }

    const center = document.querySelector('[data-mix-center-amt]');
    if (center) animateNumber(center, parseAmountFromEl(center), centerMad, { duration: 700, format: v => frMoney(v) });

    /* On retire data-i18n côté venue réelle, sinon i18n.js réimposerait la
     * légende démo au prochain changement de langue ; on le remet pour la démo
     * afin qu'un retour en arrière retrouve sa traduction. */
    const centerUnit = center && center.parentElement
      ? center.parentElement.querySelector('.slash') : null;
    if (centerUnit) {
      if (custom || data._demoLedger) {
        centerUnit.removeAttribute('data-i18n');
        centerUnit.textContent = MIX_CENTER_ALL[lang] || MIX_CENTER_ALL.fr;
      } else {
        const T = window.KiwiI18n?.T?.[lang] || {};
        centerUnit.setAttribute('data-i18n', 'dash.mix.center.unit');
        centerUnit.textContent = T['dash.mix.center.unit'] || 'MAD carte';
      }
    }

    const sub = document.querySelector('[data-mix-sub]');
    if (sub) sub.textContent = RANGE_STR[lang]?.[currentRange] || RANGE_STR.fr[currentRange];

    const legend = document.querySelector('[data-mix-legend]');
    if (legend) {
      // No sales yet is a real answer — say so, rather than print rails at 0 %.
      if (!rows.length) {
        legend.innerHTML = `<div class="li"><div class="n" style="color:var(--n-500,#77807b);">${MIX_EMPTY[lang] || MIX_EMPTY.fr}</div></div>`;
        legend.dataset.built = '';
        legend.dataset.sig = '';
        return;
      }
      // Rows are addressed by label, so a changed tender set needs a fresh build.
      const lsig = rows.map((r) => r.label).join('|');
      if (legend.dataset.sig !== lsig) legend.dataset.built = '';
      legend.dataset.sig = lsig;
      const built = legend.dataset.built === '1';
      if (!built) {
        legend.innerHTML = rows.map(r =>
          `<div class="li"><div class="n"><i style="background:${r.color};"></i>${r.label}</div><div class="v" data-mix-pct="${r.label}">0 %</div></div>`
        ).join('');
        legend.dataset.built = '1';
      }
      rows.forEach(r => {
        const el = legend.querySelector(`[data-mix-pct="${r.label}"]`);
        if (!el) return;
        const from = parseInt((el.textContent || '').replace(/\D/g, ''), 10) || 0;
        animateNumber(el, from, r.pct, { duration: 600, format: v => `${Math.round(v)} %` });
      });
    }
  }

  const PLAN_NAME = { basic: 'Basic', plus: 'Plus', pro: 'Pro', ultra: 'Ultra', ultimate: 'Ultimate' };
  const PLAN_ACTIVE = { fr: 'Plan en cours', en: 'Current plan', ar: 'الخطة الحالية' };
  const PLAN_PENDING = { fr: 'Plan en cours de vérification', en: 'Plan being verified', ar: 'جارٍ التحقق من الخطة' };
  function renderMixPlan(custom, lang) {
    const label = document.querySelector('[data-mix-plan-name]');
    const status = document.querySelector('[data-mix-plan-status]');
    if (!label || !status) return;
    if (document.documentElement.classList.contains('kiwi-native')) {
      label.removeAttribute('data-i18n'); status.removeAttribute('data-i18n');
      label.textContent = 'Kiwi Pro';
      status.textContent = ({fr:'Votre espace de travail', en:'Your workspace', ar:'مساحة عملك'})[lang] || 'Kiwi Pro';
      return;
    }
    if (!custom) {
      label.setAttribute('data-i18n', 'dash.mix.subscription');
      status.setAttribute('data-i18n', 'dash.mix.subscription.price');
      /* The keys stay on the nodes for the next language switch, but this
         render runs after i18n has applied them: writing the French original
         here left « 399 MAD/mois · tout inclus » under English and Arabic. */
      const T = (window.KiwiI18n && window.KiwiI18n.T && window.KiwiI18n.T[lang]) || {};
      label.textContent = T['dash.mix.subscription'] || 'Abonnement Kiwi Pro';
      status.textContent = T['dash.mix.subscription.price'] || '399 MAD/mois · tout inclus';
      return;
    }
    label.removeAttribute('data-i18n');
    status.removeAttribute('data-i18n');
    const raw = String(window.KiwiConfig?.plan || '').toLowerCase();
    label.textContent = PLAN_NAME[raw] ? `Kiwi ${PLAN_NAME[raw]}` : 'Abonnement Kiwi';
    status.textContent = PLAN_NAME[raw]
      ? (PLAN_ACTIVE[lang] || PLAN_ACTIVE.fr)
      : (PLAN_PENDING[lang] || PLAN_PENDING.fr);
  }

  /* ═══════════════ RENDER: LIVE FEED ═══════════════
   * On "aujourdhui" the feed is driven by KiwiDemoClock.cumTx — same
   * source as the dashboard's Commandes KPI tile + the Commandes drawer.
   * At minute :00 of each real hour cumTx = 0 → feed is empty. As the
   * hour progresses, cumTx grows and the feed shows the last 6 orders
   * (cards + mobile + cash, deterministic seeded by venue+date+orderIdx
   * so the same order #57 always looks the same).
   *
   * For non-today ranges (hier / 7j / 30j) the static FEED_BY_VENUE
   * historical samples are still used. */

  /* Deterministic order generator — same (venue, date, idx) always
   * yields the same order object, so the feed visually stabilises and
   * doesn't shuffle on every clock tick. */
  function buildOrder(venue, dateKey, idx) {
    const seedStr = `${venue}-${dateKey}-${idx}`;
    let h = 2166136261;
    for (let i = 0; i < seedStr.length; i++) { h ^= seedStr.charCodeAt(i); h = Math.imul(h, 16777619); }
    const rnd = () => {
      h |= 0; h = (h + 0x6D2B79F5) | 0;
      let t = Math.imul(h ^ (h >>> 15), 1 | h);
      t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
      return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
    };

    /* Payment-method mix: 20% Visa, 20% MC, 15% Tap, 15% QR, 30% cash —
     * realistic for a Moroccan café/restaurant. */
    const r = rnd();
    let method, primary, sub, flag;
    if (r < 0.20) {
      method = 'visa';
      const last4 = String(Math.floor(rnd() * 10000)).padStart(4, '0');
      primary = `Visa •• ${last4}`;
      const banks = [['ma', 'Carte marocaine · Attijariwafa'], ['ma', 'Carte marocaine · BMCE'], ['ma', 'Carte marocaine · CIH'], ['fr', 'Carte française · Société Générale'], ['es', 'Carte espagnole · CaixaBank']];
      const b = banks[Math.floor(rnd() * banks.length)]; flag = b[0]; sub = b[1];
    } else if (r < 0.40) {
      method = 'mc';
      const last4 = String(Math.floor(rnd() * 10000)).padStart(4, '0');
      primary = `Mastercard •• ${last4}`;
      const banks = [['ma', 'Carte marocaine · BOA'], ['ma', 'Carte marocaine · CIH'], ['fr', 'Carte française · BNP Paribas']];
      const b = banks[Math.floor(rnd() * banks.length)]; flag = b[0]; sub = b[1];
    } else if (r < 0.55) {
      method = 'tap'; primary = 'Kiwi Tap'; flag = 'ma'; sub = 'NFC · contactless';
    } else if (r < 0.70) {
      method = 'qr'; primary = 'Kiwi Wallet QR'; flag = 'ma'; sub = 'Client abonné';
    } else {
      method = 'cash'; primary = 'Espèces'; flag = 'ma'; sub = 'Cash · table';
    }

    const customers = ['Karim B.', 'Sara L.', 'Youssef A.', 'Nawal K.', 'Hassan J.', 'Imane M.', 'Mehdi R.', 'Fatima Z.', 'Rachid O.', 'Lina S.', 'Ahmed T.', 'Yasmine H.', 'Julie M.', 'Fadoua K.', 'Hind M.', 'Walid F.', 'Soukaina A.', 'Aïcha R.', 'Brahim K.', 'Salma F.'];
    const customer = customers[Math.floor(rnd() * customers.length)];
    const tableNum = 1 + Math.floor(rnd() * 12);
    const covers = 1 + Math.floor(rnd() * 5); // 1–5 people at the table

    /* Servers — small rotating crew per venue. The same hire roster appears
     * across the dashboard so the names feel familiar to the merchant. */
    const servers = ['Fatima K.', 'Omar B.', 'Naima R.', 'Hicham E.', 'Khadija M.'];
    const server = servers[Math.floor(rnd() * servers.length)];

    /* Items — pull the venue's real menu via KiwiVenue.getMenuItems(). Pick
     * 1–4 dishes with realistic quantities; if the menu isn't loaded yet
     * (early-render race) we fall back to a sensible Café Atlas-style mix. */
    const menu = (window.KiwiVenue?.getMenuItems?.(venue) || []);
    const itemCount = 1 + Math.floor(rnd() * 4); // 1–4 distinct items
    const items = [];
    const usedIds = new Set();
    let computedSubtotal = 0;
    if (menu.length) {
      for (let i = 0; i < itemCount && i < menu.length; i++) {
        let pick, guard = 0;
        do { pick = menu[Math.floor(rnd() * menu.length)]; guard++; }
        while (usedIds.has(pick.id) && guard < 12);
        if (usedIds.has(pick.id)) break;
        usedIds.add(pick.id);
        const qty = 1 + (rnd() < 0.3 ? 1 : 0) + (rnd() < 0.15 ? 1 : 0); // 1–3
        items.push({ id: pick.id, name: pick.name, qty, price: pick.price });
        computedSubtotal += qty * pick.price;
      }
    } else {
      const fallback = [
        { name: 'Tajine kefta',        price: 120 },
        { name: 'Thé à la menthe',     price: 30  },
        { name: 'Café noir',           price: 15  },
        { name: 'Pastilla poulet',     price: 140 },
        { name: "Jus d'avocat",        price: 50  },
        { name: 'Couscous royal',      price: 220 },
      ];
      for (let i = 0; i < itemCount; i++) {
        const pick = fallback[Math.floor(rnd() * fallback.length)];
        const qty = 1 + (rnd() < 0.3 ? 1 : 0);
        items.push({ name: pick.name, qty, price: pick.price });
        computedSubtotal += qty * pick.price;
      }
    }

    /* Tax (TVA 10% restauration au Maroc, 20% spa/services). Use the
     * computed subtotal for the displayed amount so the modal numbers add
     * up — the legacy amt range is dropped in favour of real menu math. */
    const tvaRate = venue === 'spaBahia' ? 0.20 : 0.10;
    const subtotal = Math.round(computedSubtotal * 100) / 100;
    const tva = Math.round(subtotal * tvaRate * 100) / 100;
    const amt = Math.round((subtotal + tva) * 100) / 100;

    /* Receipt number — deterministic, looks like a real POS sequence. */
    const receiptNo = 'TKT-' + String(10000 + Math.floor(rnd() * 89999));

    /* Service duration — 12–75 min, longer for tables with more covers. */
    const serviceMinutes = 12 + Math.floor(rnd() * 50) + covers * 4;

    const fmt = (n) => (window.KiwiNumber?.format(n, { minimumFractionDigits: 2, maximumFractionDigits: 2 }) ?? n.toLocaleString(document.documentElement?.lang === 'en' ? 'en-GB' : 'fr-FR', { minimumFractionDigits: 2, maximumFractionDigits: 2 }));
    return {
      method, primary, sub, flag,
      customer, table: tableNum,
      ctx: `${customer} · T${tableNum}`,
      amt: fmt(amt),
      amtRaw: amt,
      neg: false,
      /* Rich detail used by the order-detail drawer. */
      receiptNo, server, covers, serviceMinutes,
      items,
      subtotal: fmt(subtotal),
      tva: fmt(tva),
      tvaRate: Math.round(tvaRate * 100),
      total: fmt(amt),
    };
  }

  /* Pull the last 6 orders from the simulator's current cumTx. */
  function buildLiveFeed(venue) {
    const rows = window.KiwiDemoClock?.getDaySales?.() || [];
    const fmt = n => (window.KiwiNumber?.format(n, {minimumFractionDigits:2, maximumFractionDigits:2}) ?? n.toLocaleString(document.documentElement?.lang === 'en' ? 'en-GB' : 'fr-FR', {minimumFractionDigits:2, maximumFractionDigits:2}));
    return rows.slice(-10).reverse().map((sale, slot) => ({
      method:sale.method === 'card' ? 'visa' : sale.method === 'wallet' ? 'qr' : 'cash',
      primary:sale.method === 'card' ? 'Visa' : sale.method === 'wallet' ? 'Kiwi Wallet QR' : ({en:'Cash',ar:'نقداً'}[(window.KiwiI18n?.getLang?.() || 'fr')] || 'Espèces'),
      sub:'', flag:'ma', customer:sale.customer, table:sale.table,
      ctx:sale.customer + ' · T' + sale.table,
      amt:fmt(sale.amount), amtRaw:sale.amount, neg:false, receiptNo:sale.ref,
      server:sale.staff, covers:1, serviceMinutes:0,
      items:sale.lines.map(line => ({n:line.name, name:line.name, q:line.qty, qty:line.qty, p:line.price, price:line.price, total:line.total})),
      subtotal:fmt(sale.amount), tva:fmt(0), tvaRate:0, total:fmt(sale.amount),
      t:new Date(sale.ts).toLocaleTimeString('en-GB',{hour:'2-digit',minute:'2-digit',timeZone:(globalThis.KiwiZoneLaw?.effectiveZone(window.KiwiDayReport?.timezone?.(), sale.ts) || window.KiwiDayReport?.timezone?.())}), isNew:slot===0
    }));
  }

  // Feed rows for a user-created venue — newest 8 of the merchant's sales.
  function buildCustomFeed(venue) {
    /* Bornées à la MÊME période que le sous-titre affiché juste au-dessus.
     * Ce `.slice(-8)` prenait les huit dernières ventes de tout l'historique,
     * pendant que le sous-titre, lui, comptait « N commandes aujourd'hui » sur
     * la seule journée. Un commerçant qui n'avait encore rien vendu ce matin
     * lisait donc « 0 commande aujourd'hui » posé sur trois tickets d'hier — et
     * comme les lignes ne portent que l'heure, rien ne trahissait leur date. Le
     * titre du panneau rendait la chose pire : ces ventes-là n'étaient ni en
     * direct, ni du jour. */
    const [lo, hi] = rangeBounds(currentRange);
    const sales = (window.KiwiSales?.list?.(venue) || []).concat(
      (window.KiwiRefunds?.list?.(venue) || []).map((r) => ({ ...r, amount: -Math.abs(+r.amount || 0), kind: 'refund' }))
    )
      .filter((s) => { const ts = +(s && s.ts) || 0; return ts >= lo && ts < hi; })
      .sort((a, b) => (+a.ts || 0) - (+b.ts || 0)).slice(-8).reverse();
    const lang = getLang();
    /* Every method the till can actually record (see live-link METHOD_LABEL).
     * `cash` was missing, so `L[s.method] || L.card` relabelled EVERY cash sale
     * as "Carte bancaire" — on a Moroccan boutique dashboard, where cash is the
     * dominant tender, the owner could not tell cash from card on their own
     * feed. */
    const ML = {
      fr: { cash: 'Espèces', card: 'Carte bancaire', tap: 'Kiwi Tap', qr: 'QR Kiwi Wallet', wallet: 'Kiwi Wallet', link: 'Lien de paiement', transfer: 'Virement / Versement', cheque: 'Chèque', split: 'Paiement partagé', credit: 'Crédit client', delivery: 'Livraison · à recevoir', sub: 'Vente encaissée', deliverySub: 'Vente enregistrée · non encaissée' },
      en: { cash: 'Cash', card: 'Bank card', tap: 'Kiwi Tap', qr: 'QR Kiwi Wallet', wallet: 'Kiwi Wallet', link: 'Payment link', transfer: 'Bank transfer', cheque: 'Cheque', split: 'Split payment', credit: 'Customer credit', delivery: 'Delivery · receivable', sub: 'Sale recorded', deliverySub: 'Sale recorded · unpaid' },
      ar: { cash: 'نقدًا', card: 'بطاقة بنكية', tap: 'Kiwi Tap', qr: 'QR Kiwi Wallet', wallet: 'Kiwi Wallet', link: 'رابط الدفع', transfer: 'تحويل بنكي', cheque: 'شيك', split: 'دفع مقسّم', credit: 'دين العميل', delivery: 'توصيل · مبلغ مستحق', sub: 'عملية بيع مسجّلة', deliverySub: 'بيع مسجّل · غير محصّل' },
    };
    /* Chip art per method. The till records the TENDER, never the card network,
     * so a card sale gets the neutral card chip — printing a Visa or Mastercard
     * mark here would invent a fact the sale does not carry. */
    const ICON_FOR = { cash: 'cash', card: 'cmi', tap: 'tap', qr: 'qr', wallet: 'qr', link: 'qr', transfer: 'qr', cheque: 'qr', split: 'cmi', credit: 'qr', delivery: 'qr' };
    const L = ML[lang] || ML.fr;
    const num = (n) => window.KiwiNumber?.number(Math.abs(n || 0), 2) ?? new Intl.NumberFormat(document.documentElement?.lang === 'en' ? 'en-GB' : 'fr-FR', {minimumFractionDigits:2,maximumFractionDigits:2}).format(Math.abs(n || 0));
    /* A delivery (or customer credit) is stored at 0 MAD: no money came in that
     * day. The amount owed rides on the sale, in its delivery parts or its
     * basket, so the row shows what is to receive instead of 0. */
    const basketOf = (s) => (Array.isArray(s.lines) ? s.lines : []).reduce((n, l) => n + (+(l && l.total) || 0), 0);
    const owedOf = (s) => {
      const parts = Array.isArray(s.paymentParts) ? s.paymentParts : [];
      const cents = parts.reduce((n, p) => n + (p && p.method === s.method ? (+p.amountCents || 0) : 0), 0);
      return cents > 0 ? cents / 100 : basketOf(s);
    };
    return sales.map((s, i) => {
      const d = new Date(s.ts);
      const t = String(d.getHours()).padStart(2, '0') + ':' + String(d.getMinutes()).padStart(2, '0');
      const isRefund = s.kind === 'refund' || Number(s.amount) < 0;
      const toReceive = !isRefund && (s.method === 'delivery' || s.method === 'credit');
      const shown = toReceive ? Math.max(Math.abs(+s.amount || 0), owedOf(s)) : Math.abs(s.amount || 0);
      const items = (Array.isArray(s.lines) ? s.lines : []).filter((l) => l && l.name).map((l) => {
        const qty = Math.max(1, +l.qty || 1);
        return { name: l.name, qty, price: (+l.total || 0) / qty };
      });
      return {
        t,
        method: ICON_FOR[s.method] || 'cmi',
        primary: isRefund ? (lang === 'en' ? 'Refund' : lang === 'ar' ? 'استرداد' : 'Remboursement') : (L[s.method] || L.card),
        /* The "who/what" column. On a boutique the useful identifier is the item,
         * which the sale now carries — a row reading "Chemise en lin" is what the
         * owner needs to find the original sale when that customer returns. Falls
         * back to the generic subtitle only when the till sent no label. */
        sub: isRefund ? (s.ref || '') : ((s.method === 'delivery' || s.method === 'credit') ? L.deliverySub : L.sub), flag: '', ctx: s.label || '',
        // Amount ONLY — the row template appends its own <span class="cur">MAD</span>,
        // so spelling the unit here too printed "450,00 MADMAD" on every real sale.
        amt: (isRefund ? '− ' : '') + num(shown),
        /* Detail drawer: the basket and its total; a delivery reads « à recevoir ». */
        items, subtotal: num(shown), total: num(shown), tva: num(0), tvaRate: 0, toReceive,
        tip: '·', neg: isRefund, isNew: i === 0,
        saleId: String(s.id || ''),
        ref: String(s.ref || s.receiptRef || s.id || '').trim(),
        receiptNo: String(s.ref || s.receiptRef || '').trim(),
      };
    });
  }

  function renderFeed() {
    const lang = getLang();
    const effective = effRange();
    const isLive = effective === 'aujourdhui';

    /* Cached tx rows carry FR payment strings baked at generation time —
     * translate the known method strings at render time so a language switch
     * applies to feeds that were already generated. */
    const PAY_TR = {
      'Espèces': { en: 'Cash', ar: 'نقدًا' },
      'Cash · table': { en: 'Cash · at the table', ar: 'نقدًا · على الطاولة' },
      'Client abonné': { en: 'Subscribed client', ar: 'عميل مشترك' },
      'NFC · contactless': { en: 'NFC · contactless', ar: 'NFC · بدون تلامس' },
    };
    const PAY_PREFIX = [
      ['Carte marocaine', { en: 'Moroccan card', ar: 'بطاقة مغربية' }],
      ['Carte française', { en: 'French card', ar: 'بطاقة فرنسية' }],
      ['Carte espagnole', { en: 'Spanish card', ar: 'بطاقة إسبانية' }],
    ];
    const trPay = (s) => {
      if (!s || lang === 'fr') return s;
      const hit = PAY_TR[s];
      if (hit) return hit[lang] || s;
      for (const [pre, tr2] of PAY_PREFIX) {
        if (s.indexOf(pre) === 0) return (tr2[lang] || pre) + s.slice(pre.length);
      }
      return s;
    };

    const venue = window.KiwiVenue?.getVenue?.() || 'cafeAtlas';
    // A user-created venue's feed is built from the merchant's own recorded
    // sales — empty state until the first one is rung up.
    //
    // The `isReal` arm matters as much as the `isCustom` one. A real session on
    // a venue id that isn't flagged custom used to fall through to the static
    // demo feed, and those rows do not just sit on screen: renderFeed caches
    // them in window.__kiwiFeedOrders, which the assistant reads as "les
    // dernières commandes encaissées" and puts in the model's prompt. Demo
    // covers, demo servers, demo tickets, quoted back as the merchant's own.
    const rows = ownData(venue) ? buildCustomFeed(venue)
      : isLive ? buildLiveFeed(venue) : vData(FEED_BY_VENUE, currentRange);
    const wrap = document.querySelector('[data-feed]');

    if (wrap) {
      if (!rows || rows.length === 0) {
        /* Empty state — start of hour, no orders yet. */
        const fe = tradeStr('feedEmpty', FEED_EMPTY[lang] || FEED_EMPTY.fr);
        wrap['inner' + 'HTML'] = `
          <div style="padding: 38px 18px 42px; text-align: center; display: flex; flex-direction: column; align-items: center;">
            <div style="width: 44px; height: 44px; border-radius: 13px; background: rgba(11,110,79,0.10); border: 1px solid rgba(11,110,79,0.18); color: var(--atlas); display: grid; place-items: center; margin-bottom: 14px;">
              <svg width="22" height="22" viewBox="0 -960 960 960" fill="currentColor" aria-hidden="true"><path d="M200-80q-33 0-56.5-23.5T120-160v-451q-18-11-29-28.5T80-680v-120q0-33 23.5-56.5T160-880h640q33 0 56.5 23.5T880-800v120q0 23-11 40.5T840-611v451q0 33-23.5 56.5T760-80H200Zm0-520v440h560v-440H200Zm-40-80h640v-120H160v120Zm200 280h240v-80H360v80Zm120 20Z"/></svg>
            </div>
            <div style="display:inline-flex; align-items:center; gap:8px; padding:4px 12px; background:var(--paper-soft); border-radius:999px; font-family:var(--mono); font-size:11px; letter-spacing:0.06em; color:var(--n-600); margin-bottom:8px; border:1px solid var(--n-200);">
              <span class="pulse-dot" style="width:6px; height:6px; background:var(--atlas);"></span>${escTxt(fe.badge)}
            </div>
            <div style="font-weight: 600; color: var(--ink); font-size: 14.5px; letter-spacing: -0.01em;">${escTxt(fe.title)}</div>
            <div style="margin-top: 4px; font-size: 12.5px; color: var(--n-500); max-width: 36ch; line-height: 1.45;">${escTxt(fe.sub)}</div>
          </div>
        `;
      } else {
        /* Cache the rich order objects so the click handler can pull full
         * detail (items, server, breakdown) from a stable key — avoids
         * round-tripping JSON through DOM attributes. */
        window.__kiwiFeedOrders = {};
        /* Rows cascade on data changes; live ticks rebuild without replay
         * (the .new row keeps its own slide-in). */
        wrap.classList.toggle('feed-anim', !liveTickInProgress);
        wrap.innerHTML = rows.map((r, idx) => {
          const key = `o${idx}`;
          window.__kiwiFeedOrders[key] = r;

          /* Official brand assets live under assets/icons/ (downloaded by
           * the merchant): Visa SVG with proper gradient, Mastercard PNG
           * interlocking circles, illustrated cash bills, scannable QR.
           * NFC stays inline — there's no neutral third-party mark for it. */
          const ICONS = {
            visa: `<img src="assets/icons/visa.svg" alt="Visa">`,
            mc:   `<img src="assets/icons/mastercard.png" alt="Mastercard">`,
            cash: `<img src="assets/icons/cash.webp" alt="Espèces">`,
            tap:  `<i data-lucide="contactless" aria-hidden="true"></i>`,
            qr:   `<img src="assets/icons/qr-code.png" alt="QR">`,
            /* Neutral card chip — used when we know a card was tapped/inserted
             * but not which network. Never substitute a Visa/MC mark here. */
            cmi:  `<i data-lucide="credit-card" aria-hidden="true"></i>`,
          };
          const chipInner = ICONS[r.method] || '';

          /* Table promoted to a circular badge so the row scans as
           * "seat → person → amount" instead of running text together. */
          const tableChip = (r.table != null)
            ? `<span class="t-chip" aria-label="Table ${escTxt(r.table)}">T${escTxt(r.table)}</span>`
            : '';
          /* `ctx` is the till's sale label and `sub` a refund's ref: free text
           * typed at any till, stored raw by POST /api/sale. It goes through
           * innerHTML here, so every user-controlled field is escaped. */
          const who = escTxt(r.customer ? r.customer : (r.ctx || ''));

          return `
          <div class="feed-row${r.isNew ? ' new' : ''}" style="--i:${idx};" tabindex="0" role="button" data-action="open-order" data-order-key="${key}">
            <div class="t">${escTxt(r.t)}</div>
            <div class="method">
              <div class="ci ${escTxt(r.method)}">${chipInner}</div>
              <div class="desc">
                <div class="primary">${escTxt(trPay(r.primary))}</div>
                <div class="sub"><span class="flag ${escTxt(r.flag)}"></span>${escTxt(trPay(r.sub))}</div>
              </div>
            </div>
            <div class="ctx">${tableChip}<span class="who">${who}</span></div>
            <div class="amt"${r.neg ? ' style="color: var(--danger);"' : ''}>${r.amt}<span class="cur">${curUnit()}</span></div>
            <div class="more" aria-hidden="true"><i data-lucide="chevron-right" width="14" height="14"></i></div>
          </div>
        `;
        }).join('');
      }
    }
    const titleEl = document.querySelector('[data-feed-title]');
    if (titleEl) titleEl.textContent = FEED_TITLE[lang]?.[currentRange] || FEED_TITLE.fr[currentRange];
    const subEl = document.querySelector('[data-feed-sub]');
    if (subEl) {
      if (isLive && rows && rows.length === 0) {
        subEl.textContent = tradeStr('feedAwait',
            lang === 'en' ? 'Service open · awaiting first order'
          : lang === 'ar' ? 'الخدمة مفتوحة · في انتظار الطلب الأول'
          : 'Service ouvert · en attente de la 1ʳᵉ commande');
      } else if (isLive) {
        /* Live subtitle reflects the actual row count + total today.
         * A REAL merchant's count must come from their OWN sales: the demo
         * clock keeps simulating in the background, so reading its cumTx here
         * printed "98 commandes aujourd'hui" on a store that had rung 2. */
        let cumTx;
        if (ownData() && window.KiwiSales) {
          const [t0, t1] = rangeBounds('aujourdhui');
          let sales = [];
          try { sales = window.KiwiSales.list(getCurrentVenue()) || []; } catch (_) { sales = []; }
          cumTx = sales.filter((s) => {
            const ts = +(s && s.ts) || 0;
            /* Un ticket réglé entièrement par avoir (0 MAD, méthode credit) est
             * une vente : la bande le compte, la page Ventes aussi. Il manquait
             * ici, et l'accueil disait « 67 commandes » sous « 68 ventes ». */
            return ts >= t0 && ts < t1 && String(s.kind || '') !== 'refund'
              && (Number(s.amount) > 0 || (Number(s.amount) === 0 && /^(credit|avoir)/i.test(String(s.method || ''))));
          }).length;
        } else {
          const sim = window.KiwiDemoClock?.getSimState?.();
          cumTx = sim?.cumTx ?? 0;
        }
        const n = rows.length;
        const word = lang === 'en' ? 'last' : lang === 'ar' ? 'آخر' : (n < 2 ? 'dernière' : 'dernières');
        const total = lang === 'en' ? `· ${cumTx} today`
                    : lang === 'ar' ? `· ${cumTx} اليوم`
                    : `· ${cumTx} commande${cumTx > 1 ? 's' : ''} aujourd'hui`;
        subEl.textContent = `${n} ${word} ${total}`;
      } else {
        subEl.textContent = FEED_SUB[lang]?.[currentRange] || FEED_SUB.fr[currentRange];
      }
    }
    const strip = (x) => String(x == null ? '' : x).replace(/<[^>]*>/g, '');
    const feedEmpty = tradeStr('feedEmpty', FEED_EMPTY[lang] || FEED_EMPTY.fr);
    typeof homeSet === 'function' && homeSet('feed', {
      title: titleEl ? titleEl.textContent : '', sub: subEl ? subEl.textContent : '', unit: curUnit(),
      empty: { title: feedEmpty.title, sub: feedEmpty.sub },
      rows: (rows || []).map((r, idx) => ({ key: `o${idx}`, time: strip(r.t), primary: strip(trPay(r.primary)), sub: strip(trPay(r.sub)),
        table: r.table == null ? null : r.table, who: strip(r.customer ? r.customer : (r.ctx || '')), amount: strip(r.amt), neg: !!r.neg })),
    });
  }

  /* ═══════════════ RENDER: SETTLEMENT ═══════════════ */

  function renderSettle() {
    const lang = getLang();
    const effective = effRange();
    const data = vData(settleByVenue, currentRange);
    if (!data) return;

    const lblEl = document.querySelector('[data-settle-lbl]');
    if (lblEl) lblEl.textContent = SETTLE_LBL[lang]?.[currentRange] || SETTLE_LBL.fr[currentRange];

    const amtEl = document.querySelector('[data-settle-amt]');
    if (amtEl) animateNumber(amtEl, parseIntFromEl(amtEl), data.amt, { duration: 800, format: fmtSettleAmount });

    const subEl = document.querySelector('[data-settle-sub]');
    if (subEl) subEl.textContent = data.sub;

    const detailEl = document.querySelector('[data-settle-detail]');
    if (detailEl) {
      detailEl.innerHTML = `
        <span>${SETTLE_DETAIL_LBL[lang] || SETTLE_DETAIL_LBL.fr}</span>
        <span style="color: var(--mint); font-family: var(--mono);">${data.detailVal}</span>
      `;
    }
  }

  /* ═══════════════ RENDER: EVENING SERVICE + STOCK (custom-venue aware) ═══
   * These two right-rail cards are static Café Atlas markup. On a user-created
   * venue they would otherwise leak Café Atlas reservations / stock alerts, so
   * we capture the original HTML once and swap in a clean empty state. */
  let _eveningOrig = null, _stockOrig = null;

  const EVENING_EMPTY = {
    fr: { lbl: 'SERVICE DU SOIR · CE SOIR', head: 'Aucune réservation',
          msg: 'Vos réservations du soir s’afficheront ici dès qu’un client réserve une table.' },
    en: { lbl: 'EVENING SERVICE · TONIGHT', head: 'No reservations',
          msg: 'Your evening reservations will appear here as soon as a guest books a table.' },
    ar: { lbl: 'خدمة المساء · الليلة', head: 'لا توجد حجوزات',
          msg: 'ستظهر حجوزات المساء هنا بمجرد أن يحجز أحد الزبائن طاولة.' },
  };
  const STOCK_EMPTY = {
    fr: { title: 'Stock à recommander', head: 'Aucune alerte de stock',
          msg: 'Dès que vous suivez vos ingrédients, Kiwi vous signale ce qui passe sous votre seuil d\'alerte.' },
    en: { title: 'Stock to reorder', head: 'No stock alerts',
          msg: 'Once you track your ingredients, Kiwi flags what drops below your alert level.' },
    ar: { title: 'مخزون للطلب', head: 'لا توجد تنبيهات مخزون',
          msg: 'بمجرد تتبّع مكوّناتك، ينبّهك Kiwi إلى ما ينزل تحت حدّ التنبيه.' },
  };

  /* Ces deux cartes n'existent que dans la démo. Pour un vrai commerce, Kiwi
   * ne calcule aucun score de santé et ne détient aucune cohorte de
   * comparaison : l'état vide promettait « après vos premières semaines » un
   * chiffre qui ne serait jamais venu. La carte est donc masquée ; le texte
   * ci-dessous ne sert qu'à ne laisser aucun chiffre de démo dans le DOM. */
  const HEALTH_EMPTY = {
    fr: { title: 'Score de santé Kiwi', head: 'Non disponible', msg: 'Kiwi ne calcule pas de score de santé pour votre établissement.' },
    en: { title: 'Kiwi health score', head: 'Not available', msg: 'Kiwi does not compute a health score for your venue.' },
    ar: { title: 'نقاط صحة Kiwi', head: 'غير متاح', msg: 'لا يحسب Kiwi نقاط صحة لمنشأتك.' },
  };
  const BENCH_EMPTY = {
    fr: { title: 'Vous vs établissements similaires', head: 'Non disponible', msg: 'Kiwi ne dispose d’aucune donnée d’établissements comparables.' },
    en: { title: 'You vs similar venues', head: 'Not available', msg: 'Kiwi holds no data on comparable venues.' },
    ar: { title: 'أنت مقابل منشآت مماثلة', head: 'غير متاح', msg: 'لا يملك Kiwi بيانات عن منشآت مماثلة.' },
  };
  const PRODUCTS_EMPTY = {
    fr: { sub: 'Aucune vente enregistrée', msg: 'Vos meilleures ventes s’afficheront ici dès la première commande.' },
    en: { sub: 'No sales recorded', msg: 'Your best sellers will appear here after the first order.' },
    ar: { sub: 'لا مبيعات مسجّلة', msg: 'ستظهر أفضل مبيعاتك هنا بعد أوّل طلب.' },
  };
  const PRODUCTS_COVERAGE = {
    fr: (items, covered, total) => `${items} article${items > 1 ? 's' : ''} · détail disponible sur ${covered}/${total} vente${total > 1 ? 's' : ''}`,
    en: (items, covered, total) => `${items} item${items > 1 ? 's' : ''} · line detail available for ${covered}/${total} sale${total > 1 ? 's' : ''}`,
    ar: (items, covered, total) => `${items} منتج · تفاصيل ${covered}/${total} عملية بيع متاحة`,
  };
  const PRODUCTS_NO_LINES = {
    fr: (n) => `Aucune ligne article enregistrée dans ${n} vente${n > 1 ? 's' : ''}. Les totaux restent exacts, mais Kiwi ne peut pas classer les produits.`,
    en: (n) => `No item lines were recorded in ${n} sale${n > 1 ? 's' : ''}. Totals remain accurate, but Kiwi cannot rank products.`,
    ar: (n) => `لا توجد تفاصيل منتجات في ${n} عملية بيع. الإجماليات صحيحة، لكن لا يمكن ترتيب المنتجات.`,
  };
  const PRODUCT_SOLD = {
    fr: (n) => `${n} vendu${n > 1 ? 's' : ''}`,
    en: (n) => `${n} sold`,
    ar: (n) => `${n} مبيع`,
  };
  /* ── Stock à recommander · inventaire réel ───────────────────────────────
   * Boutique and restaurant use different stores and different thresholds;
   * both adapters return the same small, auditable shape to the card. */
  const LOW_STOCK_SEUIL = 5;
  const STOCK_TITLE_STR = { fr: 'Stock à recommander', en: 'Stock to reorder', ar: 'مخزون لإعادة الطلب' };
  const RUPTURE_STR = { fr: 'Rupture · à racheter', en: 'Out of stock · reorder', ar: 'نفد المخزون · أعد الطلب' };
  const LOWSTK_STR = {
    fr: (s) => `Stock bas · seuil ${s}`,
    en: (s) => `Low stock · threshold ${s}`,
    ar: (s) => `مخزون منخفض · العتبة ${s}`,
  };
  const STOCK_SUB_STR = {
    fr: (n) => `${n} article${n > 1 ? 's' : ''} sous le seuil`,
    en: (n) => `${n} item${n > 1 ? 's' : ''} below threshold`,
    ar: (n) => `${n} منتج تحت العتبة`,
  };
  const STOCK_OK_STR = {
    fr: (n) => `Rien à recommander : ${n > 1 ? `${n} articles sont au-dessus de leur seuil configuré` : `${n} article est au-dessus de son seuil configuré`}.`,
    en: (n) => `Nothing to reorder: ${n > 1 ? `${n} items are above their configured thresholds` : `${n} item is above its configured threshold`}.`,
    ar: (n) => `لا شيء لإعادة طلبه: ${n} منتج فوق العتبة المحددة.`,
  };
  const STOCK_NO_THRESHOLDS = {
    fr: (n) => `${n} article${n > 1 ? 's sont suivis' : ' est suivi'}, mais aucun seuil de réapprovisionnement n’est configuré.`,
    en: (n) => `${n} item${n > 1 ? 's are' : ' is'} tracked, but no reorder threshold is configured.`,
    ar: (n) => `يتم تتبع ${n} منتج، لكن لم يتم تحديد عتبة إعادة الطلب.`,
  };
  /* Les noms d'articles sont saisis par le commerçant : ils passent par du HTML,
   * donc ils s'échappent. dateRange.js n'avait pas d'esc() — les autres listes
   * n'affichent que des libellés de démo. */
  const escTxt = (s) => String(s == null ? '' : s)
    .replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');
  function realLowStock() {
    try {
      const type = window.KiwiVenue?.getVenueType?.();
      if (type === 'restaurant' && window.KiwiRestaurantStock?.items) {
        const items = window.KiwiRestaurantStock.items() || [];
        if (!items.length) return null;
        const configured = items.filter((it) => Number(it.reorderLevel) > 0);
        const rows = configured.map((it) => {
          const stock = Number(it.currentStock) || 0; // Montrer aussi le déficit réel.
          const threshold = Math.max(0, Number(it.reorderLevel) || 0);
          const par = Math.max(threshold, Number(it.parLevel) || threshold);
          const suggested = Math.max(0, Math.round((par * 1.2 - stock) * 10) / 10);
          return { id: it.id, name: it.name, stock, threshold, par, suggested,
            unit: it.unit || 'unité', cost: Math.max(0, Number(it.costPerUnit) || 0) };
        }).filter((r) => r.stock < r.threshold)
          .sort((a, b) => (a.stock / a.threshold) - (b.stock / b.threshold))
          .slice(0, 5);
        return { rows, tracked: items.length, configured: configured.length, source: 'restaurant' };
      }
      if (type === 'boutique') {
        const cat = window.KiwiBoutiqueCatalog;
        if (!cat) return null;
        const key = window.KiwiBoutiqueVenueKey && window.KiwiBoutiqueVenueKey();
        if (key) cat.use(key);
        const prods = cat.listProducts() || [];
        if (!prods.length) return null;
        const rows = prods.map((p) => ({ id: p.id, name: p.name, stock: cat.productStock(p.id), threshold: LOW_STOCK_SEUIL }))
          .filter((r) => r.stock <= LOW_STOCK_SEUIL).sort((a, b) => a.stock - b.stock).slice(0, 5);
        return { rows, tracked: prods.length, configured: prods.length, source: 'boutique' };
      }
    } catch (_) { return null; }
    return null;
  }

  function realTopProducts(range) {
    const [from, to] = rangeBounds(range == null ? currentRange : range);
    /* Une ligne boutique porte la taille dans son nom (« Hoodie Blue M ») et une
       variante `prod_7:M:bleu`. On nomme le produit, pas la première taille
       vendue ; un plat de restaurant (sans variante de ce format) ne change pas. */
    const productLabel = (line) => {
      const name = String((line && line.name) || ''), item = String((line && line.itemId) || ''), variant = String((line && line.variantId) || '');
      if (!item || variant.indexOf(item + ':') !== 0) return name;
      const size = variant.slice(item.length + 1).split(':')[0];
      return size && name.length > size.length + 1 && name.endsWith(' ' + size) ? name.slice(0, -(size.length + 1)) : name;
    };
    const sales = realSalesList().filter((e) => (+e.ts || 0) >= from && (+e.ts || 0) < to);
    const by = new Map(); let covered = 0;
    sales.forEach((sale) => {
      const lines = Array.isArray(sale.lines) ? sale.lines.filter((l) => l && l.name && (+l.qty || 0) > 0) : [];
      if (!lines.length) return;
      covered++;
      lines.forEach((line) => {
        const key = String(line.itemId || line.variantId || line.name).trim().toLowerCase();
        const qty = Math.max(0, Number(line.qty) || 0);
        const revenue = Math.max(0, Number(line.total) || ((Number(line.price) || 0) * qty));
        const row = by.get(key) || { name: productLabel(line), qty: 0, revenue: 0 };
        row.qty += qty; row.revenue += revenue; by.set(key, row);
      });
    });
    const rows = [...by.values()].sort((a, b) => b.qty - a.qty || b.revenue - a.revenue).slice(0, 5);
    return { rows, sales: sales.length, covered };
  }

  /* ── « Souvent pris ensemble » ─────────────────────────────────────────────
   * Les paires d'articles que les tickets RÉELS de la période réunissent. On
   * ne montre une paire que si elle a été prise ensemble au moins
   * PAIRS_MIN_TOGETHER fois, et seulement à partir de PAIRS_MIN_BASKETS
   * tickets à plusieurs articles : en dessous, trois tickets « thé + msemen »
   * feraient une règle de ce qui n'est qu'un hasard. Chaque paire dit sa
   * preuve : combien de tickets, et quelle part des tickets de l'article le
   * moins vendu des deux contenaient aussi l'autre. Mêmes clés d'article que
   * le classement juste au-dessus (realTopProducts). */
  const PAIRS_MIN_BASKETS = 20, PAIRS_MIN_TOGETHER = 5, PAIRS_MAX_KEYS = 40;
  function realPairs(range) {
    const [from, to] = rangeBounds(range == null ? currentRange : range);
    /* Une ligne boutique porte la taille dans son nom (« Hoodie Blue M ») et une
       variante `prod_7:M:bleu`. On nomme le produit, pas la première taille
       vendue ; un plat de restaurant (sans variante de ce format) ne change pas. */
    const productLabel = (line) => {
      const name = String((line && line.name) || ''), item = String((line && line.itemId) || ''), variant = String((line && line.variantId) || '');
      if (!item || variant.indexOf(item + ':') !== 0) return name;
      const size = variant.slice(item.length + 1).split(':')[0];
      return size && name.length > size.length + 1 && name.endsWith(' ' + size) ? name.slice(0, -(size.length + 1)) : name;
    };
    const seen = new Map(), names = new Map(), together = new Map();
    let baskets = 0;
    realSalesList().forEach((sale) => {
      const ts = +sale.ts || 0;
      if (ts < from || ts >= to) return;
      const keys = new Set();
      (Array.isArray(sale.lines) ? sale.lines : []).forEach((l) => {
        if (!l || !l.name || !((+l.qty || 0) > 0)) return;
        const k = String(l.itemId || l.variantId || l.name).trim().toLowerCase();
        if (!k || keys.size >= PAIRS_MAX_KEYS) return;
        keys.add(k);
        if (!names.has(k)) names.set(k, productLabel(l));
      });
      keys.forEach((k) => seen.set(k, (seen.get(k) || 0) + 1));
      if (keys.size < 2) return;
      baskets++;
      const ks = [...keys].sort();
      for (let i = 0; i < ks.length; i++) {
        for (let j = i + 1; j < ks.length; j++) {
          const pk = ks[i] + '\u0000' + ks[j];
          together.set(pk, (together.get(pk) || 0) + 1);
        }
      }
    });
    if (baskets < PAIRS_MIN_BASKETS) return { rows: [], baskets };
    const rows = [...together].filter(([, n]) => n >= PAIRS_MIN_TOGETHER).map(([pk, n]) => {
      const [x, y] = pk.split('\u0000');
      const lead = (seen.get(x) || 0) <= (seen.get(y) || 0) ? x : y;
      const other = lead === x ? y : x;
      return { lead: names.get(lead), other: names.get(other), together: n, share: n / Math.max(1, seen.get(lead) || 0) };
    }).sort((p, q) => q.together - p.together || q.share - p.share || String(p.lead).localeCompare(String(q.lead))).slice(0, 3);
    return { rows, baskets };
  }
  const PAIRS_STR = {
    fr: { t: 'Souvent pris ensemble',
          why: (n, pct, lead) => `${n} tickets · ${pct} % des tickets avec ${lead}`,
          wait: (n, min) => `Les articles souvent pris ensemble apparaîtront à partir de ${min} tickets à plusieurs articles sur la période (${n} pour l’instant).`,
          none: (n) => `Aucune paire ne revient encore assez souvent sur ces ${n} tickets à plusieurs articles.` },
    en: { t: 'Often bought together',
          why: (n, pct, lead) => `${n} tickets · ${pct}% of tickets with ${lead}`,
          wait: (n, min) => `Items often bought together will appear from ${min} multi-item tickets in the period (${n} so far).`,
          none: (n) => `No pair comes back often enough yet across these ${n} multi-item tickets.` },
    ar: { t: 'يُشترى معاً غالباً',
          why: (n, pct, lead) => `${n} تذاكر · ${pct}٪ من التذاكر التي فيها ${lead}`,
          wait: (n, min) => `ستظهر المنتجات التي تُشترى معاً ابتداءً من ${min} تذكرة بعدة منتجات خلال الفترة (${n} حتى الآن).`,
          none: (n) => `لا يتكرر أي زوج بما يكفي بعد في هذه التذاكر الـ${n} ذات المنتجات المتعددة.` },
  };
  function renderPairs(card, isCustom, lang) {
    const host = card && card.querySelector('[data-products-pairs]');
    if (!host) return;
    const p = isCustom ? realPairs(currentRange) : null;
    if (!p || !p.baskets) { host.hidden = true; host.replaceChildren(); return; }
    const S = PAIRS_STR[lang] || PAIRS_STR.fr;
    const head = `<div class="pp-t">${escTxt(S.t)}</div>`;
    if (p.baskets < PAIRS_MIN_BASKETS) {
      host.innerHTML = head + `<div class="pp-wait">${escTxt(S.wait(frInt(p.baskets), frInt(PAIRS_MIN_BASKETS)))}</div>`;
    } else if (!p.rows.length) {
      host.innerHTML = head + `<div class="pp-wait">${escTxt(S.none(frInt(p.baskets)))}</div>`;
    } else {
      host.innerHTML = head + p.rows.map((r) => `
        <div class="pp-row">
          <div class="pp-n">${escTxt(r.lead)}<span class="pp-plus" aria-hidden="true">+</span>${escTxt(r.other)}</div>
          <div class="pp-why">${escTxt(S.why(frInt(r.together), frInt(Math.round(r.share * 100)), r.lead))}</div>
        </div>`).join('');
    }
    host.hidden = false;
  }

  const STAFF_ONDUTY_STR = {
    fr: (n, tot) => `${n} sur ${tot} en service aujourd'hui`,
    en: (n, tot) => `${n} of ${tot} on shift today`,
    ar: (n, tot) => `${n} من ${tot} في الخدمة اليوم`,
  };
  const fmtHeures = (h) => `${(window.KiwiNumber?.format(h, { minimumFractionDigits: 0, maximumFractionDigits: 2 }) ?? h.toLocaleString(document.documentElement?.lang === 'en' ? 'en-GB' : 'fr-FR', { minimumFractionDigits: 0, maximumFractionDigits: 2 }))} h`;
  /* team.js se charge APRÈS ce fichier : au premier rendu KiwiTeam n'existe pas
   * encore et on renvoie null, ce qui laisse l'état vide d'origine. Le listener
   * 'kiwi-team-ready' plus bas repeint la carte dès que le roster est publié. */
  function realRoster() {
    try { return (window.KiwiTeam && window.KiwiTeam.roster) ? window.KiwiTeam.roster() : null; }
    catch (_) { return null; }
  }

  const STAFF_EMPTY = {
    fr: { sub: 'Aucun membre d’équipe', msg: 'Ajoutez votre équipe pour suivre les performances par personne.' },
    en: { sub: 'No team members', msg: 'Add your team to track performance per person.' },
    ar: { sub: 'لا أعضاء فريق', msg: 'أضِف فريقك لتتبّع الأداء لكل شخص.' },
  };
  const INTEG_TITLE = { fr: 'Intégrations', en: 'Integrations', ar: 'عمليات الدمج' };
  const INTEG_SUB = {
    fr: 'Aucune connexion active · choisissez un outil à connecter',
    en: 'No active connection · choose a tool to connect',
    ar: 'لا يوجد اتصال نشط · اختر أداة لربطها',
  };
  const INTEG_NOTCONN = { fr: 'Non connecté', en: 'Not connected', ar: 'غير متّصل' };
  const INTEG_LIST = [
    { n: 'Glovo', logo: 'G', bg: '#F29137' },
    { n: 'Yassir Express', logo: 'Y', bg: '#2B5AA8' },
    { n: 'Shopify', logo: 'S', bg: '#5E8E3E', channel: 'shopify' },
    { n: 'Comptabilité', logo: 'A', bg: '#1D3F6B' },
    { n: 'Bank of Africa', logo: 'B', bg: '#00613E' },
  ];

  /* Standard padded empty-state body for a light .block card. */
  function emptyBlockBody(head, msg) {
    return `<div style="padding:26px 8px 14px;text-align:center;">` +
      `<div style="font-size:14px;font-weight:600;color:var(--ink);">${head}</div>` +
      `<div style="font-size:12.5px;color:var(--n-500);margin-top:6px;line-height:1.5;max-width:340px;margin-inline:auto;">${msg}</div>` +
      `</div>`;
  }
  /* Message-only empty body — for cards whose header already labels them. */
  function emptyListBody(msg) {
    return `<div style="padding:30px 8px 20px;text-align:center;font-size:12.5px;` +
      `color:var(--n-500);line-height:1.5;max-width:320px;margin-inline:auto;">${msg}</div>`;
  }

  /* Grow [data-grow] elements from width 0 to their target — bars draw in
   * on every data change. The double-rAF lets the 0-width frame paint first
   * so the CSS width transition has something to animate from. */
  function growBars(scope) {
    if (!scope) return;
    const els = scope.querySelectorAll('[data-grow]');
    if (!els.length) return;
    if (window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches) {
      els.forEach((el) => { el.style.width = el.dataset.grow; });
      return;
    }
    const apply = () => els.forEach((el) => { el.style.width = el.dataset.grow; });
    requestAnimationFrame(() => requestAnimationFrame(apply));
    /* rAF is frozen in hidden tabs — the timer guarantees the bars land at
     * their real widths even if the render happened in the background. */
    setTimeout(apply, 450);
  }

  /* Merge the current venue's trade vocabulary over a default empty-state
   * dict — a gym's cards talk passages/adhérents, a boutique's talk ventes.
   * KiwiVenue.getVocab returns null for demo venues and plain restaurants,
   * so the defaults pass through untouched. */
  function tradeStr(section, base) {
    const v = window.KiwiVenue?.getVocab?.(section);
    if (!v) return base;
    return typeof base === 'string' ? v : { ...base, ...v };
  }

  /* Card titles owned by JS (not data-i18n) so the trade vocabulary can
   * relabel them per venue. Values mirror the former i18n.js entries. */
  const PRODUCTS_TITLE  = { fr: 'Top produits', en: 'Top products', ar: 'المنتجات الأكثر مبيعًا' };
  const PRODUCTS_MANAGE = { fr: 'Gérer menu →', en: 'Manage menu →', ar: 'إدارة القائمة →' };
  const STAFF_TITLE     = { fr: 'Performance équipe', en: 'Team performance', ar: 'أداء الفريق' };

  let _healthOrig = null, _benchOrig = null, _integOrig = null;

  /* Integrations — for custom venues, show the tools as available-to-connect
   * rather than leaking Café Atlas's live sync figures. */
  function renderInteg() {
    const card = document.querySelector('[data-integ-card]');
    if (!card) return;
    if (_integOrig == null) _integOrig = card['inner' + 'HTML'];
    if (ownData()) {
      const lang = getLang();
      const notConn = INTEG_NOTCONN[lang] || INTEG_NOTCONN.fr;
      const addLbl = (window.KiwiI18n?.t?.('dash.integ.add')) || '+ Ajouter une intégration';
      const cards = INTEG_LIST.map(it =>
        `<div class="integ-card" data-action="${it.channel ? 'integration-connect' : 'add-integration'}"` +
        ` data-arg="${it.n}" data-channel="${it.channel || ''}">` +
        `<div class="logo" style="background:${it.bg};opacity:.55;">${it.logo}</div>` +
        `<div class="info"><div class="n">${it.n}</div>` +
        `<div class="s"><span class="dot warn"></span><span>${notConn}</span></div></div></div>`
      ).join('');
      card['inner' + 'HTML'] =
        `<div class="block-head"><div>` +
        `<div class="t">${INTEG_TITLE[lang] || INTEG_TITLE.fr}</div>` +
        `<div class="s">${INTEG_SUB[lang] || INTEG_SUB.fr}</div></div>` +
        `<a data-activation=write href="#" data-action="add-integration" style="font-size:13px;color:var(--atlas);font-weight:500;">${addLbl}</a>` +
        `</div><div class="integ-grid">${cards}</div>`;
    } else if (_integOrig != null && card['inner' + 'HTML'] !== _integOrig) {
      card['inner' + 'HTML'] = _integOrig;
    }
  }

  /* Notification badge — no fake alerts on a fresh custom venue. */
  function renderNotifBadge() {
    const b = document.querySelector('[data-notif-badge]');
    if (!b) return;
    b.style.display = ownData() ? 'none' : '';
  }

  /* Le bandeau « garde » de la pharmacie. Lit les fiches du tableau de bord ; les heures sont
     celles du magasin (KiwiTradeSchema.wallNow), jamais celles de l'appareil. */
  /* Ces destinations n'ont pas de gestionnaire écrit à la main : trade-workspaces.js enregistre
     « nav-<route> » pour chaque fiche du métier. On les nomme ici pour que le lien soit lisible. */
  const BAND_NAV = { duty: 'nav-duty', bookorders: 'nav-bookorders' };
  function dutyBand(lang, t) {
    const W = window.KiwiTradeWorkspaces, S = window.KiwiTradeSchema;
    if (!W || !S || !W.config || !W.config('duty')) return null;
    const rows = (W.rows('duty') || []).map((r) => ({ r, v: r.values || {} }));
    const now = S.wallNow();
    const cur = rows.filter((x) => (+x.r.status || 0) === 2 || ((+x.r.status || 0) < 3 && String(x.v.startAt || '') <= now && now <= String(x.v.endAt || ''))).sort((a, b) => String(a.v.startAt).localeCompare(String(b.v.startAt)))[0];
    const next = rows.filter((x) => (+x.r.status || 0) < 2 && String(x.v.startAt || '') > now).sort((a, b) => String(a.v.startAt).localeCompare(String(b.v.startAt)))[0];
    const S2 = {
      fr: { on: 'EN GARDE', until: (x) => `jusqu’à ${x}`, since: (x) => `depuis ${x}`, next: 'PROCHAINE GARDE', open: 'Ouvrir Gardes & relève' },
      en: { on: 'ON DUTY', until: (x) => `until ${x}`, since: (x) => `since ${x}`, next: 'NEXT DUTY', open: 'Open Duty & handover' },
      ar: { on: 'في الحراسة', until: (x) => `حتى ${x}`, since: (x) => `منذ ${x}`, next: 'الحراسة القادمة', open: 'فتح الحراسة والتسليم' },
    }[lang] || null;
    const L2 = S2 || { on: 'EN GARDE', until: (x) => `jusqu’à ${x}`, since: (x) => `depuis ${x}`, next: 'PROCHAINE GARDE', open: 'Ouvrir Gardes & relève' };
    const fmt = (k) => { try { return new (globalThis.KiwiZoneLaw?.DateTimeFormat || Intl.DateTimeFormat)(lang === 'ar' ? 'ar-MA' : lang === 'en' ? 'en-GB' : 'fr-FR', { weekday: 'short', day: 'numeric', month: 'short', hour: '2-digit', minute: '2-digit' }).format(new Date(String(k).slice(0, 16) + ':00')); } catch (_) { return String(k); } };
    const cta = `<div class="instant" data-action="${BAND_NAV.duty}"><div style="font-weight:500;">${L2.open}</div></div>`;
    const hand = (x) => (x.v.handover ? `<div style="font-size:12px;opacity:.7;margin-top:8px;line-height:1.45;">${escTxt(String(x.v.handover).slice(0, 160))}</div>` : '');
    if (cur) {
      return `<div class="lbl">${L2.on}</div><div class="big" style="font-size:30px;">${escTxt(cur.r.title || '')}</div>` +
        `<div class="sub">${L2.since(escTxt(fmt(cur.v.startAt)))} · ${L2.until(escTxt(fmt(cur.v.endAt)))}</div>${hand(cur)}${cta}`;
    }
    if (next) {
      return `<div class="lbl">${L2.next}</div><div class="big" style="font-size:30px;">${escTxt(fmt(next.v.startAt))}</div>` +
        `<div class="sub">${escTxt(next.r.title || '')} · ${L2.until(escTxt(fmt(next.v.endAt)))}</div>${hand(next)}${cta}`;
    }
    return `<div class="lbl">${t.lbl}</div><div style="padding:28px 4px 8px;text-align:center;">` +
      `<div style="font-size:14px;font-weight:600;">${t.head}</div>` +
      `<div style="font-size:12px;opacity:.7;margin-top:6px;line-height:1.5;">${t.msg}</div></div>${cta}`;
  }

  /* Librairie, épicerie : « fin de journée » n'est pas un service du soir avec des tables à réserver.
     L'ancien bandeau disait « Réservations non configurées, ajoutez vos tables » à un libraire. La
     librairie y voit ses commandes spéciales (fiches du tableau de bord, que la caisse écrit) ;
     l'épicerie, qui n'a aucune donnée à y mettre, un état vide honnête sans renvoi vers les tables.
     Même chose pour TOUT commerce de détail (boutique, maison, fleuriste, autre) : ils tombaient
     dans la branche des réservations et lisaient « Réservations non configurées, ajoutez vos
     tables ». Une boutique ne prend pas de réservation ; son état vide est celui de son métier. */
  function retailBand(lang, t) {
    let trade = '', base = '';
    try { const v = window.KiwiVenue?.getCurrentVenueData?.() || {}; trade = String(v.subtype || v.type || ''); } catch (_) {}
    try { base = String(window.KiwiVenue?.getVenueType?.() || ''); } catch (_) {}
    if (trade !== 'librairie' && trade !== 'epicerie' && base !== 'boutique') return null;
    const W = window.KiwiTradeWorkspaces;
    const T = {
      fr: { lbl: 'COMMANDES SPÉCIALES', arrived: (n) => `${n} ${n > 1 ? 'arrivées' : 'arrivée'} à retirer`, waiting: (n) => `${n} en attente de livraison`, open: 'Ouvrir Commandes de livres' },
      en: { lbl: 'SPECIAL ORDERS', arrived: (n) => `${n} arrived, to collect`, waiting: (n) => `${n} awaiting delivery`, open: 'Open Special orders' },
      ar: { lbl: 'الطلبات الخاصة', arrived: (n) => `${n} وصلت للاستلام`, waiting: (n) => `${n} في انتظار التسليم`, open: 'فتح الطلبات الخاصة' },
    }[lang] || null;
    const L2 = T || { lbl: 'COMMANDES SPÉCIALES', arrived: (n) => `${n} ${n > 1 ? 'arrivées' : 'arrivée'} à retirer`, waiting: (n) => `${n} en attente de livraison`, open: 'Ouvrir Commandes de livres' };
    if (trade === 'librairie' && W && W.config && W.config('bookorders')) {
      const rows = (W.rows('bookorders') || []).filter((r) => (+r.status || 0) < 2);
      const arrived = rows.filter((r) => (+r.status || 0) === 1).length, waiting = rows.length - arrived;
      if (rows.length) {
        return `<div class="lbl">${L2.lbl}</div><div class="big">${rows.length}</div>` +
          `<div class="sub">${L2.arrived(arrived)} · ${L2.waiting(waiting)}</div>` +
          `<div class="instant" data-action="${BAND_NAV.bookorders}"><div style="font-weight:500;">${L2.open}</div></div>`;
      }
    }
    return `<div class="lbl">${t.lbl}</div><div style="padding:28px 4px 8px;text-align:center;">` +
      `<div style="font-size:14px;font-weight:600;">${t.head}</div>` +
      `<div style="font-size:12px;opacity:.7;margin-top:6px;line-height:1.5;">${t.msg}</div></div>`;
  }

  function renderEvening() {
    const el = document.querySelector('[data-evening-card]');
    if (!el) return;
    if (_eveningOrig == null) _eveningOrig = el['inner' + 'HTML'];
    if (ownData()) {
      const lang = getLang();
      const t = tradeStr('eveningEmpty', EVENING_EMPTY[lang] || EVENING_EMPTY.fr);
      /* Pharmacie : ce soir = la garde (fiches « Gardes & relève », que la caisse ouvre et ferme),
         pas des réservations de tables. */
      const dutyHtml = dutyBand(lang, t) || retailBand(lang, t);
      if (dutyHtml) { el['inner' + 'HTML'] = dutyHtml; return; }
      let doc = null;
      try { doc = window.KiwiReservations?.get?.(); } catch (_) {}
      const now = Date.now(), currentDay = merchantDayKey(now, activeMerchantSlug()), currentWindow = merchantDayBounds(currentDay, activeMerchantSlug()), start = currentWindow.from, end = currentWindow.to;
      const active = doc && Array.isArray(doc.bookings) ? doc.bookings.filter((b) =>
        ['requested', 'confirmed', 'checked_in'].includes(b.status) && +b.startAt >= start && +b.startAt < end && +b.endAt >= now
      ).sort((a, b) => +a.startAt - +b.startAt) : [];
      if (active.length) {
        const covers = active.reduce((n, b) => n + Math.max(1, +b.partySize || 1), 0);
        const resource = new Map((doc.resources || []).map((r) => [String(r.id), r.name]));
        const labels = {
          fr: { lbl: 'RÉSERVATIONS À VENIR · AUJOURD’HUI', unit: 'couverts', sub: (n) => `${n} réservation${n > 1 ? 's actives' : ' active'}`, pending: 'À confirmer', confirmed: 'Confirmée', checked_in: 'Arrivé', open: 'Ouvrir Réservations', more: (n) => `+${n} autre${n > 1 ? 's' : ''}` },
          en: { lbl: 'UPCOMING BOOKINGS · TODAY', unit: 'guests', sub: (n) => `${n} active booking${n > 1 ? 's' : ''}`, pending: 'Pending', confirmed: 'Confirmed', checked_in: 'Checked in', open: 'Open Reservations', more: (n) => `+${n} more` },
          ar: { lbl: 'الحجوزات القادمة · اليوم', unit: 'ضيف', sub: (n) => `${n} حجوزات نشطة`, pending: 'في انتظار التأكيد', confirmed: 'مؤكد', checked_in: 'وصل', open: 'فتح الحجوزات', more: (n) => `+${n} أخرى` },
        }[lang] || null;
        const L = labels || { lbl: 'RÉSERVATIONS À VENIR · AUJOURD’HUI', unit: 'couverts', sub: (n) => `${n} réservations actives`, pending: 'À confirmer', confirmed: 'Confirmée', checked_in: 'Arrivé', open: 'Ouvrir Réservations', more: (n) => `+${n} autres` };
        el['inner' + 'HTML'] = `<div class="lbl">${L.lbl}</div>` +
          `<div class="big">${covers} <span style="font-size:.42em;opacity:.72;">${L.unit}</span></div>` +
          `<div class="sub">${L.sub(active.length)}</div>` +
          `<div style="margin-top:16px;padding-top:12px;border-top:1px solid color-mix(in srgb,currentColor 14%,transparent);display:flex;flex-direction:column;gap:9px;">` +
          active.slice(0, 3).map((b) => {
            const status = b.status === 'requested' ? L.pending : (L[b.status] || L.confirmed);
            const at = new (globalThis.KiwiZoneLaw?.DateTimeFormat || Intl.DateTimeFormat)(lang === 'ar' ? 'ar-MA' : lang === 'en' ? 'en-GB' : 'fr-FR', { hour: '2-digit', minute: '2-digit' }).format(new Date(+b.startAt));
            const place = resource.get(String(b.resourceId));
            return `<div style="display:grid;grid-template-columns:48px 1fr auto;gap:9px;align-items:center;font-size:12px;">` +
              `<span style="font-family:var(--mono);color:var(--mint);font-weight:600;">${escTxt(at)}</span>` +
              `<div style="min-width:0;"><div style="font-weight:600;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;">${escTxt(b.customer?.name)}</div>` +
              `<div style="opacity:.7;margin-top:1px;">${Math.max(1, +b.partySize || 1)} ${L.unit}${place ? ` · ${escTxt(place)}` : ''}</div></div>` +
              `<span style="font-size:11px;opacity:.7;">${status}</span></div>`;
          }).join('') + `</div>` +
          `<div class="instant" data-action="nav-reservations"><div class="ico"><svg width="16" height="16" viewBox="0 -960 960 960" fill="currentColor" aria-hidden="true"><path d="m612-292 56-56-148-148v-184h-80v216l172 172ZM480-80q-83 0-156-31.5T197-197q-54-54-85.5-127T80-480q0-83 31.5-156T197-763q54-54 127-85.5T480-880q83 0 156 31.5T763-763q54 54 85.5 127T880-480q0 83-31.5 156T763-197q-54 54-127 85.5T480-80Zm0-400Zm0 320q133 0 226.5-93.5T800-480q0-133-93.5-226.5T480-800q-133 0-226.5 93.5T160-480q0 133 93.5 226.5T480-160Z"/></svg></div>` +
          `<div style="font-weight:500;">${L.open}</div><div class="cost">${active.length > 3 ? L.more(active.length - 3) : ''}</div></div>`;
      } else {
        const configured = !!(doc && doc.settings && doc.services?.length && doc.resources?.length);
        const head = configured ? t.head : ({ fr: 'Réservations non configurées', en: 'Bookings not configured', ar: 'الحجوزات غير مهيأة' }[lang]);
        const msg = configured ? t.msg : ({ fr: 'Ajoutez vos tables et vos horaires pour recevoir des réservations.', en: 'Add tables and opening hours to accept bookings.', ar: 'أضف الطاولات وساعات العمل لاستقبال الحجوزات.' }[lang]);
        el['inner' + 'HTML'] = `<div class="lbl">${t.lbl}</div><div style="padding:28px 4px 8px;text-align:center;">` +
          `<div style="font-size:14px;font-weight:600;">${head}</div>` +
          `<div style="font-size:12px;opacity:.7;margin-top:6px;line-height:1.5;">${msg}</div></div>` +
          `<div class="instant" data-action="nav-reservations"><div style="font-weight:500;">${lang === 'en' ? 'Open Reservations' : lang === 'ar' ? 'فتح الحجوزات' : 'Ouvrir Réservations'}</div></div>`;
      }
    } else if (el['inner' + 'HTML'] !== _eveningOrig) {
      el['inner' + 'HTML'] = _eveningOrig;
    }
  }

  function renderStock() {
    const el = document.querySelector('[data-stock-card]');
    if (!el) return;
    if (_stockOrig == null) _stockOrig = el['inner' + 'HTML'];
    if (ownData()) {
      const lang = getLang();
      const t = tradeStr('stockEmpty', STOCK_EMPTY[lang] || STOCK_EMPTY.fr);
      /* L'accueil porte DEUX cartes « Stock à recommander » : celle-ci, dans la
       * colonne de droite, et la liste [data-products-list]. Seule la seconde
       * avait été rebranchée sur le catalogue — le commerçant lisait donc
       * « Aucune alerte de stock » à droite pendant que la gauche affichait
       * l'article sous le seuil. Même source, même seuil, plus de contradiction. */
      const low = realLowStock();
      if (low && low.rows.length) {
        el['inner' + 'HTML'] =
          `<div class="block-head" style="margin-bottom:6px;"><div>` +
          `<div class="t">${STOCK_TITLE_STR[lang] || STOCK_TITLE_STR.fr}</div>` +
          `<div class="s">${(STOCK_SUB_STR[lang] || STOCK_SUB_STR.fr)(low.rows.length)}</div>` +
          `</div></div>` +
          low.rows.map((r) => {
            const dead = r.stock === 0;
            return `<div style="display:flex;align-items:center;justify-content:space-between;gap:10px;` +
              `padding:9px 2px;border-top:1px solid var(--n-200);">` +
              `<div style="min-width:0;">` +
              `<div style="font-size:13px;font-weight:500;color:var(--ink);overflow:hidden;` +
              `text-overflow:ellipsis;white-space:nowrap;">${escTxt(r.name)}</div>` +
              `<div style="font-size:11.5px;margin-top:2px;color:${dead ? 'var(--danger)' : 'var(--n-500)'};">` +
              `${dead ? (RUPTURE_STR[lang] || RUPTURE_STR.fr) : (LOWSTK_STR[lang] || LOWSTK_STR.fr)(r.threshold)}</div>` +
              `</div>` +
              `<div style="text-align:right;font-family:var(--mono);color:${dead ? 'var(--danger)' : 'var(--ink)'};">` +
              `<div style="font-size:14px;font-weight:600;">${r.stock} ${escTxt(r.unit || '')}</div>` +
              `${r.suggested ? `<div style="font-size:11px;color:var(--n-500);">+${r.suggested} ${escTxt(r.unit)}${r.cost ? ` · ${frInt(r.suggested * r.cost)} ${curUnit()}` : ''}</div>` : ''}</div>` +
              `</div>`;
          }).join('');
        el['inner' + 'HTML'] += `<a href="#" data-action="nav-stock" style="display:block;margin-top:12px;text-align:center;font-size:12.5px;color:var(--atlas);font-weight:600;">${lang === 'en' ? 'Open inventory & purchasing →' : lang === 'ar' ? 'فتح المخزون والمشتريات ←' : 'Ouvrir Stock & approvisionnement →'}</a>`;
        return;
      }
      el['inner' + 'HTML'] =
        `<div class="block-head" style="margin-bottom:14px;"><div>` +
        `<div class="t">${t.title}</div></div></div>` +
        `<div style="padding:16px 8px 12px;text-align:center;">` +
        `<div style="width:36px;height:36px;border-radius:10px;background:rgba(63,182,122,0.12);color:var(--mint);display:inline-flex;align-items:center;justify-content:center;margin-bottom:10px;">` +
        `<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><path d="M20 6L9 17l-5-5"/></svg>` +
        `</div>` +
        `<div style="font-size:14px;font-weight:600;color:var(--ink);">${t.head}</div>` +
        `<div style="font-size:12px;color:var(--n-500);margin-top:6px;line-height:1.5;max-width:280px;margin-inline:auto;">${low && !low.configured ? (STOCK_NO_THRESHOLDS[lang] || STOCK_NO_THRESHOLDS.fr)(low.tracked) : low ? (STOCK_OK_STR[lang] || STOCK_OK_STR.fr)(low.tracked) : t.msg}</div>` +
        `</div>`;
    } else if (el['inner' + 'HTML'] !== _stockOrig) {
      el['inner' + 'HTML'] = _stockOrig;
    }
  }

  /* ═══════════════ RENDER: TIMELINE WEEK TOTAL ═══════════════ */

  function renderTimeline() {
    const effective = effRange();
    const totalEl = document.querySelector('[data-timeline-week-total]');
    if (!totalEl) return;
    /* Le repli `|| timelineWeekTotalByVenue.cafeAtlas` servait le total du CAFÉ
     * ATLAS à tout commerçant absent de cette table — c'est-à-dire à tous les
     * vrais. Ce n'était pas un état vide, c'était le chiffre d'affaires de
     * quelqu'un d'autre affiché comme le sien. Une venue réelle additionne ses
     * propres ventes ; le tilde disparaît, ce total-là est exact. */
    if (ownData() && window.KiwiSales) {
      totalEl.textContent = `${frInt(realSalesTotals(currentRange).revenue)} ${curUnit()}`;
      return;
    }
    const total = (timelineWeekTotalByVenue[getCurrentVenue()] || timelineWeekTotalByVenue.cafeAtlas)[effective];
    if (total) totalEl.textContent = total;
  }

  /* ═══════════════ RENDER: HEALTH SCORE ═══════════════ */

  function renderHealth() {
    const lang = getLang();
    const card = document.querySelector('[data-health-card]');
    if (card && _healthOrig == null) _healthOrig = card['inner' + 'HTML'];
    if (ownData()) {
      if (card) {
        const t = HEALTH_EMPTY[lang] || HEALTH_EMPTY.fr;
        card.hidden = true;
        card.classList.add('is-empty-state');
        card['inner' + 'HTML'] =
          `<div class="block-head"><div><div class="t">${t.title}</div></div></div>` +
          emptyBlockBody(t.head, t.msg);
      }
      return;
    }
    if (card) {
      card.hidden = false;
      card.classList.remove('is-empty-state');
      if (_healthOrig != null && card['inner' + 'HTML'] !== _healthOrig) card['inner' + 'HTML'] = _healthOrig;
    }
    const effective = effRange();
    const data = vData(healthByVenue, currentRange);
    if (!data) return;

    const subEl = document.querySelector('[data-health-sub]');
    if (subEl) subEl.textContent = HEALTH_SUB[lang]?.[currentRange] || HEALTH_SUB.fr[currentRange];

    const chipEl = document.querySelector('[data-health-chip]');
    if (chipEl) chipEl.textContent = HEALTH_CHIP[lang]?.[data.chipKey] || HEALTH_CHIP.fr[data.chipKey];

    const scoreEl = document.querySelector('[data-health-score]');
    if (scoreEl) animateNumber(scoreEl, parseIntFromEl(scoreEl), data.score, { duration: 700, format: v => `${Math.round(v)}` });

    const arc = document.querySelector('[data-health-arc]');
    if (arc) arc.setAttribute('stroke-dasharray', `${data.score} 100`);
  }

  /* ═══════════════ RENDER: BENCHMARK ═══════════════ */

  function renderBench() {
    const lang = getLang();
    const card = document.querySelector('[data-bench-card]');
    if (card && _benchOrig == null) _benchOrig = card['inner' + 'HTML'];
    /* "#12 sur 147 cafés à Casablanca · top 8 %" is a cohort Kiwi does not
     * have. It is fine in the demo, where every number is openly a rehearsal,
     * and it is not fine anywhere else — an invented peer benchmark is worse
     * than an invented figure, because it reads like data somebody else
     * collected and a merchant reasonably prices against it. The gate was
     * isCustom() alone, which left the real-but-not-custom session showing a
     * ranking among 147 cafés that were never counted. */
    if (ownData() || window.KiwiEnv?.isReal?.()) {
      if (card) {
        const t = BENCH_EMPTY[lang] || BENCH_EMPTY.fr;
        card.hidden = true;
        card.classList.add('is-empty-state');
        card['inner' + 'HTML'] =
          `<div class="block-head"><div><div class="t">${t.title}</div></div></div>` +
          emptyBlockBody(t.head, t.msg);
      }
      return;
    }
    if (card) {
      card.hidden = false;
      card.classList.remove('is-empty-state');
      if (_benchOrig != null && card['inner' + 'HTML'] !== _benchOrig) card['inner' + 'HTML'] = _benchOrig;
    }
    const effective = effRange();
    const data = vData(benchByVenue, currentRange);
    if (!data) return;

    // Title + sub vary by venue type (cafés / boutiques / spas similaires)
    const benchLabels = window.KiwiVenue?.getBenchLabels?.() || { title: BENCH_TITLE_FALLBACK[lang] || BENCH_TITLE_FALLBACK.fr, sub: BENCH_SUB.fr[currentRange] };
    const titleEl = document.querySelector('[data-bench-title]');
    if (titleEl) titleEl.textContent = benchLabels.title;
    const subEl = document.querySelector('[data-bench-sub]');
    if (subEl) subEl.textContent = benchLabels.sub || BENCH_SUB[lang]?.[currentRange] || BENCH_SUB.fr[currentRange];

    const rankEl = document.querySelector('[data-bench-rank]');
    if (rankEl) animateNumber(rankEl, parseIntFromEl(rankEl), data.rank, { duration: 650, format: v => `#${Math.round(v)}` });

    // Match the rank-sub wording to the vertical
    const venueType = window.KiwiVenue?.getVenueType?.() || 'restaurant';
    const peerLabel = (BENCH_PEER[lang] || BENCH_PEER.fr)[venueType] || (BENCH_PEER[lang] || BENCH_PEER.fr).restaurant;
    const cityLabel = (BENCH_CITY[lang] || BENCH_CITY.fr)[venueType === 'spa' ? 'spa' : 'default'];
    const rankSubEl = document.querySelector('[data-bench-rank-sub]');
    if (rankSubEl) rankSubEl['inner' + 'HTML'] = (BENCH_RANK_SUB[lang] || BENCH_RANK_SUB.fr)(data.total, peerLabel, cityLabel, data.top);

    const comp = document.querySelector('[data-bench-comp]');
    if (comp) {
      comp.innerHTML = data.rows.map((r, i) => `
        <div class="bench-row" style="--i:${i};">
          <div class="lbl">${trStr(r.lbl, BENCH_LBL)}</div>
          <div class="bench-bar">
            <div class="you" style="width: 0%;" data-grow="${r.you}%"></div>
            <div class="peer" style="left: ${r.peer}%;"></div>
          </div>
          <div class="v"${r.warn ? ' style="color: var(--warning);"' : ''}>${r.v}</div>
        </div>
      `).join('');
      growBars(comp);
    }
  }

  /* ═══════════════ RENDER: TOP PRODUCTS ═══════════════ */

  function renderProducts() {
    const lang = getLang();
    const effective = effRange();
    const isCustom = ownData();
    const data = isCustom ? [] : vData(productsByVenue, currentRange);
    const pe = tradeStr('productsEmpty', PRODUCTS_EMPTY[lang] || PRODUCTS_EMPTY.fr);
    const real = isCustom ? realTopProducts(currentRange) : null;
    const titleEl = document.querySelector('[data-products-title]');
    if (titleEl) titleEl.textContent = (isCustom && pe.title) || PRODUCTS_TITLE[lang] || PRODUCTS_TITLE.fr;
    const manageEl = document.querySelector('[data-products-manage]');
    if (manageEl) manageEl.textContent = (isCustom && pe.manage) || PRODUCTS_MANAGE[lang] || PRODUCTS_MANAGE.fr;
    const list = document.querySelector('[data-products-list]');
    const card = list?.closest('.block');
    if (list && real && real.rows.length) {
      const cap = Math.max(1, ...real.rows.map((r) => r.qty));
      list.innerHTML = real.rows.map((r, i) => `
        <div class="prod-row" style="--i:${i};">
          <div class="rank${i === 0 ? ' top' : ''}">${i + 1}</div>
          <div class="info">
            <div class="n">${escTxt(r.name)}</div>
            <div class="r">${frInt(r.revenue)} MAD</div>
          </div>
          <div class="mini-bar"><div style="width: 0%;" data-grow="${Math.round((r.qty / cap) * 100)}%"></div></div>
          <div class="sales">${(PRODUCT_SOLD[lang] || PRODUCT_SOLD.fr)(r.qty)}</div>
        </div>
      `).join('');
      growBars(list);
    } else if (list && isCustom) {
      list.innerHTML = emptyListBody(real && real.sales ? (PRODUCTS_NO_LINES[lang] || PRODUCTS_NO_LINES.fr)(real.sales) : pe.msg);
    } else if (list && data) {
      list.innerHTML = data.map((p, i) => `
        <div class="prod-row" style="--i:${i};">
          <div class="rank${i === 0 ? ' top' : ''}">${p.rank}</div>
          <div class="info">
            <div class="n">${p.name}</div>
            <div class="r">${p.sub}</div>
          </div>
          <div class="mini-bar"><div style="width: 0%;" data-grow="${p.bar}%"></div></div>
          <div class="sales">${p.sales}</div>
        </div>
      `).join('');
      growBars(list);
    }
    if (card) card.classList.toggle('is-empty-state', !!list && !list.querySelector('.prod-row'));
    try { renderPairs(card, isCustom, lang); } catch (_) {}
    const sub = document.querySelector('[data-products-sub]');
    if (sub) sub.textContent = isCustom
      ? (real && real.rows.length ? (PRODUCTS_COVERAGE[lang] || PRODUCTS_COVERAGE.fr)(real.rows.length, real.covered, real.sales) : pe.sub)
      : (PRODUCTS_SUB[lang]?.[currentRange] || PRODUCTS_SUB.fr[currentRange]);
  }

  /* ═══════════════ RENDER: STAFF ═══════════════ */

  function renderStaff() {
    const lang = getLang();
    const effective = effRange();
    const isCustom = ownData();
    const data = isCustom ? [] : vData(staffByVenue, currentRange);
    const se = tradeStr('staffEmpty', STAFF_EMPTY[lang] || STAFF_EMPTY.fr);
    const titleEl = document.querySelector('[data-staff-title]');
    if (titleEl) titleEl.textContent = (isCustom && se.title) || STAFF_TITLE[lang] || STAFF_TITLE.fr;
    const list = document.querySelector('[data-staff-list]');
    const card = list?.closest('.block');
    /* Une équipe existe dès qu'un membre est saisi côté Équipe — la carte ne peut
     * plus prétendre le contraire. Les heures viennent de la grille de Paie, donc
     * « en service » veut dire ici exactement ce qu'il veut dire là-bas.
     * Le montant reste « — » : Kiwi ne rattache pas encore une vente à un
     * vendeur, et inventer un chiffre par personne serait pire que le tiret. */
    const roster = isCustom ? realRoster() : null;
    if (list && roster && roster.length) {
      list.innerHTML = roster.map((s, i) => {
        const on = s.hoursToday > 0;
        return `
        <div class="staff-row" style="--i:${i};">
          <div class="av${on ? '' : ' offline'}"${on ? '' : ' style="background: var(--n-400);"'}>${escTxt(s.avatar)}</div>
          <div class="info">
            <div class="n">${escTxt(s.name)}</div>
            <div class="role">${escTxt(s.role)}</div>
          </div>
          <div class="shift"${on ? '' : ' style="color: var(--n-500);"'}>${on ? fmtHeures(s.hoursToday) : '·'}</div>
          <div class="tx-n" style="color: var(--n-500);">·</div>
        </div>`;
      }).join('');
    } else if (list && isCustom) {
      list.innerHTML = emptyListBody(se.msg);
    } else if (list && data) {
      list.innerHTML = data.map((s, i) => `
        <div class="staff-row" style="--i:${i};">
          <div class="av ${s.cls}"${s.cls === 'offline' ? ' style="background: var(--n-400);"' : ''}>${s.av}</div>
          <div class="info">
            <div class="n">${s.name}</div>
            <div class="role">${demoRole(s.role, getLang())}</div>
          </div>
          <div class="shift"${s.shift === '·' ? ' style="color: var(--n-500);"' : ''}>${s.shift}</div>
          <div class="tx-n"${s.amt === '·' ? ' style="color: var(--n-500);"' : ''}>${s.amt}${s.tx ? `<br/><span style="color: var(--success); font-size: 11px;">${s.tx}</span>` : ''}</div>
        </div>
      `).join('');
    }
    if (card) card.classList.toggle('is-empty-state', !!list && !list.querySelector('.staff-row'));
    const sub = document.querySelector('[data-staff-sub]');
    if (sub) sub.textContent = (roster && roster.length)
      ? (STAFF_ONDUTY_STR[lang] || STAFF_ONDUTY_STR.fr)(roster.filter((s) => s.hoursToday > 0).length, roster.length)
      : (isCustom
        ? se.sub
        : (STAFF_SUB[lang]?.[currentRange] || STAFF_SUB.fr[currentRange]));
  }

  /* ═══════════════ ACTION HANDLER + I18N HOOK ═══════════════ */

  function onAction(el) {
    const id = el?.dataset?.range;
    if (!id) return;
    setDateRange(id);
  }
  function onCompareToggle() { setShowComparison(!showComparison); }

  function hookI18n() {
    const api = window.KiwiI18n;
    if (!api?.setLang || api.__drWrapped) return;
    const orig = api.setLang;
    api.setLang = function () {
      const r = orig.apply(this, arguments);
      // Re-render everything that has lang-dependent text
      renderSelector();
      renderHero();
      renderHeroAi();
      renderGoal();
      renderHeatmap();
      renderKpiBand();
      renderRevChart();
      renderMix();
      renderFeed();
      renderSettle();
      renderEvening();
      renderStock();
      renderHealth();
      renderBench();
      renderInteg();
      renderProducts();
      renderStaff();
      return r;
    };
    api.__drWrapped = true;
  }

  /* ═══════════════ CUSTOM RANGE · calendar popover ═══════════════
   * A branded two-month range picker that drops under the "Personnalisé"
   * pill and commits a { start, end } pair via commitCustomRange().
   * Self-contained — its own event delegation, no data-action hooks, no
   * Kiwi.modal — so it can be lifted into the caisse app untouched. */

  const LOCALES = { fr: 'fr-FR', en: 'en-GB', ar: 'ar-MA' };
  const PICKER_STR = {
    fr: { title: 'Période personnalisée', apply: 'Appliquer', cancel: 'Annuler',
          presets: 'Raccourcis', hintStart: 'Sélectionnez la date de début',
          hintEnd: 'Sélectionnez la date de fin', day: 'jour', days: 'jours',
          p7: '7 derniers jours', p14: '14 derniers jours', p30: '30 derniers jours',
          pMonth: 'Ce mois-ci', pLast: 'Mois dernier', p90: '90 derniers jours' },
    en: { title: 'Custom period', apply: 'Apply', cancel: 'Cancel',
          presets: 'Shortcuts', hintStart: 'Pick a start date',
          hintEnd: 'Pick an end date', day: 'day', days: 'days',
          p7: 'Last 7 days', p14: 'Last 14 days', p30: 'Last 30 days',
          pMonth: 'This month', pLast: 'Last month', p90: 'Last 90 days' },
    ar: { title: 'فترة مخصّصة', apply: 'تطبيق', cancel: 'إلغاء',
          presets: 'اختصارات', hintStart: 'اختر تاريخ البداية',
          hintEnd: 'اختر تاريخ النهاية', day: 'يوم', days: 'أيام',
          p7: 'آخر 7 أيام', p14: 'آخر 14 يومًا', p30: 'آخر 30 يومًا',
          pMonth: 'هذا الشهر', pLast: 'الشهر الماضي', p90: 'آخر 90 يومًا' },
  };

  const dpEsc = (s) => String(s).replace(/[&<>"]/g,
    (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));
  const startOfDay = (d) => new Date(d.getFullYear(), d.getMonth(), d.getDate());
  const addDays = (d, n) => { const x = startOfDay(d); x.setDate(x.getDate() + n); return x; };
  const ymdInt = (d) => d.getFullYear() * 10000 + d.getMonth() * 100 + d.getDate();
  const sameDay = (a, b) => !!a && !!b && ymdInt(a) === ymdInt(b);
  const shiftMonth = (y, m, n) => { const t = new Date(y, m + n, 1); return { y: t.getFullYear(), m: t.getMonth() }; };
  const capFirst = (s) => (s ? s.charAt(0).toUpperCase() + s.slice(1) : s);
  const monthOnly = (d, lang, style) =>
    new (globalThis.KiwiZoneLaw?.DateTimeFormat || Intl.DateTimeFormat)(LOCALES[lang] || LOCALES.fr, { month: style }).format(d);
  const monthLabel = (y, m, lang) => capFirst(new (globalThis.KiwiZoneLaw?.DateTimeFormat || Intl.DateTimeFormat)(
    LOCALES[lang] || LOCALES.fr, { month: 'long', year: 'numeric' }).format(new Date(y, m, 1)));

  /* Human span — "14 mai 2026" · "1 – 14 mai 2026" · "28 avr. – 3 mai 2026"
   * · "28 déc. 2025 – 4 janv. 2026". */
  function fmtHumanRange(s, e, lang) {
    if (sameDay(s, e)) return `${s.getDate()} ${monthOnly(s, lang, 'long')} ${s.getFullYear()}`;
    const sameYear = s.getFullYear() === e.getFullYear();
    if (sameYear && s.getMonth() === e.getMonth())
      return `${s.getDate()} – ${e.getDate()} ${monthOnly(e, lang, 'long')} ${e.getFullYear()}`;
    if (sameYear)
      return `${s.getDate()} ${monthOnly(s, lang, 'short')} – ${e.getDate()} ${monthOnly(e, lang, 'short')} ${e.getFullYear()}`;
    return `${s.getDate()} ${monthOnly(s, lang, 'short')} ${s.getFullYear()} – `
         + `${e.getDate()} ${monthOnly(e, lang, 'short')} ${e.getFullYear()}`;
  }

  let dpEl = null, dpOutside = null, dpKey = null, dpControl = null;

  function closeCustomPicker() {
    if (!dpEl) return;
    const pop = dpEl;
    dpEl = null;
    pop.classList.remove('open');
    pop.removeAttribute('aria-modal');
    if (pop.__releaseScroll) pop.__releaseScroll();
    if (pop.__focusBefore?.isConnected) pop.__focusBefore.focus({ preventScroll: true });
    const veil = pop.__veil;
    if (veil) { veil.classList.remove('in'); setTimeout(() => veil.remove(), 260); }
    if (dpOutside) document.removeEventListener('mousedown', dpOutside);
    if (dpKey) document.removeEventListener('keydown', dpKey);
    dpOutside = dpKey = null;
    const pill = dpControl?.querySelector('.dr-pill-custom');
    if (pill) pill.setAttribute('aria-expanded', 'false');
    dpControl = null;
    let gone = false;
    const drop = () => { if (gone) return; gone = true; pop.remove(); };
    pop.addEventListener('transitionend', drop, { once: true });
    setTimeout(drop, 300);
  }

  function openCustomPicker(options) {
    if (dpEl) { closeCustomPicker(); return; }          // second click → toggle shut
    const dayMode = options?.mode === 'day';
    const control = options?.control || document.querySelector('.dash-date-range .dr-control');
    if (!control) return;
    dpControl = control;
    const lang = getLang();
    const S = PICKER_STR[lang] || PICKER_STR.fr;
    const today = dayMode && isoToDate(options.maxDay) ? isoToDate(options.maxDay) : startOfDay(new Date());
    const monIdx = (y, m) => y * 12 + m;
    const maxLeft = monIdx(today.getFullYear(), today.getMonth()) - 1;  // right pane never future

    const selectedDay = dayMode ? isoToDate(options.selected) : null;
    let selStart = dayMode ? selectedDay : customRange ? startOfDay(customRange.start) : null;
    let selEnd   = dayMode ? selectedDay : customRange ? startOfDay(customRange.end)   : null;
    let hoverD   = null;
    let view = selEnd
      ? shiftMonth(selEnd.getFullYear(), selEnd.getMonth(), -1)
      : shiftMonth(today.getFullYear(), today.getMonth(), -1);

    const pop = document.createElement('div');
    pop.className = 'dr-popover';
    pop.setAttribute('role', 'dialog');
    pop.setAttribute('aria-label', S.title);
    if (lang === 'ar') pop.setAttribute('dir', 'rtl');
    dpEl = pop;
    // On a phone the two-month popover is taller than the screen and its
    // Apply button ends up under the tab bar (ticket #0108): present it as a
    // bottom sheet instead, with a scrolling calendar and a pinned footer.
    const asSheet = window.matchMedia && matchMedia('(max-width: 640px)').matches;
    if (asSheet) {
      const veil = document.createElement('div');
      veil.className = 'dr-sheet-veil';
      document.body.appendChild(veil);
      pop.__veil = veil;
      pop.classList.add('dr-sheet');
      veil.addEventListener('click', closeCustomPicker);
      pop.setAttribute('aria-modal', 'true');
      pop.__focusBefore = document.activeElement;
      pop.__releaseScroll = window.Kiwi?.scrollLock?.acquire();
      document.body.appendChild(pop);
      requestAnimationFrame(() => veil.classList.add('in'));
    } else if (dayMode) document.body.appendChild(pop);
    else control.appendChild(pop);

    const presets = [['p7', S.p7], ['p14', S.p14], ['p30', S.p30],
                     ['pMonth', S.pMonth], ['pLast', S.pLast], ['p90', S.p90]];
    function presetRange(key) {
      if (key === 'p7')  return [addDays(today, -6), today];
      if (key === 'p14') return [addDays(today, -13), today];
      if (key === 'p30') return [addDays(today, -29), today];
      if (key === 'p90') return [addDays(today, -89), today];
      if (key === 'pMonth') return [new Date(today.getFullYear(), today.getMonth(), 1), today];
      if (key === 'pLast')  return [new Date(today.getFullYear(), today.getMonth() - 1, 1),
                                    new Date(today.getFullYear(), today.getMonth(), 0)];
      return null;
    }
    function activePreset() {
      if (!selStart || !selEnd) return null;
      for (let i = 0; i < presets.length; i++) {
        const r = presetRange(presets[i][0]);
        if (r && sameDay(startOfDay(r[0]), selStart) && sameDay(startOfDay(r[1]), selEnd))
          return presets[i][0];
      }
      return null;
    }
    const chev = (dir) => `<span class="dr-icon dr-icon-${dir === 'prev' ? 'prev' : 'next'}" aria-hidden="true"></span>`;

    function weekdayRow() {
      const mon = addDays(today, -((today.getDay() + 6) % 7));
      let h = '';
      for (let i = 0; i < 7; i++) {
        const wd = new (globalThis.KiwiZoneLaw?.DateTimeFormat || Intl.DateTimeFormat)(LOCALES[lang] || LOCALES.fr, { weekday: 'short' })
          .format(addDays(mon, i)).replace('.', '');
        h += `<span class="drp-wd">${dpEsc(wd)}</span>`;
      }
      return h;
    }
    function monthGrid(y, m) {
      const lead = (new Date(y, m, 1).getDay() + 6) % 7;
      const days = new Date(y, m + 1, 0).getDate();
      let cells = '';
      for (let i = 0; i < lead; i++) cells += '<span class="drp-day drp-empty"></span>';
      for (let d = 1; d <= days; d++) {
        const date = new Date(y, m, d);
        const future = ymdInt(date) > ymdInt(today);
        let cls = 'drp-day';
        if (future) cls += ' is-disabled';
        if (sameDay(date, today)) cls += ' is-today';
        cells += `<button type="button" class="${cls}" data-day="${dateToIso(date)}"`
          + `${future ? ' disabled' : ''}><span class="drp-dn">${d}</span></button>`;
      }
      return cells;
    }
    function monthCard(y, m, side) {
      const canNext = monIdx(view.y, view.m) < maxLeft;
      const lBtn = side === 'left'
        ? `<button type="button" class="drp-nav" data-nav="prev" aria-label="${dpEsc({fr:'Mois précédent',en:'Previous month',ar:'الشهر السابق'}[lang])}">${chev('prev')}</button>`
        : '<span class="drp-nav-gap"></span>';
      const rBtn = side === 'right'
        ? `<button type="button" class="drp-nav" data-nav="next" aria-label="${dpEsc({fr:'Mois suivant',en:'Next month',ar:'الشهر التالي'}[lang])}"${canNext ? '' : ' disabled'}>${chev('next')}</button>`
        : '<span class="drp-nav-gap"></span>';
      return `<div class="drp-month"><div class="drp-mhead">${lBtn}`
        + `<span class="drp-mname">${dpEsc(monthLabel(y, m, lang))}</span>${rBtn}</div>`
        + `<div class="drp-wdrow">${weekdayRow()}</div>`
        + `<div class="drp-grid">${monthGrid(y, m)}</div></div>`;
    }

    function decorate() {
      let lo = selStart, hi = selEnd;
      if (selStart && !selEnd && hoverD) {
        lo = ymdInt(hoverD) < ymdInt(selStart) ? hoverD : selStart;
        hi = ymdInt(hoverD) < ymdInt(selStart) ? selStart : hoverD;
      }
      const a = lo ? ymdInt(lo) : null;
      const b = hi ? ymdInt(hi) : null;
      pop.querySelectorAll('.drp-day').forEach((btn) => {
        btn.classList.remove('in-range', 'is-start', 'is-end', 'is-edge', 'is-solo');
        if (!btn.dataset.day) return;
        const v = ymdInt(isoToDate(btn.dataset.day));
        if (a != null && b != null) {
          if (a === b) { if (v === a) btn.classList.add('is-edge', 'is-solo'); }
          else if (v === a) btn.classList.add('is-start', 'is-edge');
          else if (v === b) btn.classList.add('is-end', 'is-edge');
          else if (v > a && v < b) btn.classList.add('in-range');
        } else if (a != null && v === a) {
          btn.classList.add('is-edge', 'is-solo');
        }
      });
      const ro = pop.querySelector('[data-drp-readout]');
      if (ro) {
        if (lo && hi) ro.textContent = fmtHumanRange(lo, hi, lang);
        else if (selStart) ro.textContent = fmtHumanRange(selStart, selStart, lang);
        // Nothing picked yet: name the period in effect, in the muted colour,
        // instead of a lone dot.
        else ro.textContent = RANGE_STR[lang]?.[currentRange] || RANGE_STR.fr[currentRange] || S.hintStart;
        ro.classList.toggle('is-set', !!(lo || selStart));
      }
      const hint = pop.querySelector('[data-drp-hint]');
      if (hint) {
        if (lo && hi) {
          const n = spanDays(lo, hi);
          hint.innerHTML = `<b>${n}</b> ${dpEsc(n > 1 ? S.days : S.day)}`;
        } else {
          hint.textContent = selStart ? S.hintEnd : S.hintStart;
        }
      }
      const apply = pop.querySelector('[data-drp-apply]');
      if (apply) apply.disabled = !(selStart && selEnd);
      const ap = dayMode ? null : activePreset();
      pop.querySelectorAll('.drp-preset').forEach((p) => {
        p.classList.toggle('is-active', p.dataset.preset === ap);
      });
    }

    function render() {
      const scrollTop = pop.querySelector('.drp-body')?.scrollTop || 0;
      const r = shiftMonth(view.y, view.m, 1);
      pop.innerHTML =
        `<div class="drp-head"><div><div class="drp-eyebrow">${dpEsc(dayMode ? ({ fr: 'Choisir une date', en: 'Pick a date', ar: 'اختر تاريخاً' }[lang] || 'Choisir une date') : S.title)}</div>`
        + `<div class="drp-readout" data-drp-readout></div></div>`
        + `<button type="button" class="drp-x" data-drp-cancel aria-label="${dpEsc(S.cancel)}">`
        + `<span class="dr-icon dr-icon-close" aria-hidden="true"></span></button></div>`
        + `<div class="drp-body">${dayMode ? '' : `<div class="drp-presets">`
        + `<div class="drp-presets-lbl">${dpEsc(S.presets)}</div>`
        + presets.map(([k, lbl]) =>
            `<button type="button" class="drp-preset" data-preset="${k}">${dpEsc(lbl)}</button>`).join('')
        + `</div>`}<div class="drp-cal"><div class="drp-months">`
        + monthCard(view.y, view.m, 'left') + monthCard(r.y, r.m, 'right')
        + `</div></div></div>`
        + `<div class="drp-foot"><div class="drp-hint" data-drp-hint></div>`
        + `<div class="drp-acts">`
        + `<button type="button" class="drp-btn drp-btn-ghost" data-drp-cancel>${dpEsc(S.cancel)}</button>`
        + `<button type="button" class="drp-btn drp-btn-go" data-drp-apply>${dpEsc(S.apply)}</button>`
        + `</div></div>`;
      decorate();
      pop.querySelector('.drp-body').scrollTop = scrollTop;
    }

    function pickDay(iso) {
      const d = isoToDate(iso);
      if (!d) return;
      if (dayMode) { selStart = d; selEnd = d; hoverD = null; render(); return; }
      if (!selStart || (selStart && selEnd)) { selStart = d; selEnd = null; }
      else if (ymdInt(d) < ymdInt(selStart)) { selEnd = selStart; selStart = d; }
      else { selEnd = d; }
      hoverD = null;
      render();
    }
    function applyPreset(key) {
      const r = presetRange(key);
      if (!r) return;
      selStart = startOfDay(r[0]);
      selEnd = startOfDay(r[1]);
      hoverD = null;
      view = shiftMonth(selEnd.getFullYear(), selEnd.getMonth(), -1);
      render();
    }
    function shiftView(n) {
      const nv = shiftMonth(view.y, view.m, n);
      if (n > 0 && monIdx(nv.y, nv.m) > maxLeft) return;
      view = nv;
      render();
    }

    pop.addEventListener('click', (e) => {
      const day = e.target.closest('.drp-day');
      if (day && day.dataset.day && !day.disabled) { pickDay(day.dataset.day); return; }
      const nav = e.target.closest('[data-nav]');
      if (nav) { shiftView(nav.dataset.nav === 'next' ? 1 : -1); return; }
      const pre = e.target.closest('[data-preset]');
      if (pre) { applyPreset(pre.dataset.preset); return; }
      if (e.target.closest('[data-drp-cancel]')) { closeCustomPicker(); return; }
      if (e.target.closest('[data-drp-apply]') && selStart && selEnd) {
        if (dayMode) options.onApply(dateToIso(selStart));
        else commitCustomRange(selStart, selEnd);
        closeCustomPicker();
      }
    });
    pop.addEventListener('mouseover', (e) => {
      if (dayMode || !selStart || selEnd) return;
      const day = e.target.closest('.drp-day');
      const nd = (day && day.dataset.day && !day.disabled) ? isoToDate(day.dataset.day) : null;
      if ((nd ? ymdInt(nd) : 0) === (hoverD ? ymdInt(hoverD) : 0)) return;
      hoverD = nd;
      decorate();
    });
    pop.addEventListener('mouseleave', () => {
      if (selStart && !selEnd && hoverD) { hoverD = null; decorate(); }
    });

    // Swipe the calendar sideways to change month, like the iOS date picker.
    let swipeX = null, swipeY = 0;
    pop.addEventListener('touchstart', (e) => {
      if (!e.target.closest('.drp-cal') || e.touches.length !== 1) { swipeX = null; return; }
      swipeX = e.touches[0].clientX; swipeY = e.touches[0].clientY;
    }, { passive: true });
    pop.addEventListener('touchend', (e) => {
      if (swipeX == null) return;
      const t = e.changedTouches[0];
      const dx = t.clientX - swipeX, dy = t.clientY - swipeY;
      swipeX = null;
      if (Math.abs(dx) < 48 || Math.abs(dx) < Math.abs(dy) * 1.4) return;
      const forward = lang === 'ar' ? dx > 0 : dx < 0;
      shiftView(forward ? 1 : -1);
    }, { passive: true });

    render();
    if (dayMode && !asSheet) {
      // Drawers clip their scrollable bodies with contain:paint. Portal the
      // SAME calendar above them and anchor it to the shared pill.
      const rect = control.getBoundingClientRect();
      pop.style.position = 'fixed';
      pop.style.insetInlineEnd = 'auto';
      const anchorX = lang === 'ar' ? rect.right - pop.offsetWidth : rect.left;
      pop.style.left = Math.max(8, Math.min(anchorX, innerWidth - pop.offsetWidth - 8)) + 'px';
      pop.style.top = Math.max(8, Math.min(rect.bottom + 10, innerHeight - pop.offsetHeight - 8)) + 'px';
    }
    requestAnimationFrame(() => requestAnimationFrame(() => {
      if (dpEl === pop) pop.classList.add('open');
    }));

    dpOutside = (e) => {
      if (pop.contains(e.target)) return;
      if (control.contains(e.target)) return;   // the control's own click toggles
      closeCustomPicker();
    };
    dpKey = (e) => {
      if (e.key === 'Escape') { e.preventDefault(); closeCustomPicker(); return; }
      if (!asSheet || e.key !== 'Tab') return;
      const buttons = [...pop.querySelectorAll('button:not([disabled])')];
      const first = buttons[0], last = buttons[buttons.length - 1];
      if (e.shiftKey && (document.activeElement === first || !pop.contains(document.activeElement))) {
        e.preventDefault(); last?.focus({preventScroll:true});
      } else if (!e.shiftKey && (document.activeElement === last || !pop.contains(document.activeElement))) {
        e.preventDefault(); first?.focus({preventScroll:true});
      }
    };
    setTimeout(() => {
      if (dpEl !== pop) return;
      document.addEventListener('mousedown', dpOutside);
      document.addEventListener('keydown', dpKey);
    }, 0);

    const pill = control.querySelector('.dr-pill-custom');
    if (pill) pill.setAttribute('aria-expanded', 'true');
  }

  /* A business-day version of the SAME control and two-month calendar used on
   * Accueil. Rapport journalier and restaurant Commandes supply only their
   * relative-day choices; neither owns another native date input or picker. */
  function mountDaySelector(host, options = {}) {
    if (!host) return;
    const report = window.KiwiDayReport;
    const today = report?.today?.(options.merchant) || dateToIso(new Date());
    const shift = (n) => report?.shiftDay?.(today, -n, options.merchant) || dateToIso(addDays(isoToDate(today), -n));
    const chosen = isoToDate(options.value) ? options.value : today;
    const offsets = options.offsets || [0, 1];
    const lang = getLang();
    const labels = {
      fr: ["Aujourd'hui", 'Hier', 'Avant-hier', 'Choisir une date'],
      en: ['Today', 'Yesterday', 'Day before yesterday', 'Pick a date'],
      ar: ['اليوم', 'أمس', 'أول أمس', 'اختر تاريخاً'],
    }[lang] || ["Aujourd'hui", 'Hier', 'Avant-hier', 'Choisir une date'];
    const relative = offsets.find(n => shift(n) === chosen);
    const custom = relative == null;
    const customLabel = custom ? new (globalThis.KiwiZoneLaw?.DateTimeFormat || Intl.DateTimeFormat)(lang === 'ar' ? 'ar-MA' : lang,
      { day: 'numeric', month: 'short', year: 'numeric' }).format(isoToDate(chosen)) : labels[3];
    host.innerHTML = `<div class="dr-control dr-day-control"><div class="dr-pills" role="group" aria-label="${dpEsc(options.ariaLabel || labels[3])}">`
      + offsets.map(n => `<button type="button" class="dr-pill${relative === n ? ' on' : ''}" data-dr-day-offset="${n}" aria-pressed="${relative === n}">${dpEsc(labels[n])}</button>`).join('')
      + `<button type="button" class="dr-pill dr-pill-custom${custom ? ' on' : ''}" data-dr-day-custom aria-pressed="${custom}" aria-haspopup="dialog" aria-expanded="false">`
      + `<span class="dr-icon dr-icon-calendar" aria-hidden="true"></span>${dpEsc(customLabel)}</button></div></div>`;
    const control = host.querySelector('.dr-control');
    requestAnimationFrame(() => { const selected = control.querySelector('.dr-pill.on'); if (selected) revealDayPill(selected); });
    host.querySelectorAll('[data-dr-day-offset]').forEach(button => {
      button.addEventListener('click', () => options.onChange?.(shift(+button.dataset.drDayOffset)));
    });
    host.querySelector('[data-dr-day-custom]').addEventListener('click', () => openCustomPicker({
      mode: 'day', control, selected: chosen, maxDay: today, onApply: day => options.onChange?.(day),
    }));
    window.KiwiLens?.rescan?.();
  }

  function registerHandler() {
    const tryReg = () => {
      if (window.Kiwi?.handlers) {
        window.Kiwi.handlers['date-range'] = onAction;
        window.Kiwi.handlers['open-date-picker'] = openCustomPicker;
        window.Kiwi.handlers['rev-compare'] = onCompareToggle;
        window.Kiwi.handlers['customize-kpi'] = openKpiCustomizer;
        window.Kiwi.handlers['hero-toggle-chart'] = () => {
          const hero = document.querySelector('.hero-today');
          if (!hero) return;
          const toChart = !hero.classList.contains('chart-view');
          hero.classList.toggle('chart-view', toChart);
          const btn = hero.querySelector('.hero-view-toggle');
          if (btn) btn.setAttribute('aria-pressed', String(toChart));
          try { localStorage.setItem('kiwiHeroView', toChart ? 'chart' : 'today'); } catch (_) {}
          if (toChart) {
            // Pane was display:none — SVG had no measurable width. Reset the
            // render cache so the chart re-measures and replays its draw-in.
            const svg = document.querySelector('[data-rev-svg]');
            if (svg) { svg.dataset.lastW = '0'; svg.dataset.lastRange = ''; }
            renderRevChart();
          }
        };
        window.Kiwi.handlers['hh-ai-glovo'] = () => {
          const gl = GLOVO_TOAST[getLang()] || GLOVO_TOAST.fr;
          window.Kiwi?.toast?.(gl.t, { type: 'info', desc: gl.d });
        };
        return;
      }
      setTimeout(tryReg, 30);
    };
    tryReg();
  }

  function restoreRange() {
    let stored = null;
    try { stored = localStorage.getItem(STORAGE_KEY); } catch (_) {}
    try { customRange = parseCustom(localStorage.getItem(CUSTOM_KEY)); } catch (_) {}
    currentRange = VALID.includes(stored) ? stored : DEFAULT_RANGE;
    // A stored 'personnalise' only stands if its date pair survived too.
    if (currentRange === 'personnalise' && !customRange) currentRange = DEFAULT_RANGE;
  }

  function init() {
    if (!/dashboard(?:\.html)?(?:$|\/)/.test(location.pathname)) return;
    restoreRange();
    try { showComparison = localStorage.getItem(CMP_KEY) === '1'; } catch (_) {}

    // Own the custom-picker trigger at capture phase. The shared action router is
    // intentionally extensible and can be registered or wrapped by later bundles;
    // this control must still open even if that registry is temporarily unavailable.
    document.addEventListener('click', (event) => {
      const trigger = event.target.closest?.('.dr-pill-custom[data-action="open-date-picker"]');
      if (!trigger) return;
      event.preventDefault();
      event.stopPropagation();
      openCustomPicker();
    }, true);

    registerHandler();
    hookI18n();

    // Restore persisted hero view (today ⇄ chart). Applied before the first
    // renderRevChart() so the chart pane is visible and measures real width.
    try {
      if (localStorage.getItem('kiwiHeroView') === 'chart') {
        const hero = document.querySelector('.hero-today');
        if (hero) {
          hero.classList.add('chart-view');
          const btn = hero.querySelector('.hero-view-toggle');
          if (btn) btn.setAttribute('aria-pressed', 'true');
        }
      }
    } catch (_) {}

    // Reflect persisted compare state into the toggle button on first paint
    queueMicrotask(() => {
      const btn = document.querySelector('[data-rev-compare-btn]');
      if (btn) {
        btn.classList.toggle('on', showComparison);
        btn.setAttribute('aria-pressed', String(showComparison));
      }
    });

    subscribe(renderHero);
    subscribe(renderHeroAi);
    subscribe(renderGoal);
    subscribe(renderHeatmap);
    subscribe(renderHeatmapAi);
    subscribe(renderKpiBand);
    subscribe(renderRevChart);
    subscribe(renderMix);
    subscribe(renderFeed);
    subscribe(renderSettle);
    subscribe(renderEvening);
    subscribe(renderStock);
    subscribe(renderTimeline);
    subscribe(renderHealth);
    subscribe(renderBench);
    subscribe(renderInteg);
    subscribe(renderNotifBadge);
    subscribe(renderProducts);
    subscribe(renderStaff);

    // Re-fire all renders when the UI language changes, so dynamically-rendered
    // copy (feed title/subtitle and other non-data-i18n strings) re-translates
    // immediately — not only on the next date-range switch.
    window.addEventListener('kiwi:langchange', () => {
      subscribers.forEach(fn => { try { fn(currentRange); } catch (_) {} });
    });

    // Subscribe to venue changes — refire all renders so dashboard
    // reskins when user picks a different venue from the sidebar.
    const subVenue = () => {
      if (window.KiwiVenue?.subscribe) {
        window.KiwiVenue.subscribe(() => {
          renderHero();
          renderHeroAi();
          renderGoal();
          renderHeatmap();
          renderHeatmapAi();
          renderKpiBand();
          renderRevChart();
          renderMix();
          renderFeed();
          renderSettle();
          renderEvening();
          renderStock();
          renderTimeline();
          renderHealth();
          renderBench();
          renderInteg();
          renderNotifBadge();
          renderProducts();
          renderStaff();
        });
        return;
      }
      setTimeout(subVenue, 30);
    };
    subVenue();

    // Subscribe to the demo clock — every 3 seconds the "today" data ticks
    // forward (revenue/tx/tips count up); at the top of every real hour the
    // sim restarts at 11h with 0 MAD. Only re-renders if currently viewing
    // the live "aujourdhui" range.
    const subDemo = () => {
      if (window.KiwiDemoClock?.subscribe) {
        window.KiwiDemoClock.subscribe((state, isReset) => {
          const eff = effRange();
          if (eff !== 'aujourdhui') return;
          liveTickInProgress = true;
          demoRenderSim = state;
          try {
            renderHero();
            renderGoal();
            renderKpiBand();
            renderRevChart();
            renderHeatmap();
            renderFeed();
          } finally {
            liveTickInProgress = false;
            demoRenderSim = null;
          }
        });
        return;
      }
      setTimeout(subDemo, 30);
    };
    subDemo();

    // Subscribe to the sales store — when a sale is rung on a user-created venue,
    // whether on this device's keypad or on a till across the room (Live Link
    // bridges those into the same store), every surface that reads it recomputes
    // live. The revenue chart is in that list: it buckets the same KiwiSales rows
    // (see renderRevChart), so leaving it out meant the hero moved on a new sale
    // and the graph underneath it stayed on the last reload's shape.
    const subSales = () => {
      if (window.KiwiSales?.subscribe) {
        window.KiwiSales.subscribe(() => {
          renderHero();
          renderHeroAi();
          renderGoal();
          renderKpiBand();
          renderRevChart();
          renderHeatmap();
          renderHeatmapAi();
          renderFeed();
          renderMix();   // la ventilation par mode de paiement bouge avec chaque vente
          renderProducts();
        });
        /* Une livraison listée ou reçue change les créances, sans vente nouvelle. */
        window.addEventListener('kiwi:deliveries', () => { renderKpiBand(); renderHero(); });
        return;
      }
      setTimeout(subSales, 30);
    };
    subSales();
    window.KiwiSalesSummary?.subscribe(() => {
      subscribers.forEach(fn => { try { fn(currentRange); } catch (_) {} });
    });
    /* « Pourboires » lit les journées closes du classeur, qui arrive du
     * serveur après le premier rendu (et à chaque clôture d'une autre caisse) :
     * la bande se repeint quand il change. day-report.js est chargé en différé. */
    const subDayReports = (tries = 0) => {
      if (window.KiwiDayReport?.subscribe) { window.KiwiDayReport.subscribe(() => { try { renderKpiBand(); } catch (_) {} }); return; }
      if (tries < 200) setTimeout(() => subDayReports(tries + 1), 80);
    };
    subDayReports();
    /* Réguliers, fidélité et nouveaux clients lisent le carnet clients, qui
     * se synchronise après le premier rendu et bouge à chaque vente rattachée. */
    const subClientBook = (tries = 0) => {
      if (window.KiwiClients?.subscribe) { window.KiwiClients.subscribe(() => { try { renderKpiBand(); } catch (_) {} }); return; }
      if (tries < 200) setTimeout(() => subClientBook(tries + 1), 80);
    };
    subClientBook();

    /* Operational cards repaint from their own domain stores. Previously they
     * only refreshed after a page reload, which made a truthful source look
     * stale immediately after a booking or stock count. */
    window.addEventListener('kiwi-reservations-changed', renderEvening);
    window.addEventListener('kiwi-reservations-ready', renderEvening);
    window.addEventListener('kiwi-stock-changed', renderStock);
    window.addEventListener('kiwi-stock-ready', renderStock);
    const subInventory = () => {
      if (window.KiwiInventory?.subscribe) window.KiwiInventory.subscribe(() => renderStock());
      else setTimeout(subInventory, 80);
    };
    subInventory();
    const subCatalog = () => {
      if (window.KiwiBoutiqueCatalog?.subscribe) {
        window.KiwiBoutiqueCatalog.subscribe(() => { renderStock(); renderProducts(); });
      } else setTimeout(subCatalog, 80);
    };
    subCatalog();

    /* day-report.js loads later because it depends on CloudDoc. Until it
     * publishes the venue's business-day cutoff, midnight is only a temporary
     * fallback. Repaint every time-sensitive card when that cutoff arrives. */
    window.addEventListener('kiwi-day-report-ready', () => {
      renderHero(); renderHeroAi(); renderGoal(); renderKpiBand();
      renderRevChart(); renderHeatmap(); renderHeatmapAi(); renderMix();
      renderFeed(); renderEvening(); renderProducts();
    });
    document.addEventListener('kiwi-config', () => renderMix());

    // Re-fit hero amount + re-flow chart on viewport resize
    let resizeTimer = null;
    window.addEventListener('resize', () => {
      clearTimeout(resizeTimer);
      resizeTimer = setTimeout(() => {
        const amtEl = document.querySelector('[data-hero-amount]');
        if (amtEl) {
          const eff = effRange();
          const data = vData(heroDataByVenue, eff);
          if (data) fitHeroAmount(amtEl, data.amount);
        }
        // Re-render chart at the new pixel width — no entrance animation
        // because lastRange matches and lastW differs (handled by .no-anim flag).
        renderRevChart();
      }, 140);
    });

    renderSelector();
    renderHero();
    renderHeroAi();
    renderGoal();
    renderHeatmap();
    renderHeatmapAi();
    renderKpiBand();
    renderRevChart();
    renderMix();
    renderFeed();
    renderSettle();
    renderEvening();
    renderStock();
    renderTimeline();
    renderHealth();
    renderBench();
    renderInteg();
    renderNotifBadge();
    renderProducts();
    renderStaff();
  }

  /* Publish before init. The truth reader remains available even if an optional
   * dashboard renderer fails during first paint. */
  window.KiwiDateRange = {
    getDateRange, setDateRange, subscribe, tickLiveRevenue,
    kpiComparisonLabel: () => KPI_DELTA_SUFFIX[getLang()]?.[currentRange] || KPI_DELTA_SUFFIX.fr[currentRange],
    mountDaySelector: mountDaySelector,
    selectedBusinessDay: (range = currentRange) => {
      // Same civil timezone/cutoff as functions/api/_business-day.js, including
      // boutiques. This reference must not inherit a midnight chart cutoff.
      const parts = Object.fromEntries(new (globalThis.KiwiZoneLaw?.DateTimeFormat || Intl.DateTimeFormat)('en-CA', {
        timeZone:merchantTimeZone(activeMerchantSlug()),year:'numeric',month:'2-digit',day:'2-digit',hour:'2-digit',hourCycle:'h23'
      }).formatToParts(new Date()).map(p => [p.type,p.value]));
      const civil = `${parts.year}-${parts.month}-${parts.day}`;
      const today = +parts.hour < 5 ? addMerchantDays(civil,-1) : civil;
      if (range === 'aujourdhui') return today;
      if (range === 'hier') return addMerchantDays(today,-1);
      return range === 'personnalise' && customRange && dateToIso(customRange.start) === dateToIso(customRange.end)
        ? dateToIso(customRange.start) : null;
    },
    getShowComparison, setShowComparison,
    bounds: (range) => rangeBounds(range == null ? currentRange : range),
    /* Le carnet clients d'un vrai établissement sur la plage : { visitors, regulars,
       newcomers }. La carte « Clients réguliers » le lit ici, qu'il y ait ou non
       une tuile « réguliers » dans la bande (la boutique n'en a pas). */
    clientMix: (range) => {
      if (!ownData()) return null;
      const [from, to] = closedBounds(range == null ? currentRange : range);
      return realClientMix(from, to);
    },
    /* L'accueil du kit (étape 5) : ce que les rendus viennent de dessiner. */
    home: () => Object.assign({ range: currentRange }, homeStore()),
    todayPace,
    insights: { summary: realInsightSummary, hero: buildRealHeroRec, heatmap: buildRealHeatmapRec },
    _truth: { tenderBucket, realMixRows, realTopProducts, realLowStock, realInsightSummary, buildRealHeroRec, buildRealHeatmapRec },
  };

  function startDashboardRendering() {
    if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', init, { once: true });
    else init();
  }
  window.addEventListener('kiwi:z-reference', () => { renderHero(); });
  document.addEventListener('kiwi:operator-snapshot', () => {
    renderHero(); renderGoal(); renderKpiBand(); renderRevChart();
  });
  /* Les dépôts du pressing arrivent par le document pressing-orders, après le
     premier rendu : sans cet abonnement la tuile restait sur le journal des
     ventes jusqu'au prochain changement de période. */
  window.addEventListener('kiwi:pressing-ops', () => { try { renderKpiBand(); } catch (_) {} });
  /* Le titre et les pastilles ne lisent aucune donnée : ils se peignent
   * derrière l'écran de code, sur la période enregistrée et dans la langue de
   * l'écran. Ils attendaient le premier rendu complet, qui passe après le
   * message d'accueil : un commerçant en arabe lisait alors « Aujourd'hui »,
   * en français, sous la pastille « اليوم » allumée, alors que sa période
   * était « Mois dernier ». init() repeint ensuite, à l'identique. */
  function paintSelectorEarly() {
    if (!/dashboard(?:\.html)?(?:$|\/)/.test(location.pathname)) return;
    try { restoreRange(); renderSelector(); } catch (_) {}
  }
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', paintSelectorEarly, { once: true });
  else paintSelectorEarly();
  if (window.KiwiDashboardBoot?.whenUnlocked) window.KiwiDashboardBoot.whenUnlocked(startDashboardRendering);
  else startDashboardRendering();

  /* Ce fichier est `defer` : à son exécution readyState vaut déjà 'interactive',
   * donc init() part TOUT DE SUITE — avant pages-pro.js, chargé plus bas, qui
   * publie la clé du catalogue. Le premier rendu de la bande ne pouvait donc pas
   * résoudre les coûts et retombait sur la marge forfaitaire : le commerçant
   * voyait 729 MAD, puis 736 dès qu'il touchait une pastille de période. On
   * rejoue la bande une fois, quand la clé est publiée. */
  window.addEventListener('kiwi-catalog-key', () => {
    try { renderKpiBand(); } catch (_) {}
    try { renderProducts(); } catch (_) {}
    try { renderStock(); } catch (_) {}
  }, { once: true });

  /* Même problème pour l'équipe : team.js est chargé après pages-pro.js, donc
   * encore plus tard. Il annonce son roster et la carte se repeint une fois. */
  window.addEventListener('kiwi-team-ready', () => {
    try { renderStaff(); } catch (_) {}
  }, { once: true });

  /* Et à CHAQUE changement de roster ou d'heures — pas une seule fois : on
   * saisit les heures sur Paie puis on revient à l'accueil, la carte doit déjà
   * le savoir. */
  window.addEventListener('kiwi-team-changed', () => {
    try { renderStaff(); } catch (_) {}
  });

  /* ─── Live tick API · called from polish.js when a new fake tx lands ─── */
  function tickLiveRevenue({ amount = 0, tip = 0 } = {}) {
    // Demo clock owns deterministic ticking on aujourdhui — skip random ticks.
    if (window.KiwiDemoClock?.isActive?.()) return;
    // Live ticks only make sense on "today" — skip on historical ranges.
    const r = effRange();
    if (r !== 'aujourdhui') return;
    // And only mutate the currently active venue's data (each venue has its own).
    const v = getCurrentVenue();
    const hero = heroDataByVenue[v]?.aujourdhui;
    const goal = goalByVenue[v]?.aujourdhui;
    const kpi  = kpiByVenue[v]?.aujourdhui;
    if (!hero || !goal || !kpi) return;

    hero.amount += amount;
    goal.current = hero.amount;
    // Keep "Net après Kiwi" roughly proportional (~83.9 % after commission)
    hero.netAfterKiwi = Math.round(hero.amount * 0.839);

    // Bump KPI counters that the live tx affects
    if (kpi.tx)     kpi.tx.value += 1;
    if (kpi.tips)   kpi.tips.value += tip;
    if (kpi.panier && kpi.tx?.value > 0) {
      kpi.panier.value = Math.round(hero.amount / kpi.tx.value);
    }
    if (kpi.regulars) kpi.regulars.unit = `/ ${kpi.tx.value}`;

    // Re-render the affected blocks (each respects its own animation)
    renderHero();
    renderGoal();
    renderKpiBand();
  }

  /* `bounds` sort d'ici parce que la fenêtre « en ce moment » doit avoir UNE
   * définition, pas une par écran. Elle était privée, alors trois surfaces se
   * sont mises à compter sans fenêtre du tout : la pastille « Commandes » de la
   * barre latérale (venues.js), la page Ventes (pages-pro.js) et les lignes du
   * fil en direct (buildCustomFeed, plus haut) additionnaient TOUT l'historique
   * du navigateur pendant que la tuile « Commandes » — le même mot, à trente
   * centimètres — ne comptait que la période choisie. Au troisième jour d'un
   * vrai commerçant, la pastille disait 47 et la tuile 6. Aucune des deux ne
   * mentait ; elles ne répondaient simplement pas à la même question, et rien
   * à l'écran ne le disait.
   *
   * Exporter la fonction plutôt que recopier ses quatre lignes : une borne
   * recopiée est une borne qu'on corrigera à un seul endroit sur trois. */
})();
